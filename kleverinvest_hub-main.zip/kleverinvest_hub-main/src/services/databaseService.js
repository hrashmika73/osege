/**
 * Database Service Layer for KleverInvest Hub
 * Provides unified interface for all database operations
 */

import { getDatabase, databaseConfig } from '../config/database.js';

class DatabaseService {
  constructor() {
    this.db = null;
    this.config = databaseConfig;
    this.initialized = false;
  }

  // Initialize database service
  async initialize() {
    if (this.initialized) return this.db;
    
    try {
      this.db = await getDatabase();
      this.initialized = true;
      return this.db;
    } catch (error) {
      console.error('DatabaseService initialization failed:', error);
      throw error;
    }
  }

  // Generic query interface
  async query(table, operation, data = {}, options = {}) {
    await this.initialize();
    
    switch (this.config.type) {
      case 'supabase':
        return await this.supabaseQuery(table, operation, data, options);
      case 'postgresql':
      case 'mysql':
        return await this.sqlQuery(table, operation, data, options);
      case 'localStorage':
      default:
        return await this.localStorageQuery(table, operation, data, options);
    }
  }

  // Supabase query handler
  async supabaseQuery(table, operation, data, options) {
    const { client } = this.db;
    let query = client.from(table);

    try {
      switch (operation) {
        case 'select':
          if (options.select) query = query.select(options.select);
          if (options.where) {
            Object.entries(options.where).forEach(([key, value]) => {
              query = query.eq(key, value);
            });
          }
          if (options.orderBy) query = query.order(options.orderBy.column, { ascending: options.orderBy.ascending });
          if (options.limit) query = query.limit(options.limit);
          if (options.offset) query = query.range(options.offset, options.offset + (options.limit || 25) - 1);
          break;

        case 'insert':
          query = query.insert(data);
          if (options.returning !== false) query = query.select();
          break;

        case 'update':
          if (options.where) {
            Object.entries(options.where).forEach(([key, value]) => {
              query = query.eq(key, value);
            });
          }
          query = query.update(data);
          if (options.returning !== false) query = query.select();
          break;

        case 'delete':
          if (options.where) {
            Object.entries(options.where).forEach(([key, value]) => {
              query = query.eq(key, value);
            });
          }
          query = query.delete();
          break;

        case 'upsert':
          query = query.upsert(data);
          if (options.returning !== false) query = query.select();
          break;

        default:
          throw new Error(`Unsupported operation: ${operation}`);
      }

      const { data: result, error } = await query;
      
      if (error) {
        console.error(`Supabase ${operation} error:`, error);
        throw error;
      }

      return { success: true, data: result, count: result?.length };

    } catch (error) {
      console.error(`Supabase query error:`, error);
      return { success: false, error: error.message };
    }
  }

  // SQL query handler (via API)
  async sqlQuery(table, operation, data, options) {
    try {
      // Check if API is available
      if (!this.config.apiUrl || this.config.apiUrl === '/api') {
        console.warn('🔄 API not configured, falling back to localStorage');
        return await this.localStorageQuery(table, operation, data, options);
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);

      const response = await fetch(`${this.config.apiUrl}/database/query`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          table,
          operation,
          data,
          options,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Database query failed');
      }

      return result;

    } catch (error) {
      console.warn(`📡 SQL API unavailable (${error.message}), falling back to localStorage`);

      // Fallback to localStorage if API fails
      return await this.localStorageQuery(table, operation, data, options);
    }
  }

  // localStorage query handler
  async localStorageQuery(table, operation, data, options) {
    try {
      const storageKey = `${this.config.config.prefix}${table}`;
      let tableData = JSON.parse(localStorage.getItem(storageKey) || '[]');

      switch (operation) {
        case 'select':
          let result = [...tableData];
          
          // Apply where conditions
          if (options.where) {
            result = result.filter(item => {
              return Object.entries(options.where).every(([key, value]) => {
                return item[key] === value;
              });
            });
          }
          
          // Apply ordering
          if (options.orderBy) {
            result.sort((a, b) => {
              const aVal = a[options.orderBy.column];
              const bVal = b[options.orderBy.column];
              const comparison = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
              return options.orderBy.ascending ? comparison : -comparison;
            });
          }
          
          // Apply pagination
          if (options.offset || options.limit) {
            const start = options.offset || 0;
            const end = start + (options.limit || result.length);
            result = result.slice(start, end);
          }
          
          return { success: true, data: result, count: result.length };

        case 'insert':
          const newItem = {
            id: data.id || `${table}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            ...data,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          };
          
          tableData.push(newItem);
          localStorage.setItem(storageKey, JSON.stringify(tableData));
          
          return { success: true, data: [newItem], count: 1 };

        case 'update':
          let updated = false;
          const updatedData = tableData.map(item => {
            const matches = options.where ? 
              Object.entries(options.where).every(([key, value]) => item[key] === value) :
              false;
            
            if (matches) {
              updated = true;
              return {
                ...item,
                ...data,
                updated_at: new Date().toISOString(),
              };
            }
            return item;
          });
          
          if (updated) {
            localStorage.setItem(storageKey, JSON.stringify(updatedData));
            const updatedItems = updatedData.filter(item => {
              return options.where ? 
                Object.entries(options.where).every(([key, value]) => item[key] === value) :
                false;
            });
            return { success: true, data: updatedItems, count: updatedItems.length };
          }
          
          return { success: true, data: [], count: 0 };

        case 'delete':
          const originalLength = tableData.length;
          const filteredData = tableData.filter(item => {
            return options.where ? 
              !Object.entries(options.where).every(([key, value]) => item[key] === value) :
              true;
          });
          
          localStorage.setItem(storageKey, JSON.stringify(filteredData));
          const deletedCount = originalLength - filteredData.length;
          
          return { success: true, data: [], count: deletedCount };

        case 'upsert':
          const existingIndex = tableData.findIndex(item => 
            options.conflictKeys ? 
              options.conflictKeys.every(key => item[key] === data[key]) :
              item.id === data.id
          );
          
          if (existingIndex >= 0) {
            // Update existing
            tableData[existingIndex] = {
              ...tableData[existingIndex],
              ...data,
              updated_at: new Date().toISOString(),
            };
          } else {
            // Insert new
            const newItem = {
              id: data.id || `${table}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              ...data,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            };
            tableData.push(newItem);
          }
          
          localStorage.setItem(storageKey, JSON.stringify(tableData));
          
          return { success: true, data: [tableData[existingIndex] || tableData[tableData.length - 1]], count: 1 };

        default:
          throw new Error(`Unsupported operation: ${operation}`);
      }

    } catch (error) {
      console.error(`localStorage query error:`, error);
      return { success: false, error: error.message };
    }
  }

  // Transaction support
  async transaction(operations) {
    await this.initialize();
    
    switch (this.config.type) {
      case 'supabase':
        return await this.supabaseTransaction(operations);
      case 'postgresql':
      case 'mysql':
        return await this.sqlTransaction(operations);
      case 'localStorage':
      default:
        return await this.localStorageTransaction(operations);
    }
  }

  // Supabase transaction
  async supabaseTransaction(operations) {
    // Supabase doesn't have explicit transactions in the client
    // We'll execute operations sequentially and rollback on error
    const results = [];
    const rollbackOperations = [];

    try {
      for (const op of operations) {
        const result = await this.query(op.table, op.operation, op.data, op.options);
        if (!result.success) {
          throw new Error(`Transaction failed at operation: ${op.operation} on ${op.table}`);
        }
        results.push(result);
        
        // Prepare rollback operation
        if (op.operation === 'insert' && result.data?.[0]?.id) {
          rollbackOperations.unshift({
            table: op.table,
            operation: 'delete',
            options: { where: { id: result.data[0].id } }
          });
        }
      }

      return { success: true, data: results };

    } catch (error) {
      // Attempt rollback
      console.warn('Transaction failed, attempting rollback...');
      for (const rollbackOp of rollbackOperations) {
        try {
          await this.query(rollbackOp.table, rollbackOp.operation, rollbackOp.data, rollbackOp.options);
        } catch (rollbackError) {
          console.error('Rollback failed:', rollbackError);
        }
      }

      return { success: false, error: error.message };
    }
  }

  // SQL transaction via API
  async sqlTransaction(operations) {
    try {
      // Check if API is available
      if (!this.config.apiUrl || this.config.apiUrl === '/api') {
        console.warn('🔄 API not configured, falling back to localStorage transaction');
        return await this.localStorageTransaction(operations);
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(`${this.config.apiUrl}/database/transaction`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ operations }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Transaction failed');
      }

      return result;

    } catch (error) {
      console.warn(`📡 SQL API transaction unavailable (${error.message}), falling back to localStorage`);

      // Fallback to localStorage transaction if API fails
      return await this.localStorageTransaction(operations);
    }
  }

  // localStorage transaction
  async localStorageTransaction(operations) {
    // Create backup of all affected tables
    const backups = {};
    const affectedTables = [...new Set(operations.map(op => op.table))];
    
    try {
      // Create backups
      for (const table of affectedTables) {
        const storageKey = `${this.config.config.prefix}${table}`;
        backups[table] = localStorage.getItem(storageKey);
      }

      // Execute operations
      const results = [];
      for (const op of operations) {
        const result = await this.query(op.table, op.operation, op.data, op.options);
        if (!result.success) {
          throw new Error(`Transaction failed at operation: ${op.operation} on ${op.table}`);
        }
        results.push(result);
      }

      return { success: true, data: results };

    } catch (error) {
      // Restore from backups
      console.warn('Transaction failed, restoring from backup...');
      for (const [table, backup] of Object.entries(backups)) {
        const storageKey = `${this.config.config.prefix}${table}`;
        if (backup !== null) {
          localStorage.setItem(storageKey, backup);
        } else {
          localStorage.removeItem(storageKey);
        }
      }

      return { success: false, error: error.message };
    }
  }

  // Real-time subscriptions (Supabase only)
  subscribe(table, callback, options = {}) {
    if (this.config.type !== 'supabase') {
      console.warn('Real-time subscriptions only supported with Supabase');
      return null;
    }

    const { client } = this.db;
    
    let subscription = client
      .channel(`realtime-${table}`)
      .on('postgres_changes', 
        { 
          event: options.event || '*', 
          schema: options.schema || 'public', 
          table: table 
        }, 
        callback
      )
      .subscribe();

    return subscription;
  }

  // Unsubscribe from real-time updates
  unsubscribe(subscription) {
    if (subscription && this.config.type === 'supabase') {
      subscription.unsubscribe();
    }
  }
}

// Create singleton instance
const databaseService = new DatabaseService();

export default databaseService;

// Export specific methods for convenience
export const {
  initialize,
  query,
  transaction,
  subscribe,
  unsubscribe,
} = databaseService;
