/**
 * Builder.io API Service with Cache-Busting for Real-time Content Updates
 * Similar to PHP file_get_contents() with cache-busting parameters
 */

class BuilderApiService {
  constructor() {
    this.baseUrl = 'https://builder.io/api/v1';
    this.apiKey = import.meta.env.VITE_BUILDER_API_KEY;
    this.publicKey = import.meta.env.VITE_BUILDER_PUBLIC_KEY;
    this.cache = new Map();
    this.cacheTTL = 5 * 60 * 1000; // 5 minutes default cache
  }

  /**
   * Fetch latest content with cache-busting
   * Similar to PHP approach but for React frontend
   */
  async getContent(modelName, options = {}) {
    const {
      cacheBust = true,
      forceRefresh = false,
      ttl = this.cacheTTL,
      url = window.location.pathname,
      query = {}
    } = options;

    // Generate cache key
    const cacheKey = this.generateCacheKey(modelName, url, query);

    // Check cache first (unless force refresh)
    if (!forceRefresh && this.cache.has(cacheKey)) {
      const cached = this.cache.get(cacheKey);
      if (Date.now() - cached.timestamp < ttl) {
        return cached.data;
      }
    }

    try {
      // Build API URL with cache-busting parameters
      const apiUrl = this.buildApiUrl(modelName, url, query, cacheBust);
      
      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
          // Add cache-control headers
          'Cache-Control': cacheBust ? 'no-cache, no-store, must-revalidate' : 'public, max-age=300',
          'Pragma': cacheBust ? 'no-cache' : 'cache',
          'Expires': cacheBust ? '0' : new Date(Date.now() + 300000).toUTCString()
        }
      });

      if (!response.ok) {
        throw new Error(`Builder.io API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      // Cache the result
      this.cache.set(cacheKey, {
        data,
        timestamp: Date.now()
      });

      return data;
    } catch (error) {
      console.error('Builder.io API fetch error:', error);
      
      // Return cached data if available during error
      if (this.cache.has(cacheKey)) {
        console.warn('Returning cached data due to API error');
        return this.cache.get(cacheKey).data;
      }
      
      throw error;
    }
  }

  /**
   * Build API URL with cache-busting parameters
   * Equivalent to PHP's cache-busting query parameters
   */
  buildApiUrl(modelName, url, query, cacheBust) {
    const params = new URLSearchParams({
      'apiKey': this.publicKey,
      'url': url,
      'format': 'json',
      'cachebust': cacheBust ? Date.now().toString() : '',
      'preview': 'false',
      'includeRefs': 'true',
      ...query
    });

    // Remove empty parameters
    for (const [key, value] of params.entries()) {
      if (!value) {
        params.delete(key);
      }
    }

    return `${this.baseUrl}/content/${modelName}?${params.toString()}`;
  }

  /**
   * Generate cache key for content
   */
  generateCacheKey(modelName, url, query) {
    const queryString = JSON.stringify(query);
    return `${modelName}-${url}-${btoa(queryString)}`;
  }

  /**
   * Clear all cached content (for admin changes)
   */
  clearCache() {
    this.cache.clear();
  }

  /**
   * Clear specific model cache
   */
  clearModelCache(modelName) {
    for (const [key] of this.cache.entries()) {
      if (key.startsWith(modelName + '-')) {
        this.cache.delete(key);
      }
    }
  }

  /**
   * Subscribe to real-time updates via WebSocket
   * Similar to polling but more efficient
   */
  subscribeToUpdates(modelName, callback) {
    const ws = new WebSocket(`wss://builder.io/api/v1/socket`);
    
    ws.onopen = () => {
      ws.send(JSON.stringify({
        type: 'subscribe',
        model: modelName,
        apiKey: this.publicKey
      }));
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'content-updated' && data.model === modelName) {
        // Clear cache for this model
        this.clearModelCache(modelName);
        // Notify callback
        callback(data);
      }
    };

    return () => ws.close();
  }

  /**
   * Force refresh content (bypass all caches)
   * Equivalent to PHP's file_get_contents with cache-busting
   */
  async forceRefreshContent(modelName, url = window.location.pathname) {
    return this.getContent(modelName, {
      forceRefresh: true,
      cacheBust: true,
      url
    });
  }

  /**
   * Preload content for faster subsequent loads
   */
  async preloadContent(models = []) {
    const promises = models.map(model => 
      this.getContent(model, { cacheBust: false })
    );
    
    try {
      await Promise.all(promises);
      console.log('Content preloaded successfully');
    } catch (error) {
      console.error('Content preload error:', error);
    }
  }
}

// Export singleton instance
export const builderApiService = new BuilderApiService();
export default builderApiService;
