/**
 * Admin Backend API Service
 * Handles all admin-related API calls with fallback to mock data
 */

import axios from 'axios';

// API Configuration
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';
const ENABLE_BACKEND = import.meta.env.VITE_ENABLE_BACKEND === 'true';

// Create admin API instance
const adminApi = axios.create({
  baseURL: `${API_BASE_URL}/admin`,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor for admin auth token
adminApi.interceptors.request.use(
  (config) => {
    const adminToken = localStorage.getItem('adminToken');
    if (adminToken) {
      config.headers.Authorization = `Bearer ${adminToken}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Add response interceptor for admin error handling
adminApi.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Handle admin unauthorized access
      localStorage.removeItem('adminToken');
      localStorage.removeItem('adminData');
      window.location.href = '/admin-secure-login';
    }
    return Promise.reject(error);
  }
);

// Production admin credentials should be configured via environment variables or database

// Mock user data removed for production

// Helper function to simulate API delay
const simulateDelay = (ms = 800) => new Promise(resolve => setTimeout(resolve, ms));

// Helper function to get real user data from localStorage
const getRealUserData = () => {
  try {
    // Get users from localStorage (production mode - no mock data)
    const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
    return adminUsers;
  } catch (error) {
    console.warn('Error reading user data from localStorage:', error);
    return [];
  }
};

// Helper function to get real KYC data from localStorage
const getRealKycData = () => {
  try {
    const kycRequests = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
    return kycRequests;
  } catch (error) {
    console.warn('Error reading KYC data from localStorage:', error);
    return [];
  }
};

// Helper function to handle API errors and fallback with connection management
const handleApiCall = async (apiCall, fallbackData) => {
  // Production mode: prioritize backend API over localStorage
  if (ENABLE_BACKEND) {
    try {
      const response = await apiCall();

      // If backend responds, sync the data to localStorage for caching
      if (response?.data) {
        await syncToLocalStorage(response.data);
      }

      return {
        success: true,
        data: response.data,
        mockMode: false,
        source: 'backend_api'
      };
    } catch (error) {
      console.error('Backend API call failed:', error.message);

      // In production, if backend fails, try localStorage as emergency fallback
      const realData = getRealUserData();

      return {
        success: false,
        error: error.message,
        data: realData,
        mockMode: true,
        fallbackReason: error.message,
        source: 'localStorage_emergency_fallback'
      };
    }
  } else {
    // Development mode: use localStorage
    const realData = getRealUserData();
    await simulateDelay();

    return {
      success: true,
      data: realData,
      mockMode: true,
      source: 'localStorage_development'
    };
  }
};

// Helper function to sync backend data to localStorage
const syncToLocalStorage = async (backendData) => {
  try {
    if (backendData.users) {
      localStorage.setItem('admin_users_data', JSON.stringify(backendData.users));
    }
    if (backendData.transactions) {
      localStorage.setItem('admin_transactions', JSON.stringify(backendData.transactions));
    }
    if (backendData.kycRequests) {
      localStorage.setItem('admin_pending_kyc', JSON.stringify(backendData.kycRequests));
    }
  } catch (error) {
    console.warn('Failed to sync backend data to localStorage:', error);
  }
};

// Helper function to refresh localStorage data
const refreshLocalStorageData = async () => {
  try {
    // Clear and refresh localStorage data directly
    const keysToRefresh = [
      'admin_users_data',
      'admin_pending_kyc',
      'user_session_data'
    ];

    keysToRefresh.forEach(key => {
      try {
        const data = localStorage.getItem(key);
        if (data) {
          const parsed = JSON.parse(data);
          localStorage.setItem(key, JSON.stringify(parsed));
        }
      } catch (error) {
        console.warn(`Error refreshing ${key}:`, error);
        localStorage.removeItem(key);
      }
    });
  } catch (error) {
    console.warn('Failed to refresh localStorage data:', error);
  }
};

// Admin Authentication API
export const adminAuthAPI = {
  // Admin login
  login: async (credentials) => {
    return handleApiCall(
      () => adminApi.post('/auth/login', credentials),
      (() => {
        // Mock login logic
        const admin = mockAdminUsers.find(u =>
          (u.email === credentials.email || u.username === credentials.username) &&
          u.password === credentials.password
        );

        if (admin) {
          const token = `mock_admin_token_${admin.id}_${Date.now()}`;
          return {
            token,
            admin: { ...admin, password: undefined },
            expiresIn: 28800 // 8 hours
          };
        } else {
          throw new Error('Invalid admin credentials');
        }
      })()
    );
  },

  // Admin logout
  logout: async () => {
    return handleApiCall(
      () => adminApi.post('/auth/logout'),
      { message: 'Logged out successfully' }
    );
  },

  // Verify admin token
  verifyToken: async (token) => {
    return handleApiCall(
      () => adminApi.post('/auth/verify', { token }),
      { valid: true, admin: mockAdminUsers[0] }
    );
  },

  // Get admin profile
  getProfile: async () => {
    return handleApiCall(
      () => adminApi.get('/auth/profile'),
      mockAdminUsers[0]
    );
  }
};

// Admin User Management API
export const adminUserAPI = {
  // Get all users
  getUsers: async (page = 1, limit = 50, filters = {}) => {
    return handleApiCall(
      () => adminApi.get('/users', { params: { page, limit, ...filters } }),
      (() => {
        const realUsers = getRealUserData();

        // Apply filters if provided
        let filteredUsers = realUsers;
        if (filters.status) {
          filteredUsers = filteredUsers.filter(u => u.status === filters.status);
        }
        if (filters.kycStatus) {
          filteredUsers = filteredUsers.filter(u => u.kycStatus === filters.kycStatus);
        }
        if (filters.search) {
          const searchTerm = filters.search.toLowerCase();
          filteredUsers = filteredUsers.filter(u =>
            u.fullName?.toLowerCase().includes(searchTerm) ||
            u.email?.toLowerCase().includes(searchTerm) ||
            u.username?.toLowerCase().includes(searchTerm)
          );
        }

        // Apply pagination
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit;
        const paginatedUsers = filteredUsers.slice(startIndex, endIndex);

        return {
          users: paginatedUsers,
          pagination: {
            page,
            limit,
            total: filteredUsers.length,
            pages: Math.ceil(filteredUsers.length / limit)
          }
        };
      })()
    );
  },

  // Get user by ID
  getUser: async (userId) => {
    return handleApiCall(
      () => adminApi.get(`/users/${userId}`),
      (() => {
        const realUsers = getRealUserData();
        return realUsers.find(u => u.id.toString() === userId.toString()) || null;
      })()
    );
  },

  // Update user
  updateUser: async (userId, userData) => {
    return handleApiCall(
      () => adminApi.put(`/users/${userId}`, userData),
      (() => {
        try {
          const realUsers = getRealUserData();
          const userIndex = realUsers.findIndex(u => u.id.toString() === userId.toString());

          if (userIndex !== -1) {
            // Update the user data
            realUsers[userIndex] = { ...realUsers[userIndex], ...userData };

            // Save back to localStorage
            localStorage.setItem('admin_users_data', JSON.stringify(realUsers));

            return realUsers[userIndex];
          } else {
            throw new Error('User not found');
          }
        } catch (error) {
          console.error('Error updating user:', error);
          throw error;
        }
      })()
    );
  },

  // Delete user
  deleteUser: async (userId) => {
    return handleApiCall(
      () => adminApi.delete(`/users/${userId}`),
      { message: 'User deleted successfully' }
    );
  },

  // Get user statistics
  getUserStats: async () => {
    return handleApiCall(
      () => adminApi.get('/users/stats'),
      (() => {
        const realUsers = getRealUserData();
        const today = new Date().toISOString().split('T')[0];
        const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

        return {
          total: realUsers.length,
          active: realUsers.filter(u => u.status === 'active').length,
          inactive: realUsers.filter(u => u.status === 'inactive' || u.status === 'banned').length,
          verified: realUsers.filter(u => u.kycStatus === 'verified').length,
          pending: realUsers.filter(u => u.kycStatus === 'pending' || u.kycStatus === 'pending_documents').length,
          totalBalance: realUsers.reduce((sum, u) => sum + (u.balance || 0), 0),
          newToday: realUsers.filter(u => u.registrationDate && u.registrationDate.startsWith(today)).length,
          newThisWeek: realUsers.filter(u => u.registrationDate && u.registrationDate >= oneWeekAgo).length
        };
      })()
    );
  }
};

// Admin System API
export const adminSystemAPI = {
  // Get system health
  getSystemHealth: async () => {
    return handleApiCall(
      () => adminApi.get('/system/health'),
      {
        status: 'healthy',
        uptime: '2d 14h 30m',
        version: '1.0.0',
        database: { status: 'connected', latency: '12ms' },
        cache: { status: 'connected', memory: '45%' },
        lastCheck: new Date().toISOString()
      }
    );
  },

  // Get system logs
  getLogs: async (level = 'all', limit = 100) => {
    return handleApiCall(
      () => adminApi.get('/system/logs', { params: { level, limit } }),
      [
        {
          id: 1,
          level: 'info',
          message: 'Admin login successful',
          timestamp: new Date().toISOString(),
          module: 'auth'
        },
        {
          id: 2,
          level: 'warning',
          message: 'Failed login attempt detected',
          timestamp: new Date(Date.now() - 300000).toISOString(),
          module: 'security'
        }
      ]
    );
  },

  // Get system metrics
  getMetrics: async () => {
    return handleApiCall(
      () => adminApi.get('/system/metrics'),
      {
        cpu: Math.random() * 100,
        memory: Math.random() * 100,
        disk: Math.random() * 100,
        network: {
          incoming: Math.random() * 1000,
          outgoing: Math.random() * 1000
        },
        activeConnections: Math.floor(Math.random() * 50) + 10,
        requestsPerMinute: Math.floor(Math.random() * 200) + 50
      }
    );
  }
};

// Admin KYC API
export const adminKycAPI = {
  // Get all KYC requests
  getKycRequests: async (page = 1, limit = 50, filters = {}) => {
    return handleApiCall(
      () => adminApi.get('/kyc/requests', { params: { page, limit, ...filters } }),
      (() => {
        const kycRequests = getRealKycData();

        // Apply filters if provided
        let filteredRequests = kycRequests;
        if (filters.status) {
          filteredRequests = filteredRequests.filter(r => r.status === filters.status);
        }

        // Apply pagination
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit;
        const paginatedRequests = filteredRequests.slice(startIndex, endIndex);

        return {
          requests: paginatedRequests,
          pagination: {
            page,
            limit,
            total: filteredRequests.length,
            pages: Math.ceil(filteredRequests.length / limit)
          }
        };
      })()
    );
  },

  // Update KYC status
  updateKycStatus: async (requestId, status, notes = '') => {
    return handleApiCall(
      () => adminApi.put(`/kyc/requests/${requestId}`, { status, notes }),
      (() => {
        try {
          // Update KYC request
          const kycRequests = getRealKycData();
          const requestIndex = kycRequests.findIndex(r => r.id.toString() === requestId.toString());

          if (requestIndex !== -1) {
            kycRequests[requestIndex] = {
              ...kycRequests[requestIndex],
              status,
              reviewNotes: notes,
              reviewDate: new Date().toISOString()
            };
            localStorage.setItem('admin_pending_kyc', JSON.stringify(kycRequests));
          }

          // Update user's KYC status
          const realUsers = getRealUserData();
          const userIndex = realUsers.findIndex(u => u.userId === kycRequests[requestIndex]?.userId);

          if (userIndex !== -1) {
            realUsers[userIndex].kycStatus = status;
            localStorage.setItem('admin_users_data', JSON.stringify(realUsers));
          }

          return { message: 'KYC status updated successfully' };
        } catch (error) {
          console.error('Error updating KYC status:', error);
          throw error;
        }
      })()
    );
  }
};

// Admin Transaction API
export const adminTransactionAPI = {
  // Get all transactions
  getTransactions: async (page = 1, limit = 50, filters = {}) => {
    const mockTransactions = [
      {
        id: 'tx_001',
        userId: 1,
        type: 'deposit',
        amount: 1000,
        status: 'completed',
        currency: 'USD',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'tx_002',
        userId: 2,
        type: 'withdrawal',
        amount: 500,
        status: 'pending',
        currency: 'USD',
        createdAt: new Date(Date.now() - 3600000).toISOString(),
        updatedAt: new Date(Date.now() - 3600000).toISOString()
      }
    ];

    return handleApiCall(
      () => adminApi.get('/transactions', { params: { page, limit, ...filters } }),
      {
        transactions: mockTransactions,
        pagination: {
          page,
          limit,
          total: mockTransactions.length,
          pages: Math.ceil(mockTransactions.length / limit)
        }
      }
    );
  },

  // Update transaction status
  updateTransaction: async (transactionId, status) => {
    return handleApiCall(
      () => adminApi.put(`/transactions/${transactionId}/status`, { status }),
      { message: 'Transaction status updated successfully' }
    );
  }
};

// Connection test utility
export const testBackendConnection = async () => {
  try {
    console.log('🔗 Testing backend connection...');
    
    if (!ENABLE_BACKEND) {
      return {
        connected: false,
        mockMode: true,
        message: 'Backend disabled - using mock mode',
        status: 'mock'
      };
    }

    const response = await adminApi.get('/health');
    return {
      connected: true,
      mockMode: false,
      message: 'Backend connected successfully',
      status: 'connected',
      data: response.data
    };
  } catch (error) {
    console.warn('Backend connection failed:', error.message);
    return {
      connected: false,
      mockMode: true,
      message: `Backend connection failed: ${error.message}`,
      status: 'failed',
      error: error.message
    };
  }
};

export default {
  adminAuthAPI,
  adminUserAPI,
  adminKycAPI,
  adminSystemAPI,
  adminTransactionAPI,
  testBackendConnection
};
