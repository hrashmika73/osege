import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
// Add your imports here
import LandingPage from "pages/landing";
import HomeLandingPage from "pages/home-landing-page";
import AboutCompanyPage from "pages/about-company-page";
import WhyChooseKleverInvest from "pages/why-choose-klever-invest";
import InvestmentPlans from "pages/investment-plans";
import HowItWorks from "pages/how-it-works";
import CustomerTestimonials from "pages/customer-testimonials";

import AdminDashboard from "pages/admin-dashboard";
import AdminSystemAnalytics from "pages/admin-system-analytics";
import SiteAccessibilityAuditDashboard from "pages/site-accessibility-audit-dashboard";
import SupportChatSystem from "pages/support-chat-system";
import ReferralProgram from "pages/referral-program";
import UserProfileSettings from "pages/user-profile-settings";
import AdminUserManagement from "pages/admin-user-management";
import AdminTransactionManagement from "pages/admin-transaction-management";
import WithdrawalRequests from "pages/withdrawal-requests";
import NotificationsCenter from "pages/notifications-center";
import InvestmentPortfolioDashboard from "pages/investment-portfolio-dashboard";
import InvestmentOpportunities from "pages/investment-opportunities";
import TransactionHistory from "pages/transaction-history";
import BTCLiveTradingInterface from "pages/btc-live-trading-interface";
import TradingDashboard from "pages/trading-dashboard";
import MarketAnalysisCenter from "pages/market-analysis-center";
import UserLoginPortal from "pages/user-login-portal";
import UserDashboard from "pages/user-dashboard";
import CPanelHostingConfigurationCenter from "pages/c-panel-hosting-configuration-center";
import NotFound from "pages/NotFound";
import RegistrationPage from "pages/registration";
import PasswordRecovery from "pages/password-recovery";
import AdminSecureLogin from "pages/admin-secure-login";
import AdminPaymentGateway from "pages/admin-payment-gateway";
import AdminSiteSettings from "pages/admin-site-settings";
import AdminSystemLogs from "pages/admin-system-logs";
import AdminUserManagementEnhanced from "pages/admin-user-management-enhanced";
import AdminInvestmentPlans from "pages/admin/investment-plans";
import FAQPage from "pages/faq";
import TestimonialsPage from "pages/testimonials";
import ContactPage from "pages/contact";
import UserLogin from "pages/user-login";
import LoginSelection from "pages/login-selection";
import DepositPage from "pages/deposit";
import KYCVerification from "pages/kyc-verification";

// New admin pages
import AdminActiveUsers from "pages/admin-active-users";
import AdminBannedUsers from "pages/admin-banned-users";
import AdminPendingKYC from "pages/admin-pending-kyc";
import AdminKYCLog from "pages/admin-kyc-log";
import AdminGateways from "pages/admin-gateways";
import AdminPendingDeposits from "pages/admin-pending-deposits";
import AdminAcceptedDeposits from "pages/admin-accepted-deposits";
import AdminRejectedDeposits from "pages/admin-rejected-deposits";
import AdminDepositLog from "pages/admin-deposit-log";
import AdminPendingWithdraws from "pages/admin-pending-withdraws";
import AdminWithdrawLog from "pages/admin-withdraw-log";
import AdminThemeSettings from "pages/admin-theme-settings";
import AdminEmailSettings from "pages/admin-email-settings";
import AdminLanguageManager from "pages/admin-language-manager";
import AdminGoogleTools from "pages/admin-google-tools";
import AdminLogoIcon from "pages/admin-logo-icon";
import AdminWebInterface from "pages/admin-web-interface";
import AdminGatewayEdit from "pages/admin-gateway-edit";
import AdminUserDetails from "pages/admin-user-details";
import AdminSendMessage from "pages/admin-send-message";
import AdminEditUser from "pages/admin-edit-user";
import AdminBanDetails from "pages/admin-ban-details";
import AdminBanAppeal from "pages/admin-ban-appeal";
import AdminSecurityTestPage from "pages/admin-security-test";
import AdminLoginInfoPage from "pages/admin-login-info";
import BiometricDemo from "pages/biometric-demo";
import BackendIntegrationTestPage from "pages/backend-integration-test";
import ProtectedAdminRoute from "components/ProtectedAdminRoute";
import AuthDebugPage from "pages/auth-debug";
import Fix403Page from "pages/fix-403";
import UserDashboardTest from "pages/user-dashboard-test";
import NetworkErrorFixPage from "pages/network-error-fix";


const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <ScrollToTop />
        <RouterRoutes>
          {/* Define your routes here */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/home-landing-page" element={<HomeLandingPage />} />
          <Route path="/about-company-page" element={<AboutCompanyPage />} />
          <Route path="/about" element={<AboutCompanyPage />} />
          <Route path="/why-choose-klever-invest" element={<WhyChooseKleverInvest />} />
          <Route path="/investment-plans" element={<InvestmentPlans />} />
          <Route path="/how-it-works" element={<HowItWorks />} />
          <Route path="/customer-testimonials" element={<TestimonialsPage />} />
          <Route path="/testimonials" element={<TestimonialsPage />} />
          <Route path="/faq" element={<FAQPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/login" element={<LoginSelection />} />
          <Route path="/login-selection" element={<LoginSelection />} />
          <Route path="/user-login" element={<UserLogin />} />
          <Route path="/register" element={<RegistrationPage />} />
          <Route path="/signup" element={<RegistrationPage />} />
          <Route path="/password-recovery" element={<PasswordRecovery />} />
          <Route path="/forgot-password" element={<PasswordRecovery />} />
          <Route path="/reset-password" element={<PasswordRecovery />} />
          <Route path="/kyc-verification" element={<KYCVerification />} />
          <Route path="/user-login-portal" element={<UserLoginPortal />} />
          <Route path="/user-dashboard" element={<UserDashboard />} />
          <Route path="/auth-debug" element={<AuthDebugPage />} />
          <Route path="/fix-403" element={<Fix403Page />} />
          <Route path="/user-dashboard-test" element={<UserDashboardTest />} />
          <Route path="/network-error-fix" element={<NetworkErrorFixPage />} />
          <Route path="/deposit" element={<DepositPage />} />
          
          {/* Admin Login Route - Single secure login */}
          <Route path="/admin-secure-login" element={<AdminSecureLogin />} />
          <Route path="/admin" element={<AdminSecureLogin />} />
          <Route path="/admin-login" element={<AdminSecureLogin />} />
          
          {/* Admin Pages - All properly protected with authentication */}
          <Route path="/admin-dashboard" element={
            <ProtectedAdminRoute>
              <AdminDashboard />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-system-analytics" element={
            <ProtectedAdminRoute>
              <AdminSystemAnalytics />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-user-management" element={
            <ProtectedAdminRoute>
              <AdminUserManagement />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-transaction-management" element={
            <ProtectedAdminRoute>
              <AdminTransactionManagement />
            </ProtectedAdminRoute>
          } />
          <Route path="/site-accessibility-audit-dashboard" element={<SiteAccessibilityAuditDashboard />} />
          <Route path="/c-panel-hosting-configuration-center" element={<CPanelHostingConfigurationCenter />} />
          <Route path="/support-chat-system" element={<SupportChatSystem />} />
          <Route path="/referral-program" element={<ReferralProgram />} />
          <Route path="/user-profile-settings" element={<UserProfileSettings />} />
          <Route path="/withdrawal-requests" element={<WithdrawalRequests />} />
          <Route path="/notifications-center" element={<NotificationsCenter />} />
          <Route path="/investment-portfolio-dashboard" element={<InvestmentPortfolioDashboard />} />
          <Route path="/investment-opportunities" element={<InvestmentOpportunities />} />
          <Route path="/transaction-history" element={<TransactionHistory />} />
          <Route path="/btc-live-trading-interface" element={<BTCLiveTradingInterface />} />
          <Route path="/trading-dashboard" element={<TradingDashboard />} />
          <Route path="/market-analysis-center" element={<MarketAnalysisCenter />} />

          {/* Additional Admin Pages - All Protected */}
          <Route path="/admin-payment-gateway" element={
            <ProtectedAdminRoute>
              <AdminPaymentGateway />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-site-settings" element={
            <ProtectedAdminRoute>
              <AdminSiteSettings />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-system-logs" element={
            <ProtectedAdminRoute>
              <AdminSystemLogs />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-user-management-enhanced" element={
            <ProtectedAdminRoute>
              <AdminUserManagementEnhanced />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-investment-plans" element={
            <ProtectedAdminRoute>
              <AdminInvestmentPlans />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-security-test" element={
            <ProtectedAdminRoute>
              <AdminSecurityTestPage />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-login-info" element={<AdminLoginInfoPage />} />
          <Route path="/biometric-demo" element={<BiometricDemo />} />
          <Route path="/backend-integration-test" element={
            <ProtectedAdminRoute>
              <BackendIntegrationTestPage />
            </ProtectedAdminRoute>
          } />

          {/* User Management Routes - Protected */}
          <Route path="/admin-active-users" element={
            <ProtectedAdminRoute>
              <AdminActiveUsers />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-user-details/:userId" element={
            <ProtectedAdminRoute>
              <AdminUserDetails />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-edit-user/:userId" element={
            <ProtectedAdminRoute>
              <AdminEditUser />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-send-message/:userId" element={
            <ProtectedAdminRoute>
              <AdminSendMessage />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-banned-users" element={
            <ProtectedAdminRoute>
              <AdminBannedUsers />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-ban-details/:userId" element={
            <ProtectedAdminRoute>
              <AdminBanDetails />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-ban-appeal/:userId" element={
            <ProtectedAdminRoute>
              <AdminBanAppeal />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-pending-kyc" element={
            <ProtectedAdminRoute>
              <AdminPendingKYC />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-kyc-log" element={
            <ProtectedAdminRoute>
              <AdminKYCLog />
            </ProtectedAdminRoute>
          } />

          {/* Gateway Management Routes - Protected */}
          <Route path="/admin-gateways" element={
            <ProtectedAdminRoute>
              <AdminGateways />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-gateway-edit/:gatewayId" element={
            <ProtectedAdminRoute>
              <AdminGatewayEdit />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-pending-deposits" element={
            <ProtectedAdminRoute>
              <AdminPendingDeposits />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-accepted-deposits" element={
            <ProtectedAdminRoute>
              <AdminAcceptedDeposits />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-rejected-deposits" element={
            <ProtectedAdminRoute>
              <AdminRejectedDeposits />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-deposit-log" element={
            <ProtectedAdminRoute>
              <AdminDepositLog />
            </ProtectedAdminRoute>
          } />

          {/* Payment Management Routes - Protected */}
          <Route path="/admin-pending-withdraws" element={
            <ProtectedAdminRoute>
              <AdminPendingWithdraws />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-withdraw-log" element={
            <ProtectedAdminRoute>
              <AdminWithdrawLog />
            </ProtectedAdminRoute>
          } />

          {/* Controls Routes - Protected */}
          <Route path="/admin-theme-settings" element={
            <ProtectedAdminRoute>
              <AdminThemeSettings />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-email-settings" element={
            <ProtectedAdminRoute>
              <AdminEmailSettings />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-language-manager" element={
            <ProtectedAdminRoute>
              <AdminLanguageManager />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-google-tools" element={
            <ProtectedAdminRoute>
              <AdminGoogleTools />
            </ProtectedAdminRoute>
          } />

          {/* Theme Settings Sub-routes - Protected */}
          <Route path="/admin-logo-icon" element={
            <ProtectedAdminRoute>
              <AdminLogoIcon />
            </ProtectedAdminRoute>
          } />
          <Route path="/admin-web-interface" element={
            <ProtectedAdminRoute>
              <AdminWebInterface />
            </ProtectedAdminRoute>
          } />

          {/* Catch-all route for 404 */}
          <Route path="*" element={<NotFound />} />
        </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
