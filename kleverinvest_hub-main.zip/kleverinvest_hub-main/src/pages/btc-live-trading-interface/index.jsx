import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import TradingViewChart from './components/TradingViewChart';
import TradingPanel from './components/TradingPanel';
import OrderBook from './components/OrderBook';
import PortfolioSection from './components/PortfolioSection';
import RecentTrades from './components/RecentTrades';
import QuickActions from './components/QuickActions';

const BTCLiveTradingInterface = () => {
  const navigate = useNavigate();
  const [currentPrice, setCurrentPrice] = useState(45780.25);
  const [priceChange, setPriceChange] = useState(1256.42);
  const [priceChangePercent, setPriceChangePercent] = useState(2.82);
  const [selectedTimeframe, setSelectedTimeframe] = useState('1H');
  const [activeTab, setActiveTab] = useState('chart');
  const [isConnected, setIsConnected] = useState(true);

  // Simulate real-time price updates
  useEffect(() => {
    const interval = setInterval(() => {
      const randomChange = (Math.random() - 0.5) * 100;
      const newPrice = currentPrice + randomChange;
      const change = newPrice - 45780.25;
      const changePercent = (change / 45780.25) * 100;
      
      setCurrentPrice(newPrice);
      setPriceChange(change);
      setPriceChangePercent(changePercent);
    }, 3000);

    return () => clearInterval(interval);
  }, [currentPrice]);

  const timeframes = ['1M', '5M', '15M', '1H', '4H', '1D', '1W'];

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(price);
  };

  const formatChange = (change, isPercent = false) => {
    const sign = change >= 0 ? '+' : '';
    const value = isPercent ? `${change.toFixed(2)}%` : formatPrice(Math.abs(change));
    return `${sign}${isPercent ? change.toFixed(2) + '%' : formatPrice(change)}`;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">₿</span>
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-foreground">Bitcoin Trading</h1>
                <p className="text-sm text-muted-foreground">BTC/USD Live Trading Interface</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-success' : 'bg-error'}`} />
              <span className="text-xs text-muted-foreground">
                {isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>
          </div>

          {/* Price Display */}
          <div className="flex items-center space-x-6">
            <div className="text-right">
              <div className="text-2xl font-bold text-foreground">
                {formatPrice(currentPrice)}
              </div>
              <div className={`text-sm font-medium flex items-center ${
                priceChange >= 0 ? 'text-success' : 'text-error'
              }`}>
                <Icon 
                  name={priceChange >= 0 ? 'ArrowUp' : 'ArrowDown'} 
                  size={14} 
                  className="mr-1" 
                />
                {formatChange(priceChange)} ({formatChange(priceChangePercent, true)})
              </div>
            </div>
            
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => navigate('/trading-dashboard')}
            >
              <Icon name="BarChart3" size={16} />
              <span className="hidden sm:inline ml-2">Dashboard</span>
            </Button>
          </div>
        </div>

        {/* Mobile Tabs */}
        <div className="flex lg:hidden mt-4 bg-muted rounded-lg p-1">
          {[
            { key: 'chart', label: 'Chart', icon: 'TrendingUp' },
            { key: 'trade', label: 'Trade', icon: 'ShoppingCart' },
            { key: 'portfolio', label: 'Portfolio', icon: 'PieChart' }
          ].map((tab) => (
            <Button
              key={tab.key}
              variant={activeTab === tab.key ? "default" : "ghost"}
              size="sm"
              className="flex-1"
              onClick={() => setActiveTab(tab.key)}
            >
              <Icon name={tab.icon} size={16} />
              <span className="ml-2">{tab.label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Desktop Layout */}
      <div className="hidden lg:grid lg:grid-cols-4 lg:h-[calc(100vh-120px)]">
        {/* Main Chart Area */}
        <div className="lg:col-span-3 border-r">
          <div className="h-full flex flex-col">
            {/* Chart Controls */}
            <div className="flex items-center justify-between p-4 border-b bg-card">
              <div className="flex items-center space-x-2">
                {timeframes.map((timeframe) => (
                  <Button
                    key={timeframe}
                    variant={selectedTimeframe === timeframe ? "default" : "ghost"}
                    size="xs"
                    onClick={() => setSelectedTimeframe(timeframe)}
                  >
                    {timeframe}
                  </Button>
                ))}
              </div>
              
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm">
                  <Icon name="Settings" size={16} />
                </Button>
                <Button variant="ghost" size="sm">
                  <Icon name="Maximize2" size={16} />
                </Button>
              </div>
            </div>

            {/* TradingView Chart */}
            <div className="flex-1">
              <TradingViewChart 
                symbol="BTCUSD" 
                timeframe={selectedTimeframe.toLowerCase()}
                currentPrice={currentPrice}
              />
            </div>
          </div>
        </div>

        {/* Trading Sidebar */}
        <div className="bg-card">
          <div className="h-full flex flex-col">
            {/* Trading Panel */}
            <div className="flex-1 overflow-y-auto">
              <TradingPanel currentPrice={currentPrice} />
              <OrderBook />
              <RecentTrades />
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Layout */}
      <div className="lg:hidden">
        {activeTab === 'chart' && (
          <div className="h-96 border-b">
            <div className="flex items-center justify-between p-4 border-b bg-card">
              <div className="flex items-center space-x-1">
                {timeframes.map((timeframe) => (
                  <Button
                    key={timeframe}
                    variant={selectedTimeframe === timeframe ? "default" : "ghost"}
                    size="xs"
                    className="text-xs px-2"
                    onClick={() => setSelectedTimeframe(timeframe)}
                  >
                    {timeframe}
                  </Button>
                ))}
              </div>
            </div>
            <TradingViewChart 
              symbol="BTCUSD" 
              timeframe={selectedTimeframe.toLowerCase()}
              currentPrice={currentPrice}
            />
          </div>
        )}

        {activeTab === 'trade' && (
          <div className="p-4 space-y-4">
            <TradingPanel currentPrice={currentPrice} />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <OrderBook />
              <RecentTrades />
            </div>
          </div>
        )}

        {activeTab === 'portfolio' && (
          <div className="p-4">
            <PortfolioSection />
            <QuickActions />
          </div>
        )}
      </div>

      {/* Desktop Portfolio & Quick Actions */}
      <div className="hidden lg:block p-6 bg-muted/50 border-t">
        <div className="grid grid-cols-2 gap-6">
          <PortfolioSection />
          <QuickActions />
        </div>
      </div>
    </div>
  );
};

export default BTCLiveTradingInterface;