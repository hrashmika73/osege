import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActions = () => {
  const navigate = useNavigate();

  const quickActions = [
    {
      label: 'Market Buy',
      description: 'Buy BTC at market price',
      icon: 'ArrowUp',
      color: 'success',
      onClick: () => {
        // Handle market buy
        alert('Market buy executed');
      }
    },
    {
      label: 'Market Sell',
      description: 'Sell BTC at market price',
      icon: 'ArrowDown',
      color: 'danger',
      onClick: () => {
        // Handle market sell
        alert('Market sell executed');
      }
    },
    {
      label: 'Set Alert',
      description: 'Price alert notification',
      icon: 'Bell',
      color: 'secondary',
      onClick: () => {
        // Handle set alert
        alert('Price alert configured');
      }
    },
    {
      label: 'Copy Trading',
      description: 'Follow expert traders',
      icon: 'Users',
      color: 'secondary',
      onClick: () => {
        // Handle copy trading
        alert('Copy trading feature');
      }
    },
    {
      label: 'Portfolio',
      description: 'View full portfolio',
      icon: 'PieChart',
      color: 'secondary',
      onClick: () => navigate('/investment-portfolio-dashboard')
    },
    {
      label: 'History',
      description: 'Trading history',
      icon: 'History',
      color: 'secondary',
      onClick: () => navigate('/transaction-history')
    }
  ];

  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 border-b">
        <h3 className="text-lg font-semibold text-foreground">Quick Actions</h3>
        <p className="text-sm text-muted-foreground">Fast access to common trading functions</p>
      </div>

      <div className="p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {quickActions.map((action, index) => (
            <Button
              key={index}
              variant="outline"
              className="h-auto p-4 flex flex-col items-center space-y-2 hover:border-primary"
              onClick={action.onClick}
            >
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                action.color === 'success' ? 'bg-success/20 text-success' :
                action.color === 'danger'? 'bg-error/20 text-error' : 'bg-muted text-muted-foreground'
              }`}>
                <Icon name={action.icon} size={20} />
              </div>
              <div className="text-center">
                <div className="font-medium text-foreground text-sm">
                  {action.label}
                </div>
                <div className="text-xs text-muted-foreground">
                  {action.description}
                </div>
              </div>
            </Button>
          ))}
        </div>

        {/* Quick Stats */}
        <div className="mt-6 pt-4 border-t">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="text-center">
              <div className="text-muted-foreground">Today's P&L</div>
              <div className="font-semibold text-success">+$1,234.56</div>
            </div>
            <div className="text-center">
              <div className="text-muted-foreground">Win Rate</div>
              <div className="font-semibold text-foreground">78.5%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickActions;