import React, { useEffect, useRef } from 'react';

const TradingViewChart = ({ symbol = 'BTCUSD', timeframe = '1h', currentPrice }) => {
  const chartRef = useRef(null);

  const widgetOptions = {
    symbol: `BINANCE:${symbol}`,
    interval: timeframe.toUpperCase(),
    timezone: "Etc/UTC",
    theme: "dark",
    style: "1",
    locale: "en",
    toolbar_bg: "#f1f3f6",
    enable_publishing: false,
    hide_top_toolbar: false,
    hide_legend: false,
    save_image: false,
    width: "100%",
    height: "100%",
    autosize: true,
    studies: [
      "Volume@tv-basicstudies",
      "MACD@tv-basicstudies"
    ],
    show_popup_button: true,
    popup_width: "1000",
    popup_height: "650",
    range: "1D",
    hide_side_toolbar: false,
    allow_symbol_change: true,
    details: true,
    hotlist: true,
    calendar: true,
    studies_overrides: {},
    overrides: {
      "paneProperties.background": "#1a1a1a",
      "paneProperties.vertGridProperties.color": "#2a2a2a",
      "paneProperties.horzGridProperties.color": "#2a2a2a",
      "symbolWatermarkProperties.transparency": 90,
      "scalesProperties.textColor": "#AAA",
      "mainSeriesProperties.candleStyle.wickUpColor": "#336854",
      "mainSeriesProperties.candleStyle.wickDownColor": "#843c39",
      "mainSeriesProperties.candleStyle.upColor": "#336854",
      "mainSeriesProperties.candleStyle.downColor": "#843c39",
      "mainSeriesProperties.candleStyle.borderUpColor": "#336854",
      "mainSeriesProperties.candleStyle.borderDownColor": "#843c39"
    },
    disabled_features: [
      "use_localstorage_for_settings",
      "volume_force_overlay"
    ],
    enabled_features: [
      "study_templates"
    ]
  };

  return (
    <div className="w-full h-full relative bg-slate-900 rounded-lg overflow-hidden">
      {/* Mock Trading Chart */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-900">
        <div className="h-full w-full flex items-center justify-center">
          <div className="text-center text-slate-400">
            <div className="text-6xl mb-4">📊</div>
            <div className="text-lg font-medium">Trading Chart</div>
            <div className="text-sm">TradingView integration would load here</div>
          </div>
        </div>
      </div>
      
      {/* Custom Price Overlay */}
      <div className="absolute top-4 left-4 bg-slate-800/90 backdrop-blur-sm border border-slate-700 rounded-lg p-3 shadow-lg">
        <div className="text-xs text-slate-400 uppercase tracking-wide mb-1">
          Current Price
        </div>
        <div className="text-lg font-bold text-white">
          ${currentPrice?.toLocaleString(undefined, { 
            minimumFractionDigits: 2, 
            maximumFractionDigits: 2 
          })}
        </div>
      </div>

      {/* Mock Chart Controls */}
      <div className="absolute bottom-4 left-4 flex space-x-2">
        {['1H', '4H', '1D', '1W'].map(tf => (
          <button
            key={tf}
            className={`px-3 py-1 text-xs rounded ${
              tf === timeframe.toUpperCase() 
                ? 'bg-blue-600 text-white' 
                : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
            }`}
          >
            {tf}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TradingViewChart;
