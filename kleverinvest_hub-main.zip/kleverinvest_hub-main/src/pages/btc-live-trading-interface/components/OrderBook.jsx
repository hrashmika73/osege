import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const OrderBook = () => {
  const [orderBook, setOrderBook] = useState({ bids: [], asks: [] });
  const [spread, setSpread] = useState(0);

  // Mock order book data
  useEffect(() => {
    const generateOrderBook = () => {
      const basePrice = 45780.25;
      const bids = [];
      const asks = [];

      // Generate bids (buy orders) - below current price
      for (let i = 0; i < 10; i++) {
        bids.push({
          price: basePrice - (i + 1) * Math.random() * 50,
          size: Math.random() * 2 + 0.1,
          total: 0
        });
      }

      // Generate asks (sell orders) - above current price  
      for (let i = 0; i < 10; i++) {
        asks.push({
          price: basePrice + (i + 1) * Math.random() * 50,
          size: Math.random() * 2 + 0.1,
          total: 0
        });
      }

      // Calculate totals
      let bidTotal = 0;
      let askTotal = 0;

      bids.forEach(bid => {
        bidTotal += bid.size;
        bid.total = bidTotal;
      });

      asks.forEach(ask => {
        askTotal += ask.size;
        ask.total = askTotal;
      });

      const currentSpread = asks[0]?.price - bids[0]?.price;
      setSpread(currentSpread);
      setOrderBook({ bids, asks });
    };

    generateOrderBook();
    const interval = setInterval(generateOrderBook, 2000);
    return () => clearInterval(interval);
  }, []);

  const formatPrice = (price) => price.toFixed(2);
  const formatSize = (size) => size.toFixed(4);

  const getDepthPercentage = (total, maxTotal) => {
    return (total / maxTotal) * 100;
  };

  const maxBidTotal = Math.max(...orderBook.bids.map(b => b.total));
  const maxAskTotal = Math.max(...orderBook.asks.map(a => a.total));

  return (
    <div className="bg-card border-b">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-foreground">Order Book</h3>
          <div className="flex items-center space-x-2 text-xs">
            <span className="text-muted-foreground">Spread:</span>
            <span className="font-medium text-foreground">
              ${spread.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      <div className="h-64 overflow-y-auto">
        {/* Header */}
        <div className="grid grid-cols-3 gap-2 px-4 py-2 text-xs font-medium text-muted-foreground bg-muted/50 sticky top-0">
          <div>Price (USD)</div>
          <div className="text-right">Size (BTC)</div>
          <div className="text-right">Total</div>
        </div>

        {/* Asks (Sell Orders) */}
        <div className="space-y-0">
          {orderBook.asks.slice().reverse().map((ask, index) => (
            <div
              key={`ask-${index}`}
              className="relative grid grid-cols-3 gap-2 px-4 py-1 text-xs hover:bg-muted/30 cursor-pointer"
            >
              <div
                className="absolute inset-y-0 right-0 bg-error/10"
                style={{
                  width: `${getDepthPercentage(ask.total, maxAskTotal)}%`
                }}
              />
              <div className="relative z-10 text-error font-mono">
                {formatPrice(ask.price)}
              </div>
              <div className="relative z-10 text-right font-mono">
                {formatSize(ask.size)}
              </div>
              <div className="relative z-10 text-right font-mono text-muted-foreground">
                {formatSize(ask.total)}
              </div>
            </div>
          ))}
        </div>

        {/* Current Price Indicator */}
        <div className="flex items-center justify-center py-2 bg-muted/50 border-y">
          <div className="flex items-center space-x-2">
            <Icon name="TrendingUp" size={12} className="text-success" />
            <span className="text-sm font-semibold text-foreground">
              $45,780.25
            </span>
            <span className="text-xs text-success">↗ +2.82%</span>
          </div>
        </div>

        {/* Bids (Buy Orders) */}
        <div className="space-y-0">
          {orderBook.bids.map((bid, index) => (
            <div
              key={`bid-${index}`}
              className="relative grid grid-cols-3 gap-2 px-4 py-1 text-xs hover:bg-muted/30 cursor-pointer"
            >
              <div
                className="absolute inset-y-0 right-0 bg-success/10"
                style={{
                  width: `${getDepthPercentage(bid.total, maxBidTotal)}%`
                }}
              />
              <div className="relative z-10 text-success font-mono">
                {formatPrice(bid.price)}
              </div>
              <div className="relative z-10 text-right font-mono">
                {formatSize(bid.size)}
              </div>
              <div className="relative z-10 text-right font-mono text-muted-foreground">
                {formatSize(bid.total)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OrderBook;