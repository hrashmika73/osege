import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const RecentTrades = () => {
  const [trades, setTrades] = useState([]);

  // Mock recent trades data
  useEffect(() => {
    const generateTrades = () => {
      const newTrades = [];
      const basePrice = 45780.25;

      for (let i = 0; i < 20; i++) {
        const priceVariation = (Math.random() - 0.5) * 200;
        const price = basePrice + priceVariation;
        const size = Math.random() * 1 + 0.01;
        const isBuy = Math.random() > 0.5;
        
        newTrades.push({
          id: Date.now() + i,
          price,
          size,
          side: isBuy ? 'buy' : 'sell',
          timestamp: new Date(Date.now() - i * 1000 * Math.random() * 60),
          total: price * size
        });
      }

      setTrades(newTrades.sort((a, b) => b.timestamp - a.timestamp));
    };

    generateTrades();
    const interval = setInterval(() => {
      // Add new trade occasionally
      if (Math.random() > 0.7) {
        const basePrice = 45780.25;
        const priceVariation = (Math.random() - 0.5) * 100;
        const price = basePrice + priceVariation;
        const size = Math.random() * 0.5 + 0.01;
        const isBuy = Math.random() > 0.5;
        
        const newTrade = {
          id: Date.now(),
          price,
          size,
          side: isBuy ? 'buy' : 'sell',
          timestamp: new Date(),
          total: price * size
        };

        setTrades(prev => [newTrade, ...prev.slice(0, 19)]);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const formatPrice = (price) => price.toFixed(2);
  const formatSize = (size) => size.toFixed(4);
  const formatTime = (timestamp) => {
    return timestamp.toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="bg-card">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-foreground">Recent Trades</h3>
          <div className="flex items-center space-x-1">
            <Icon name="Activity" size={14} className="text-primary" />
            <span className="text-xs text-muted-foreground">Live</span>
          </div>
        </div>
      </div>

      <div className="h-64 overflow-y-auto">
        {/* Header */}
        <div className="grid grid-cols-4 gap-2 px-4 py-2 text-xs font-medium text-muted-foreground bg-muted/50 sticky top-0">
          <div>Time</div>
          <div className="text-right">Price</div>
          <div className="text-right">Size</div>
          <div className="text-right">Side</div>
        </div>

        {/* Trades List */}
        <div className="space-y-0">
          {trades.map((trade) => (
            <div
              key={trade.id}
              className="grid grid-cols-4 gap-2 px-4 py-1.5 text-xs hover:bg-muted/30 transition-colors"
            >
              <div className="font-mono text-muted-foreground">
                {formatTime(trade.timestamp)}
              </div>
              <div className={`text-right font-mono font-medium ${
                trade.side === 'buy' ? 'text-success' : 'text-error'
              }`}>
                {formatPrice(trade.price)}
              </div>
              <div className="text-right font-mono">
                {formatSize(trade.size)}
              </div>
              <div className="text-right">
                <span className={`px-1.5 py-0.5 rounded text-xs font-medium ${
                  trade.side === 'buy' ?'bg-success/20 text-success' :'bg-error/20 text-error'
                }`}>
                  {trade.side.toUpperCase()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Trade Summary */}
      <div className="p-4 border-t bg-muted/50">
        <div className="grid grid-cols-2 gap-4 text-xs">
          <div>
            <div className="text-muted-foreground mb-1">24h Volume</div>
            <div className="font-semibold text-foreground">
              {(Math.random() * 5000 + 15000).toFixed(0)} BTC
            </div>
          </div>
          <div>
            <div className="text-muted-foreground mb-1">24h High/Low</div>
            <div className="font-semibold text-foreground">
              $46,250 / $44,890
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecentTrades;