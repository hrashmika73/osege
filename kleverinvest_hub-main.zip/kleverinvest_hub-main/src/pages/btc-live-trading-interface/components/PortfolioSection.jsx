import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PortfolioSection = () => {
  // Mock portfolio data
  const portfolioData = {
    btcHoldings: 2.45892156,
    btcValue: 112456.78,
    usdBalance: 25678.90,
    totalValue: 138135.68,
    dayChange: 3245.67,
    dayChangePercent: 2.41,
    positions: [
      {
        id: 1,
        symbol: 'BTC/USD',
        side: 'long',
        size: 0.5,
        entryPrice: 44250.00,
        currentPrice: 45780.25,
        pnl: 765.13,
        pnlPercent: 3.46,
        margin: 2212.50
      },
      {
        id: 2,
        symbol: 'BTC/USD',
        side: 'short',
        size: 0.2,
        entryPrice: 46100.00,
        currentPrice: 45780.25,
        pnl: 63.95,
        pnlPercent: 0.69,
        margin: 922.00
      }
    ]
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(price);
  };

  const formatBTC = (amount) => {
    return `${amount.toFixed(8)} BTC`;
  };

  const formatChange = (change, isPercent = false) => {
    const sign = change >= 0 ? '+' : '';
    return isPercent 
      ? `${sign}${change.toFixed(2)}%` 
      : `${sign}${formatPrice(change)}`;
  };

  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Portfolio</h3>
          <Button variant="ghost" size="sm">
            <Icon name="RefreshCw" size={14} />
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Total Portfolio Value */}
        <div className="bg-muted/50 rounded-lg p-4">
          <div className="text-sm text-muted-foreground mb-1">Total Portfolio Value</div>
          <div className="text-2xl font-bold text-foreground mb-2">
            {formatPrice(portfolioData.totalValue)}
          </div>
          <div className={`flex items-center text-sm font-medium ${
            portfolioData.dayChange >= 0 ? 'text-success' : 'text-error'
          }`}>
            <Icon 
              name={portfolioData.dayChange >= 0 ? 'ArrowUp' : 'ArrowDown'} 
              size={14} 
              className="mr-1" 
            />
            {formatChange(portfolioData.dayChange)} ({formatChange(portfolioData.dayChangePercent, true)})
          </div>
        </div>

        {/* Holdings Breakdown */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-foreground">Holdings</h4>
          
          <div className="space-y-2">
            {/* BTC Holdings */}
            <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">₿</span>
                </div>
                <div>
                  <div className="font-medium text-foreground">Bitcoin</div>
                  <div className="text-xs text-muted-foreground">BTC</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium text-foreground">
                  {formatBTC(portfolioData.btcHoldings)}
                </div>
                <div className="text-xs text-muted-foreground">
                  {formatPrice(portfolioData.btcValue)}
                </div>
              </div>
            </div>

            {/* USD Balance */}
            <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">$</span>
                </div>
                <div>
                  <div className="font-medium text-foreground">US Dollar</div>
                  <div className="text-xs text-muted-foreground">USD</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium text-foreground">
                  {formatPrice(portfolioData.usdBalance)}
                </div>
                <div className="text-xs text-muted-foreground">Available</div>
              </div>
            </div>
          </div>
        </div>

        {/* Active Positions */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-foreground">Active Positions</h4>
          
          <div className="space-y-2">
            {portfolioData.positions.map((position) => (
              <div key={position.id} className="border rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-foreground">{position.symbol}</span>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                      position.side === 'long' ?'bg-success/20 text-success' :'bg-error/20 text-error'
                    }`}>
                      {position.side.toUpperCase()}
                    </span>
                  </div>
                  <div className={`text-sm font-medium ${
                    position.pnl >= 0 ? 'text-success' : 'text-error'
                  }`}>
                    {formatChange(position.pnl)} ({formatChange(position.pnlPercent, true)})
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <div className="text-muted-foreground">Size</div>
                    <div className="font-medium text-foreground">{formatBTC(position.size)}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Entry Price</div>
                    <div className="font-medium text-foreground">{formatPrice(position.entryPrice)}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Risk Metrics */}
        <div className="bg-muted/30 rounded-lg p-3">
          <h4 className="text-sm font-medium text-foreground mb-2">Risk Management</h4>
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <div className="text-muted-foreground">Total Margin</div>
              <div className="font-medium text-foreground">{formatPrice(3134.50)}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Free Margin</div>
              <div className="font-medium text-foreground">{formatPrice(22544.40)}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PortfolioSection;