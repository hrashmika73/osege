import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const TradingPanel = ({ currentPrice }) => {
  const [orderType, setOrderType] = useState('market');
  const [tradeAction, setTradeAction] = useState('buy');
  const [amount, setAmount] = useState('');
  const [price, setPrice] = useState(currentPrice?.toString() || '');
  const [stopLoss, setStopLoss] = useState('');
  const [takeProfit, setTakeProfit] = useState('');
  const [leverage, setLeverage] = useState(1);

  const balance = 50000; // Mock balance
  const btcBalance = 0.825; // Mock BTC balance

  const orderTypes = [
    { value: 'market', label: 'Market' },
    { value: 'limit', label: 'Limit' },
    { value: 'stop', label: 'Stop' }
  ];

  const leverageOptions = [1, 2, 5, 10, 25, 50, 100];

  const calculateTotal = () => {
    if (!amount || !price) return 0;
    return parseFloat(amount) * parseFloat(price);
  };

  const handleQuickAmount = (percentage) => {
    const maxAmount = tradeAction === 'buy' 
      ? balance / currentPrice 
      : btcBalance;
    const quickAmount = (maxAmount * percentage / 100).toFixed(8);
    setAmount(quickAmount);
  };

  const handleSubmitOrder = () => {
    const orderData = {
      type: orderType,
      action: tradeAction,
      amount: parseFloat(amount),
      price: orderType === 'market' ? currentPrice : parseFloat(price),
      stopLoss: stopLoss ? parseFloat(stopLoss) : null,
      takeProfit: takeProfit ? parseFloat(takeProfit) : null,
      leverage,
      total: calculateTotal()
    };

    console.log('Submitting order:', orderData);
    // Handle order submission
    alert(`${tradeAction.toUpperCase()} order submitted for ${amount} BTC`);
  };

  return (
    <div className="bg-card border-b p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Trade BTC</h3>
        <div className="flex items-center space-x-2 text-sm">
          <Icon name="Wallet" size={14} className="text-primary" />
          <span className="text-muted-foreground">
            ${balance.toLocaleString()} / {btcBalance} BTC
          </span>
        </div>
      </div>

      {/* Order Type Selector */}
      <div className="flex bg-muted rounded-lg p-1">
        {orderTypes.map((type) => (
          <Button
            key={type.value}
            variant={orderType === type.value ? "default" : "ghost"}
            size="sm"
            className="flex-1"
            onClick={() => setOrderType(type.value)}
          >
            {type.label}
          </Button>
        ))}
      </div>

      {/* Buy/Sell Toggle */}
      <div className="grid grid-cols-2 gap-2">
        <Button
          variant={tradeAction === 'buy' ? "success" : "outline"}
          className="h-12"
          onClick={() => setTradeAction('buy')}
        >
          <Icon name="ArrowUp" size={16} />
          <span className="ml-2">Buy</span>
        </Button>
        <Button
          variant={tradeAction === 'sell' ? "danger" : "outline"}
          className="h-12"
          onClick={() => setTradeAction('sell')}
        >
          <Icon name="ArrowDown" size={16} />
          <span className="ml-2">Sell</span>
        </Button>
      </div>

      {/* Amount Input */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Amount (BTC)</label>
        <div className="relative">
          <Input
            type="number"
            placeholder="0.00000000"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            step="0.00000001"
            className="pr-20"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
            <span className="text-xs text-muted-foreground">BTC</span>
          </div>
        </div>
        
        {/* Quick Amount Buttons */}
        <div className="flex space-x-1">
          {[25, 50, 75, 100].map((percentage) => (
            <Button
              key={percentage}
              variant="ghost"
              size="xs"
              className="flex-1"
              onClick={() => handleQuickAmount(percentage)}
            >
              {percentage}%
            </Button>
          ))}
        </div>
      </div>

      {/* Price Input (for limit/stop orders) */}
      {orderType !== 'market' && (
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Price (USD)</label>
          <div className="relative">
            <Input
              type="number"
              placeholder="0.00"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              step="0.01"
              className="pr-20"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              <span className="text-xs text-muted-foreground">USD</span>
            </div>
          </div>
        </div>
      )}

      {/* Advanced Options */}
      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <Icon name="Settings" size={14} className="text-muted-foreground" />
          <span className="text-sm font-medium text-foreground">Advanced</span>
        </div>

        {/* Leverage Selector */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Leverage: {leverage}x</label>
          <div className="flex flex-wrap gap-1">
            {leverageOptions.map((lev) => (
              <Button
                key={lev}
                variant={leverage === lev ? "default" : "outline"}
                size="xs"
                onClick={() => setLeverage(lev)}
              >
                {lev}x
              </Button>
            ))}
          </div>
        </div>

        {/* Stop Loss & Take Profit */}
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-xs text-muted-foreground">Stop Loss</label>
            <Input
              type="number"
              placeholder="Price"
              value={stopLoss}
              onChange={(e) => setStopLoss(e.target.value)}
              size="sm"
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Take Profit</label>
            <Input
              type="number"
              placeholder="Price"
              value={takeProfit}
              onChange={(e) => setTakeProfit(e.target.value)}
              size="sm"
            />
          </div>
        </div>
      </div>

      {/* Order Summary */}
      <div className="bg-muted rounded-lg p-3 space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Total</span>
          <span className="font-medium text-foreground">
            ${calculateTotal().toLocaleString(undefined, { 
              minimumFractionDigits: 2, 
              maximumFractionDigits: 2 
            })}
          </span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Fee (0.1%)</span>
          <span className="font-medium text-foreground">
            ${(calculateTotal() * 0.001).toFixed(2)}
          </span>
        </div>
      </div>

      {/* Submit Button */}
      <Button
        className="w-full h-12"
        variant={tradeAction === 'buy' ? "success" : "danger"}
        onClick={handleSubmitOrder}
        disabled={!amount || (orderType !== 'market' && !price)}
      >
        <Icon name={tradeAction === 'buy' ? 'ArrowUp' : 'ArrowDown'} size={16} />
        <span className="ml-2 font-semibold">
          {tradeAction.toUpperCase()} {amount || '0'} BTC
        </span>
      </Button>
    </div>
  );
};

export default TradingPanel;