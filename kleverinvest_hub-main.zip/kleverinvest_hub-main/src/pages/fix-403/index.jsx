import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import { initializeTestUsers } from '../../utils/initTestUser';
import { useUserAuth } from '../../contexts/UserAuthContext';

const Fix403Page = () => {
  const navigate = useNavigate();
  const { userLogin } = useUserAuth();
  const [isFixing, setIsFixing] = useState(false);
  const [fixComplete, setFixComplete] = useState(false);
  const [loginTested, setLoginTested] = useState(false);

  const handleFix403 = async () => {
    setIsFixing(true);
    try {
      // Clear all conflicting auth data
      localStorage.removeItem('userToken');
      localStorage.removeItem('userData');
      localStorage.removeItem('adminToken');
      localStorage.removeItem('adminData');
      localStorage.removeItem('userLoginAttempts');
      localStorage.removeItem('userLockoutUntil');
      
      // Initialize test users
      initializeTestUsers();
      
      // Wait a moment for initialization
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setFixComplete(true);
    } catch (error) {
      console.error('Fix failed:', error);
      alert('Fix failed. Please try manually clearing your browser data.');
    } finally {
      setIsFixing(false);
    }
  };

  const handleTestLogin = async () => {
    try {
      await userLogin({
        email: 'user@kleverinvest.com',
        password: 'password123'
      });
      setLoginTested(true);
      alert('Login test successful! You can now access the user dashboard.');
    } catch (error) {
      alert(`Login test failed: ${error.message}`);
    }
  };

  const navigateToDashboard = () => {
    navigate('/user-dashboard');
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Helmet>
        <title>Fix 403 Forbidden - KleverInvest</title>
      </Helmet>

      <div className="max-w-md w-full">
        <div className="bg-card border rounded-lg p-8 text-center">
          <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="AlertTriangle" size={32} className="text-destructive" />
          </div>
          
          <h1 className="text-2xl font-bold text-foreground mb-4">
            403 Forbidden Error Fix
          </h1>
          
          <p className="text-muted-foreground mb-6">
            This page will fix the 403 Forbidden error you're experiencing when trying to access the user dashboard.
          </p>

          {!fixComplete ? (
            <div className="space-y-4">
              <div className="bg-muted/30 p-4 rounded-lg text-left">
                <h3 className="font-medium mb-2">What this will do:</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Clear conflicting authentication data</li>
                  <li>• Initialize verified test users</li>
                  <li>• Reset authentication state</li>
                  <li>• Prepare system for fresh login</li>
                </ul>
              </div>

              <Button 
                onClick={handleFix403} 
                className="w-full" 
                disabled={isFixing}
              >
                {isFixing ? (
                  <>
                    <Icon name="Loader2" size={16} className="mr-2 animate-spin" />
                    Fixing...
                  </>
                ) : (
                  <>
                    <Icon name="Wrench" size={16} className="mr-2" />
                    Fix 403 Error
                  </>
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-success/10 p-4 rounded-lg">
                <Icon name="CheckCircle" className="text-success mx-auto mb-2" />
                <p className="text-success font-medium">Fix Complete!</p>
              </div>

              {!loginTested ? (
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Now test the login with the default credentials:
                  </p>
                  <div className="bg-muted/30 p-3 rounded text-xs">
                    <div>Email: user@kleverinvest.com</div>
                    <div>Password: password123</div>
                  </div>
                  <Button onClick={handleTestLogin} variant="outline" className="w-full">
                    <Icon name="TestTube" size={16} className="mr-2" />
                    Test Login
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="bg-success/10 p-3 rounded">
                    <Icon name="CheckCircle" className="text-success mx-auto mb-1" />
                    <p className="text-success text-sm">Login test successful!</p>
                  </div>
                  <Button onClick={navigateToDashboard} className="w-full">
                    <Icon name="ExternalLink" size={16} className="mr-2" />
                    Access User Dashboard
                  </Button>
                </div>
              )}
            </div>
          )}

          <div className="mt-6 pt-6 border-t border-border">
            <div className="flex justify-center space-x-4">
              <Button variant="outline" size="sm" onClick={() => navigate('/')}>
                <Icon name="Home" size={14} className="mr-1" />
                Home
              </Button>
              <Button variant="outline" size="sm" onClick={() => navigate('/auth-debug')}>
                <Icon name="Bug" size={14} className="mr-1" />
                Debug
              </Button>
              <Button variant="outline" size="sm" onClick={() => navigate('/user-login')}>
                <Icon name="LogIn" size={14} className="mr-1" />
                Login
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Fix403Page;
