import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const GeographicMap = ({ data }) => {
  const [viewMode, setViewMode] = useState('heatmap');

  const getIntensityColor = (percentage) => {
    if (percentage > 20) return 'bg-blue-600';
    if (percentage > 15) return 'bg-blue-500';
    if (percentage > 10) return 'bg-blue-400';
    if (percentage > 5) return 'bg-blue-300';
    return 'bg-blue-200';
  };

  const renderHeatMapView = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {data?.slice(0, 4).map((country, index) => (
          <div key={country.country} className="bg-muted/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${getIntensityColor(country.percentage)}`}></div>
                <span className="text-sm font-medium text-foreground">{country.country}</span>
              </div>
              <span className="text-sm text-muted-foreground">{country.percentage}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold text-foreground">{country.users?.toLocaleString()}</span>
              <div className="w-16 bg-muted rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${getIntensityColor(country.percentage)}`}
                  style={{ width: `${(country.percentage / 30) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* World Map Placeholder */}
      <div className="bg-muted/20 rounded-lg p-8 text-center">
        <Icon name="Globe" size={64} className="mx-auto mb-4 text-muted-foreground" />
        <p className="text-muted-foreground mb-2">Interactive World Map</p>
        <p className="text-sm text-muted-foreground">
          Geographic heat map showing user distribution across regions
        </p>
      </div>
    </div>
  );

  const renderListView = () => (
    <div className="space-y-3">
      {data?.map((country, index) => (
        <div key={country.country} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
              <span className="text-sm font-bold text-primary">{index + 1}</span>
            </div>
            <div>
              <div className="font-medium text-foreground">{country.country}</div>
              <div className="text-sm text-muted-foreground">{country.percentage}% of total users</div>
            </div>
          </div>
          <div className="text-right">
            <div className="font-bold text-foreground">{country.users?.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">users</div>
          </div>
        </div>
      ))}
    </div>
  );

  const renderDemographicsView = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-3">
            <Icon name="Users" size={20} className="text-primary" />
            <span className="font-medium text-foreground">Age Distribution</span>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">18-25</span>
              <span className="text-sm font-medium">22%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">26-35</span>
              <span className="text-sm font-medium">38%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">36-45</span>
              <span className="text-sm font-medium">28%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">46+</span>
              <span className="text-sm font-medium">12%</span>
            </div>
          </div>
        </div>

        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-3">
            <Icon name="Activity" size={20} className="text-success" />
            <span className="font-medium text-foreground">Activity Levels</span>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">High Activity</span>
              <span className="text-sm font-medium text-green-600">45%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Medium Activity</span>
              <span className="text-sm font-medium text-yellow-600">35%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Low Activity</span>
              <span className="text-sm font-medium text-red-600">20%</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-muted/30 rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-3">
          <Icon name="Clock" size={20} className="text-warning" />
          <span className="font-medium text-foreground">Peak Usage Times by Region</span>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-lg font-bold text-foreground">9-11 AM</div>
            <div className="text-sm text-muted-foreground">Americas</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-foreground">2-4 PM</div>
            <div className="text-sm text-muted-foreground">Europe</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-foreground">7-9 PM</div>
            <div className="text-sm text-muted-foreground">Asia Pacific</div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Geographic Distribution</h3>
          <p className="text-sm text-muted-foreground">User activity by region with demographic insights</p>
        </div>
        <div className="flex items-center space-x-1 bg-muted rounded-lg p-1">
          <Button
            variant={viewMode === 'heatmap' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('heatmap')}
            className="text-xs px-3 py-1"
          >
            <Icon name="Map" size={14} />
            Heat Map
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('list')}
            className="text-xs px-3 py-1"
          >
            <Icon name="List" size={14} />
            List
          </Button>
          <Button
            variant={viewMode === 'demographics' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('demographics')}
            className="text-xs px-3 py-1"
          >
            <Icon name="Users" size={14} />
            Demographics
          </Button>
        </div>
      </div>

      {viewMode === 'heatmap' && renderHeatMapView()}
      {viewMode === 'list' && renderListView()}  
      {viewMode === 'demographics' && renderDemographicsView()}
    </div>
  );
};

export default GeographicMap;