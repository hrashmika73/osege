import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RevenueAnalytics = () => {
  const [activeTab, setActiveTab] = useState('overview');

  // Mock revenue data
  const revenueOverviewData = [
    { month: 'Jan', revenue: 2400000, costs: 1200000, profit: 1200000 },
    { month: 'Feb', revenue: 2800000, costs: 1300000, profit: 1500000 },
    { month: 'Mar', revenue: 3200000, costs: 1400000, profit: 1800000 },
    { month: 'Apr', revenue: 3600000, costs: 1500000, profit: 2100000 },
    { month: 'May', revenue: 4000000, costs: 1600000, profit: 2400000 },
    { month: 'Jun', revenue: 4400000, costs: 1700000, profit: 2700000 }
  ];

  const feeCollectionData = [
    { category: 'Trading Fees', amount: 1200000, percentage: 45 },
    { category: 'Withdrawal Fees', amount: 400000, percentage: 15 },
    { category: 'Investment Fees', amount: 533333, percentage: 20 },
    { category: 'Premium Subscriptions', amount: 266667, percentage: 10 },
    { category: 'Other Fees', amount: 266667, percentage: 10 }
  ];

  const operationalCosts = [
    { category: 'Infrastructure', amount: 500000, trend: 'up', change: '+5.2%' },
    { category: 'Personnel', amount: 600000, trend: 'up', change: '+3.1%' },
    { category: 'Marketing', amount: 200000, trend: 'down', change: '-2.3%' },
    { category: 'Legal & Compliance', amount: 150000, trend: 'up', change: '+8.7%' },
    { category: 'Technology', amount: 250000, trend: 'up', change: '+12.4%' }
  ];

  const investmentReturns = [
    { investment: 'DeFi Pool A', allocated: 5000000, returns: 750000, apy: '15.2%', status: 'active' },
    { investment: 'Staking Rewards', allocated: 3000000, returns: 360000, apy: '12.0%', status: 'active' },
    { investment: 'Liquidity Mining', allocated: 2000000, returns: 400000, apy: '20.0%', status: 'active' },
    { investment: 'Treasury Bonds', allocated: 1000000, returns: 45000, apy: '4.5%', status: 'stable' }
  ];

  const renderOverviewTab = () => (
    <div className="space-y-6">
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={revenueOverviewData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
            <XAxis dataKey="month" stroke="#64748B" fontSize={12} />
            <YAxis stroke="#64748B" fontSize={12} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#FFFFFF', 
                border: '1px solid #E2E8F0', 
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }}
              formatter={(value) => [`$${value.toLocaleString()}`, '']}
            />
            <Line type="monotone" dataKey="revenue" stroke="#1E40AF" strokeWidth={2} name="Revenue" />
            <Line type="monotone" dataKey="profit" stroke="#10B981" strokeWidth={2} name="Profit" />
            <Line type="monotone" dataKey="costs" stroke="#EF4444" strokeWidth={2} name="Costs" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-muted/30 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-foreground">$4.4M</div>
          <div className="text-sm text-muted-foreground">Total Revenue</div>
          <div className="text-sm text-green-600 font-medium">+22.3%</div>
        </div>
        <div className="bg-muted/30 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-foreground">$2.7M</div>
          <div className="text-sm text-muted-foreground">Net Profit</div>
          <div className="text-sm text-green-600 font-medium">+35.1%</div>
        </div>
        <div className="bg-muted/30 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-foreground">61.4%</div>
          <div className="text-sm text-muted-foreground">Profit Margin</div>
          <div className="text-sm text-green-600 font-medium">+8.2%</div>
        </div>
      </div>
    </div>
  );

  const renderFeesTab = () => (
    <div className="space-y-4">
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={feeCollectionData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
            <XAxis dataKey="category" stroke="#64748B" fontSize={11} />
            <YAxis stroke="#64748B" fontSize={12} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#FFFFFF', 
                border: '1px solid #E2E8F0', 
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }}
              formatter={(value) => [`$${value.toLocaleString()}`, 'Revenue']}
            />
            <Bar dataKey="amount" fill="#1E40AF" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="space-y-3">
        {feeCollectionData.map((fee, index) => (
          <div key={fee.category} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-4 h-4 bg-primary rounded"></div>
              <span className="font-medium text-foreground">{fee.category}</span>
            </div>
            <div className="text-right">
              <div className="font-bold text-foreground">${fee.amount.toLocaleString()}</div>
              <div className="text-sm text-muted-foreground">{fee.percentage}%</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCostsTab = () => (
    <div className="space-y-4">
      {operationalCosts.map((cost, index) => (
        <div key={cost.category} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
          <div className="flex items-center space-x-3">
            <Icon name="DollarSign" size={20} className="text-red-500" />
            <div>
              <div className="font-medium text-foreground">{cost.category}</div>
              <div className="text-sm text-muted-foreground">Monthly operational cost</div>
            </div>
          </div>
          <div className="text-right">
            <div className="font-bold text-foreground">${cost.amount.toLocaleString()}</div>
            <div className={`text-sm font-medium flex items-center space-x-1 ${
              cost.trend === 'up' ? 'text-red-600' : 'text-green-600'
            }`}>
              <Icon name={cost.trend === 'up' ? 'ArrowUp' : 'ArrowDown'} size={14} />
              <span>{cost.change}</span>
            </div>
          </div>
        </div>
      ))}

      <div className="bg-muted/30 rounded-lg p-4 mt-4">
        <div className="flex items-center justify-between">
          <span className="font-medium text-foreground">Total Monthly Costs</span>
          <span className="text-xl font-bold text-foreground">$1,700,000</span>
        </div>
        <div className="text-sm text-muted-foreground mt-1">
          Cost efficiency: 38.6% of revenue
        </div>
      </div>
    </div>
  );

  const renderInvestmentsTab = () => (
    <div className="space-y-4">
      {investmentReturns.map((investment, index) => (
        <div key={investment.investment} className="p-4 bg-muted/30 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <div className={`w-3 h-3 rounded-full ${
                investment.status === 'active' ? 'bg-green-500' : 'bg-blue-500'
              }`}></div>
              <div>
                <div className="font-medium text-foreground">{investment.investment}</div>
                <div className="text-sm text-muted-foreground">
                  Allocated: ${investment.allocated.toLocaleString()}
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-bold text-green-600">{investment.apy}</div>
              <div className="text-sm text-muted-foreground">APY</div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              Returns: ${investment.returns.toLocaleString()}
            </div>
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${
              investment.status === 'active' ?'bg-green-100 text-green-700' :'bg-blue-100 text-blue-700'
            }`}>
              {investment.status}
            </div>
          </div>
        </div>
      ))}

      <div className="bg-muted/30 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <span className="font-medium text-foreground">Total Investment Returns</span>
          <span className="text-xl font-bold text-green-600">$1,555,000</span>
        </div>
        <div className="text-sm text-muted-foreground mt-1">
          Average APY: 12.9% across all investments
        </div>
      </div>
    </div>
  );

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'BarChart3' },
    { id: 'fees', label: 'Fee Collection', icon: 'Coins' },
    { id: 'costs', label: 'Operational Costs', icon: 'TrendingDown' },
    { id: 'investments', label: 'Investment Returns', icon: 'TrendingUp' }
  ];

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Revenue Analytics</h3>
          <p className="text-sm text-muted-foreground">
            Comprehensive financial performance tracking
          </p>
        </div>
        <Button variant="outline" size="sm">
          <Icon name="Download" size={16} />
          Export
        </Button>
      </div>

      <div className="flex items-center space-x-1 bg-muted rounded-lg p-1 mb-6">
        {tabs.map((tab) => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab(tab.id)}
            className="text-xs px-3 py-2"
          >
            <Icon name={tab.icon} size={14} className="mr-1" />
            {tab.label}
          </Button>
        ))}
      </div>

      {activeTab === 'overview' && renderOverviewTab()}
      {activeTab === 'fees' && renderFeesTab()}
      {activeTab === 'costs' && renderCostsTab()}
      {activeTab === 'investments' && renderInvestmentsTab()}
    </div>
  );
};

export default RevenueAnalytics;