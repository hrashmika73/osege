import React, { useState } from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, ComposedChart } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AnalyticsWidget = ({ title, type = 'line', data, height = 300, description }) => {
  const [viewMode, setViewMode] = useState('chart');
  
  const colors = ['#1E40AF', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

  const renderChart = () => {
    switch (type) {
      case 'multiline':
        return (
          <ComposedChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
            <XAxis dataKey="name" stroke="#64748B" fontSize={12} />
            <YAxis stroke="#64748B" fontSize={12} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#FFFFFF', 
                border: '1px solid #E2E8F0', 
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }} 
            />
            <Line type="monotone" dataKey="organic" stroke="#1E40AF" strokeWidth={2} name="Organic" />
            <Line type="monotone" dataKey="referral" stroke="#10B981" strokeWidth={2} name="Referral" />
            <Line type="monotone" dataKey="paid" stroke="#F59E0B" strokeWidth={2} name="Paid" />
          </ComposedChart>
        );
      case 'area':
        return (
          <AreaChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
            <XAxis dataKey="name" stroke="#64748B" fontSize={12} />
            <YAxis stroke="#64748B" fontSize={12} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#FFFFFF', 
                border: '1px solid #E2E8F0', 
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }} 
            />
            <Area type="monotone" dataKey="volume" stroke="#1E40AF" fill="#1E40AF" fillOpacity={0.1} name="Volume" />
          </AreaChart>
        );
      case 'doughnut':
        return (
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={70}
              outerRadius={120}
              paddingAngle={3}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
              ))}
            </Pie>
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#FFFFFF', 
                border: '1px solid #E2E8F0', 
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }} 
              formatter={(value, name) => [`$${value?.toLocaleString()}`, name]}
            />
          </PieChart>
        );
      case 'performance':
        return (
          <div className="space-y-4">
            {data?.map((crypto, index) => (
              <div key={crypto.name} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold`}
                       style={{ backgroundColor: colors[index % colors.length] }}>
                    {crypto.name}
                  </div>
                  <div>
                    <div className="font-medium text-foreground">${crypto.price?.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">
                      Vol: ${crypto.volume?.toLocaleString()}
                    </div>
                  </div>
                </div>
                <div className={`flex items-center space-x-1 ${crypto.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  <Icon name={crypto.change >= 0 ? "TrendingUp" : "TrendingDown"} size={16} />
                  <span className="font-medium">{Math.abs(crypto.change)}%</span>
                </div>
              </div>
            ))}
          </div>
        );
      default:
        return (
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
            <XAxis dataKey="name" stroke="#64748B" fontSize={12} />
            <YAxis stroke="#64748B" fontSize={12} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#FFFFFF', 
                border: '1px solid #E2E8F0', 
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }} 
            />
            <Line type="monotone" dataKey="value" stroke="#1E40AF" strokeWidth={2} />
          </LineChart>
        );
    }
  };

  const renderTableView = () => {
    if (type === 'performance') {
      return (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left py-2">Crypto</th>
                <th className="text-right py-2">Price</th>
                <th className="text-right py-2">Change</th>
                <th className="text-right py-2">Volume</th>
              </tr>
            </thead>
            <tbody>
              {data?.map((crypto, index) => (
                <tr key={crypto.name} className="border-b">
                  <td className="py-2 font-medium">{crypto.name}</td>
                  <td className="py-2 text-right">${crypto.price?.toLocaleString()}</td>
                  <td className={`py-2 text-right ${crypto.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {crypto.change >= 0 ? '+' : ''}{crypto.change}%
                  </td>
                  <td className="py-2 text-right">${crypto.volume?.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }
    
    return (
      <div className="text-center text-muted-foreground py-8">
        <Icon name="Table" size={48} className="mx-auto mb-2" />
        <p>Table view not available for this chart type</p>
      </div>
    );
  };

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-foreground">{title}</h3>
          {description && (
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
          )}
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant={viewMode === 'chart' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('chart')}
          >
            <Icon name="BarChart3" size={16} />
          </Button>
          <Button
            variant={viewMode === 'table' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('table')}
          >
            <Icon name="Table" size={16} />
          </Button>
          <Button variant="ghost" size="sm">
            <Icon name="MoreHorizontal" size={16} />
          </Button>
        </div>
      </div>
      
      <div style={{ width: '100%', height }}>
        {viewMode === 'chart' ? (
          type === 'performance' ? renderChart() : (
            <ResponsiveContainer>
              {renderChart()}
            </ResponsiveContainer>
          )
        ) : renderTableView()}
      </div>
    </div>
  );
};

export default AnalyticsWidget;