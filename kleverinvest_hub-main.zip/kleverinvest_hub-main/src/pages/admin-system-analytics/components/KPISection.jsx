import React from 'react';
import Icon from '../../../components/AppIcon';

const KPISection = ({ data }) => {
  const kpiItems = [
    {
      key: 'conversionRate',
      title: 'Conversion Rate',
      description: 'Visitor to user conversion',
      icon: 'Target',
      color: 'primary'
    },
    {
      key: 'userRetention',
      title: 'User Retention',
      description: '30-day retention rate',
      icon: 'Users',
      color: 'success'
    },
    {
      key: 'avgTransactionValue',
      title: 'Avg Transaction Value',
      description: 'Per transaction average',
      icon: 'DollarSign',
      color: 'warning'
    },
    {
      key: 'platformGrowth',
      title: 'Platform Growth',
      description: 'Monthly growth rate',
      icon: 'TrendingUp',
      color: 'info'
    }
  ];

  const getChangeColor = (trend) => {
    switch (trend) {
      case 'up':
        return 'text-green-600';
      case 'down':
        return 'text-red-600';
      default:
        return 'text-muted-foreground';
    }
  };

  const getChangeIcon = (trend) => {
    switch (trend) {
      case 'up':
        return 'ArrowUp';
      case 'down':
        return 'ArrowDown';
      default:
        return 'Minus';
    }
  };

  return (
    <div className="mb-8">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-foreground mb-2">Key Performance Indicators</h2>
        <p className="text-muted-foreground">
          Critical metrics with comparative period analysis
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiItems.map((item) => {
          const kpiData = data[item.key];
          return (
            <div key={item.key} className="bg-card border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg bg-${item.color}/10 flex items-center justify-center`}>
                  <Icon 
                    name={item.icon} 
                    size={24} 
                    className={`text-${item.color}`}
                  />
                </div>
                <div className={`flex items-center space-x-1 ${getChangeColor(kpiData?.trend)}`}>
                  <Icon name={getChangeIcon(kpiData?.trend)} size={16} />
                  <span className="text-sm font-medium">{kpiData?.change}</span>
                </div>
              </div>
              
              <div>
                <div className="text-2xl font-bold text-foreground mb-1">
                  {kpiData?.value}
                </div>
                <div className="text-sm font-medium text-foreground mb-1">
                  {item.title}
                </div>
                <div className="text-xs text-muted-foreground">
                  {item.description}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Comparative Analysis */}
      <div className="mt-6 bg-card border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Performance Trends</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">User Acquisition</span>
                <span className="text-sm text-green-600 font-medium">+18.5%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: '75%' }}></div>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Revenue Growth</span>
                <span className="text-sm text-green-600 font-medium">+22.3%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: '85%' }}></div>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Customer Satisfaction</span>
                <span className="text-sm text-green-600 font-medium">+5.2%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: '92%' }}></div>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="bg-muted/30 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="TrendingUp" size={16} className="text-green-600" />
                <span className="text-sm font-medium text-foreground">Top Performer</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Platform Growth rate exceeded targets by 4.2% this month
              </p>
            </div>
            
            <div className="bg-muted/30 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="AlertTriangle" size={16} className="text-yellow-600" />
                <span className="text-sm font-medium text-foreground">Needs Attention</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Average transaction value showing slight decline - investigate user behavior
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KPISection;