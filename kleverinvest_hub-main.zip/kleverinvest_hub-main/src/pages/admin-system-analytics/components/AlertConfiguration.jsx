import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const AlertConfiguration = () => {
  const [activeAlerts, setActiveAlerts] = useState([
    {
      id: 1,
      name: 'High Transaction Volume',
      metric: 'transaction_volume',
      condition: 'above',
      threshold: 50000,
      timeframe: '1h',
      enabled: true,
      severity: 'warning'
    },
    {
      id: 2,
      name: 'Low System Performance',
      metric: 'response_time',
      condition: 'above',
      threshold: 500,
      timeframe: '5m',
      enabled: true,
      severity: 'critical'
    },
    {
      id: 3,
      name: 'Revenue Drop',
      metric: 'revenue',
      condition: 'below',
      threshold: 100000,
      timeframe: '1d',
      enabled: false,
      severity: 'warning'
    }
  ]);

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newAlert, setNewAlert] = useState({
    name: '',
    metric: 'transaction_volume',
    condition: 'above',
    threshold: '',
    timeframe: '1h',
    severity: 'warning'
  });

  const metricOptions = [
    { value: 'transaction_volume', label: 'Transaction Volume' },
    { value: 'user_count', label: 'Active Users' },
    { value: 'revenue', label: 'Revenue' },
    { value: 'response_time', label: 'Response Time' },
    { value: 'error_rate', label: 'Error Rate' },
    { value: 'conversion_rate', label: 'Conversion Rate' }
  ];

  const conditionOptions = [
    { value: 'above', label: 'Above' },
    { value: 'below', label: 'Below' },
    { value: 'equals', label: 'Equals' }
  ];

  const timeframeOptions = [
    { value: '5m', label: '5 Minutes' },
    { value: '15m', label: '15 Minutes' },
    { value: '1h', label: '1 Hour' },
    { value: '4h', label: '4 Hours' },
    { value: '1d', label: '1 Day' }
  ];

  const severityOptions = [
    { value: 'info', label: 'Info' },
    { value: 'warning', label: 'Warning' },
    { value: 'critical', label: 'Critical' }
  ];

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'info': return 'text-blue-600 bg-blue-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'critical': return 'AlertTriangle';
      case 'warning': return 'AlertCircle';
      case 'info': return 'Info';
      default: return 'Bell';
    }
  };

  const toggleAlert = (alertId) => {
    setActiveAlerts(alerts => 
      alerts.map(alert => 
        alert.id === alertId 
          ? { ...alert, enabled: !alert.enabled }
          : alert
      )
    );
  };

  const deleteAlert = (alertId) => {
    setActiveAlerts(alerts => alerts.filter(alert => alert.id !== alertId));
  };

  const createAlert = () => {
    if (!newAlert.name || !newAlert.threshold) return;

    const alert = {
      id: Date.now(),
      ...newAlert,
      threshold: parseFloat(newAlert.threshold),
      enabled: true
    };

    setActiveAlerts(alerts => [...alerts, alert]);
    setNewAlert({
      name: '',
      metric: 'transaction_volume',
      condition: 'above',
      threshold: '',
      timeframe: '1h',
      severity: 'warning'
    });
    setShowCreateModal(false);
  };

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Alert Configuration</h3>
          <p className="text-sm text-muted-foreground">
            Configure automated alerts for threshold breaches and performance anomalies
          </p>
        </div>
        <Button onClick={() => setShowCreateModal(true)}>
          <Icon name="Plus" size={16} />
          New Alert
        </Button>
      </div>

      {/* Active Alerts */}
      <div className="space-y-4 mb-6">
        {activeAlerts.map((alert) => (
          <div key={alert.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
            <div className="flex items-center space-x-4">
              <div className={`p-2 rounded-lg ${getSeverityColor(alert.severity)}`}>
                <Icon name={getSeverityIcon(alert.severity)} size={20} />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-medium text-foreground">{alert.name}</span>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    alert.enabled ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                  }`}>
                    {alert.enabled ? 'Active' : 'Disabled'}
                  </div>
                </div>
                <div className="text-sm text-muted-foreground">
                  {metricOptions.find(m => m.value === alert.metric)?.label} {alert.condition} {alert.threshold.toLocaleString()} 
                  (checked every {alert.timeframe})
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleAlert(alert.id)}
              >
                <Icon name={alert.enabled ? "Pause" : "Play"} size={16} />
              </Button>
              <Button
                variant="ghost"
                size="sm" 
                onClick={() => deleteAlert(alert.id)}
                className="text-red-600 hover:text-red-700"
              >
                <Icon name="Trash2" size={16} />
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Performance Monitoring Summary */}
      <div className="bg-muted/30 rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-3">
          <Icon name="Activity" size={20} className="text-primary" />
          <span className="font-medium text-foreground">Alert Performance Summary</span>
        </div>
        <div className="grid grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-foreground">{activeAlerts.filter(a => a.enabled).length}</div>
            <div className="text-sm text-muted-foreground">Active Alerts</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">127</div>
            <div className="text-sm text-muted-foreground">Alerts Triggered</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">23</div>
            <div className="text-sm text-muted-foreground">False Positives</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-primary">98.2%</div>
            <div className="text-sm text-muted-foreground">Accuracy Rate</div>
          </div>
        </div>
      </div>

      {/* Create Alert Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card border rounded-lg p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Create New Alert</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowCreateModal(false)}
              >
                <Icon name="X" size={16} />
              </Button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Alert Name</label>
                <Input
                  value={newAlert.name}
                  onChange={(e) => setNewAlert({ ...newAlert, name: e.target.value })}
                  placeholder="Enter alert name"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Metric</label>
                  <Select
                    value={newAlert.metric}
                    onValueChange={(value) => setNewAlert({ ...newAlert, metric: value })}
                    options={metricOptions}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Condition</label>
                  <Select
                    value={newAlert.condition}
                    onValueChange={(value) => setNewAlert({ ...newAlert, condition: value })}
                    options={conditionOptions}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Threshold</label>
                  <Input
                    type="number"
                    value={newAlert.threshold}
                    onChange={(e) => setNewAlert({ ...newAlert, threshold: e.target.value })}
                    placeholder="Enter threshold value"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Timeframe</label>
                  <Select
                    value={newAlert.timeframe}
                    onValueChange={(value) => setNewAlert({ ...newAlert, timeframe: value })}
                    options={timeframeOptions}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Severity</label>
                <Select
                  value={newAlert.severity}
                  onValueChange={(value) => setNewAlert({ ...newAlert, severity: value })}
                  options={severityOptions}
                />
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3 mt-6">
              <Button
                variant="outline"
                onClick={() => setShowCreateModal(false)}
              >
                Cancel
              </Button>
              <Button onClick={createAlert}>
                Create Alert
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AlertConfiguration;