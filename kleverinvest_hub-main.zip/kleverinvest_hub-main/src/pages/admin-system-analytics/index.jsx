import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Select from '../../components/ui/Select';
import AdminNavigation from '../../components/ui/AdminNavigation';
import AnalyticsWidget from './components/AnalyticsWidget';
import KPISection from './components/KPISection';
import GeographicMap from './components/GeographicMap';
import RevenueAnalytics from './components/RevenueAnalytics';
import AlertConfiguration from './components/AlertConfiguration';

const AdminSystemAnalytics = () => {
  const navigate = useNavigate();
  const [dateRange, setDateRange] = useState('30d');
  const [userSegment, setUserSegment] = useState('all');
  const [cryptoFilter, setCryptoFilter] = useState('all');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every minute for real-time feel
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  // Mock real-time data update
  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      // Simulate real-time data updates
      console.log('Refreshing analytics data...');
    }, 30000);
    return () => clearInterval(interval);
  }, [autoRefresh]);

  // Filter options
  const dateRangeOptions = [
    { value: '24h', label: 'Last 24 Hours' },
    { value: '7d', label: 'Last 7 Days' },
    { value: '30d', label: 'Last 30 Days' },
    { value: '90d', label: 'Last 90 Days' },
    { value: '1y', label: 'Last Year' }
  ];

  const userSegmentOptions = [
    { value: 'all', label: 'All Users' },
    { value: 'new', label: 'New Users' },
    { value: 'active', label: 'Active Users' },
    { value: 'premium', label: 'Premium Users' },
    { value: 'dormant', label: 'Dormant Users' }
  ];

  const cryptoFilterOptions = [
    { value: 'all', label: 'All Cryptocurrencies' },
    { value: 'btc', label: 'Bitcoin (BTC)' },
    { value: 'eth', label: 'Ethereum (ETH)' },
    { value: 'usdt', label: 'Tether (USDT)' },
    { value: 'bnb', label: 'Binance Coin (BNB)' }
  ];

  // Mock analytics data
  const userAcquisitionData = [
    { name: 'Week 1', organic: 450, referral: 200, paid: 150 },
    { name: 'Week 2', organic: 520, referral: 240, paid: 180 },
    { name: 'Week 3', organic: 480, referral: 260, paid: 160 },
    { name: 'Week 4', organic: 600, referral: 300, paid: 200 }
  ];

  const transactionVolumeData = [
    { name: 'Jan', volume: 2400000, transactions: 12000 },
    { name: 'Feb', volume: 2800000, transactions: 14000 },
    { name: 'Mar', volume: 3200000, transactions: 16000 },
    { name: 'Apr', volume: 3600000, transactions: 18000 },
    { name: 'May', volume: 4000000, transactions: 20000 },
    { name: 'Jun', volume: 4400000, transactions: 22000 }
  ];

  const revenueData = [
    { name: 'Trading Fees', value: 1200000, percentage: 45 },
    { name: 'Investment Returns', value: 800000, percentage: 30 },
    { name: 'Subscription Fees', value: 400000, percentage: 15 },
    { name: 'Other Services', value: 266667, percentage: 10 }
  ];

  const cryptoPerformanceData = [
    { name: 'BTC', price: 45000, change: 2.5, volume: 890000000 },
    { name: 'ETH', price: 3200, change: -1.2, volume: 450000000 },
    { name: 'USDT', price: 1, change: 0.01, volume: 2100000000 },
    { name: 'BNB', price: 420, change: 3.8, volume: 120000000 },
    { name: 'ADA', price: 1.2, change: -0.5, volume: 80000000 }
  ];

  // KPI data
  const kpiData = {
    conversionRate: { value: '3.2%', change: '+0.3%', trend: 'up' },
    userRetention: { value: '78.5%', change: '+2.1%', trend: 'up' },
    avgTransactionValue: { value: '$2,847', change: '-1.2%', trend: 'down' },
    platformGrowth: { value: '24.7%', change: '+4.2%', trend: 'up' }
  };

  // Geographic data
  const geographicData = [
    { country: 'United States', users: 3547, percentage: 28.5 },
    { country: 'United Kingdom', users: 2156, percentage: 17.3 },
    { country: 'Germany', users: 1834, percentage: 14.7 },
    { country: 'Japan', users: 1298, percentage: 10.4 },
    { country: 'Canada', users: 987, percentage: 7.9 },
    { country: 'Others', users: 2625, percentage: 21.2 }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Navigation */}
      <AdminNavigation
        title="System Analytics"
        breadcrumb={[
          { label: "Analytics", link: null },
          { label: "System Overview", link: null }
        ]}
        actions={[
          {
            label: autoRefresh ? 'Pause' : 'Resume',
            icon: autoRefresh ? "Pause" : "Play",
            variant: "outline",
            onClick: () => setAutoRefresh(!autoRefresh)
          },
          {
            label: "Export Report",
            icon: "Download",
            variant: "outline",
            onClick: () => {
              alert('Exporting analytics report...');
            }
          }
        ]}
      />

      <div className="p-6">
        {/* Advanced Filtering */}
        <div className="bg-card border rounded-lg p-6 mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">Advanced Analytics Filters</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Date Range</label>
              <Select
                value={dateRange}
                onChange={setDateRange}
                options={dateRangeOptions}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">User Segment</label>
              <Select
                value={userSegment}
                onChange={setUserSegment}
                options={userSegmentOptions}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Cryptocurrency Focus</label>
              <Select
                value={cryptoFilter}
                onChange={setCryptoFilter}
                options={cryptoFilterOptions}
              />
            </div>
          </div>
        </div>

        {/* KPI Section */}
        <KPISection data={kpiData} />

        {/* Multi-dimensional Analytics Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <AnalyticsWidget
            title="User Acquisition Metrics"
            type="multiline"
            data={userAcquisitionData}
            height={350}
            description="Organic, referral, and paid acquisition channels"
          />
          <AnalyticsWidget
            title="Transaction Volume Trends"
            type="area"
            data={transactionVolumeData}
            height={350}
            description="Monthly transaction volume and count"
          />
          <AnalyticsWidget
            title="Revenue Distribution"
            type="doughnut"
            data={revenueData}
            height={350}
            description="Revenue breakdown by service category"
          />
          <AnalyticsWidget
            title="Cryptocurrency Performance"
            type="performance"
            data={cryptoPerformanceData}
            height={350}
            description="Price changes and trading volumes"
          />
        </div>

        {/* Geographic Distribution and Revenue Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <GeographicMap data={geographicData} />
          <RevenueAnalytics />
        </div>

        {/* Alert Configuration */}
        <AlertConfiguration />
      </div>
    </div>
  );
};

export default AdminSystemAnalytics;
