import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../home-landing-page/components/Header';
import Footer from '../home-landing-page/components/Footer';
import HeroSection from './components/HeroSection';
import StepByStepProcess from './components/StepByStepProcess';
import InvestmentLifecycle from './components/InvestmentLifecycle';
import VideoTutorials from './components/VideoTutorials';
import FAQSection from './components/FAQSection';
import GettingStartedChecklist from './components/GettingStartedChecklist';

const HowItWorks = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: isLoaded ? 1 : 0 }}
        transition={{ duration: 0.5 }}
        className="pt-16"
      >
        <HeroSection />
        <StepByStepProcess />
        <InvestmentLifecycle />
        <VideoTutorials />
        <FAQSection />
        <GettingStartedChecklist />
      </motion.main>

      <Footer />
    </div>
  );
};

export default HowItWorks;