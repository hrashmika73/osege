import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const VideoTutorials = () => {
  const [selectedCategory, setSelectedCategory] = useState('getting-started');
  const [playingVideo, setPlayingVideo] = useState(null);

  const categories = [
    { id: 'getting-started', label: 'Getting Started', icon: 'Play' },
    { id: 'account-setup', label: 'Account Setup', icon: 'UserPlus' },
    { id: 'investment-basics', label: 'Investment Basics', icon: 'TrendingUp' },
    { id: 'advanced-features', label: 'Advanced Features', icon: 'Settings' }
  ];

  const tutorials = {
    'getting-started': [
      {
        id: 1,
        title: 'Welcome to KleverInvest Hub',
        duration: '3:24',
        thumbnail: '/api/placeholder/320/180',
        description: 'Complete overview of our platform and investment opportunities',
        views: '15.2K'
      },
      {
        id: 2,
        title: 'Your First Investment',
        duration: '5:18',
        thumbnail: '/api/placeholder/320/180',
        description: 'Step-by-step guide to making your first cryptocurrency investment',
        views: '12.8K'
      },
      {
        id: 3,
        title: 'Understanding Returns',
        duration: '4:12',
        thumbnail: '/api/placeholder/320/180',
        description: 'How our investment returns work and profit calculation',
        views: '9.7K'
      }
    ],
    'account-setup': [
      {
        id: 4,
        title: 'Account Registration Process',
        duration: '2:45',
        thumbnail: '/api/placeholder/320/180',
        description: 'Complete guide to creating and verifying your account',
        views: '8.3K'
      },
      {
        id: 5,
        title: 'KYC Verification Made Easy',
        duration: '3:56',
        thumbnail: '/api/placeholder/320/180',
        description: 'Document requirements and verification process',
        views: '7.1K'
      },
      {
        id: 6,
        title: 'Security Setup Guide',
        duration: '4:33',
        thumbnail: '/api/placeholder/320/180',
        description: '2FA setup and account security best practices',
        views: '6.8K'
      }
    ],
    'investment-basics': [
      {
        id: 7,
        title: 'Choosing Investment Plans',
        duration: '6:21',
        thumbnail: '/api/placeholder/320/180',
        description: 'Compare plans and select the right investment strategy',
        views: '11.4K'
      },
      {
        id: 8,
        title: 'Risk Management Basics',
        duration: '5:07',
        thumbnail: '/api/placeholder/320/180',
        description: 'Understanding investment risks and mitigation strategies',
        views: '9.2K'
      },
      {
        id: 9,
        title: 'Portfolio Diversification',
        duration: '4:44',
        thumbnail: '/api/placeholder/320/180',
        description: 'Building a balanced cryptocurrency investment portfolio',
        views: '8.6K'
      }
    ],
    'advanced-features': [
      {
        id: 10,
        title: 'Advanced Analytics Dashboard',
        duration: '7:15',
        thumbnail: '/api/placeholder/320/180',
        description: 'Using advanced tools for investment analysis',
        views: '5.9K'
      },
      {
        id: 11,
        title: 'Automated Reinvestment',
        duration: '3:38',
        thumbnail: '/api/placeholder/320/180',
        description: 'Setting up automatic profit reinvestment strategies',
        views: '4.7K'
      },
      {
        id: 12,
        title: 'Tax Reporting Tools',
        duration: '5:52',
        thumbnail: '/api/placeholder/320/180',
        description: 'Generate tax reports and documentation',
        views: '3.8K'
      }
    ]
  };

  return (
    <section className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Video{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Tutorials
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Learn with guided video walkthroughs covering every aspect of the platform
          </motion.p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              className={selectedCategory === category.id 
                ? "gradient-gold text-black font-semibold" :"border-orange-500 text-orange-400 hover:bg-orange-500/10"
              }
              onClick={() => setSelectedCategory(category.id)}
            >
              <Icon name={category.icon} size={16} className="mr-2" />
              {category.label}
            </Button>
          ))}
        </div>

        {/* Video Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {tutorials[selectedCategory]?.map((tutorial, index) => (
            <motion.div
              key={tutorial.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="glass-effect rounded-xl overflow-hidden hover:bg-card/80 transition-all duration-300 group cursor-pointer"
              onClick={() => setPlayingVideo(tutorial.id)}
            >
              {/* Video Thumbnail */}
              <div className="relative">
                <div className="aspect-video bg-gradient-to-br from-orange-500/20 to-yellow-500/20 flex items-center justify-center">
                  {playingVideo === tutorial.id ? (
                    <div className="w-full h-full bg-black flex items-center justify-center">
                      <Icon name="Play" size={48} className="text-white" />
                    </div>
                  ) : (
                    <>
                      <div className="absolute inset-0 bg-gradient-to-br from-orange-500/20 to-yellow-500/20"></div>
                      <div className="relative z-10 w-16 h-16 gradient-gold rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Icon name="Play" size={24} color="black" />
                      </div>
                    </>
                  )}
                </div>
                
                {/* Duration Badge */}
                <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded">
                  {tutorial.duration}
                </div>
              </div>

              {/* Video Info */}
              <div className="p-6">
                <h3 className="font-bold text-lg mb-2 group-hover:text-orange-400 transition-colors">
                  {tutorial.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {tutorial.description}
                </p>
                
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Icon name="Eye" size={12} />
                    <span>{tutorial.views} views</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Clock" size={12} />
                    <span>{tutorial.duration}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <Button variant="outline" className="border-orange-500 text-orange-400 hover:bg-orange-500/10">
            View All Tutorials
            <Icon name="ArrowRight" size={16} className="ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default VideoTutorials;