import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FAQSection = () => {
  const [expandedFAQ, setExpandedFAQ] = useState(0);
  const navigate = useNavigate();

  const faqCategories = [
    {
      title: 'Investment Process',
      faqs: [
        {
          question: 'How long does it take to start earning returns?',
          answer: 'Returns begin generating within 24 hours of your investment activation. You can track your earnings in real-time through your dashboard.'
        },
        {
          question: 'What is the minimum investment amount?',
          answer: 'The minimum investment starts at $100 USD equivalent in cryptocurrency. This allows new investors to get started with a manageable amount.'
        },
        {
          question: 'Can I withdraw my profits anytime?',
          answer: 'Yes, you can request profit withdrawals at any time. Standard withdrawals are processed within 24-48 hours, with instant withdrawal options available for premium accounts.'
        }
      ]
    },
    {
      title: 'Security & Safety',
      faqs: [
        {
          question: 'How secure are my funds and personal information?',
          answer: 'We employ bank-grade security measures including cold storage for funds, SSL encryption, and strict KYC/AML compliance to protect your assets and data.'
        },
        {
          question: 'What happens if I lose access to my account?',
          answer: 'Our support team can help recover your account through our secure verification process. We recommend enabling 2FA and keeping recovery codes safe.'
        },
        {
          question: 'Are my investments insured?',
          answer: 'Yes, we maintain comprehensive insurance coverage for digital assets and have partnerships with leading cryptocurrency custody providers.'
        }
      ]
    },
    {
      title: 'Platform Features',
      faqs: [
        {
          question: 'How do I track my investment performance?',
          answer: 'Your dashboard provides real-time performance metrics, profit calculations, and detailed analytics. You can also set up email notifications for important updates.'
        },
        {
          question: 'Can I change my investment strategy?',
          answer: 'Yes, you can modify your investment allocation or switch between plans. Changes take effect at the next investment cycle.'
        },
        {
          question: 'What customer support is available?',
          answer: '24/7 customer support through live chat, email, and phone. Premium account holders get priority support with dedicated account managers.'
        }
      ]
    }
  ];

  const allFAQs = faqCategories.flatMap((category, categoryIndex) => 
    category.faqs.map((faq, faqIndex) => ({
      ...faq,
      categoryTitle: category.title,
      globalIndex: categoryIndex * 10 + faqIndex
    }))
  );

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Frequently Asked{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Questions
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Get answers to common questions about our investment process and platform features
          </motion.p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="space-y-4">
            {allFAQs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="glass-effect rounded-xl overflow-hidden"
              >
                <button
                  className="w-full p-6 text-left flex items-center justify-between hover:bg-card/50 transition-colors"
                  onClick={() => setExpandedFAQ(expandedFAQ === index ? -1 : index)}
                >
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-1">
                      <span className="text-xs text-orange-400 font-medium">
                        {faq.categoryTitle}
                      </span>
                    </div>
                    <h3 className="font-semibold text-lg">{faq.question}</h3>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 gradient-gold rounded-full flex items-center justify-center flex-shrink-0">
                      <Icon 
                        name={expandedFAQ === index ? "Minus" : "Plus"} 
                        size={16} 
                        color="black" 
                      />
                    </div>
                  </div>
                </button>

                {expandedFAQ === index && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="px-6 pb-6"
                  >
                    <div className="border-t border-border pt-4">
                      <p className="text-muted-foreground leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ))}
          </div>

          {/* Contact Support */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="text-center mt-12 p-8 glass-effect rounded-xl"
          >
            <Icon name="MessageCircle" size={48} className="text-orange-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">Still have questions?</h3>
            <p className="text-muted-foreground mb-6">
              Our support team is available 24/7 to help you with any questions
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button
                className="gradient-gold text-black font-semibold px-6 py-3 hover:scale-105 transition-transform"
                onClick={() => navigate('/contact')}
              >
                Contact Support
                <Icon name="ArrowRight" size={16} className="ml-2 inline" />
              </Button>
              <Button
                variant="outline"
                className="border-orange-500 text-orange-400 hover:bg-orange-500/10 px-6 py-3"
                onClick={() => navigate('/support-chat-system')}
              >
                Live Chat
                <Icon name="MessageSquare" size={16} className="ml-2 inline" />
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
