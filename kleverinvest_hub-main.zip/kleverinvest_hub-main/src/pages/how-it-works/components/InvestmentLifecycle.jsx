import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const InvestmentLifecycle = () => {
  const [activePhase, setActivePhase] = useState(0);

  const phases = [
    {
      title: 'Initial Deposit',
      duration: 'Day 1',
      description: 'Your investment begins with secure fund deposit',
      milestones: ['Account verification', 'Fund deposit', 'Investment allocation'],
      progress: 100,
      color: 'from-green-500 to-emerald-500'
    },
    {
      title: 'Growth Phase',
      duration: 'Days 2-30',
      description: 'Your investment starts generating returns',
      milestones: ['Market analysis', 'Strategic positioning', 'Daily compounding'],
      progress: 75,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      title: 'Optimization',
      duration: 'Days 31-90',
      description: 'Portfolio optimization for maximum returns',
      milestones: ['Performance review', 'Strategy adjustment', 'Risk management'],
      progress: 50,
      color: 'from-orange-500 to-yellow-500'
    },
    {
      title: 'Profit Realization',
      duration: 'Day 91+',
      description: 'Harvest profits and reinvest or withdraw',
      milestones: ['Profit calculation', 'Withdrawal options', 'Reinvestment choices'],
      progress: 25,
      color: 'from-purple-500 to-pink-500'
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setActivePhase((prev) => (prev + 1) % phases.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [phases.length]);

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Investment{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Lifecycle
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Track your investment journey from initial deposit through profit realization
          </motion.p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Timeline Visualization */}
          <div className="relative mb-16">
            {/* Progress Line */}
            <div className="absolute top-1/2 left-0 w-full h-1 bg-border transform -translate-y-1/2"></div>
            <motion.div
              className="absolute top-1/2 left-0 h-1 bg-gradient-to-r from-orange-400 to-yellow-500 transform -translate-y-1/2"
              initial={{ width: '0%' }}
              animate={{ width: `${((activePhase + 1) / phases.length) * 100}%` }}
              transition={{ duration: 0.5 }}
            ></motion.div>

            {/* Phase Points */}
            <div className="relative flex justify-between">
              {phases.map((phase, index) => (
                <motion.div
                  key={index}
                  className={`flex flex-col items-center cursor-pointer ${
                    index <= activePhase ? 'opacity-100' : 'opacity-50'
                  }`}
                  onClick={() => setActivePhase(index)}
                  whileHover={{ scale: 1.05 }}
                >
                  <div
                    className={`w-16 h-16 rounded-full bg-gradient-to-r ${phase.color} flex items-center justify-center mb-4 relative z-10 ${
                      index === activePhase ? 'ring-4 ring-orange-500/30' : ''
                    }`}
                  >
                    <Icon name="Target" size={20} color="white" />
                  </div>
                  <div className="text-center">
                    <h3 className="font-bold text-sm mb-1">{phase.title}</h3>
                    <p className="text-xs text-orange-400">{phase.duration}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Active Phase Details */}
          <motion.div
            key={activePhase}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="glass-effect p-8 rounded-xl"
          >
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-bold mb-4">{phases[activePhase]?.title}</h3>
                <p className="text-muted-foreground mb-6">{phases[activePhase]?.description}</p>
                
                <div className="space-y-3">
                  <h4 className="font-semibold text-orange-400">Key Milestones:</h4>
                  {phases[activePhase]?.milestones?.map((milestone, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <Icon name="CheckCircle" size={16} className="text-green-500" />
                      <span className="text-sm">{milestone}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="text-center">
                {/* Progress Circle */}
                <div className="relative w-48 h-48 mx-auto mb-6">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle
                      cx="96"
                      cy="96"
                      r="80"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="none"
                      className="text-border"
                    />
                    <motion.circle
                      cx="96"
                      cy="96"
                      r="80"
                      stroke="url(#gradient)"
                      strokeWidth="8"
                      fill="none"
                      strokeLinecap="round"
                      initial={{ pathLength: 0 }}
                      animate={{ pathLength: phases[activePhase]?.progress / 100 }}
                      transition={{ duration: 1, ease: "easeInOut" }}
                      style={{ strokeDasharray: "502.65", strokeDashoffset: 0 }}
                    />
                    <defs>
                      <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#F97316" />
                        <stop offset="100%" stopColor="#EAB308" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-orange-400">
                        {phases[activePhase]?.progress}%
                      </div>
                      <div className="text-sm text-muted-foreground">Complete</div>
                    </div>
                  </div>
                </div>

                <div className="text-lg font-semibold text-orange-400">
                  {phases[activePhase]?.duration}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default InvestmentLifecycle;