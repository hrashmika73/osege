import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const HeroSection = () => {
  const navigate = useNavigate();

  const keyFeatures = [
    { icon: 'BookOpen', text: 'Step-by-Step Guidance' },
    { icon: 'PlayCircle', text: 'Video Tutorials' },
    { icon: 'CheckCircle2', text: 'Interactive Checklists' }
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute top-16 left-8 w-28 h-28 gradient-gold rounded-full opacity-10 animate-pulse"></div>
        <div className="absolute bottom-24 right-12 w-20 h-20 bg-orange-500 rounded-full opacity-20 animate-bounce"></div>
        <motion.div
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
          animate={{ rotate: 360 }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        >
          <div className="w-72 h-72 border border-orange-500/15 rounded-full"></div>
        </motion.div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-4xl md:text-6xl font-bold mb-6"
          >
            How{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              It Works
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto"
          >
            Master the cryptocurrency investment process with our comprehensive step-by-step guide. 
            From account setup to profit realization, we'll walk you through every stage.
          </motion.p>

          {/* Key Features */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="flex flex-wrap justify-center gap-6 mb-12"
          >
            {keyFeatures.map((feature, index) => (
              <div
                key={index}
                className="flex items-center space-x-2 glass-effect px-4 py-2 rounded-full"
              >
                <div className="w-8 h-8 gradient-gold rounded-full flex items-center justify-center">
                  <Icon name={feature.icon} size={16} color="black" />
                </div>
                <span className="text-sm font-medium">{feature.text}</span>
              </div>
            ))}
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            className="flex flex-col sm:flex-row justify-center gap-4"
          >
            <Button
              className="gradient-gold text-black font-semibold px-8 py-3 hover:scale-105 transition-transform"
              onClick={() => navigate('/signup')}
            >
              Get Started Now
              <Icon name="ArrowRight" size={16} className="ml-2" />
            </Button>
            <Button
              variant="outline"
              className="border-orange-500 text-orange-400 hover:bg-orange-500/10 px-8 py-3"
              onClick={() => window.open('https://www.youtube.com/watch?v=dQw4w9WgXcQ', '_blank')}
            >
              Watch Tutorial
              <Icon name="Play" size={16} className="ml-2" />
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
