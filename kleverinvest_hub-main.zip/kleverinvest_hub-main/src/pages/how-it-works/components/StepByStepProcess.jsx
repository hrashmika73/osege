import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';


const StepByStepProcess = () => {
  const [expandedStep, setExpandedStep] = useState(0);

  const steps = [
    {
      number: '01',
      title: 'Account Registration',
      subtitle: 'Complete KYC & Identity Verification',
      description: 'Create your secure account with comprehensive identity verification for regulatory compliance.',
      details: [
        'Complete personal information form',
        'Upload government-issued ID documents',
        'Verify email and phone number',
        'Complete KYC verification process',
        'Set up two-factor authentication'
      ],
      icon: 'UserPlus',
      duration: '5-10 minutes',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      number: '02',
      title: 'Fund Deposit',
      subtitle: 'Multiple Payment Methods Available',
      description: 'Securely deposit funds using cryptocurrency transfers, bank wire, or other supported methods.',
      details: [
        'Choose from multiple payment methods',
        'Bank wire transfers (3-5 business days)',
        'Cryptocurrency deposits (instant)',
        'Credit/debit card payments',
        'View real-time deposit confirmations'
      ],
      icon: 'CreditCard',
      duration: 'Instant - 5 days',
      color: 'from-green-500 to-emerald-500'
    },
    {
      number: '03',
      title: 'Investment Selection',
      subtitle: 'Choose Your Investment Strategy',
      description: 'Select from various investment plans tailored to your risk tolerance and financial goals.',
      details: [
        'Compare investment plans side-by-side',
        'Complete risk assessment questionnaire',
        'Review historical performance data',
        'Customize portfolio allocation',
        'Set investment amount and duration'
      ],
      icon: 'Target',
      duration: '10-15 minutes',
      color: 'from-orange-500 to-yellow-500'
    },
    {
      number: '04',
      title: 'Earnings Management',
      subtitle: 'Track & Manage Your Returns',
      description: 'Monitor your investment performance and manage earnings with flexible withdrawal options.',
      details: [
        'Real-time profit tracking dashboard',
        'Flexible withdrawal schedules',
        'Reinvestment opportunities',
        'Performance analytics and reports',
        'Tax documentation support'
      ],
      icon: 'TrendingUp',
      duration: 'Ongoing',
      color: 'from-purple-500 to-pink-500'
    }
  ];

  return (
    <section className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Investment Process{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Simplified
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Follow these four simple steps to start your cryptocurrency investment journey
          </motion.p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Desktop Layout */}
          <div className="hidden md:block">
            <div className="grid grid-cols-4 gap-8">
              {steps.map((step, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className={`relative cursor-pointer group ${
                    expandedStep === index ? 'transform scale-105' : ''
                  }`}
                  onClick={() => setExpandedStep(expandedStep === index ? -1 : index)}
                >
                  {/* Connecting Line */}
                  {index < steps.length - 1 && (
                    <div className="absolute top-16 left-full w-8 h-0.5 bg-gradient-to-r from-orange-500 to-transparent z-10"></div>
                  )}

                  <div className="glass-effect p-6 rounded-xl hover:bg-card/80 transition-all duration-300">
                    {/* Step Number */}
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${step.color} flex items-center justify-center mb-4 mx-auto`}>
                      <span className="text-white font-bold text-lg">{step.number}</span>
                    </div>

                    {/* Icon */}
                    <div className="w-16 h-16 gradient-gold rounded-full flex items-center justify-center mb-4 mx-auto">
                      <Icon name={step.icon} size={24} color="black" />
                    </div>

                    {/* Content */}
                    <h3 className="text-lg font-bold text-center mb-2">{step.title}</h3>
                    <p className="text-sm text-orange-400 text-center mb-3">{step.subtitle}</p>
                    <p className="text-sm text-muted-foreground text-center mb-4">{step.description}</p>
                    
                    {/* Duration */}
                    <div className="flex items-center justify-center space-x-2 mb-4">
                      <Icon name="Clock" size={14} className="text-orange-400" />
                      <span className="text-xs text-orange-400">{step.duration}</span>
                    </div>

                    {/* Expanded Details */}
                    {expandedStep === index && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="border-t border-border pt-4"
                      >
                        <ul className="space-y-2">
                          {step.details?.map((detail, detailIndex) => (
                            <li key={detailIndex} className="flex items-start space-x-2">
                              <Icon name="Check" size={14} className="text-green-500 mt-0.5 flex-shrink-0" />
                              <span className="text-xs text-muted-foreground">{detail}</span>
                            </li>
                          ))}
                        </ul>
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Mobile Accordion Layout */}
          <div className="md:hidden space-y-4">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="glass-effect rounded-xl overflow-hidden"
              >
                <button
                  className="w-full p-6 text-left flex items-center space-x-4"
                  onClick={() => setExpandedStep(expandedStep === index ? -1 : index)}
                >
                  <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${step.color} flex items-center justify-center flex-shrink-0`}>
                    <span className="text-white font-bold">{step.number}</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{step.title}</h3>
                    <p className="text-sm text-orange-400">{step.subtitle}</p>
                  </div>
                  <Icon 
                    name={expandedStep === index ? "ChevronUp" : "ChevronDown"} 
                    size={20} 
                    className="text-muted-foreground" 
                  />
                </button>

                {expandedStep === index && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="px-6 pb-6"
                  >
                    <p className="text-muted-foreground mb-4">{step.description}</p>
                    <div className="flex items-center space-x-2 mb-4">
                      <Icon name="Clock" size={14} className="text-orange-400" />
                      <span className="text-sm text-orange-400">{step.duration}</span>
                    </div>
                    <ul className="space-y-2">
                      {step.details?.map((detail, detailIndex) => (
                        <li key={detailIndex} className="flex items-start space-x-2">
                          <Icon name="Check" size={14} className="text-green-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-muted-foreground">{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default StepByStepProcess;