import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const GettingStartedChecklist = () => {
  const [completedItems, setCompletedItems] = useState(new Set([0])); // First item completed by default

  const checklistItems = [
    {
      title: 'Create Your Account',
      description: 'Sign up and complete email verification',
      duration: '2 minutes',
      action: 'Register Now',
      icon: 'UserPlus',
      status: 'completed'
    },
    {
      title: 'Complete KYC Verification',
      description: 'Upload ID documents and verify your identity',
      duration: '5 minutes',
      action: 'Verify Identity',
      icon: 'ShieldCheck',
      status: 'current'
    },
    {
      title: 'Set Up Security',
      description: 'Enable 2FA and secure your account',
      duration: '3 minutes',
      action: 'Setup Security',
      icon: 'Lock',
      status: 'pending'
    },
    {
      title: 'Make First Deposit',
      description: 'Fund your account with minimum $100',
      duration: '5 minutes',
      action: 'Deposit Funds',
      icon: 'CreditCard',
      status: 'pending'
    },
    {
      title: 'Choose Investment Plan',
      description: 'Select the plan that matches your goals',
      duration: '10 minutes',
      action: 'View Plans',
      icon: 'Target',
      status: 'pending'
    },
    {
      title: 'Start Investing',
      description: 'Make your first investment and start earning',
      duration: '2 minutes',
      action: 'Start Now',
      icon: 'TrendingUp',
      status: 'pending'
    }
  ];

  const toggleComplete = (index) => {
    const newCompleted = new Set(completedItems);
    if (newCompleted.has(index)) {
      newCompleted.delete(index);
    } else {
      newCompleted.add(index);
    }
    setCompletedItems(newCompleted);
  };

  const completionPercentage = (completedItems.size / checklistItems.length) * 100;

  return (
    <section className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Getting Started{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Checklist
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Follow this step-by-step checklist to set up your account and start investing
          </motion.p>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Progress Overview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="glass-effect p-8 rounded-xl mb-12"
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold">Your Progress</h3>
                <p className="text-muted-foreground">
                  {completedItems.size} of {checklistItems.length} steps completed
                </p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-orange-400">
                  {Math.round(completionPercentage)}%
                </div>
                <div className="text-sm text-muted-foreground">Complete</div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-border rounded-full h-3 mb-4">
              <motion.div
                className="h-3 gradient-gold rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${completionPercentage}%` }}
                transition={{ duration: 0.5 }}
              ></motion.div>
            </div>

            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                {completionPercentage === 100 
                  ? "🎉 Congratulations! You're ready to start investing!" 
                  : `${checklistItems.length - completedItems.size} steps remaining to get started`
                }
              </p>
            </div>
          </motion.div>

          {/* Checklist Items */}
          <div className="space-y-4">
            {checklistItems.map((item, index) => {
              const isCompleted = completedItems.has(index);
              const isCurrent = !isCompleted && (index === 0 || completedItems.has(index - 1));
              
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className={`glass-effect rounded-xl p-6 transition-all duration-300 ${
                    isCompleted 
                      ? 'bg-green-500/10 border-green-500/30' 
                      : isCurrent 
                        ? 'bg-orange-500/10 border-orange-500/30 ring-2 ring-orange-500/20' :'opacity-60'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    {/* Step Number/Icon */}
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 cursor-pointer transition-all ${
                        isCompleted
                          ? 'bg-green-500 text-white'
                          : isCurrent
                            ? 'gradient-gold text-black' :'bg-border text-muted-foreground'
                      }`}
                      onClick={() => toggleComplete(index)}
                    >
                      {isCompleted ? (
                        <Icon name="Check" size={20} />
                      ) : (
                        <Icon name={item.icon} size={20} />
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className={`font-bold text-lg mb-1 ${
                            isCompleted ? 'line-through text-muted-foreground' : ''
                          }`}>
                            {item.title}
                          </h3>
                          <p className="text-muted-foreground text-sm mb-2">
                            {item.description}
                          </p>
                          <div className="flex items-center space-x-4 text-xs">
                            <div className="flex items-center space-x-1">
                              <Icon name="Clock" size={12} className="text-orange-400" />
                              <span className="text-orange-400">{item.duration}</span>
                            </div>
                            {isCompleted && (
                              <div className="flex items-center space-x-1">
                                <Icon name="CheckCircle" size={12} className="text-green-500" />
                                <span className="text-green-500">Completed</span>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Action Button */}
                        <Button
                          size="sm"
                          variant={isCompleted ? "outline" : isCurrent ? "default" : "ghost"}
                          className={
                            isCompleted
                              ? "border-green-500 text-green-500"
                              : isCurrent
                                ? "gradient-gold text-black font-semibold" :"opacity-50 cursor-not-allowed"
                          }
                          disabled={!isCurrent && !isCompleted}
                        >
                          {isCompleted ? 'Completed' : item.action}
                          {!isCompleted && <Icon name="ArrowRight" size={14} className="ml-2" />}
                        </Button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Next Steps */}
          {completionPercentage === 100 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mt-12 p-8 glass-effect rounded-xl bg-green-500/10 border-green-500/30"
            >
              <Icon name="Award" size={48} className="text-green-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2">🎉 You're All Set!</h3>
              <p className="text-muted-foreground mb-6">
                Congratulations! You've completed all the setup steps and are ready to start your investment journey.
              </p>
              <Button className="gradient-gold text-black font-semibold px-8 py-3 hover:scale-105 transition-transform">
                Go to Dashboard
                <Icon name="ArrowRight" size={16} className="ml-2" />
              </Button>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
};

export default GettingStartedChecklist;