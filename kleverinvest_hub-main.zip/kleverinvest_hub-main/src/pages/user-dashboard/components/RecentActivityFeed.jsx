import React from 'react';
import Icon from '../../../components/AppIcon';

const RecentActivityFeed = ({ activities }) => {
  const getActivityIcon = (type) => {
    switch (type) {
      case 'investment_completed': return 'CheckCircle';
      case 'deposit': return 'ArrowDownLeft';
      case 'withdrawal': return 'ArrowUpRight';
      case 'earning': return 'DollarSign';
      default: return 'Activity';
    }
  };

  const getActivityColor = (type) => {
    switch (type) {
      case 'investment_completed': return 'text-green-600 bg-green-100';
      case 'deposit': return 'text-blue-600 bg-blue-100';
      case 'withdrawal': return 'text-orange-600 bg-orange-100';
      case 'earning': return 'text-purple-600 bg-purple-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'failed': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const formatTime = (timestamp) => {
    const now = new Date();
    const diff = now - new Date(timestamp);
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) {
      const minutes = Math.floor(diff / (1000 * 60));
      return `${minutes}m ago`;
    } else if (hours < 24) {
      return `${hours}h ago`;
    } else {
      const days = Math.floor(hours / 24);
      return `${days}d ago`;
    }
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-slate-900">Recent Activity</h3>
        <button className="text-sm text-orange-600 hover:text-orange-700 font-medium">
          View all
        </button>
      </div>

      <div className="space-y-4">
        {activities?.map((activity) => (
          <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 transition-colors">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${getActivityColor(activity.type)}`}>
              <Icon name={getActivityIcon(activity.type)} size={16} />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className="font-medium text-slate-900 text-sm">{activity.title}</p>
                <span className="text-sm font-medium text-slate-900">{activity.amount}</span>
              </div>
              <p className="text-sm text-slate-600 mt-1">{activity.description}</p>
              
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs text-slate-500">{formatTime(activity.timestamp)}</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(activity.status)}`}>
                  {activity.status}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-slate-200 text-center">
        <p className="text-sm text-slate-600">
          <Icon name="Bell" size={14} className="inline mr-1" />
          You have {activities?.filter(a => a.status === 'pending')?.length} pending actions
        </p>
      </div>
    </div>
  );
};

export default RecentActivityFeed;