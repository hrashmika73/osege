import React from 'react';
import Icon from '../../../components/AppIcon';

const PortfolioOverviewCard = ({ portfolioData }) => {
  const { totalValue, dayChange, dayChangeAmount, totalProfit, profitPercentage, totalInvested } = portfolioData || {};

  const isPositiveChange = dayChange >= 0;
  const isPositiveProfit = totalProfit >= 0;

  return (
    <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-6 text-white shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold opacity-90">Total Portfolio Value</h2>
          <p className="text-3xl font-bold">${totalValue?.toLocaleString()}</p>
        </div>
        <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
          <Icon name="Wallet" size={24} color="white" />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* 24h Change */}
        <div className="bg-white/10 rounded-xl p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon 
              name={isPositiveChange ? 'TrendingUp' : 'TrendingDown'} 
              size={16} 
              color={isPositiveChange ? '#10b981' : '#ef4444'}
            />
            <span className="text-sm opacity-90">24h Change</span>
          </div>
          <p className={`text-lg font-semibold ${isPositiveChange ? 'text-green-300' : 'text-red-300'}`}>
            {isPositiveChange ? '+' : ''}{dayChange}%
          </p>
          <p className={`text-sm ${isPositiveChange ? 'text-green-300' : 'text-red-300'}`}>
            {isPositiveChange ? '+' : ''}${dayChangeAmount?.toLocaleString()}
          </p>
        </div>

        {/* Total Profit/Loss */}
        <div className="bg-white/10 rounded-xl p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon 
              name={isPositiveProfit ? 'ArrowUp' : 'ArrowDown'} 
              size={16} 
              color={isPositiveProfit ? '#10b981' : '#ef4444'}
            />
            <span className="text-sm opacity-90">Total P&L</span>
          </div>
          <p className={`text-lg font-semibold ${isPositiveProfit ? 'text-green-300' : 'text-red-300'}`}>
            {isPositiveProfit ? '+' : ''}${totalProfit?.toLocaleString()}
          </p>
          <p className={`text-sm ${isPositiveProfit ? 'text-green-300' : 'text-red-300'}`}>
            {isPositiveProfit ? '+' : ''}{profitPercentage}%
          </p>
        </div>

        {/* Total Invested */}
        <div className="bg-white/10 rounded-xl p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="DollarSign" size={16} color="white" />
            <span className="text-sm opacity-90">Invested</span>
          </div>
          <p className="text-lg font-semibold">${totalInvested?.toLocaleString()}</p>
          <p className="text-sm opacity-75">Principal amount</p>
        </div>
      </div>
    </div>
  );
};

export default PortfolioOverviewCard;