import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const MarketOverviewWidget = () => {
  const [marketData, setMarketData] = useState([]);
  const [btcPrice, setBtcPrice] = useState(null);

  // Simulate market data loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setMarketData([
        { symbol: 'BTC', name: 'Bitcoin', price: 67420.50, change: 2.34, isUp: true },
        { symbol: 'ETH', name: 'Ethereum', price: 3840.75, change: -1.12, isUp: false },
        { symbol: 'BNB', name: 'BNB', price: 592.80, change: 0.95, isUp: true },
        { symbol: 'SOL', name: 'Solana', price: 178.25, change: 4.67, isUp: true },
        { symbol: 'ADA', name: 'Cardano', price: 0.487, change: -2.18, isUp: false }
      ]);
      
      setBtcPrice(67420.50);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-slate-900">Market Overview</h3>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-slate-600">Live</span>
        </div>
      </div>

      {/* BTC Price Highlight */}
      <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-xl p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
              <Icon name="Bitcoin" size={20} color="white" />
            </div>
            <div>
              <p className="font-medium text-slate-900">Bitcoin (BTC)</p>
              <p className="text-sm text-slate-600">Cryptocurrency</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-lg font-bold text-slate-900">${btcPrice?.toLocaleString()}</p>
            <div className="flex items-center space-x-1">
              <Icon name="TrendingUp" size={14} className="text-green-600" />
              <span className="text-sm font-medium text-green-600">+2.34%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Other Cryptocurrencies */}
      <div className="space-y-3">
        {marketData.slice(1).map((crypto, index) => (
          <div key={index} className="flex items-center justify-between py-2 border-b border-slate-100 last:border-b-0">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center">
                <span className="text-xs font-bold text-slate-700">{crypto.symbol}</span>
              </div>
              <div>
                <p className="font-medium text-slate-900 text-sm">{crypto.name}</p>
                <p className="text-xs text-slate-600">{crypto.symbol}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-semibold text-slate-900 text-sm">${crypto.price.toLocaleString()}</p>
              <div className="flex items-center space-x-1">
                <Icon 
                  name={crypto.isUp ? 'TrendingUp' : 'TrendingDown'} 
                  size={12} 
                  className={crypto.isUp ? 'text-green-600' : 'text-red-600'}
                />
                <span className={`text-xs font-medium ${crypto.isUp ? 'text-green-600' : 'text-red-600'}`}>
                  {crypto.isUp ? '+' : ''}{crypto.change}%
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-slate-200 text-center">
        <button className="text-orange-600 hover:text-orange-700 text-sm font-medium transition-colors">
          View full market →
        </button>
      </div>
    </div>
  );
};

export default MarketOverviewWidget;