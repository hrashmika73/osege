import React, { useState } from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const DepositWithdrawSection = () => {
  const { user, updateUser } = useAuth();
  const [activeTab, setActiveTab] = useState('deposit');
  const [amount, setAmount] = useState('');
  const [processing, setProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('bank');
  const [withdrawalMethod, setWithdrawalMethod] = useState('bank');

  const handleDeposit = async () => {
    if (!amount || parseFloat(amount) <= 0) return;

    setProcessing(true);
    try {
      // Simulate deposit API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const depositAmount = parseFloat(amount);
      updateUser({
        balance: (user.balance || 0) + depositAmount
      });
      
      setAmount('');
      alert(`Deposit of $${depositAmount.toLocaleString()} has been processed successfully!`);
    } catch (error) {
      alert('Deposit failed. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const handleWithdrawal = async () => {
    if (!amount || parseFloat(amount) <= 0) return;
    
    const withdrawalAmount = parseFloat(amount);
    if (withdrawalAmount > (user.balance || 0)) {
      alert('Insufficient balance for withdrawal');
      return;
    }

    setProcessing(true);
    try {
      // Simulate withdrawal API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      updateUser({
        balance: (user.balance || 0) - withdrawalAmount
      });
      
      setAmount('');
      alert(`Withdrawal of $${withdrawalAmount.toLocaleString()} has been submitted for processing!`);
    } catch (error) {
      alert('Withdrawal failed. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const paymentMethods = [
    { value: 'bank', label: 'Bank Transfer', icon: 'Building2', fees: '0%' },
    { value: 'card', label: 'Credit/Debit Card', icon: 'CreditCard', fees: '2.5%' },
    { value: 'crypto', label: 'Cryptocurrency', icon: 'Bitcoin', fees: '1%' },
    { value: 'paypal', label: 'PayPal', icon: 'Wallet', fees: '3%' }
  ];

  const withdrawalMethods = [
    { value: 'bank', label: 'Bank Transfer', icon: 'Building2', time: '1-3 days' },
    { value: 'crypto', label: 'Crypto Wallet', icon: 'Bitcoin', time: '30 mins' },
    { value: 'paypal', label: 'PayPal', icon: 'Wallet', time: '24 hours' }
  ];

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-green-500/10 rounded-lg flex items-center justify-center">
          <Icon name="ArrowUpDown" size={20} className="text-green-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-slate-900">Deposit & Withdrawal</h3>
          <p className="text-sm text-slate-600">Manage your account funds</p>
        </div>
      </div>

      {/* Balance Display */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-4 mb-6">
        <div className="text-center">
          <div className="text-sm text-slate-600 mb-1">Available Balance</div>
          <div className="text-3xl font-bold text-slate-900">
            ${(user?.balance || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 mb-6 bg-slate-100 rounded-lg p-1">
        <button
          onClick={() => setActiveTab('deposit')}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'deposit'
              ? 'bg-white text-green-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Icon name="ArrowDownLeft" size={16} className="inline mr-2" />
          Deposit
        </button>
        <button
          onClick={() => setActiveTab('withdraw')}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'withdraw'
              ? 'bg-white text-red-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Icon name="ArrowUpRight" size={16} className="inline mr-2" />
          Withdraw
        </button>
      </div>

      {activeTab === 'deposit' ? (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Deposit Amount ($)
            </label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount to deposit"
              min="10"
              step="0.01"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Payment Method
            </label>
            <div className="space-y-2">
              {paymentMethods.map(method => (
                <label key={method.value} className="flex items-center p-3 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value={method.value}
                    checked={paymentMethod === method.value}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="text-green-600"
                  />
                  <Icon name={method.icon} size={20} className="mx-3 text-slate-600" />
                  <div className="flex-1">
                    <div className="font-medium text-slate-900">{method.label}</div>
                    <div className="text-sm text-slate-600">Processing fee: {method.fees}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <Button
            onClick={handleDeposit}
            disabled={!amount || parseFloat(amount) <= 0 || processing}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            {processing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Processing...
              </>
            ) : (
              <>
                <Icon name="ArrowDownLeft" size={16} />
                <span className="ml-2">Deposit ${amount || '0'}</span>
              </>
            )}
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Withdrawal Amount ($)
            </label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount to withdraw"
              min="10"
              max={user?.balance || 0}
              step="0.01"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            />
            <div className="text-sm text-slate-600 mt-1">
              Maximum: ${(user?.balance || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Withdrawal Method
            </label>
            <div className="space-y-2">
              {withdrawalMethods.map(method => (
                <label key={method.value} className="flex items-center p-3 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                  <input
                    type="radio"
                    name="withdrawalMethod"
                    value={method.value}
                    checked={withdrawalMethod === method.value}
                    onChange={(e) => setWithdrawalMethod(e.target.value)}
                    className="text-red-600"
                  />
                  <Icon name={method.icon} size={20} className="mx-3 text-slate-600" />
                  <div className="flex-1">
                    <div className="font-medium text-slate-900">{method.label}</div>
                    <div className="text-sm text-slate-600">Processing time: {method.time}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <Button
            onClick={handleWithdrawal}
            disabled={!amount || parseFloat(amount) <= 0 || parseFloat(amount) > (user?.balance || 0) || processing}
            className="w-full bg-red-600 hover:bg-red-700"
          >
            {processing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Processing...
              </>
            ) : (
              <>
                <Icon name="ArrowUpRight" size={16} />
                <span className="ml-2">Withdraw ${amount || '0'}</span>
              </>
            )}
          </Button>
        </div>
      )}

      {/* Recent Transactions */}
      <div className="mt-6 pt-6 border-t border-slate-200">
        <h4 className="text-sm font-medium text-slate-900 mb-3">Recent Transactions</h4>
        <div className="space-y-2">
          {[
            { type: 'deposit', amount: 5000, method: 'Bank Transfer', time: '2 hours ago', status: 'completed' },
            { type: 'withdrawal', amount: 1500, method: 'Crypto Wallet', time: '1 day ago', status: 'pending' },
            { type: 'deposit', amount: 2500, method: 'Credit Card', time: '3 days ago', status: 'completed' }
          ].map((tx, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  tx.type === 'deposit' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                }`}>
                  <Icon name={tx.type === 'deposit' ? 'ArrowDownLeft' : 'ArrowUpRight'} size={16} />
                </div>
                <div>
                  <div className="font-medium text-slate-900">
                    {tx.type === 'deposit' ? '+' : '-'}${tx.amount.toLocaleString()}
                  </div>
                  <div className="text-sm text-slate-600">{tx.method}</div>
                </div>
              </div>
              <div className="text-right">
                <div className={`text-xs px-2 py-1 rounded-full ${
                  tx.status === 'completed' 
                    ? 'bg-green-100 text-green-700' 
                    : 'bg-yellow-100 text-yellow-700'
                }`}>
                  {tx.status}
                </div>
                <div className="text-xs text-slate-600 mt-1">{tx.time}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DepositWithdrawSection;
