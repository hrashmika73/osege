import React, { useState } from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const WalletSection = () => {
  const { user, updateUser } = useAuth();
  const [walletSetup, setWalletSetup] = useState(false);
  const [newWallet, setNewWallet] = useState({ address: '', type: 'BTC' });
  const [copying, setCopying] = useState(false);

  const handleSetupWallet = async () => {
    if (!newWallet.address.trim()) return;

    try {
      // Simulate wallet setup API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      updateUser({
        wallet: {
          address: newWallet.address,
          type: newWallet.type
        }
      });
      
      setWalletSetup(false);
      setNewWallet({ address: '', type: 'BTC' });
    } catch (error) {
      console.error('Wallet setup failed:', error);
    }
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopying(true);
      setTimeout(() => setCopying(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const walletTypes = [
    { value: 'BTC', label: 'Bitcoin (BTC)', icon: '₿' },
    { value: 'ETH', label: 'Ethereum (ETH)', icon: 'Ξ' },
    { value: 'USDT', label: 'Tether (USDT)', icon: '₮' },
    { value: 'BNB', label: 'Binance Coin (BNB)', icon: 'BNB' }
  ];

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center">
            <Icon name="Wallet" size={20} className="text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-900">Wallet Management</h3>
            <p className="text-sm text-slate-600">Configure your crypto wallets</p>
          </div>
        </div>
        {!user?.wallet && (
          <Button
            onClick={() => setWalletSetup(true)}
            size="sm"
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Icon name="Plus" size={16} />
            <span className="ml-2">Setup Wallet</span>
          </Button>
        )}
      </div>

      {user?.wallet ? (
        <div className="space-y-4">
          <div className="bg-slate-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-slate-700">
                {walletTypes.find(w => w.value === user.wallet.type)?.label || user.wallet.type}
              </span>
              <span className="text-lg">
                {walletTypes.find(w => w.value === user.wallet.type)?.icon || '₿'}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <code className="flex-1 text-sm bg-white px-3 py-2 rounded border font-mono">
                {user.wallet.address}
              </code>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(user.wallet.address)}
                className="flex-shrink-0"
              >
                <Icon name={copying ? "Check" : "Copy"} size={16} />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">${user.balance?.toLocaleString() || '0'}</div>
              <div className="text-sm text-slate-600">Available Balance</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {user.wallet.type === 'BTC' ? '0.0045' : user.wallet.type === 'ETH' ? '0.125' : '450.00'}
              </div>
              <div className="text-sm text-slate-600">Crypto Balance</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">5</div>
              <div className="text-sm text-slate-600">Active Investments</div>
            </div>
          </div>
        </div>
      ) : walletSetup ? (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Wallet Type
            </label>
            <select
              value={newWallet.type}
              onChange={(e) => setNewWallet(prev => ({ ...prev, type: e.target.value }))}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              {walletTypes.map(type => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Wallet Address
            </label>
            <input
              type="text"
              value={newWallet.address}
              onChange={(e) => setNewWallet(prev => ({ ...prev, address: e.target.value }))}
              placeholder={`Enter your ${newWallet.type} wallet address`}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono text-sm"
            />
          </div>

          <div className="flex space-x-3">
            <Button
              onClick={handleSetupWallet}
              disabled={!newWallet.address.trim()}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              <Icon name="Save" size={16} />
              <span className="ml-2">Save Wallet</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setWalletSetup(false);
                setNewWallet({ address: '', type: 'BTC' });
              }}
              className="flex-1"
            >
              Cancel
            </Button>
          </div>
        </div>
      ) : (
        <div className="text-center py-8">
          <Icon name="Wallet" size={48} className="text-slate-400 mx-auto mb-4" />
          <h4 className="text-lg font-medium text-slate-900 mb-2">No Wallet Configured</h4>
          <p className="text-slate-600 mb-4">
            Set up your crypto wallet to start depositing and managing funds.
          </p>
          <Button
            onClick={() => setWalletSetup(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Icon name="Plus" size={16} />
            <span className="ml-2">Setup Wallet</span>
          </Button>
        </div>
      )}
    </div>
  );
};

export default WalletSection;
