import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActionButtons = ({ actions }) => {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
      <h3 className="text-lg font-semibold text-slate-900 mb-4">Quick Actions</h3>
      <div className="grid grid-cols-2 lg:grid-cols-1 gap-3">
        {actions?.map((action, index) => (
          <Button
            key={index}
            variant="outline"
            onClick={action.onClick}
            className={`${action.color} hover:bg-opacity-20 p-4 h-auto flex flex-col lg:flex-row lg:items-center lg:justify-start space-y-2 lg:space-y-0 lg:space-x-3`}
          >
            <div className="flex items-center justify-center lg:justify-start">
              <Icon name={action.icon} size={20} />
            </div>
            <div className="text-center lg:text-left">
              <p className="font-medium text-sm">{action.label}</p>
              <p className="text-xs opacity-70">{action.description}</p>
            </div>
          </Button>
        ))}
      </div>
    </div>
  );
};

export default QuickActionButtons;