import React, { useState } from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ProfileManagementSection = () => {
  const { user, updateUser } = useAuth();
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    country: user?.country || '',
    city: user?.city || '',
    dateOfBirth: user?.dateOfBirth || '',
    investmentExperience: user?.investmentExperience || 'beginner'
  });
  const [passwordData, setPasswordData] = useState({
    current: '',
    new: '',
    confirm: ''
  });
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      updateUser(formData);
      setEditing(false);
      alert('Profile updated successfully!');
    } catch (error) {
      alert('Failed to update profile. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async () => {
    if (passwordData.new !== passwordData.confirm) {
      alert('New passwords do not match');
      return;
    }
    if (passwordData.new.length < 8) {
      alert('Password must be at least 8 characters long');
      return;
    }

    setSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setPasswordData({ current: '', new: '', confirm: '' });
      setShowPasswordChange(false);
      alert('Password changed successfully!');
    } catch (error) {
      alert('Failed to change password. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const verificationStatus = user?.verified ? 'verified' : 'pending';
  
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-purple-500/10 rounded-lg flex items-center justify-center">
            <Icon name="User" size={20} className="text-purple-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-900">Profile Management</h3>
            <p className="text-sm text-slate-600">Manage your account information</p>
          </div>
        </div>
        {!editing && (
          <Button
            onClick={() => setEditing(true)}
            variant="outline"
            size="sm"
          >
            <Icon name="Edit" size={16} />
            <span className="ml-2">Edit</span>
          </Button>
        )}
      </div>

      {/* Profile Picture & Verification Status */}
      <div className="flex items-center space-x-4 mb-6 p-4 bg-slate-50 rounded-lg">
        <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full flex items-center justify-center">
          <span className="text-white text-xl font-bold">
            {user?.name?.split(' ').map(n => n[0]).join('') || 'U'}
          </span>
        </div>
        <div className="flex-1">
          <h4 className="text-lg font-semibold text-slate-900">{user?.name}</h4>
          <p className="text-slate-600">{user?.email}</p>
          <div className="flex items-center space-x-2 mt-1">
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${
              verificationStatus === 'verified' 
                ? 'bg-green-100 text-green-700' 
                : 'bg-yellow-100 text-yellow-700'
            }`}>
              <Icon 
                name={verificationStatus === 'verified' ? 'CheckCircle' : 'Clock'} 
                size={12} 
                className="inline mr-1" 
              />
              {verificationStatus === 'verified' ? 'Verified' : 'Verification Pending'}
            </div>
            <div className="text-xs text-slate-500">
              Member since {new Date(user?.memberSince || Date.now()).toLocaleDateString()}
            </div>
          </div>
        </div>
      </div>

      {editing ? (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Full Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Phone Number
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                placeholder="+1 (555) 123-4567"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Date of Birth
              </label>
              <input
                type="date"
                value={formData.dateOfBirth}
                onChange={(e) => setFormData(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Country
              </label>
              <input
                type="text"
                value={formData.country}
                onChange={(e) => setFormData(prev => ({ ...prev, country: e.target.value }))}
                placeholder="United States"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                City
              </label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                placeholder="New York"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Investment Experience
            </label>
            <select
              value={formData.investmentExperience}
              onChange={(e) => setFormData(prev => ({ ...prev, investmentExperience: e.target.value }))}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            >
              <option value="beginner">Beginner (0-1 years)</option>
              <option value="intermediate">Intermediate (1-5 years)</option>
              <option value="advanced">Advanced (5+ years)</option>
              <option value="expert">Expert (10+ years)</option>
            </select>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              onClick={handleSaveProfile}
              disabled={saving}
              className="flex-1 bg-purple-600 hover:bg-purple-700"
            >
              {saving ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Saving...
                </>
              ) : (
                <>
                  <Icon name="Save" size={16} />
                  <span className="ml-2">Save Changes</span>
                </>
              )}
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setEditing(false);
                setFormData({
                  name: user?.name || '',
                  email: user?.email || '',
                  phone: user?.phone || '',
                  country: user?.country || '',
                  city: user?.city || '',
                  dateOfBirth: user?.dateOfBirth || '',
                  investmentExperience: user?.investmentExperience || 'beginner'
                });
              }}
              className="flex-1"
            >
              Cancel
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-slate-500">Email</label>
                <p className="text-slate-900">{user?.email || 'Not provided'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-500">Phone</label>
                <p className="text-slate-900">{formData.phone || 'Not provided'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-500">Date of Birth</label>
                <p className="text-slate-900">
                  {formData.dateOfBirth ? new Date(formData.dateOfBirth).toLocaleDateString() : 'Not provided'}
                </p>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-slate-500">Country</label>
                <p className="text-slate-900">{formData.country || 'Not provided'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-500">City</label>
                <p className="text-slate-900">{formData.city || 'Not provided'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-500">Investment Experience</label>
                <p className="text-slate-900 capitalize">
                  {formData.investmentExperience?.replace('-', ' ') || 'Not specified'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Security Section */}
      <div className="mt-6 pt-6 border-t border-slate-200">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-sm font-medium text-slate-900">Security Settings</h4>
          {!showPasswordChange && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowPasswordChange(true)}
            >
              <Icon name="Lock" size={16} />
              <span className="ml-2">Change Password</span>
            </Button>
          )}
        </div>

        {showPasswordChange && (
          <div className="space-y-4 bg-slate-50 rounded-lg p-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Current Password
              </label>
              <input
                type="password"
                value={passwordData.current}
                onChange={(e) => setPasswordData(prev => ({ ...prev, current: e.target.value }))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                New Password
              </label>
              <input
                type="password"
                value={passwordData.new}
                onChange={(e) => setPasswordData(prev => ({ ...prev, new: e.target.value }))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Confirm New Password
              </label>
              <input
                type="password"
                value={passwordData.confirm}
                onChange={(e) => setPasswordData(prev => ({ ...prev, confirm: e.target.value }))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
            </div>
            <div className="flex space-x-3">
              <Button
                onClick={handleChangePassword}
                disabled={saving || !passwordData.current || !passwordData.new || passwordData.new !== passwordData.confirm}
                size="sm"
                className="bg-red-600 hover:bg-red-700"
              >
                {saving ? 'Changing...' : 'Change Password'}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setShowPasswordChange(false);
                  setPasswordData({ current: '', new: '', confirm: '' });
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfileManagementSection;
