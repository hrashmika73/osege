import React from 'react';
import Icon from '../../../components/AppIcon';

const ActiveInvestmentsSection = ({ investments }) => {
  const getRiskColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-slate-900">Active Investments</h3>
        <span className="text-sm text-slate-600">{investments?.length} active</span>
      </div>

      <div className="space-y-4">
        {investments?.map((investment) => (
          <div key={investment.id} className="border border-slate-200 rounded-xl p-4 hover:bg-slate-50 transition-colors">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                  <Icon name="Bitcoin" size={20} color="white" />
                </div>
                <div>
                  <h4 className="font-medium text-slate-900">{investment.name}</h4>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRiskColor(investment.status)}`}>
                      {investment.status}
                    </span>
                    <span className="text-sm text-slate-600">{investment.apy}% APY</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-slate-900">${investment.currentValue?.toLocaleString()}</p>
                <p className="text-sm text-green-600">
                  +${(investment.currentValue - investment.amount)?.toLocaleString()}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-600">Progress</span>
                <span className="text-slate-900">{investment.progress}%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-orange-500 to-orange-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${investment.progress}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-sm text-slate-600">
                <span>Invested: ${investment.amount?.toLocaleString()}</span>
                <span>{investment.remaining} days remaining</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-slate-200">
        <button className="text-orange-600 hover:text-orange-700 text-sm font-medium transition-colors">
          View all investments →
        </button>
      </div>
    </div>
  );
};

export default ActiveInvestmentsSection;