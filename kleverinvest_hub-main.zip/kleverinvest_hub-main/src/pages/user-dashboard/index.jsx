import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Header from '../../components/ui/Header';
import KYCGuard from '../../components/KYCGuard';

const UserDashboard = () => {
  const navigate = useNavigate();
  const { user, userLogout, isUserAuthenticated } = useUserAuth();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [activeTab, setActiveTab] = useState('overview');
  const [btcPrice, setBtcPrice] = useState(45000);
  const [userBalance, setUserBalance] = useState(15430.50);
  const [totalEarnings, setTotalEarnings] = useState(3247.80);
  const [activeInvestments, setActiveInvestments] = useState(3);
  const [btcWallet, setBtcWallet] = useState(user?.btcWallet || '');
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [referralCode, setReferralCode] = useState(user?.referralCode || 'REF' + user?.id?.toString().padStart(6, '0') || 'REF000001');

  // Update time and BTC price simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      setBtcPrice(prev => {
        const change = (Math.random() - 0.5) * 1000;
        return Math.max(40000, Math.min(50000, prev + change));
      });
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  // Mock data
  const investments = [
    { id: 1, plan: 'Daily 3%', amount: 5000, earned: 1247.80, status: 'active', startDate: '2024-01-01', endDate: '2024-02-01' },
    { id: 2, plan: 'Weekly 15%', amount: 8000, earned: 1600.00, status: 'active', startDate: '2024-01-10', endDate: '2024-03-10' },
    { id: 3, plan: 'Monthly 50%', amount: 2500, earned: 400.00, status: 'active', startDate: '2024-01-15', endDate: '2024-04-15' }
  ];

  const transactions = [
    { id: 1, type: 'deposit', amount: 5000, status: 'completed', date: '2024-01-20', method: 'Bitcoin', hash: 'bc1q...xyz123' },
    { id: 2, type: 'withdrawal', amount: 1000, status: 'pending', date: '2024-01-18', method: 'Bitcoin', hash: null },
    { id: 3, type: 'profit', amount: 150, status: 'completed', date: '2024-01-17', method: 'Auto', hash: null },
    { id: 4, type: 'deposit', amount: 2500, status: 'completed', date: '2024-01-15', method: 'PayPal', hash: 'pp_txn_456' }
  ];

  const investmentPlans = [
    { id: 1, name: 'Starter', roi: '3%', period: 'Daily', minAmount: 100, maxAmount: 1000, duration: '30 days' },
    { id: 2, name: 'Professional', roi: '15%', period: 'Weekly', minAmount: 1000, maxAmount: 10000, duration: '60 days' },
    { id: 3, name: 'Enterprise', roi: '50%', period: 'Monthly', minAmount: 5000, maxAmount: 100000, duration: '90 days' }
  ];

  // Handler functions
  const handleDeposit = () => {
    if (!depositAmount || depositAmount < 100) {
      alert('Minimum deposit amount is $100');
      return;
    }
    const proceed = confirm(`Confirm deposit of $${depositAmount}?\n\nDeposit will be processed via Bitcoin.\nYou will receive deposit instructions.`);
    if (proceed) {
      alert(`Deposit request created!\n\nAmount: $${depositAmount}\nMethod: Bitcoin\nStatus: Pending\n\nYou will receive payment instructions via email.`);
      setDepositAmount('');
    }
  };

  const handleWithdraw = () => {
    if (!withdrawAmount || withdrawAmount < 50) {
      alert('Minimum withdrawal amount is $50');
      return;
    }
    if (withdrawAmount > userBalance) {
      alert('Insufficient balance for withdrawal');
      return;
    }
    const proceed = confirm(`Confirm withdrawal of $${withdrawAmount}?\n\nWithdrawal will be processed to your BTC wallet.\nProcessing time: 24-48 hours.`);
    if (proceed) {
      alert(`Withdrawal request submitted!\n\nAmount: $${withdrawAmount}\nMethod: Bitcoin\nWallet: ${btcWallet}\nStatus: Pending Review\n\nRequest will be processed within 24-48 hours.`);
      setWithdrawAmount('');
    }
  };

  const handleSaveBtcWallet = () => {
    if (!btcWallet) {
      alert('Please enter a valid Bitcoin wallet address');
      return;
    }
    if (!btcWallet.match(/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}$/)) {
      alert('Please enter a valid Bitcoin wallet address');
      return;
    }
    alert(`Bitcoin wallet address saved successfully!\n\nAddress: ${btcWallet}\n\nThis wallet will be used for all withdrawals.`);
  };

  const copyReferralCode = () => {
    navigator.clipboard.writeText(`https://kleverinvest.com/register?ref=${referralCode}`);
    alert(`Referral link copied!\n\nhttps://kleverinvest.com/register?ref=${referralCode}\n\nShare this link to earn 10% commission on referrals.`);
  };

  // Redirect if not logged in as user
  useEffect(() => {
    if (!isUserAuthenticated) {
      navigate('/user-login');
    }
  }, [isUserAuthenticated, navigate]);

  // Redirect to KYC if not verified
  useEffect(() => {
    if (isUserAuthenticated && user && user.kycStatus !== 'verified' && user.kycStatus !== 'pending') {
      navigate('/kyc-verification');
    }
  }, [isUserAuthenticated, user, navigate]);

  if (!isUserAuthenticated) {
    return null;
  }

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'BarChart3' },
    { id: 'deposit', label: 'Deposit', icon: 'ArrowDownCircle' },
    { id: 'withdraw', label: 'Withdraw', icon: 'ArrowUpCircle' },
    { id: 'investments', label: 'Investments', icon: 'TrendingUp' },
    { id: 'transactions', label: 'Transactions', icon: 'CreditCard' },
    { id: 'wallet', label: 'Wallet', icon: 'Wallet' },
    { id: 'referrals', label: 'Referrals', icon: 'Users' }
  ];

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-r from-primary to-accent rounded-lg p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <Icon name="Wallet" size={24} />
            <span className="text-xs opacity-75">Available Balance</span>
          </div>
          <div className="text-2xl font-bold">${userBalance.toLocaleString()}</div>
          <div className="text-xs opacity-75">+8.2% this month</div>
        </div>
        
        <div className="bg-card border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <Icon name="TrendingUp" size={24} className="text-success" />
            <span className="text-xs text-muted-foreground">Total Earnings</span>
          </div>
          <div className="text-2xl font-bold text-foreground">${totalEarnings.toLocaleString()}</div>
          <div className="text-xs text-success">+12.5% this week</div>
        </div>
        
        <div className="bg-card border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <Icon name="Activity" size={24} className="text-warning" />
            <span className="text-xs text-muted-foreground">Active Investments</span>
          </div>
          <div className="text-2xl font-bold text-foreground">{activeInvestments}</div>
          <div className="text-xs text-muted-foreground">Running plans</div>
        </div>
        
        <div className="bg-card border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <Icon name="Bitcoin" size={24} className="text-orange-500" />
            <span className="text-xs text-muted-foreground">BTC Price</span>
          </div>
          <div className="text-2xl font-bold text-foreground">${btcPrice.toLocaleString()}</div>
          <div className="text-xs text-success">Live Price</div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Recent Transactions</h3>
          <div className="space-y-3">
            {transactions.slice(0, 3).map(tx => (
              <div key={tx.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    tx.type === 'deposit' ? 'bg-success/10 text-success' :
                    tx.type === 'withdrawal' ? 'bg-warning/10 text-warning' :
                    'bg-primary/10 text-primary'
                  }`}>
                    <Icon name={tx.type === 'deposit' ? 'ArrowDownCircle' : tx.type === 'withdrawal' ? 'ArrowUpCircle' : 'DollarSign'} size={16} />
                  </div>
                  <div>
                    <div className="font-medium text-foreground capitalize">{tx.type}</div>
                    <div className="text-xs text-muted-foreground">{tx.date}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-foreground">${tx.amount}</div>
                  <div className={`text-xs ${tx.status === 'completed' ? 'text-success' : 'text-warning'}`}>
                    {tx.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <Button variant="outline" className="w-full mt-4" onClick={() => setActiveTab('transactions')}>
            View All Transactions
          </Button>
        </div>

        <div className="bg-card border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Active Investments</h3>
          <div className="space-y-3">
            {investments.map(inv => (
              <div key={inv.id} className="p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-medium text-foreground">{inv.plan}</div>
                  <div className="text-success text-sm font-medium">${inv.earned}</div>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Invested: ${inv.amount}</span>
                  <span className="text-success">{inv.status}</span>
                </div>
              </div>
            ))}
          </div>
          <Button variant="outline" className="w-full mt-4" onClick={() => navigate('/investment-plans')}>
            New Investment
          </Button>
        </div>
      </div>
    </div>
  );

  const renderDeposit = () => (
    <div className="max-w-2xl mx-auto">
      <div className="bg-card border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6">Make Deposit</h3>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Deposit Amount (USD)</label>
            <Input
              type="number"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
              placeholder="Minimum $100"
              min="100"
            />
            <div className="text-xs text-muted-foreground mt-1">Minimum: $100 | Maximum: $100,000</div>
          </div>

          <div className="bg-muted/30 p-4 rounded-lg">
            <h4 className="font-medium text-foreground mb-3">Payment Methods</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-3 p-2 bg-card rounded border">
                <Icon name="Bitcoin" className="text-orange-500" />
                <div className="flex-1">
                  <div className="font-medium">Bitcoin (Recommended)</div>
                  <div className="text-xs text-muted-foreground">Instant confirmation</div>
                </div>
                <div className="text-success text-xs">0% Fee</div>
              </div>
              <div className="flex items-center space-x-3 p-2 bg-muted/20 rounded border opacity-60">
                <Icon name="CreditCard" />
                <div className="flex-1">
                  <div className="font-medium">Credit Card</div>
                  <div className="text-xs text-muted-foreground">Coming soon</div>
                </div>
              </div>
            </div>
          </div>

          <Button onClick={handleDeposit} className="w-full" disabled={!depositAmount}>
            <Icon name="ArrowDownCircle" size={16} className="mr-2" />
            Create Deposit Request
          </Button>
        </div>
      </div>
    </div>
  );

  const renderWithdraw = () => (
    <div className="max-w-2xl mx-auto">
      <div className="bg-card border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6">Withdraw Funds</h3>
        
        <div className="space-y-6">
          <div className="bg-primary/10 p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="Wallet" className="text-primary" />
              <span className="font-medium text-foreground">Available Balance</span>
            </div>
            <div className="text-2xl font-bold text-primary">${userBalance.toLocaleString()}</div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Withdrawal Amount (USD)</label>
            <Input
              type="number"
              value={withdrawAmount}
              onChange={(e) => setWithdrawAmount(e.target.value)}
              placeholder="Minimum $50"
              min="50"
              max={userBalance}
            />
            <div className="text-xs text-muted-foreground mt-1">
              Minimum: $50 | Available: ${userBalance.toLocaleString()}
            </div>
          </div>

          <div className="bg-warning/10 p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="AlertTriangle" className="text-warning" size={16} />
              <span className="font-medium text-foreground">Withdrawal Information</span>
            </div>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Processing time: 24-48 hours</li>
              <li>• Withdrawal fee: 2.5%</li>
              <li>• Sent to your registered BTC wallet</li>
            </ul>
          </div>

          <Button onClick={handleWithdraw} className="w-full" disabled={!withdrawAmount || !btcWallet}>
            <Icon name="ArrowUpCircle" size={16} className="mr-2" />
            Request Withdrawal
          </Button>
        </div>
      </div>
    </div>
  );

  const renderWallet = () => (
    <div className="max-w-2xl mx-auto">
      <div className="bg-card border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6">Wallet Management</h3>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Bitcoin Wallet Address</label>
            <Input
              value={btcWallet}
              onChange={(e) => setBtcWallet(e.target.value)}
              placeholder="Enter your BTC wallet address (bc1... or 1... or 3...)"
            />
            <div className="text-xs text-muted-foreground mt-1">
              This address will be used for all Bitcoin withdrawals
            </div>
          </div>

          <div className="bg-muted/30 p-4 rounded-lg">
            <h4 className="font-medium text-foreground mb-3">Wallet Security Tips</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Always double-check your wallet address</li>
              <li>• Use a hardware wallet for best security</li>
              <li>• Never share your private keys</li>
              <li>• Test with small amounts first</li>
            </ul>
          </div>

          <Button onClick={handleSaveBtcWallet} className="w-full">
            <Icon name="Save" size={16} className="mr-2" />
            Save Wallet Address
          </Button>
        </div>
      </div>
    </div>
  );

  const renderReferrals = () => (
    <div className="max-w-2xl mx-auto">
      <div className="bg-card border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6">Referral Program</h3>
        
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-primary/10 to-accent/10 p-4 rounded-lg">
            <h4 className="font-medium text-foreground mb-2">Earn 10% Commission</h4>
            <p className="text-sm text-muted-foreground">
              Invite friends and earn 10% of their profits for life!
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Your Referral Code</label>
            <div className="flex space-x-2">
              <Input value={referralCode} readOnly className="flex-1" />
              <Button variant="outline" onClick={copyReferralCode}>
                <Icon name="Copy" size={16} />
              </Button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Referral Link</label>
            <div className="flex space-x-2">
              <Input 
                value={`https://kleverinvest.com/register?ref=${referralCode}`} 
                readOnly 
                className="flex-1 text-xs"
              />
              <Button variant="outline" onClick={copyReferralCode}>
                <Icon name="Share" size={16} />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-muted/30 rounded-lg">
              <div className="text-2xl font-bold text-primary">12</div>
              <div className="text-xs text-muted-foreground">Referrals</div>
            </div>
            <div className="text-center p-4 bg-muted/30 rounded-lg">
              <div className="text-2xl font-bold text-success">$247</div>
              <div className="text-xs text-muted-foreground">Earned</div>
            </div>
            <div className="text-center p-4 bg-muted/30 rounded-lg">
              <div className="text-2xl font-bold text-warning">$52</div>
              <div className="text-xs text-muted-foreground">This Month</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <KYCGuard>
      <Helmet>
        <title>Dashboard - KleverInvest Hub</title>
        <meta name="description" content="Your personal investment dashboard" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />
        
        <div className="pt-16">
          <div className="container mx-auto px-4 py-8">
            
            {/* Welcome Section */}
            <div className="mb-8">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-foreground">Welcome back, {user?.name || 'Investor'}</h1>
                  <p className="text-muted-foreground">
                    {currentTime.toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </p>
                </div>
                <div className="flex items-center space-x-4">
                  <Button variant="outline" onClick={() => navigate('/investment-plans')}>
                    <Icon name="TrendingUp" size={16} className="mr-2" />
                    New Investment
                  </Button>
                  <Button variant="outline" onClick={() => navigate('/user-profile-settings')}>
                    <Icon name="Settings" size={16} className="mr-2" />
                    Settings
                  </Button>
                </div>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="mb-8">
              <div className="border-b border-border">
                <nav className="-mb-px flex space-x-8 overflow-x-auto">
                  {tabs.map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 whitespace-nowrap ${
                        activeTab === tab.id
                          ? 'border-primary text-primary'
                          : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                      }`}
                    >
                      <Icon name={tab.icon} size={16} />
                      <span>{tab.label}</span>
                    </button>
                  ))}
                </nav>
              </div>
            </div>

            {/* Tab Content */}
            {activeTab === 'overview' && renderOverview()}
            {activeTab === 'deposit' && renderDeposit()}
            {activeTab === 'withdraw' && renderWithdraw()}
            {activeTab === 'wallet' && renderWallet()}
            {activeTab === 'referrals' && renderReferrals()}
            
            {/* Placeholder tabs */}
            {activeTab === 'investments' && (
              <div className="text-center py-12">
                <Icon name="TrendingUp" size={48} className="text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">Investment Portfolio</h3>
                <p className="text-muted-foreground mb-4">Detailed investment tracking coming soon</p>
                <Button onClick={() => navigate('/investment-plans')}>
                  View Investment Plans
                </Button>
              </div>
            )}
            
            {activeTab === 'transactions' && (
              <div className="text-center py-12">
                <Icon name="CreditCard" size={48} className="text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">Transaction History</h3>
                <p className="text-muted-foreground mb-4">Complete transaction history coming soon</p>
                <Button onClick={() => navigate('/transaction-history')}>
                  View Transaction History
                </Button>
              </div>
            )}

          </div>
        </div>
      </div>
    </KYCGuard>
  );
};

export default UserDashboard;
