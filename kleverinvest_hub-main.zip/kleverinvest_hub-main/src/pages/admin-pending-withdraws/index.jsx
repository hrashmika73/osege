import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminPendingWithdraws = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [withdraws, setWithdraws] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('submissionDate');
  const [filterBy, setFilterBy] = useState('all');

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadPendingWithdraws();
  }, [isAdminAuthenticated, navigate]);

  const loadPendingWithdraws = () => {
    setLoading(true);
    setTimeout(() => {
      const mockWithdraws = [
        {
          id: 1,
          transactionId: 'WD_001_2024',
          userId: 'user_001',
          username: 'john_investor',
          fullName: 'John Smith',
          email: 'john@example.com',
          amount: 2500,
          currency: 'USD',
          withdrawMethod: 'bank_transfer',
          bankDetails: 'Bank of America - ****1234',
          submissionDate: '2024-01-15T10:30:00Z',
          status: 'pending_verification',
          priority: 'high',
          availableBalance: 5000,
          notes: 'First withdrawal request',
          verificationRequired: true,
          estimatedProcessingTime: '3-5 business days'
        },
        {
          id: 2,
          transactionId: 'WD_002_2024',
          userId: 'user_002',
          username: 'sarah_trader',
          fullName: 'Sarah Johnson',
          email: 'sarah@example.com',
          amount: 1000,
          currency: 'USD',
          withdrawMethod: 'paypal',
          bankDetails: 'PayPal - sarah@example.com',
          submissionDate: '2024-01-14T14:20:00Z',
          status: 'pending_review',
          priority: 'medium',
          availableBalance: 3500,
          notes: 'Regular withdrawal',
          verificationRequired: false,
          estimatedProcessingTime: '1-2 business days'
        },
        {
          id: 3,
          transactionId: 'WD_003_2024',
          userId: 'user_003',
          username: 'mike_crypto',
          fullName: 'Michael Brown',
          email: 'mike@example.com',
          amount: 5000,
          currency: 'USD',
          withdrawMethod: 'cryptocurrency',
          bankDetails: 'Bitcoin - 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
          submissionDate: '2024-01-13T09:15:00Z',
          status: 'pending_approval',
          priority: 'high',
          availableBalance: 7500,
          notes: 'Large withdrawal - requires approval',
          verificationRequired: true,
          estimatedProcessingTime: '1-24 hours'
        }
      ];
      setWithdraws(mockWithdraws);
      setLoading(false);
    }, 1000);
  };

  const handleWithdrawAction = (withdrawId, action) => {
    const withdraw = withdraws.find(w => w.id === withdrawId);

    switch (action) {
      case 'approve':
        if (window.confirm(`Are you sure you want to approve withdrawal ${withdraw.transactionId} for ${withdraw.fullName}?\\nAmount: $${withdraw.amount}`)) {
          // Check if user has sufficient balance
          const userData = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
          const user = userData.find(u => u.userId === withdraw.userId);

          if (!user || (user.balance || 0) < withdraw.amount) {
            alert(`❌ Insufficient balance. User balance: $${user?.balance || 0}, Withdrawal: $${withdraw.amount}`);
            return;
          }

          // Remove from pending withdrawals
          const updatedWithdraws = withdraws.filter(w => w.id !== withdrawId);
          setWithdraws(updatedWithdraws);
          localStorage.setItem('admin_pending_withdraws', JSON.stringify(updatedWithdraws));

          // Update user balance
          const updatedUserData = userData.map(u =>
            u.userId === withdraw.userId
              ? { ...u, balance: (u.balance || 0) - withdraw.amount }
              : u
          );
          localStorage.setItem('admin_users_data', JSON.stringify(updatedUserData));

          // Add to withdrawal log
          const withdrawLog = JSON.parse(localStorage.getItem('admin_withdraw_log') || '[]');
          const processedWithdraw = {
            ...withdraw,
            status: 'approved',
            approvedDate: new Date().toISOString(),
            approvedBy: 'admin_001'
          };
          withdrawLog.push(processedWithdraw);
          localStorage.setItem('admin_withdraw_log', JSON.stringify(withdrawLog));

          alert(`✅ Withdrawal approved: ${withdraw.transactionId}\\nAmount: $${withdraw.amount} deducted from user balance`);
          loadPendingWithdraws();
        }
        break;
      case 'reject':
        const reason = prompt(`Enter rejection reason for withdrawal ${withdraw.transactionId}:`);
        if (reason) {
          // Remove from pending withdrawals
          const updatedWithdraws = withdraws.filter(w => w.id !== withdrawId);
          setWithdraws(updatedWithdraws);
          localStorage.setItem('admin_pending_withdraws', JSON.stringify(updatedWithdraws));

          // Add to withdrawal log
          const withdrawLog = JSON.parse(localStorage.getItem('admin_withdraw_log') || '[]');
          const rejectedWithdraw = {
            ...withdraw,
            status: 'rejected',
            rejectedDate: new Date().toISOString(),
            rejectedBy: 'admin_001',
            rejectionReason: reason
          };
          withdrawLog.push(rejectedWithdraw);
          localStorage.setItem('admin_withdraw_log', JSON.stringify(withdrawLog));

          alert(`❌ Withdrawal rejected: ${withdraw.transactionId}\\nReason: ${reason}`);
          loadPendingWithdraws();
        }
        break;
      case 'request_info':
        const infoNeeded = prompt(`What additional information is needed for ${withdraw.transactionId}?`);
        if (infoNeeded) {
          // Update withdrawal with info request
          const updatedWithdraws = withdraws.map(w =>
            w.id === withdrawId
              ? {
                  ...w,
                  status: 'info_required',
                  notes: `${w.notes} - Info requested: ${infoNeeded}`,
                  lastUpdated: new Date().toISOString()
                }
              : w
          );
          setWithdraws(updatedWithdraws);
          localStorage.setItem('admin_pending_withdraws', JSON.stringify(updatedWithdraws));

          alert(`📋 Information requested from ${withdraw.fullName}:\\n${infoNeeded}`);
        }
        break;
      case 'view_details':
        // Navigate to withdrawal details page
        navigate(`/admin-withdrawal-details/${withdrawId}`);
        break;
      default:
        break;
    }
  };

  const filteredWithdraws = withdraws.filter(withdraw => {
    const matchesSearch = withdraw.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         withdraw.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         withdraw.transactionId.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filterBy === 'all') return matchesSearch;
    if (filterBy === 'high_priority') return matchesSearch && withdraw.priority === 'high';
    if (filterBy === 'large_amounts') return matchesSearch && withdraw.amount >= 3000;
    if (filterBy === 'verification_required') return matchesSearch && withdraw.verificationRequired;
    if (filterBy === 'crypto') return matchesSearch && withdraw.withdrawMethod === 'cryptocurrency';
    
    return matchesSearch;
  });

  const sortedWithdraws = [...filteredWithdraws].sort((a, b) => {
    switch (sortBy) {
      case 'submissionDate':
        return new Date(a.submissionDate) - new Date(b.submissionDate);
      case 'amount':
        return b.amount - a.amount;
      case 'priority':
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      case 'name':
        return a.fullName.localeCompare(b.fullName);
      default:
        return 0;
    }
  });

  const getPriorityBadge = (priority) => {
    const priorityClasses = {
      high: 'bg-red-100 text-red-800 border-red-200',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      low: 'bg-green-100 text-green-800 border-green-200'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${priorityClasses[priority] || priorityClasses.medium}`}>
        {priority.charAt(0).toUpperCase() + priority.slice(1)}
      </span>
    );
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      pending_verification: 'bg-yellow-100 text-yellow-800',
      pending_review: 'bg-blue-100 text-blue-800',
      pending_approval: 'bg-purple-100 text-purple-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusClasses[status] || statusClasses.pending_review}`}>
        {status.replace('_', ' ').charAt(0).toUpperCase() + status.replace('_', ' ').slice(1)}
      </span>
    );
  };

  const getMethodBadge = (method) => {
    const methodClasses = {
      bank_transfer: 'bg-green-100 text-green-800',
      paypal: 'bg-blue-100 text-blue-800',
      cryptocurrency: 'bg-orange-100 text-orange-800',
      check: 'bg-purple-100 text-purple-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${methodClasses[method] || methodClasses.bank_transfer}`}>
        {method.replace('_', ' ').toUpperCase()}
      </span>
    );
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getWaitingTime = (submissionDate) => {
    const now = new Date();
    const submission = new Date(submissionDate);
    const diffTime = Math.abs(now - submission);
    const diffHours = Math.ceil(diffTime / (1000 * 60 * 60));
    
    if (diffHours < 24) return `${diffHours} hours`;
    const diffDays = Math.ceil(diffHours / 24);
    return `${diffDays} days`;
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Pending Withdrawals"
        breadcrumb={[
          { label: "Payment Management", link: "/admin-payment-gateway" },
          { label: "Pending Withdrawals" }
        ]}
        actions={[
          {
            label: "Export Pending",
            icon: "Download",
            variant: "outline",
            onClick: () => {
              const csvData = withdraws.map(withdraw => ({
                'Transaction ID': withdraw.transactionId,
                User: withdraw.fullName,
                Username: withdraw.username,
                Amount: withdraw.amount,
                'Withdraw Method': withdraw.withdrawMethod,
                Status: withdraw.status,
                Priority: withdraw.priority,
                'Submission Date': formatDateTime(withdraw.submissionDate),
                'Available Balance': withdraw.availableBalance,
                Notes: withdraw.notes
              }));
              const csv = [
                Object.keys(csvData[0]).join(','),
                ...csvData.map(row => Object.values(row).map(val => `"${val}"`).join(','))
              ].join('\n');
              const blob = new Blob([csv], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `pending_withdrawals_${new Date().toISOString().split('T')[0]}.csv`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }
          },
          {
            label: "Refresh",
            icon: "RefreshCw",
            variant: "outline",
            onClick: loadPendingWithdraws
          }
        ]}
      />

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Withdrawals</p>
                <p className="text-2xl font-bold text-foreground">{withdraws.length}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Icon name="Clock" size={24} className="text-yellow-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Value</p>
                <p className="text-2xl font-bold text-foreground">
                  {formatCurrency(withdraws.reduce((sum, w) => sum + w.amount, 0))}
                </p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Icon name="TrendingDown" size={24} className="text-red-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">High Priority</p>
                <p className="text-2xl font-bold text-foreground">
                  {withdraws.filter(w => w.priority === 'high').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Icon name="AlertTriangle" size={24} className="text-red-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Need Verification</p>
                <p className="text-2xl font-bold text-foreground">
                  {withdraws.filter(w => w.verificationRequired).length}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Icon name="Shield" size={24} className="text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-card border rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search withdrawals..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={filterBy}
                onChange={(e) => setFilterBy(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="all">All Withdrawals</option>
                <option value="high_priority">High Priority</option>
                <option value="large_amounts">Large Amounts</option>
                <option value="verification_required">Need Verification</option>
                <option value="crypto">Cryptocurrency</option>
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="submissionDate">Submission Date</option>
                <option value="amount">Amount</option>
                <option value="priority">Priority</option>
                <option value="name">Name</option>
              </select>
            </div>
          </div>
        </div>

        {/* Withdrawals Table */}
        <div className="bg-card border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Transaction
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Method
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Priority
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Waiting Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {loading ? (
                  <tr>
                    <td colSpan="8" className="px-6 py-8 text-center">
                      <div className="flex items-center justify-center">
                        <Icon name="Loader" size={20} className="animate-spin mr-2" />
                        Loading pending withdrawals...
                      </div>
                    </td>
                  </tr>
                ) : sortedWithdraws.length === 0 ? (
                  <tr>
                    <td colSpan="8" className="px-6 py-8 text-center text-muted-foreground">
                      No pending withdrawals found
                    </td>
                  </tr>
                ) : (
                  sortedWithdraws.map((withdraw) => (
                    <tr key={withdraw.id} className="hover:bg-muted/30">
                      <td className="px-6 py-4">
                        <div>
                          <div className="text-sm font-medium text-foreground">{withdraw.transactionId}</div>
                          <div className="text-xs text-muted-foreground">{withdraw.bankDetails}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                            <span className="text-xs font-medium text-primary">
                              {withdraw.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-foreground">{withdraw.fullName}</div>
                            <div className="text-xs text-muted-foreground">@{withdraw.username}</div>
                            <div className="text-xs text-muted-foreground">
                              Balance: {formatCurrency(withdraw.availableBalance)}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-foreground">
                          {formatCurrency(withdraw.amount)}
                        </div>
                        <div className="text-xs text-muted-foreground">{withdraw.currency}</div>
                      </td>
                      <td className="px-6 py-4">
                        {getMethodBadge(withdraw.withdrawMethod)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="space-y-1">
                          {getStatusBadge(withdraw.status)}
                          {withdraw.verificationRequired && (
                            <div className="text-xs text-orange-600 font-medium">Verification Required</div>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {getPriorityBadge(withdraw.priority)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">{getWaitingTime(withdraw.submissionDate)}</div>
                        <div className="text-xs text-muted-foreground">
                          ETA: {withdraw.estimatedProcessingTime}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleWithdrawAction(withdraw.id, 'view_details')}
                            title="View Details"
                          >
                            <Icon name="Eye" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleWithdrawAction(withdraw.id, 'approve')}
                            title="Approve Withdrawal"
                            className="text-green-600 border-green-200 hover:bg-green-50"
                          >
                            <Icon name="Check" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleWithdrawAction(withdraw.id, 'reject')}
                            title="Reject Withdrawal"
                            className="text-red-600 border-red-200 hover:bg-red-50"
                          >
                            <Icon name="X" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleWithdrawAction(withdraw.id, 'request_info')}
                            title="Request Information"
                            className="text-blue-600 border-blue-200 hover:bg-blue-50"
                          >
                            <Icon name="MessageCircle" size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPendingWithdraws;
