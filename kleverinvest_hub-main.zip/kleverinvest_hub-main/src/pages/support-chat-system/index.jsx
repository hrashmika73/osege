import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import ChatHeader from './components/ChatHeader';
import MessageBubble from './components/MessageBubble';
import QuickResponses from './components/QuickResponses';
import MessageInput from './components/MessageInput';
import TypingIndicator from './components/TypingIndicator';
import ChatHistory from './components/ChatHistory';
import SatisfactionRating from './components/SatisfactionRating';
import { defaultAvatars } from '../../utils/avatarHelper';

const SupportChatSystem = () => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [showQuickResponses, setShowQuickResponses] = useState(true);
  const [showSatisfactionRating, setShowSatisfactionRating] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState(1);
  const messagesEndRef = useRef(null);

  // Mock data for support agent
  const supportAgent = {
    name: "Sarah Johnson",
    status: "Online - Available",
    avatar: defaultAvatars.support
  };

  // Mock conversation history
  const [conversations] = useState([
    {
      id: 1,
      subject: "Account Verification Issue",
      lastMessage: "Thank you for providing the documents...",
      lastMessageTime: new Date(Date.now() - 300000), // 5 minutes ago
      status: "active",
      unreadCount: 0
    },
    {
      id: 2,
      subject: "Withdrawal Problem",
      lastMessage: "Your withdrawal has been processed...",
      lastMessageTime: new Date(Date.now() - 86400000), // 1 day ago
      status: "resolved",
      unreadCount: 0
    },
    {
      id: 3,
      subject: "2FA Setup Help",
      lastMessage: "I need help setting up two-factor...",
      lastMessageTime: new Date(Date.now() - 172800000), // 2 days ago
      status: "pending",
      unreadCount: 2
    }
  ]);

  // Mock messages for current conversation
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hello! I\'m Sarah from KleverInvest support. How can I help you today?",
      type: "text",
      isUser: false,
      timestamp: new Date(Date.now() - 1800000),
      status: "delivered"
    },
    {
      id: 2,
      text: "Hi Sarah! I'm having trouble with my account verification. I uploaded my documents yesterday but haven't heard back.",
      type: "text",
      isUser: true,
      timestamp: new Date(Date.now() - 1740000),
      status: "read"
    },
    {
      id: 3,
      text: "I understand your concern. Let me check your verification status right away. Can you please provide your account email?",
      type: "text",
      isUser: false,
      timestamp: new Date(Date.now() - 1680000),
      status: "delivered"
    },
    {
      id: 4,
      text: "Sure, it's john.doe@email.com",
      type: "text",
      isUser: true,
      timestamp: new Date(Date.now() - 1620000),
      status: "read"
    },
    {
      id: 5,
      text: "Perfect! I can see your documents were received. Our verification team is currently reviewing them. You should receive an update within 24 hours.",
      type: "text",
      isUser: false,
      timestamp: new Date(Date.now() - 1560000),
      status: "delivered"
    },
    {
      id: 6,
      text: "Here\'s a screenshot of the error I\'m seeing when I try to check my status:",
      type: "image",
      imageUrl: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDMwMCAyMDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjMwMCIgaGVpZ2h0PSIyMDAiIGZpbGw9IiNGNkY2RjYiLz48dGV4dCB4PSIxNTAiIHk9IjEwNSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE2IiBmb250LXdlaWdodD0iYm9sZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZmlsbD0iIzk5OTk5OSI+U2NyZWVuc2hvdDwvdGV4dD48L3N2Zz4=",
      isUser: true,
      timestamp: new Date(Date.now() - 900000),
      status: "read"
    },
    {
      id: 7,
      text: "Thank you for providing the screenshot. I can see the issue now. This is a temporary display problem that doesn't affect your actual verification status. Your documents are being processed normally.",
      type: "text",
      isUser: false,
      timestamp: new Date(Date.now() - 600000),
      status: "delivered"
    }
  ]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (messageData) => {
    const newMessage = {
      id: Date.now(),
      ...messageData,
      isUser: true
    };

    setMessages(prev => [...prev, newMessage]);
    setShowQuickResponses(false);

    // Simulate agent typing and response
    setIsTyping(true);
    setTimeout(() => {
      const agentResponse = {
        id: Date.now() + 1,
        text: "Thank you for your message. I\'m looking into this for you right now. Please give me a moment to check your account details.",
        type: "text",
        isUser: false,
        timestamp: new Date(),
        status: "delivered"
      };
      setMessages(prev => [...prev, agentResponse]);
      setIsTyping(false);
      
      // Show satisfaction rating after some interactions
      if (messages.length > 8) {
        setTimeout(() => setShowSatisfactionRating(true), 2000);
      }
    }, 2000);
  };

  const handleFileUpload = (fileData) => {
    const newMessage = {
      id: Date.now(),
      ...fileData,
      isUser: true
    };

    setMessages(prev => [...prev, newMessage]);
  };

  const handleQuickResponse = (responseText) => {
    handleSendMessage({
      text: responseText,
      type: "text",
      timestamp: new Date(),
      status: "sent"
    });
  };

  const handleSelectConversation = (conversation) => {
    setCurrentConversationId(conversation.id);
    // In a real app, this would load the conversation messages
  };

  const handleSatisfactionRating = (ratingData) => {
    console.log('Satisfaction rating submitted:', ratingData);
    setShowSatisfactionRating(false);
  };

  const handleClose = () => {
    // In a real app, this might navigate away or minimize the chat
    console.log('Chat closed');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <div className="bg-card border-b px-4 py-3">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Link to="/admin-dashboard" className="flex items-center space-x-2">
              <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
                <Icon name="TrendingUp" size={20} color="white" />
              </div>
              <span className="font-bold text-lg text-foreground">KleverInvest Hub</span>
            </Link>
            
            <nav className="hidden md:flex items-center space-x-1">
              <Link
                to="/referral-program"
                className="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors duration-150"
              >
                <Icon name="UserPlus" size={16} />
                <span>Referrals</span>
              </Link>
              <Link
                to="/user-profile-settings"
                className="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors duration-150"
              >
                <Icon name="Settings" size={16} />
                <span>Settings</span>
              </Link>
              <div className="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium bg-primary text-primary-foreground">
                <Icon name="MessageCircle" size={16} />
                <span>Support</span>
              </div>
            </nav>
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Icon name="Bell" size={16} />
            </Button>
            <Button variant="ghost" size="sm">
              <Icon name="User" size={16} />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Chat Interface */}
      <div className="flex h-[calc(100vh-73px)]">
        {/* Chat History Sidebar */}
        <ChatHistory
          conversations={conversations}
          onSelectConversation={handleSelectConversation}
          currentConversationId={currentConversationId}
        />

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col">
          {/* Chat Header */}
          <ChatHeader
            agent={supportAgent}
            onClose={handleClose}
            isMinimized={isMinimized}
            onToggleMinimize={() => setIsMinimized(!isMinimized)}
          />

          {!isMinimized && (
            <>
              {/* Messages Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-muted/20">
                <div className="max-w-4xl mx-auto">
                  {/* Welcome Message */}
                  <div className="text-center mb-6 p-4 bg-card rounded-lg border">
                    <Icon name="MessageCircle" size={32} className="mx-auto mb-2 text-primary" />
                    <h2 className="text-lg font-semibold mb-1">Welcome to KleverInvest Support</h2>
                    <p className="text-sm text-muted-foreground">
                      We're here to help you with any questions about your cryptocurrency investments
                    </p>
                  </div>

                  {/* Messages */}
                  {messages.map((message, index) => (
                    <MessageBubble
                      key={message.id}
                      message={message}
                      isUser={message.isUser}
                      showAvatar={index === 0 || messages[index - 1]?.isUser !== message.isUser}
                    />
                  ))}

                  {/* Typing Indicator */}
                  <TypingIndicator
                    agentName={supportAgent.name}
                    isVisible={isTyping}
                  />

                  <div ref={messagesEndRef} />
                </div>
              </div>

              {/* Quick Responses */}
              <QuickResponses
                onSelectResponse={handleQuickResponse}
                isVisible={showQuickResponses && messages.length < 5}
              />

              {/* Satisfaction Rating */}
              <SatisfactionRating
                onSubmitRating={handleSatisfactionRating}
                isVisible={showSatisfactionRating}
              />

              {/* Message Input */}
              <MessageInput
                onSendMessage={handleSendMessage}
                onFileUpload={handleFileUpload}
                disabled={isTyping}
              />
            </>
          )}

          {isMinimized && (
            <div className="flex-1 flex items-center justify-center bg-muted/20">
              <div className="text-center">
                <Icon name="MessageCircle" size={48} className="mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Chat minimized</p>
                <Button
                  variant="outline"
                  onClick={() => setIsMinimized(false)}
                  className="mt-2"
                >
                  Restore Chat
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SupportChatSystem;
