import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const MessageInput = ({ onSendMessage, onFileUpload, disabled = false }) => {
  const [message, setMessage] = useState('');
  const [showEmoji, setShowEmoji] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);

  const emojis = ['😊', '😢', '😡', '👍', '👎', '❤️', '🎉', '🤔', '😅', '🙏'];

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!message.trim() || disabled) return;

    onSendMessage({
      text: message,
      type: 'text',
      timestamp: new Date(),
      status: 'sent'
    });
    
    setMessage('');
  };

  const handleFileSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsUploading(true);
    
    // Simulate file upload
    setTimeout(() => {
      onFileUpload({
        type: file.type.startsWith('image/') ? 'image' : 'file',
        fileName: file.name,
        fileSize: `${(file.size / 1024).toFixed(1)} KB`,
        imageUrl: file.type.startsWith('image/') ? URL.createObjectURL(file) : null,
        timestamp: new Date(),
        status: 'sent'
      });
      setIsUploading(false);
    }, 1500);
  };

  const handleEmojiSelect = (emoji) => {
    setMessage(prev => prev + emoji);
    setShowEmoji(false);
  };

  return (
    <div className="border-t bg-card">
      <form onSubmit={handleSubmit} className="p-4">
        <div className="flex items-end space-x-2">
          <div className="flex-1 relative">
            <Input
              type="text"
              placeholder="Type your message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              disabled={disabled}
              className="pr-20"
            />
            
            {/* Emoji and File buttons */}
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center space-x-1">
              <div className="relative">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowEmoji(!showEmoji)}
                  className="p-1 h-auto"
                >
                  <Icon name="Smile" size={16} />
                </Button>
                
                {showEmoji && (
                  <>
                    <div 
                      className="fixed inset-0 z-10" 
                      onClick={() => setShowEmoji(false)}
                    />
                    <div className="absolute bottom-full right-0 mb-2 p-2 bg-popover border rounded-md shadow-elevation-2 z-20">
                      <div className="grid grid-cols-5 gap-1">
                        {emojis.map((emoji, index) => (
                          <button
                            key={index}
                            type="button"
                            onClick={() => handleEmojiSelect(emoji)}
                            className="p-1 hover:bg-muted rounded text-lg"
                          >
                            {emoji}
                          </button>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
              
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="p-1 h-auto"
              >
                <Icon name={isUploading ? "Loader2" : "Paperclip"} size={16} />
              </Button>
            </div>
          </div>
          
          <Button
            type="submit"
            disabled={!message.trim() || disabled}
            className="px-4"
          >
            <Icon name="Send" size={16} />
          </Button>
        </div>
      </form>
      
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleFileSelect}
        accept="image/*,.pdf,.doc,.docx,.txt"
        className="hidden"
      />
    </div>
  );
};

export default MessageInput;