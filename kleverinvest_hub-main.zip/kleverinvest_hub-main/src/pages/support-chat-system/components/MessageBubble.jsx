import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const MessageBubble = ({ message, isUser, showAvatar = true }) => {
  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const renderMessageContent = () => {
    if (message.type === 'file') {
      return (
        <div className="space-y-2">
          <div className="flex items-center space-x-2 p-2 bg-muted/50 rounded border">
            <Icon name="Paperclip" size={16} />
            <span className="text-sm font-medium">{message.fileName}</span>
            <span className="text-xs text-muted-foreground">({message.fileSize})</span>
          </div>
          {message.text && <p>{message.text}</p>}
        </div>
      );
    }

    if (message.type === 'image') {
      return (
        <div className="space-y-2">
          <div className="rounded overflow-hidden max-w-xs">
            <Image 
              src={message.imageUrl} 
              alt="Shared image" 
              className="w-full h-auto"
            />
          </div>
          {message.text && <p>{message.text}</p>}
        </div>
      );
    }

    return <p>{message.text}</p>;
  };

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      <div className={`flex max-w-xs lg:max-w-md ${isUser ? 'flex-row-reverse' : 'flex-row'} items-end space-x-2`}>
        {showAvatar && !isUser && (
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
            <Icon name="User" size={16} />
          </div>
        )}
        
        <div className={`px-3 py-2 rounded-lg ${
          isUser 
            ? 'bg-primary text-primary-foreground rounded-br-sm' 
            : 'bg-muted text-muted-foreground rounded-bl-sm'
        }`}>
          {renderMessageContent()}
          
          <div className={`flex items-center justify-between mt-1 space-x-2 ${
            isUser ? 'flex-row-reverse' : 'flex-row'
          }`}>
            <span className="text-xs opacity-75">
              {formatTime(message.timestamp)}
            </span>
            
            {isUser && (
              <div className="flex items-center space-x-1">
                {message.status === 'sent' && (
                  <Icon name="Check" size={12} className="opacity-75" />
                )}
                {message.status === 'delivered' && (
                  <div className="flex">
                    <Icon name="Check" size={12} className="opacity-75 -mr-1" />
                    <Icon name="Check" size={12} className="opacity-75" />
                  </div>
                )}
                {message.status === 'read' && (
                  <div className="flex text-success">
                    <Icon name="Check" size={12} className="-mr-1" />
                    <Icon name="Check" size={12} />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;