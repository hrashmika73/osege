import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SatisfactionRating = ({ onSubmitRating, isVisible }) => {
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isVisible) return null;

  const handleSubmit = () => {
    onSubmitRating({ rating, feedback });
    setIsSubmitted(true);
    
    // Reset after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setRating(0);
      setFeedback('');
    }, 3000);
  };

  if (isSubmitted) {
    return (
      <div className="p-4 border-t bg-success/10 text-center">
        <Icon name="CheckCircle" size={24} className="mx-auto mb-2 text-success" />
        <p className="text-sm font-medium text-success">Thank you for your feedback!</p>
      </div>
    );
  }

  return (
    <div className="p-4 border-t bg-muted/30">
      <h4 className="text-sm font-medium mb-3">How was your support experience?</h4>
      
      <div className="flex items-center justify-center space-x-2 mb-3">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => setRating(star)}
            className="p-1 transition-colors duration-150"
          >
            <Icon
              name="Star"
              size={20}
              className={`${
                star <= rating 
                  ? 'text-warning fill-current' :'text-muted-foreground'
              }`}
            />
          </button>
        ))}
      </div>
      
      {rating > 0 && (
        <div className="space-y-3">
          <textarea
            placeholder="Tell us more about your experience (optional)"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            className="w-full p-2 text-sm border rounded-md resize-none h-16 bg-background"
          />
          
          <Button
            onClick={handleSubmit}
            size="sm"
            className="w-full"
          >
            Submit Feedback
          </Button>
        </div>
      )}
    </div>
  );
};

export default SatisfactionRating;