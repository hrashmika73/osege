import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ChatHeader = ({ agent, onClose, isMinimized, onToggleMinimize }) => {
  return (
    <div className="flex items-center justify-between p-4 bg-primary text-primary-foreground border-b">
      <div className="flex items-center space-x-3">
        <div className="relative">
          <div className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
            <Icon name="Headphones" size={20} color="white" />
          </div>
          <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-success rounded-full border-2 border-primary"></div>
        </div>
        <div>
          <h3 className="font-semibold text-sm">{agent.name}</h3>
          <p className="text-xs opacity-90 flex items-center">
            <span className="w-2 h-2 bg-success rounded-full mr-2"></span>
            {agent.status}
          </p>
        </div>
      </div>
      <div className="flex items-center space-x-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleMinimize}
          className="text-primary-foreground hover:bg-primary-foreground/20 hidden lg:flex"
        >
          <Icon name={isMinimized ? "Maximize2" : "Minimize2"} size={16} />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          className="text-primary-foreground hover:bg-primary-foreground/20"
        >
          <Icon name="X" size={16} />
        </Button>
      </div>
    </div>
  );
};

export default ChatHeader;