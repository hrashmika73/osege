import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ChatHistory = ({ conversations, onSelectConversation, currentConversationId }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);

  const filteredConversations = conversations.filter(conv =>
    conv.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    conv.lastMessage.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (date) => {
    const now = new Date();
    const messageDate = new Date(date);
    const diffInHours = (now - messageDate) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffInHours < 168) { // 7 days
      return messageDate.toLocaleDateString([], { weekday: 'short' });
    } else {
      return messageDate.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className={`bg-card border-r transition-all duration-300 ${
      isExpanded ? 'w-80' : 'w-16'
    } lg:w-80 flex flex-col`}>
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          {isExpanded && (
            <h3 className="font-semibold text-sm">Chat History</h3>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="lg:hidden"
          >
            <Icon name={isExpanded ? "ChevronLeft" : "MessageSquare"} size={16} />
          </Button>
        </div>
        
        {(isExpanded || window.innerWidth >= 1024) && (
          <div className="mt-3">
            <Input
              type="search"
              placeholder="Search conversations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="text-sm"
            />
          </div>
        )}
      </div>

      {/* Conversations List */}
      {(isExpanded || window.innerWidth >= 1024) && (
        <div className="flex-1 overflow-y-auto">
          {filteredConversations.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground">
              <Icon name="MessageCircle" size={24} className="mx-auto mb-2 opacity-50" />
              <p className="text-sm">No conversations found</p>
            </div>
          ) : (
            <div className="space-y-1 p-2">
              {filteredConversations.map((conversation) => (
                <button
                  key={conversation.id}
                  onClick={() => onSelectConversation(conversation)}
                  className={`w-full text-left p-3 rounded-lg transition-colors duration-150 ${
                    currentConversationId === conversation.id
                      ? 'bg-primary text-primary-foreground'
                      : 'hover:bg-muted'
                  }`}
                >
                  <div className="flex items-start justify-between mb-1">
                    <h4 className="font-medium text-sm truncate flex-1">
                      {conversation.subject}
                    </h4>
                    <span className="text-xs opacity-75 ml-2 flex-shrink-0">
                      {formatDate(conversation.lastMessageTime)}
                    </span>
                  </div>
                  
                  <p className="text-xs opacity-75 truncate">
                    {conversation.lastMessage}
                  </p>
                  
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${
                        conversation.status === 'active' ? 'bg-success' :
                        conversation.status === 'pending'? 'bg-warning' : 'bg-muted-foreground'
                      }`}></div>
                      <span className="text-xs opacity-75 capitalize">
                        {conversation.status}
                      </span>
                    </div>
                    
                    {conversation.unreadCount > 0 && (
                      <div className="bg-destructive text-destructive-foreground text-xs rounded-full px-2 py-0.5 min-w-[1.25rem] text-center">
                        {conversation.unreadCount}
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Collapsed state */}
      {!isExpanded && window.innerWidth < 1024 && (
        <div className="flex-1 flex flex-col items-center justify-center p-2 space-y-4">
          {filteredConversations.slice(0, 3).map((conversation) => (
            <button
              key={conversation.id}
              onClick={() => onSelectConversation(conversation)}
              className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors duration-150 ${
                currentConversationId === conversation.id
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted hover:bg-muted/80'
              }`}
              title={conversation.subject}
            >
              <Icon name="MessageCircle" size={16} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default ChatHistory;