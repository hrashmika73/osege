import React from 'react';
import Button from '../../../components/ui/Button';

const QuickResponses = ({ onSelectResponse, isVisible }) => {
  const quickResponses = [
    {
      id: 1,
      text: "I need help with my account verification",
      category: "account"
    },
    {
      id: 2,
      text: "My transaction is not showing up",
      category: "transaction"
    },
    {
      id: 3,
      text: "I can\'t withdraw my funds",
      category: "withdrawal"
    },
    {
      id: 4,
      text: "How do I enable 2FA?",
      category: "security"
    },
    {
      id: 5,
      text: "I forgot my password",
      category: "account"
    },
    {
      id: 6,
      text: "Technical issue with the platform",
      category: "technical"
    }
  ];

  if (!isVisible) return null;

  return (
    <div className="p-4 border-t bg-muted/30">
      <h4 className="text-sm font-medium text-muted-foreground mb-3">Quick responses:</h4>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {quickResponses.map((response) => (
          <Button
            key={response.id}
            variant="outline"
            size="sm"
            onClick={() => onSelectResponse(response.text)}
            className="text-left justify-start h-auto py-2 px-3 text-xs"
          >
            {response.text}
          </Button>
        ))}
      </div>
    </div>
  );
};

export default QuickResponses;