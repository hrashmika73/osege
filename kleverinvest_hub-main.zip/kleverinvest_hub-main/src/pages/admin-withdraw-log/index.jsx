import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminWithdrawLog = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBy, setFilterBy] = useState('all');
  const [dateRange, setDateRange] = useState('7days');

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadWithdrawLogs();
  }, [isAdminAuthenticated, navigate, dateRange]);

  const loadWithdrawLogs = () => {
    setLoading(true);
    setTimeout(() => {
      const mockLogs = [
        {
          id: 1,
          transactionId: 'WD_001_2024',
          userId: 'user_001',
          username: 'john_investor',
          fullName: 'John Smith',
          action: 'submitted',
          amount: 2500,
          withdrawMethod: 'bank_transfer',
          actionDate: '2024-01-15T10:30:00Z',
          actionBy: 'system',
          previousStatus: 'none',
          newStatus: 'pending_verification',
          notes: 'Withdrawal request submitted',
          ipAddress: '192.168.1.100'
        },
        {
          id: 2,
          transactionId: 'WD_001_2024',
          userId: 'user_001',
          username: 'john_investor',
          fullName: 'John Smith',
          action: 'approved',
          amount: 2500,
          withdrawMethod: 'bank_transfer',
          actionDate: '2024-01-15T14:30:00Z',
          actionBy: 'admin_001',
          previousStatus: 'pending_verification',
          newStatus: 'approved',
          notes: 'Withdrawal approved after verification',
          ipAddress: '192.168.1.50'
        },
        {
          id: 3,
          transactionId: 'WD_002_2024',
          userId: 'user_002',
          username: 'sarah_trader',
          fullName: 'Sarah Johnson',
          action: 'rejected',
          amount: 5000,
          withdrawMethod: 'paypal',
          actionDate: '2024-01-14T16:20:00Z',
          actionBy: 'admin_002',
          previousStatus: 'pending_review',
          newStatus: 'rejected',
          notes: 'Insufficient balance for withdrawal',
          ipAddress: '192.168.1.51'
        },
        {
          id: 4,
          transactionId: 'WD_003_2024',
          userId: 'user_003',
          username: 'mike_crypto',
          fullName: 'Michael Brown',
          action: 'processed',
          amount: 1000,
          withdrawMethod: 'cryptocurrency',
          actionDate: '2024-01-13T11:45:00Z',
          actionBy: 'system',
          previousStatus: 'approved',
          newStatus: 'completed',
          notes: 'Withdrawal processed successfully',
          ipAddress: '192.168.1.102'
        }
      ];
      setLogs(mockLogs);
      setLoading(false);
    }, 1000);
  };

  const getFilteredLogs = () => {
    let filtered = logs.filter(log => {
      const matchesSearch = log.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           log.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           log.transactionId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           log.notes.toLowerCase().includes(searchTerm.toLowerCase());
      
      if (filterBy === 'all') return matchesSearch;
      return matchesSearch && log.action === filterBy;
    });

    // Apply date range filter
    if (dateRange !== 'all') {
      const now = new Date();
      const days = parseInt(dateRange.replace('days', ''));
      const cutoffDate = new Date(now.setDate(now.getDate() - days));
      
      filtered = filtered.filter(log => new Date(log.actionDate) >= cutoffDate);
    }

    return filtered.sort((a, b) => new Date(b.actionDate) - new Date(a.actionDate));
  };

  const getActionBadge = (action) => {
    const actionClasses = {
      submitted: 'bg-blue-100 text-blue-800 border-blue-200',
      approved: 'bg-green-100 text-green-800 border-green-200',
      rejected: 'bg-red-100 text-red-800 border-red-200',
      processed: 'bg-purple-100 text-purple-800 border-purple-200',
      cancelled: 'bg-gray-100 text-gray-800 border-gray-200'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${actionClasses[action] || actionClasses.submitted}`}>
        {action.charAt(0).toUpperCase() + action.slice(1)}
      </span>
    );
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      pending_verification: 'bg-yellow-100 text-yellow-800',
      pending_review: 'bg-blue-100 text-blue-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      completed: 'bg-purple-100 text-purple-800',
      cancelled: 'bg-gray-100 text-gray-800',
      none: 'bg-gray-100 text-gray-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusClasses[status] || statusClasses.pending_review}`}>
        {status === 'none' ? 'Initial' : status.replace('_', ' ').charAt(0).toUpperCase() + status.replace('_', ' ').slice(1)}
      </span>
    );
  };

  const getMethodBadge = (method) => {
    const methodClasses = {
      bank_transfer: 'bg-green-100 text-green-800',
      paypal: 'bg-blue-100 text-blue-800',
      cryptocurrency: 'bg-orange-100 text-orange-800',
      check: 'bg-purple-100 text-purple-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${methodClasses[method] || methodClasses.bank_transfer}`}>
        {method.replace('_', ' ').toUpperCase()}
      </span>
    );
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleExportLogs = () => {
    const filteredLogs = getFilteredLogs();
    const csvData = filteredLogs.map(log => ({
      Date: formatDateTime(log.actionDate),
      'Transaction ID': log.transactionId,
      User: log.fullName,
      Username: log.username,
      Action: log.action,
      Amount: log.amount,
      'Withdraw Method': log.withdrawMethod,
      'Previous Status': log.previousStatus,
      'New Status': log.newStatus,
      'Processed By': log.actionBy,
      Notes: log.notes
    }));
    
    const csv = [
      Object.keys(csvData[0]).join(','),
      ...csvData.map(row => Object.values(row).map(val => `"${val}"`).join(','))
    ].join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `withdraw_log_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const filteredLogs = getFilteredLogs();

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Withdrawal Activity Log"
        breadcrumb={[
          { label: "Payment Management", link: "/admin-payment-gateway" },
          { label: "Withdrawal Log" }
        ]}
        actions={[
          {
            label: "Export Log",
            icon: "Download",
            variant: "outline",
            onClick: handleExportLogs
          },
          {
            label: "Refresh",
            icon: "RefreshCw",
            variant: "outline",
            onClick: loadWithdrawLogs
          }
        ]}
      />

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-6">
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Logs</p>
                <p className="text-2xl font-bold text-foreground">{filteredLogs.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Icon name="FileText" size={24} className="text-blue-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Submitted</p>
                <p className="text-2xl font-bold text-foreground">
                  {filteredLogs.filter(l => l.action === 'submitted').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Icon name="Upload" size={24} className="text-yellow-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Approved</p>
                <p className="text-2xl font-bold text-foreground">
                  {filteredLogs.filter(l => l.action === 'approved').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Icon name="Check" size={24} className="text-green-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Rejected</p>
                <p className="text-2xl font-bold text-foreground">
                  {filteredLogs.filter(l => l.action === 'rejected').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Icon name="X" size={24} className="text-red-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Processed</p>
                <p className="text-2xl font-bold text-foreground">
                  {filteredLogs.filter(l => l.action === 'processed').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Icon name="CheckCircle" size={24} className="text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-card border rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search withdrawal logs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={filterBy}
                onChange={(e) => setFilterBy(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="all">All Actions</option>
                <option value="submitted">Submitted</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="processed">Processed</option>
              </select>
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="7days">Last 7 days</option>
                <option value="30days">Last 30 days</option>
                <option value="90days">Last 90 days</option>
                <option value="all">All time</option>
              </select>
            </div>
          </div>
        </div>

        {/* Activity Log Table */}
        <div className="bg-card border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Date & Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Transaction
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Action
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Method
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Status Change
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Processed By
                  </th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {loading ? (
                  <tr>
                    <td colSpan="8" className="px-6 py-8 text-center">
                      <div className="flex items-center justify-center">
                        <Icon name="Loader" size={20} className="animate-spin mr-2" />
                        Loading withdrawal logs...
                      </div>
                    </td>
                  </tr>
                ) : filteredLogs.length === 0 ? (
                  <tr>
                    <td colSpan="8" className="px-6 py-8 text-center text-muted-foreground">
                      No withdrawal activity logs found
                    </td>
                  </tr>
                ) : (
                  filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-muted/30">
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-foreground">
                          {formatDateTime(log.actionDate)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-foreground">{log.transactionId}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                            <span className="text-xs font-medium text-primary">
                              {log.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-foreground">{log.fullName}</div>
                            <div className="text-xs text-muted-foreground">@{log.username}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {getActionBadge(log.action)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-foreground">
                          {formatCurrency(log.amount)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {getMethodBadge(log.withdrawMethod)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          {getStatusBadge(log.previousStatus)}
                          <Icon name="ArrowRight" size={14} className="text-muted-foreground" />
                          {getStatusBadge(log.newStatus)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-6 h-6 bg-muted rounded-full flex items-center justify-center mr-2">
                            <Icon name={log.actionBy === 'system' ? 'Bot' : 'User'} size={12} />
                          </div>
                          <div className="text-sm text-foreground">{log.actionBy}</div>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminWithdrawLog;
