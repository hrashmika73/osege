import React from 'react';
import Icon from '../../../components/AppIcon';

const RecentReferrals = ({ referrals }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'text-success bg-success/10';
      case 'Pending':
        return 'text-warning bg-warning/10';
      case 'Inactive':
        return 'text-muted-foreground bg-muted';
      default:
        return 'text-muted-foreground bg-muted';
    }
  };

  const getActivityIcon = (status) => {
    switch (status) {
      case 'Active':
        return 'CheckCircle';
      case 'Pending':
        return 'Clock';
      case 'Inactive':
        return 'XCircle';
      default:
        return 'User';
    }
  };

  return (
    <div className="bg-card border rounded-lg shadow-sm">
      <div className="p-6 border-b">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-lg text-foreground">Recent Referrals</h3>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Icon name="Users" size={16} />
            <span>{referrals.length} total referrals</span>
          </div>
        </div>
      </div>

      <div className="divide-y">
        {referrals.map((referral) => (
          <div key={referral.id} className="p-6 hover:bg-muted/50 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
                  <Icon name="User" size={20} color="var(--color-muted-foreground)" />
                </div>
                <div>
                  <p className="font-medium text-foreground">{referral.username}</p>
                  <p className="text-sm text-muted-foreground">
                    Joined {referral.registrationDate}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="font-semibold text-foreground">${referral.commissionEarned}</p>
                  <p className="text-sm text-muted-foreground">Commission</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${getStatusColor(referral.status)}`}>
                  <Icon name={getActivityIcon(referral.status)} size={12} />
                  <span>{referral.status}</span>
                </div>
              </div>
            </div>

            {referral.lastActivity && (
              <div className="mt-3 flex items-center space-x-2 text-sm text-muted-foreground">
                <Icon name="Activity" size={14} />
                <span>Last activity: {referral.lastActivity}</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {referrals.length === 0 && (
        <div className="p-12 text-center">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Users" size={32} color="var(--color-muted-foreground)" />
          </div>
          <h4 className="font-medium text-foreground mb-2">No referrals yet</h4>
          <p className="text-muted-foreground">Start sharing your referral link to see your referrals here.</p>
        </div>
      )}
    </div>
  );
};

export default RecentReferrals;