import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReferralContest = ({ contest, leaderboard, userRank }) => {
  const getRankIcon = (rank) => {
    switch (rank) {
      case 1:
        return { icon: 'Trophy', color: '#FFD700' };
      case 2:
        return { icon: 'Medal', color: '#C0C0C0' };
      case 3:
        return { icon: 'Award', color: '#CD7F32' };
      default:
        return { icon: 'User', color: 'var(--color-muted-foreground)' };
    }
  };

  const formatTimeRemaining = (endDate) => {
    const now = new Date();
    const end = new Date(endDate);
    const diff = end - now;
    
    if (diff <= 0) return 'Contest ended';
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    return `${days}d ${hours}h remaining`;
  };

  return (
    <div className="space-y-6">
      {/* Contest Banner */}
      <div className="bg-gradient-to-r from-primary to-primary/80 rounded-lg p-6 text-primary-foreground">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-xl mb-2">{contest.title}</h3>
            <p className="opacity-90 mb-4">{contest.description}</p>
            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-2">
                <Icon name="Calendar" size={16} />
                <span>{formatTimeRemaining(contest.endDate)}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="Users" size={16} />
                <span>{contest.participants} participants</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold">${contest.totalPrize.toLocaleString()}</p>
            <p className="opacity-90">Total Prize Pool</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Leaderboard */}
        <div className="bg-card border rounded-lg shadow-sm">
          <div className="p-6 border-b">
            <h4 className="font-semibold text-lg text-foreground">Contest Leaderboard</h4>
            <p className="text-sm text-muted-foreground">Top performers this month</p>
          </div>
          
          <div className="divide-y">
            {leaderboard.map((participant, index) => {
              const rank = index + 1;
              const rankInfo = getRankIcon(rank);
              const isCurrentUser = participant.isCurrentUser;
              
              return (
                <div 
                  key={participant.id} 
                  className={`p-4 flex items-center justify-between ${
                    isCurrentUser ? 'bg-primary/5 border-l-4 border-l-primary' : ''
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center bg-muted">
                      <Icon name={rankInfo.icon} size={16} color={rankInfo.color} />
                    </div>
                    <div>
                      <p className={`font-medium ${isCurrentUser ? 'text-primary' : 'text-foreground'}`}>
                        {participant.username}
                        {isCurrentUser && <span className="ml-2 text-xs">(You)</span>}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {participant.referrals} referrals
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="font-semibold text-foreground">#{rank}</p>
                    <p className="text-sm text-success">${participant.prize}</p>
                  </div>
                </div>
              );
            })}
          </div>
          
          {userRank > 10 && (
            <div className="p-4 border-t bg-muted/30">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center bg-primary/10">
                    <Icon name="User" size={16} color="var(--color-primary)" />
                  </div>
                  <div>
                    <p className="font-medium text-primary">Your Position</p>
                    <p className="text-sm text-muted-foreground">Keep going!</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-foreground">#{userRank}</p>
                  <p className="text-sm text-muted-foreground">Current rank</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Prize Structure */}
        <div className="bg-card border rounded-lg shadow-sm">
          <div className="p-6 border-b">
            <h4 className="font-semibold text-lg text-foreground">Prize Structure</h4>
            <p className="text-sm text-muted-foreground">Rewards for top performers</p>
          </div>
          
          <div className="p-6 space-y-4">
            {contest.prizes.map((prize, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    index === 0 ? 'bg-yellow-100' : index === 1 ? 'bg-gray-100' : 'bg-orange-100'
                  }`}>
                    <Icon 
                      name={getRankIcon(index + 1).icon} 
                      size={20} 
                      color={getRankIcon(index + 1).color} 
                    />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{prize.position}</p>
                    <p className="text-sm text-muted-foreground">{prize.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg text-foreground">${prize.amount}</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="p-6 border-t">
            <Button fullWidth iconName="ExternalLink" iconPosition="right">
              View Full Contest Rules
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReferralContest;