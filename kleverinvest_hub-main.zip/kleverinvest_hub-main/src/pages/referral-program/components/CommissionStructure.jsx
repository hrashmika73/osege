import React from 'react';
import Icon from '../../../components/AppIcon';

const CommissionStructure = ({ tiers, currentTier }) => {
  return (
    <div className="bg-card border rounded-lg p-6 shadow-sm">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name="Award" size={20} color="var(--color-primary)" />
        </div>
        <div>
          <h3 className="font-semibold text-lg text-foreground">Commission Structure</h3>
          <p className="text-sm text-muted-foreground">Earn more as you progress through tiers</p>
        </div>
      </div>

      <div className="space-y-4">
        {tiers.map((tier, index) => {
          const isCurrentTier = tier.name === currentTier;
          const isUnlocked = tier.minReferrals <= (tiers.find(t => t.name === currentTier)?.minReferrals || 0);
          
          return (
            <div
              key={tier.name}
              className={`relative p-4 rounded-lg border-2 transition-all ${
                isCurrentTier
                  ? 'border-primary bg-primary/5'
                  : isUnlocked
                  ? 'border-success/30 bg-success/5' :'border-border bg-muted/30'
              }`}
            >
              {isCurrentTier && (
                <div className="absolute -top-2 left-4 px-2 py-1 bg-primary text-primary-foreground text-xs font-medium rounded">
                  Current Tier
                </div>
              )}
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                    isCurrentTier
                      ? 'bg-primary text-primary-foreground'
                      : isUnlocked
                      ? 'bg-success text-success-foreground'
                      : 'bg-muted text-muted-foreground'
                  }`}>
                    <Icon 
                      name={tier.icon} 
                      size={20} 
                      color={isCurrentTier ? 'white' : isUnlocked ? 'white' : 'var(--color-muted-foreground)'} 
                    />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">{tier.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      {tier.minReferrals} referrals required
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-2xl font-bold text-foreground">{tier.commissionRate}%</p>
                  <p className="text-sm text-muted-foreground">Commission</p>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Investment Bonus</p>
                  <p className="font-medium text-foreground">{tier.investmentBonus}%</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Withdrawal Bonus</p>
                  <p className="font-medium text-foreground">{tier.withdrawalBonus}%</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Monthly Bonus</p>
                  <p className="font-medium text-foreground">${tier.monthlyBonus}</p>
                </div>
              </div>

              {tier.benefits && tier.benefits.length > 0 && (
                <div className="mt-4 pt-4 border-t">
                  <p className="text-sm font-medium text-foreground mb-2">Additional Benefits:</p>
                  <ul className="space-y-1">
                    {tier.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <Icon name="Check" size={14} color="var(--color-success)" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-6 p-4 bg-muted rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={16} color="var(--color-primary)" className="mt-0.5" />
          <div className="text-sm">
            <p className="font-medium text-foreground mb-1">How it works:</p>
            <ul className="space-y-1 text-muted-foreground">
              <li>• Earn commission on every successful referral's first investment</li>
              <li>• Higher tiers unlock better rates and additional bonuses</li>
              <li>• Commissions are paid monthly on the 1st of each month</li>
              <li>• Minimum payout threshold is $50</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommissionStructure;