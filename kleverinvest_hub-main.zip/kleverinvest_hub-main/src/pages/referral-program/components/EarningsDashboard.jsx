import React from 'react';
import Icon from '../../../components/AppIcon';

const EarningsDashboard = ({ earnings }) => {
  const progressPercentage = Math.min((earnings.currentTierEarnings / earnings.nextTierThreshold) * 100, 100);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Total Earnings */}
      <div className="bg-card border rounded-lg p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
            <Icon name="DollarSign" size={24} color="var(--color-success)" />
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-foreground">${earnings.totalEarned.toLocaleString()}</p>
            <p className="text-sm text-muted-foreground">Total Earned</p>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-sm">
          <Icon name="TrendingUp" size={16} color="var(--color-success)" />
          <span className="text-success">+{earnings.monthlyGrowth}%</span>
          <span className="text-muted-foreground">this month</span>
        </div>
      </div>

      {/* Pending Payments */}
      <div className="bg-card border rounded-lg p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
            <Icon name="Clock" size={24} color="var(--color-warning)" />
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-foreground">${earnings.pendingPayment.toLocaleString()}</p>
            <p className="text-sm text-muted-foreground">Pending Payment</p>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-sm">
          <Icon name="Calendar" size={16} color="var(--color-muted-foreground)" />
          <span className="text-muted-foreground">Next payout: {earnings.nextPayoutDate}</span>
        </div>
      </div>

      {/* Commission Rate */}
      <div className="bg-card border rounded-lg p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Percent" size={24} color="var(--color-primary)" />
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-foreground">{earnings.currentRate}%</p>
            <p className="text-sm text-muted-foreground">Commission Rate</p>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Progress to {earnings.nextTier}</span>
            <span className="text-foreground">{progressPercentage.toFixed(0)}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
          <p className="text-xs text-muted-foreground">
            ${earnings.currentTierEarnings.toLocaleString()} / ${earnings.nextTierThreshold.toLocaleString()}
          </p>
        </div>
      </div>
    </div>
  );
};

export default EarningsDashboard;