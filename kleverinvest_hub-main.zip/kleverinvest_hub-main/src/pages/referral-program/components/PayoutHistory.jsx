import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PayoutHistory = ({ payouts }) => {
  const [filter, setFilter] = useState('all');

  const getStatusColor = (status) => {
    switch (status) {
      case 'Completed':
        return 'text-success bg-success/10';
      case 'Pending':
        return 'text-warning bg-warning/10';
      case 'Processing':
        return 'text-primary bg-primary/10';
      case 'Failed':
        return 'text-destructive bg-destructive/10';
      default:
        return 'text-muted-foreground bg-muted';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Completed':
        return 'CheckCircle';
      case 'Pending':
        return 'Clock';
      case 'Processing':
        return 'Loader';
      case 'Failed':
        return 'XCircle';
      default:
        return 'Circle';
    }
  };

  const getPaymentMethodIcon = (method) => {
    switch (method) {
      case 'PayPal':
        return 'CreditCard';
      case 'Bank Transfer':
        return 'Building';
      case 'Crypto Wallet':
        return 'Wallet';
      default:
        return 'DollarSign';
    }
  };

  const filteredPayouts = filter === 'all' 
    ? payouts 
    : payouts.filter(payout => payout.status.toLowerCase() === filter);

  const totalPaid = payouts
    .filter(p => p.status === 'Completed')
    .reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="bg-card border rounded-lg shadow-sm">
      <div className="p-6 border-b">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <h3 className="font-semibold text-lg text-foreground">Payout History</h3>
            <p className="text-sm text-muted-foreground">
              Total paid: <span className="font-medium text-success">${totalPaid.toLocaleString()}</span>
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('all')}
            >
              All
            </Button>
            <Button
              variant={filter === 'completed' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('completed')}
            >
              Completed
            </Button>
            <Button
              variant={filter === 'pending' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('pending')}
            >
              Pending
            </Button>
          </div>
        </div>
      </div>

      <div className="divide-y">
        {filteredPayouts.map((payout) => (
          <div key={payout.id} className="p-6 hover:bg-muted/50 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center">
                  <Icon 
                    name={getPaymentMethodIcon(payout.paymentMethod)} 
                    size={20} 
                    color="var(--color-muted-foreground)" 
                  />
                </div>
                <div>
                  <p className="font-medium text-foreground">${payout.amount.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">
                    {payout.paymentMethod} • {payout.date}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-right hidden sm:block">
                  <p className="text-sm text-muted-foreground">Transaction ID</p>
                  <p className="font-mono text-xs text-foreground">{payout.transactionId}</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${getStatusColor(payout.status)}`}>
                  <Icon name={getStatusIcon(payout.status)} size={12} />
                  <span>{payout.status}</span>
                </div>
              </div>
            </div>

            {payout.description && (
              <div className="mt-3 text-sm text-muted-foreground">
                {payout.description}
              </div>
            )}

            <div className="mt-3 sm:hidden">
              <p className="text-xs text-muted-foreground">
                Transaction ID: <span className="font-mono">{payout.transactionId}</span>
              </p>
            </div>
          </div>
        ))}
      </div>

      {filteredPayouts.length === 0 && (
        <div className="p-12 text-center">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="DollarSign" size={32} color="var(--color-muted-foreground)" />
          </div>
          <h4 className="font-medium text-foreground mb-2">No payouts found</h4>
          <p className="text-muted-foreground">
            {filter === 'all' ?'Your payout history will appear here once you start earning commissions.'
              : `No ${filter} payouts found. Try adjusting your filter.`
            }
          </p>
        </div>
      )}
    </div>
  );
};

export default PayoutHistory;