import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReferralLinkCard = ({ referralLink, onCopy }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      setCopied(true);
      onCopy();
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const shareOnSocial = (platform) => {
    const message = "Join KleverInvest Hub and start your crypto investment journey! Use my referral link:";
    const encodedMessage = encodeURIComponent(message);
    const encodedLink = encodeURIComponent(referralLink);
    
    const urls = {
      twitter: `https://twitter.com/intent/tweet?text=${encodedMessage}&url=${encodedLink}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedLink}&quote=${encodedMessage}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedLink}`,
      whatsapp: `https://wa.me/?text=${encodedMessage}%20${encodedLink}`,
      telegram: `https://t.me/share/url?url=${encodedLink}&text=${encodedMessage}`
    };

    window.open(urls[platform], '_blank', 'width=600,height=400');
  };

  return (
    <div className="bg-card border rounded-lg p-6 shadow-sm">
      <div className="flex items-center space-x-3 mb-4">
        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name="Link" size={20} color="var(--color-primary)" />
        </div>
        <div>
          <h3 className="font-semibold text-lg text-foreground">Your Referral Link</h3>
          <p className="text-sm text-muted-foreground">Share this link to earn commissions</p>
        </div>
      </div>

      <div className="bg-muted rounded-lg p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0 mr-3">
            <p className="text-sm font-mono text-foreground truncate">{referralLink}</p>
          </div>
          <Button
            variant={copied ? "success" : "outline"}
            size="sm"
            onClick={handleCopy}
            iconName={copied ? "Check" : "Copy"}
            iconPosition="left"
          >
            {copied ? "Copied!" : "Copy"}
          </Button>
        </div>
      </div>

      <div className="space-y-3">
        <h4 className="font-medium text-foreground">Share on Social Media</h4>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareOnSocial('twitter')}
            iconName="Twitter"
            iconPosition="left"
            className="text-blue-500 border-blue-200 hover:bg-blue-50"
          >
            Twitter
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareOnSocial('facebook')}
            iconName="Facebook"
            iconPosition="left"
            className="text-blue-600 border-blue-200 hover:bg-blue-50"
          >
            Facebook
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareOnSocial('linkedin')}
            iconName="Linkedin"
            iconPosition="left"
            className="text-blue-700 border-blue-200 hover:bg-blue-50"
          >
            LinkedIn
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareOnSocial('whatsapp')}
            iconName="MessageCircle"
            iconPosition="left"
            className="text-green-600 border-green-200 hover:bg-green-50"
          >
            WhatsApp
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareOnSocial('telegram')}
            iconName="Send"
            iconPosition="left"
            className="text-blue-500 border-blue-200 hover:bg-blue-50"
          >
            Telegram
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ReferralLinkCard;