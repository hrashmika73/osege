import React, { useState, useEffect } from 'react';
import Icon from '../../components/AppIcon';

import ReferralLinkCard from './components/ReferralLinkCard';
import EarningsDashboard from './components/EarningsDashboard';
import ReferralStats from './components/ReferralStats';
import RecentReferrals from './components/RecentReferrals';
import CommissionStructure from './components/CommissionStructure';
import PayoutHistory from './components/PayoutHistory';
import ReferralContest from './components/ReferralContest';

const ReferralProgram = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  // Mock data
  const referralLink = "https://kleverinvest.com/ref/KI789012";
  
  const earnings = {
    totalEarned: 2450.75,
    pendingPayment: 320.50,
    currentRate: 15,
    nextTier: "Gold",
    currentTierEarnings: 2450,
    nextTierThreshold: 5000,
    monthlyGrowth: 23.5,
    nextPayoutDate: "Feb 1, 2025"
  };

  const stats = {
    totalClicks: 1247,
    successfulRegistrations: 89,
    conversionRate: 7.1,
    activeReferrals: 67
  };

  const chartData = {
    clicks: [
      { date: "Jan 20", clicks: 45 },
      { date: "Jan 21", clicks: 52 },
      { date: "Jan 22", clicks: 38 },
      { date: "Jan 23", clicks: 67 },
      { date: "Jan 24", clicks: 71 },
      { date: "Jan 25", clicks: 58 },
      { date: "Jan 26", clicks: 63 },
      { date: "Jan 27", clicks: 82 },
      { date: "Jan 28", clicks: 74 },
      { date: "Jan 29", clicks: 91 }
    ],
    earnings: [
      { date: "Jan 20", earnings: 125 },
      { date: "Jan 21", earnings: 180 },
      { date: "Jan 22", earnings: 95 },
      { date: "Jan 23", earnings: 240 },
      { date: "Jan 24", earnings: 310 },
      { date: "Jan 25", earnings: 275 },
      { date: "Jan 26", earnings: 195 },
      { date: "Jan 27", earnings: 380 },
      { date: "Jan 28", earnings: 420 },
      { date: "Jan 29", earnings: 485 }
    ]
  };

  const recentReferrals = [
    {
      id: 1,
      username: "CryptoTrader_2024",
      registrationDate: "Jan 28, 2025",
      status: "Active",
      commissionEarned: 45.50,
      lastActivity: "2 hours ago"
    },
    {
      id: 2,
      username: "InvestorPro_89",
      registrationDate: "Jan 27, 2025",
      status: "Active",
      commissionEarned: 78.25,
      lastActivity: "1 day ago"
    },
    {
      id: 3,
      username: "BlockchainFan_42",
      registrationDate: "Jan 26, 2025",
      status: "Pending",
      commissionEarned: 0,
      lastActivity: "3 days ago"
    },
    {
      id: 4,
      username: "DigitalAsset_Lover",
      registrationDate: "Jan 25, 2025",
      status: "Active",
      commissionEarned: 92.75,
      lastActivity: "5 hours ago"
    },
    {
      id: 5,
      username: "CoinCollector_2025",
      registrationDate: "Jan 24, 2025",
      status: "Inactive",
      commissionEarned: 15.00,
      lastActivity: "1 week ago"
    }
  ];

  const commissionTiers = [
    {
      name: "Bronze",
      icon: "Shield",
      minReferrals: 0,
      commissionRate: 10,
      investmentBonus: 2,
      withdrawalBonus: 1,
      monthlyBonus: 0,
      benefits: ["Basic support", "Monthly reports"]
    },
    {
      name: "Silver",
      icon: "Star",
      minReferrals: 10,
      commissionRate: 15,
      investmentBonus: 3,
      withdrawalBonus: 2,
      monthlyBonus: 25,
      benefits: ["Priority support", "Weekly reports", "Marketing materials"]
    },
    {
      name: "Gold",
      icon: "Crown",
      minReferrals: 25,
      commissionRate: 20,
      investmentBonus: 5,
      withdrawalBonus: 3,
      monthlyBonus: 75,
      benefits: ["VIP support", "Daily reports", "Custom marketing materials", "Personal account manager"]
    },
    {
      name: "Platinum",
      icon: "Gem",
      minReferrals: 50,
      commissionRate: 25,
      investmentBonus: 7,
      withdrawalBonus: 5,
      monthlyBonus: 150,
      benefits: ["24/7 dedicated support", "Real-time analytics", "White-label materials", "Revenue sharing program"]
    }
  ];

  const payoutHistory = [
    {
      id: 1,
      amount: 450.75,
      paymentMethod: "PayPal",
      date: "Jan 1, 2025",
      status: "Completed",
      transactionId: "PP_789012345",
      description: "Monthly commission payout for December 2024"
    },
    {
      id: 2,
      amount: 320.50,
      paymentMethod: "Bank Transfer",
      date: "Dec 1, 2024",
      status: "Completed",
      transactionId: "BT_456789012",
      description: "Monthly commission payout for November 2024"
    },
    {
      id: 3,
      amount: 275.25,
      paymentMethod: "Crypto Wallet",
      date: "Nov 1, 2024",
      status: "Completed",
      transactionId: "CW_123456789",
      description: "Monthly commission payout for October 2024"
    },
    {
      id: 4,
      amount: 180.00,
      paymentMethod: "PayPal",
      date: "Jan 29, 2025",
      status: "Processing",
      transactionId: "PP_987654321",
      description: "Bonus payout for reaching Silver tier"
    }
  ];

  const contest = {
    title: "January Referral Challenge",
    description: "Refer the most users this month and win amazing prizes!",
    endDate: "2025-01-31T23:59:59",
    participants: 1247,
    totalPrize: 5000,
    prizes: [
      { position: "1st Place", amount: 2000, description: "Most referrals" },
      { position: "2nd Place", amount: 1500, description: "Second most referrals" },
      { position: "3rd Place", amount: 1000, description: "Third most referrals" },
      { position: "4th-10th", amount: 500, description: "Top 10 participants" }
    ]
  };

  const leaderboard = [
    { id: 1, username: "CryptoKing_2025", referrals: 47, prize: 2000, isCurrentUser: false },
    { id: 2, username: "InvestMaster_Pro", referrals: 42, prize: 1500, isCurrentUser: false },
    { id: 3, username: "BlockchainGuru_89", referrals: 38, prize: 1000, isCurrentUser: false },
    { id: 4, username: "DigitalTrader_24", referrals: 35, prize: 500, isCurrentUser: false },
    { id: 5, username: "CoinExpert_2024", referrals: 32, prize: 500, isCurrentUser: false },
    { id: 6, username: "You", referrals: 29, prize: 500, isCurrentUser: true },
    { id: 7, username: "CryptoFan_42", referrals: 27, prize: 500, isCurrentUser: false },
    { id: 8, username: "InvestorElite_99", referrals: 25, prize: 500, isCurrentUser: false },
    { id: 9, username: "BlockchainPro_21", referrals: 23, prize: 500, isCurrentUser: false },
    { id: 10, username: "DigitalAsset_King", referrals: 21, prize: 500, isCurrentUser: false }
  ];

  const userRank = 6;

  const handleCopyLink = () => {
    // Copy functionality handled in component
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'LayoutDashboard' },
    { id: 'referrals', label: 'My Referrals', icon: 'Users' },
    { id: 'structure', label: 'Commission', icon: 'Percent' },
    { id: 'payouts', label: 'Payouts', icon: 'DollarSign' },
    { id: 'contest', label: 'Contest', icon: 'Trophy' }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Referral Program</h1>
              <p className="text-muted-foreground">Earn commissions by referring new users</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Total Earnings</p>
                <p className="text-xl font-bold text-success">${earnings.totalEarned.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                <Icon name="TrendingUp" size={24} color="var(--color-success)" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Navigation Tabs */}
        <div className="mb-6">
          <div className="border-b">
            <nav className="-mb-px flex space-x-8 overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors ${
                    activeTab === tab.id
                      ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground hover:border-muted'
                  }`}
                >
                  <Icon name={tab.icon} size={16} />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div className="space-y-6">
          {activeTab === 'overview' && (
            <>
              <ReferralLinkCard referralLink={referralLink} onCopy={handleCopyLink} />
              <EarningsDashboard earnings={earnings} />
              <ReferralStats stats={stats} chartData={chartData} />
            </>
          )}

          {activeTab === 'referrals' && (
            <RecentReferrals referrals={recentReferrals} />
          )}

          {activeTab === 'structure' && (
            <CommissionStructure tiers={commissionTiers} currentTier="Silver" />
          )}

          {activeTab === 'payouts' && (
            <PayoutHistory payouts={payoutHistory} />
          )}

          {activeTab === 'contest' && (
            <ReferralContest 
              contest={contest} 
              leaderboard={leaderboard} 
              userRank={userRank} 
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default ReferralProgram;