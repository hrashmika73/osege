import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import PortfolioValueCard from './components/PortfolioValueCard';
import ActiveInvestments from './components/ActiveInvestments';
import QuickActions from './components/QuickActions';
import PerformanceCharts from './components/PerformanceCharts';
import RecentActivity from './components/RecentActivity';

const InvestmentPortfolioDashboard = () => {
  const navigate = useNavigate();
  const [selectedTimeframe, setSelectedTimeframe] = useState('7d');
  const [portfolioData, setPortfolioData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Simulate data loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setPortfolioData({
        totalBalance: 45780.25,
        dayChange: 1.23,
        dayChangeAmount: 556.42,
        profitLoss: 8245.67,
        profitLossPercentage: 21.87
      });
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  // Mock active investments data
  const activeInvestments = [
    {
      id: 1,
      name: 'Bitcoin Growth Package',
      symbol: 'BTC-GP',
      invested: 10000,
      currentValue: 12500,
      duration: 30,
      daysRemaining: 15,
      projectedReturn: 25,
      progress: 50,
      riskLevel: 'medium',
      apy: 18.5
    },
    {
      id: 2,
      name: 'Ethereum Staking Pool',
      symbol: 'ETH-SP',
      invested: 8000,
      currentValue: 9200,
      duration: 60,
      daysRemaining: 42,
      projectedReturn: 22,
      progress: 30,
      riskLevel: 'low',
      apy: 12.8
    },
    {
      id: 3,
      name: 'DeFi Yield Farming',
      symbol: 'DEFI-YF',
      invested: 5000,
      currentValue: 6100,
      duration: 90,
      daysRemaining: 73,
      projectedReturn: 35,
      progress: 19,
      riskLevel: 'high',
      apy: 28.7
    }
  ];

  // Mock quick actions
  const quickActions = [
    {
      label: 'New Investment',
      description: 'Browse opportunities',
      icon: 'Plus',
      color: 'bg-primary/10 text-primary',
      onClick: () => navigate('/investment-opportunities')
    },
    {
      label: 'Withdraw Funds',
      description: 'Request withdrawal',
      icon: 'ArrowUpRight',
      color: 'bg-warning/10 text-warning',
      onClick: () => navigate('/withdrawal-requests')
    },
    {
      label: 'Rebalance Portfolio',
      description: 'Optimize allocation',
      icon: 'BarChart3',
      color: 'bg-success/10 text-success',
      onClick: () => {}
    },
    {
      label: 'View Analytics',
      description: 'Detailed insights',
      icon: 'TrendingUp',
      color: 'bg-accent/10 text-accent',
      onClick: () => {}
    }
  ];

  // Mock recent activity data
  const recentActivities = [
    {
      id: 1,
      type: 'investment_completed',
      title: 'Investment Matured',
      description: 'Bitcoin Growth Package completed successfully',
      amount: '+$2,500',
      timestamp: new Date(Date.now() - 3600000),
      status: 'completed'
    },
    {
      id: 2,
      type: 'deposit',
      title: 'Deposit Confirmed',
      description: 'Bank transfer processed',
      amount: '+$5,000',
      timestamp: new Date(Date.now() - 7200000),
      status: 'completed'
    },
    {
      id: 3,
      type: 'withdrawal',
      title: 'Withdrawal Request',
      description: 'Pending approval',
      amount: '-$1,200',
      timestamp: new Date(Date.now() - 10800000),
      status: 'pending'
    },
    {
      id: 4,
      type: 'earning',
      title: 'Daily Earnings',
      description: 'DeFi Yield Farming rewards',
      amount: '+$125.50',
      timestamp: new Date(Date.now() - 86400000),
      status: 'completed'
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your portfolio...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-foreground">Investment Portfolio</h1>
            <p className="text-sm sm:text-base text-muted-foreground">
              Monitor and manage your cryptocurrency investments
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Icon name="Download" size={16} />
              <span className="hidden sm:inline ml-2">Export</span>
            </Button>
            <Button size="sm" onClick={() => navigate('/investment-opportunities')}>
              <Icon name="Plus" size={16} />
              <span className="hidden sm:inline ml-2">Invest</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="p-4 sm:p-6 space-y-6">
        {/* Portfolio Value Card */}
        <PortfolioValueCard
          portfolioData={portfolioData}
          className="mb-6"
        />

        {/* Quick Actions - Mobile First */}
        <div className="block lg:hidden">
          <QuickActions actions={quickActions} />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Active Investments & Performance */}
          <div className="lg:col-span-2 space-y-6">
            <ActiveInvestments investments={activeInvestments} />
            <PerformanceCharts
              selectedTimeframe={selectedTimeframe}
              onTimeframeChange={setSelectedTimeframe}
            />
          </div>

          {/* Right Column - Quick Actions & Recent Activity */}
          <div className="space-y-6">
            {/* Quick Actions - Desktop */}
            <div className="hidden lg:block">
              <QuickActions actions={quickActions} />
            </div>
            
            <RecentActivity activities={recentActivities} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvestmentPortfolioDashboard;