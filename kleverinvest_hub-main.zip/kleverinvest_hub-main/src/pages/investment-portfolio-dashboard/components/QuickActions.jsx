import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActions = ({ actions }) => {
  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 sm:p-6 border-b">
        <h3 className="text-lg font-semibold text-foreground">Quick Actions</h3>
      </div>
      
      <div className="p-4 sm:p-6">
        <div className="grid grid-cols-2 sm:grid-cols-1 lg:grid-cols-1 gap-3">
          {actions?.map((action, index) => (
            <Button
              key={index}
              variant="ghost"
              className="h-auto p-4 justify-start hover:bg-muted/50"
              onClick={action.onClick}
            >
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-3 ${action.color}`}>
                <Icon name={action.icon} size={20} />
              </div>
              <div className="text-left">
                <p className="font-medium text-foreground text-sm">{action.label}</p>
                <p className="text-xs text-muted-foreground">{action.description}</p>
              </div>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuickActions;