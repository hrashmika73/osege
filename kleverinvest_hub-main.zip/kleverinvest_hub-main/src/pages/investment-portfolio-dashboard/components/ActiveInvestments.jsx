import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { cn } from '../../../utils/cn';

const ActiveInvestments = ({ investments }) => {
  const [expandedCard, setExpandedCard] = useState(null);

  const getRiskColor = (riskLevel) => {
    switch (riskLevel) {
      case 'low':
        return 'bg-success/10 text-success border-success/20';
      case 'medium':
        return 'bg-warning/10 text-warning border-warning/20';
      case 'high':
        return 'bg-error/10 text-error border-error/20';
      default:
        return 'bg-muted/10 text-muted-foreground border-muted/20';
    }
  };

  const toggleExpanded = (investmentId) => {
    setExpandedCard(expandedCard === investmentId ? null : investmentId);
  };

  if (!investments?.length) {
    return (
      <div className="bg-card border rounded-lg p-8 text-center">
        <div className="w-16 h-16 bg-muted/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="TrendingUp" size={32} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-2">No Active Investments</h3>
        <p className="text-muted-foreground mb-4">Start your investment journey today</p>
        <Button>
          <Icon name="Plus" size={16} />
          Browse Opportunities
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 sm:p-6 border-b">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Active Investments</h3>
          <span className="text-sm text-muted-foreground">{investments.length} active</span>
        </div>
      </div>

      <div className="p-4 sm:p-6 space-y-4">
        {investments.map((investment) => {
          const isExpanded = expandedCard === investment.id;
          const progressPercentage = (investment.progress / 100) * 100;
          const currentReturn = ((investment.currentValue - investment.invested) / investment.invested) * 100;
          const isProfit = currentReturn >= 0;

          return (
            <div
              key={investment.id}
              className="border rounded-lg p-4 hover:shadow-md transition-all duration-200"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="font-semibold text-foreground">{investment.name}</h4>
                    <span className={cn(
                      "px-2 py-1 rounded-full text-xs font-medium border",
                      getRiskColor(investment.riskLevel)
                    )}>
                      {investment.riskLevel}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">{investment.symbol}</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleExpanded(investment.id)}
                >
                  <Icon 
                    name={isExpanded ? "ChevronUp" : "ChevronDown"} 
                    size={16} 
                  />
                </Button>
              </div>

              {/* Investment Overview */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Invested</p>
                  <p className="text-sm font-semibold text-foreground">
                    ${investment.invested.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Current Value</p>
                  <p className="text-sm font-semibold text-foreground">
                    ${investment.currentValue.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Return</p>
                  <p className={cn(
                    "text-sm font-semibold",
                    isProfit ? "text-success" : "text-error"
                  )}>
                    {isProfit ? '+' : ''}{currentReturn.toFixed(2)}%
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Days Left</p>
                  <p className="text-sm font-semibold text-foreground">
                    {investment.daysRemaining}
                  </p>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-muted-foreground">Progress</span>
                  <span className="text-xs font-medium text-foreground">{investment.progress}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full transition-all duration-300"
                    style={{ width: `${progressPercentage}%` }}
                  />
                </div>
              </div>

              {/* Expanded Details */}
              {isExpanded && (
                <div className="pt-4 border-t space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                        <Icon name="Calendar" size={16} className="text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Duration</p>
                        <p className="text-sm font-medium text-foreground">{investment.duration} days</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-success/10 rounded-full flex items-center justify-center">
                        <Icon name="Percent" size={16} className="text-success" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">APY</p>
                        <p className="text-sm font-medium text-foreground">{investment.apy}%</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-warning/10 rounded-full flex items-center justify-center">
                        <Icon name="Target" size={16} className="text-warning" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Projected Return</p>
                        <p className="text-sm font-medium text-foreground">{investment.projectedReturn}%</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Icon name="BarChart3" size={16} />
                      View Details
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <Icon name="ArrowUpRight" size={16} />
                      Early Exit
                    </Button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ActiveInvestments;