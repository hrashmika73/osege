import React from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from 'recharts';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const PerformanceCharts = ({ selectedTimeframe, onTimeframeChange }) => {
  const timeframes = [
    { label: '7D', value: '7d' },
    { label: '1M', value: '1m' },
    { label: '3M', value: '3m' },
    { label: '6M', value: '6m' },
    { label: '1Y', value: '1y' },
    { label: 'ALL', value: 'all' }
  ];

  // Mock chart data based on timeframe
  const getChartData = (timeframe) => {
    const baseData = {
      '7d': [
        { name: 'Mon', value: 42500, profit: 1200 },
        { name: 'Tue', value: 43200, profit: 1900 },
        { name: 'Wed', value: 42800, profit: 1500 },
        { name: 'Thu', value: 44100, profit: 2600 },
        { name: 'Fri', value: 45200, profit: 3700 },
        { name: 'Sat', value: 44800, profit: 3300 },
        { name: 'Sun', value: 45780, profit: 4280 }
      ],
      '1m': [
        { name: 'Week 1', value: 40000, profit: -2000 },
        { name: 'Week 2', value: 42500, profit: 500 },
        { name: 'Week 3', value: 44200, profit: 2200 },
        { name: 'Week 4', value: 45780, profit: 3780 }
      ],
      '3m': [
        { name: 'Month 1', value: 38000, profit: -4000 },
        { name: 'Month 2', value: 41500, profit: -500 },
        { name: 'Month 3', value: 45780, profit: 3780 }
      ],
      '6m': [
        { name: 'Jan', value: 35000, profit: -7000 },
        { name: 'Feb', value: 37500, profit: -4500 },
        { name: 'Mar', value: 40000, profit: -2000 },
        { name: 'Apr', value: 42500, profit: 500 },
        { name: 'May', value: 44200, profit: 2200 },
        { name: 'Jun', value: 45780, profit: 3780 }
      ],
      '1y': [
        { name: 'Q1', value: 30000, profit: -12000 },
        { name: 'Q2', value: 35000, profit: -7000 },
        { name: 'Q3', value: 40000, profit: -2000 },
        { name: 'Q4', value: 45780, profit: 3780 }
      ],
      'all': [
        { name: '2022', value: 25000, profit: -17000 },
        { name: '2023', value: 35000, profit: -7000 },
        { name: '2024', value: 45780, profit: 3780 }
      ]
    };
    return baseData[timeframe] || baseData['7d'];
  };

  const chartData = getChartData(selectedTimeframe);

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-popover border rounded-lg shadow-lg p-3">
          <p className="text-sm font-medium text-foreground mb-1">{label}</p>
          <p className="text-sm text-muted-foreground">
            Value: <span className="font-semibold text-foreground">
              ${data.value.toLocaleString()}
            </span>
          </p>
          <p className="text-sm text-muted-foreground">
            P&L: <span className={`font-semibold ${data.profit >= 0 ? 'text-success' : 'text-error'}`}>
              {data.profit >= 0 ? '+' : ''}${data.profit.toLocaleString()}
            </span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 sm:p-6 border-b">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Portfolio Performance</h3>
            <p className="text-sm text-muted-foreground">Track your investment growth over time</p>
          </div>
          
          {/* Timeframe Selector */}
          <div className="flex items-center space-x-1 bg-muted rounded-lg p-1">
            {timeframes.map((timeframe) => (
              <Button
                key={timeframe.value}
                variant={selectedTimeframe === timeframe.value ? "default" : "ghost"}
                size="xs"
                className="text-xs"
                onClick={() => onTimeframeChange(timeframe.value)}
              >
                {timeframe.label}
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 sm:p-6">
        {/* Portfolio Value Chart */}
        <div className="mb-8">
          <div className="flex items-center space-x-2 mb-4">
            <Icon name="TrendingUp" size={16} className="text-primary" />
            <h4 className="font-medium text-foreground">Portfolio Value</h4>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="portfolioGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--color-primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--color-primary))" stopOpacity={0.05}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--color-border))" />
                <XAxis 
                  dataKey="name" 
                  stroke="hsl(var(--color-muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--color-muted-foreground))"
                  fontSize={12}
                  tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="hsl(var(--color-primary))"
                  strokeWidth={2}
                  fill="url(#portfolioGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Profit/Loss Chart */}
        <div>
          <div className="flex items-center space-x-2 mb-4">
            <Icon name="BarChart3" size={16} className="text-success" />
            <h4 className="font-medium text-foreground">Profit & Loss</h4>
          </div>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--color-border))" />
                <XAxis 
                  dataKey="name" 
                  stroke="hsl(var(--color-muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--color-muted-foreground))"
                  fontSize={12}
                  tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="profit"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  stroke="hsl(var(--color-success))"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceCharts;