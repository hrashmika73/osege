import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { cn } from '../../../utils/cn';

const RecentActivity = ({ activities }) => {
  const getActivityIcon = (type) => {
    switch (type) {
      case 'investment_completed':
        return { name: 'CheckCircle', color: 'text-success' };
      case 'deposit':
        return { name: 'ArrowDownLeft', color: 'text-primary' };
      case 'withdrawal':
        return { name: 'ArrowUpRight', color: 'text-warning' };
      case 'earning':
        return { name: 'DollarSign', color: 'text-accent' };
      default:
        return { name: 'Activity', color: 'text-muted-foreground' };
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-success/10 text-success border-success/20';
      case 'pending':
        return 'bg-warning/10 text-warning border-warning/20';
      case 'failed':
        return 'bg-error/10 text-error border-error/20';
      default:
        return 'bg-muted/10 text-muted-foreground border-muted/20';
    }
  };

  const formatTime = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 60) {
      return `${minutes}m ago`;
    } else if (hours < 24) {
      return `${hours}h ago`;
    } else {
      return `${days}d ago`;
    }
  };

  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 sm:p-6 border-b">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Recent Activity</h3>
          <Button variant="ghost" size="sm">
            <Icon name="ExternalLink" size={16} />
            View All
          </Button>
        </div>
      </div>

      <div className="divide-y">
        {activities?.length > 0 ? (
          activities.map((activity) => {
            const iconConfig = getActivityIcon(activity.type);
            const isPositiveAmount = activity.amount?.startsWith('+');

            return (
              <div key={activity.id} className="p-4 sm:p-6 hover:bg-muted/30 transition-colors">
                <div className="flex items-start space-x-4">
                  {/* Icon */}
                  <div className={cn(
                    "flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center",
                    activity.status === 'completed' ? 'bg-success/10' :
                    activity.status === 'pending'? 'bg-warning/10' : 'bg-muted/10'
                  )}>
                    <Icon 
                      name={iconConfig.name} 
                      size={20} 
                      className={iconConfig.color}
                    />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <div className="flex-1">
                        <h4 className="text-sm font-medium text-foreground truncate">
                          {activity.title}
                        </h4>
                        <p className="text-sm text-muted-foreground mt-1">
                          {activity.description}
                        </p>
                      </div>
                      
                      {activity.amount && (
                        <div className={cn(
                          "text-sm font-semibold ml-2 flex-shrink-0",
                          isPositiveAmount ? "text-success" : "text-error"
                        )}>
                          {activity.amount}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center space-x-2">
                        <span className={cn(
                          "px-2 py-1 rounded-full text-xs font-medium border capitalize",
                          getStatusBadge(activity.status)
                        )}>
                          {activity.status}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {formatTime(activity.timestamp)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-8 text-center">
            <div className="w-12 h-12 bg-muted/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <Icon name="Activity" size={24} className="text-muted-foreground" />
            </div>
            <p className="text-sm text-muted-foreground">No recent activity</p>
          </div>
        )}
      </div>

      {activities?.length > 0 && (
        <div className="p-4 sm:p-6 border-t bg-muted/20">
          <Button variant="outline" size="sm" className="w-full">
            <Icon name="History" size={16} />
            View Transaction History
          </Button>
        </div>
      )}
    </div>
  );
};

export default RecentActivity;