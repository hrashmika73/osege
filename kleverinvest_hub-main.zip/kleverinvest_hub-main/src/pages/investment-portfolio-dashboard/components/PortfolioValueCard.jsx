import React from 'react';
import Icon from '../../../components/AppIcon';
import { cn } from '../../../utils/cn';

const PortfolioValueCard = ({ portfolioData, className }) => {
  const isPositive = portfolioData?.dayChange >= 0;
  const isProfitable = portfolioData?.profitLoss >= 0;

  return (
    <div className={cn("bg-gradient-to-br from-primary to-primary/80 rounded-xl p-6 text-white shadow-lg", className)}>
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between space-y-4 sm:space-y-0">
        {/* Total Balance */}
        <div className="flex-1">
          <p className="text-primary-foreground/70 text-sm font-medium mb-1">
            Total Portfolio Value
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-2">
            ${portfolioData?.totalBalance?.toLocaleString('en-US', { 
              minimumFractionDigits: 2, 
              maximumFractionDigits: 2 
            })}
          </h2>
          
          {/* 24h Change */}
          <div className="flex flex-wrap items-center gap-4">
            <div className={cn(
              "flex items-center space-x-1 px-2 py-1 rounded-full text-sm font-medium",
              isPositive 
                ? "bg-success/20 text-success-foreground" 
                : "bg-error/20 text-error-foreground"
            )}>
              <Icon 
                name={isPositive ? "TrendingUp" : "TrendingDown"} 
                size={14} 
              />
              <span>
                {isPositive ? '+' : ''}{portfolioData?.dayChange?.toFixed(2)}%
              </span>
            </div>
            
            <div className="text-primary-foreground/80 text-sm">
              {isPositive ? '+' : ''}${Math.abs(portfolioData?.dayChangeAmount || 0).toLocaleString('en-US', { 
                minimumFractionDigits: 2, 
                maximumFractionDigits: 2 
              })} today
            </div>
          </div>
        </div>

        {/* Profit/Loss Summary */}
        <div className="flex-shrink-0 text-right sm:text-right">
          <p className="text-primary-foreground/70 text-sm font-medium mb-1">
            Total P&L
          </p>
          <div className={cn(
            "text-xl sm:text-2xl font-bold",
            isProfitable ? "text-success-foreground" : "text-error-foreground"
          )}>
            {isProfitable ? '+' : ''}${Math.abs(portfolioData?.profitLoss || 0).toLocaleString('en-US', { 
              minimumFractionDigits: 2, 
              maximumFractionDigits: 2 
            })}
          </div>
          <div className={cn(
            "text-sm font-medium",
            isProfitable ? "text-success-foreground/80" : "text-error-foreground/80"
          )}>
            {isProfitable ? '+' : ''}{portfolioData?.profitLossPercentage?.toFixed(2)}%
          </div>
        </div>
      </div>

      {/* Performance Indicators */}
      <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-primary-foreground/20">
        <div className="text-center">
          <div className="flex items-center justify-center w-10 h-10 bg-white/10 rounded-full mx-auto mb-2">
            <Icon name="TrendingUp" size={20} className="text-white" />
          </div>
          <p className="text-xs text-primary-foreground/70 mb-1">Active</p>
          <p className="text-sm font-semibold text-white">3 Investments</p>
        </div>
        
        <div className="text-center">
          <div className="flex items-center justify-center w-10 h-10 bg-white/10 rounded-full mx-auto mb-2">
            <Icon name="Clock" size={20} className="text-white" />
          </div>
          <p className="text-xs text-primary-foreground/70 mb-1">Avg Duration</p>
          <p className="text-sm font-semibold text-white">45 Days</p>
        </div>
        
        <div className="text-center">
          <div className="flex items-center justify-center w-10 h-10 bg-white/10 rounded-full mx-auto mb-2">
            <Icon name="Percent" size={20} className="text-white" />
          </div>
          <p className="text-xs text-primary-foreground/70 mb-1">Avg APY</p>
          <p className="text-sm font-semibold text-white">20.0%</p>
        </div>
      </div>
    </div>
  );
};

export default PortfolioValueCard;