import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

import NotificationTabs from './components/NotificationTabs';
import NotificationList from './components/NotificationList';
import NotificationSettings from './components/NotificationSettings';
import BulkActions from './components/BulkActions';
import SearchFilter from './components/SearchFilter';

const NotificationsCenter = () => {
  const navigate = useNavigate();
  const { isUserAuthenticated } = useUserAuth();
  const { isAdminAuthenticated } = useAdminAuth();
  const [activeTab, setActiveTab] = useState('all');

  // Determine correct dashboard URL based on authentication
  const getDashboardUrl = () => {
    if (isAdminAuthenticated) return '/admin-dashboard';
    if (isUserAuthenticated) return '/user-dashboard';
    return '/login-selection'; // fallback
  };

  // Redirect to appropriate login if not authenticated
  useEffect(() => {
    if (!isUserAuthenticated && !isAdminAuthenticated) {
      navigate('/login-selection');
    }
  }, [isUserAuthenticated, isAdminAuthenticated, navigate]);

  // Don't render if not authenticated
  if (!isUserAuthenticated && !isAdminAuthenticated) {
    return null;
  }
  const [selectedNotifications, setSelectedNotifications] = useState(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPriority, setFilterPriority] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [showSettings, setShowSettings] = useState(false);

  const [notifications, setNotifications] = useState([
    {
      id: 'inv001',
      category: 'investments',
      type: 'portfolio_update',
      title: 'Portfolio Value Increased',
      message: 'Your investment portfolio has increased by 8.5% this week',
      timestamp: new Date(Date.now() - 300000),
      priority: 'medium',
      isRead: false,
      actionRequired: false,
      relatedData: {
        amount: 2125.50,
        percentage: 8.5,
        period: 'week'
      },
      actionUrl: '/dashboard' // Will be dynamically resolved
    },
    {
      id: 'sec001',
      category: 'security',
      type: 'login_attempt',
      title: 'New Login Detected',
      message: 'Someone logged into your account from Chrome on Windows',
      timestamp: new Date(Date.now() - 600000),
      priority: 'high',
      isRead: false,
      actionRequired: true,
      relatedData: {
        device: 'Chrome on Windows',
        location: 'New York, US',
        ipAddress: '192.168.1.100'
      }
    },
    {
      id: 'inv002',
      category: 'investments',
      type: 'maturity_alert',
      title: 'Investment Maturity Alert',
      message: 'Your Bitcoin investment plan will mature in 3 days',
      timestamp: new Date(Date.now() - 900000),
      priority: 'medium',
      isRead: true,
      actionRequired: true,
      relatedData: {
        planName: 'Bitcoin Growth Plan',
        maturityDate: new Date(Date.now() + 259200000),
        principal: 5000,
        expectedReturn: 5750
      }
    },
    {
      id: 'sys001',
      category: 'system',
      type: 'maintenance',
      title: 'Scheduled Maintenance',
      message: 'Platform maintenance scheduled for tonight 2:00 AM - 4:00 AM UTC',
      timestamp: new Date(Date.now() - 1800000),
      priority: 'low',
      isRead: true,
      actionRequired: false,
      relatedData: {
        maintenanceStart: new Date(Date.now() + 86400000),
        maintenanceEnd: new Date(Date.now() + 93600000),
        affectedServices: ['API', 'Trading Engine']
      }
    },
    {
      id: 'inv003',
      category: 'investments',
      type: 'profit_summary',
      title: 'Weekly Profit Summary',
      message: 'You earned $342.75 in profits this week across all investments',
      timestamp: new Date(Date.now() - 2400000),
      priority: 'medium',
      isRead: false,
      actionRequired: false,
      relatedData: {
        totalProfit: 342.75,
        period: 'week',
        topPerformer: 'Bitcoin Growth Plan',
        topPerformerProfit: 187.25
      }
    },
    {
      id: 'sec002',
      category: 'security',
      type: 'password_change',
      title: 'Password Changed Successfully',
      message: 'Your account password was changed successfully',
      timestamp: new Date(Date.now() - 3600000),
      priority: 'low',
      isRead: true,
      actionRequired: false,
      relatedData: {
        changeTime: new Date(Date.now() - 3600000),
        device: 'Chrome on Windows'
      }
    },
    {
      id: 'sys002',
      category: 'system',
      type: 'feature_announcement',
      title: 'New Feature: Advanced Analytics',
      message: 'We\'ve launched advanced portfolio analytics with detailed insights',
      timestamp: new Date(Date.now() - 7200000),
      priority: 'low',
      isRead: false,
      actionRequired: false,
      relatedData: {
        featureName: 'Advanced Analytics',
        releaseDate: new Date(Date.now() - 7200000),
        description: 'Detailed portfolio insights and performance metrics'
      }
    }
  ]);

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    smsNotifications: false,
    categories: {
      investments: {
        enabled: true,
        email: true,
        push: true,
        sms: false
      },
      security: {
        enabled: true,
        email: true,
        push: true,
        sms: true
      },
      system: {
        enabled: true,
        email: false,
        push: true,
        sms: false
      }
    },
    quietHours: {
      enabled: true,
      start: '22:00',
      end: '08:00'
    }
  });

  useEffect(() => {
    // Simulate real-time notifications
    const interval = setInterval(() => {
      const shouldAddNotification = Math.random() < 0.1; // 10% chance every 30 seconds
      
      if (shouldAddNotification) {
        const mockNotifications = [
          {
            category: 'investments',
            type: 'price_alert',
            title: 'Price Alert Triggered',
            message: 'Bitcoin price has reached your target of $46,000',
            priority: 'medium'
          },
          {
            category: 'security',
            type: 'suspicious_activity',
            title: 'Suspicious Activity Detected',
            message: 'Multiple failed login attempts detected',
            priority: 'high'
          }
        ];

        const randomNotification = mockNotifications[Math.floor(Math.random() * mockNotifications.length)];
        const newNotification = {
          id: `auto_${Date.now()}`,
          ...randomNotification,
          timestamp: new Date(),
          isRead: false,
          actionRequired: randomNotification.priority === 'high'
        };

        setNotifications(prev => [newNotification, ...prev.slice(0, 19)]); // Keep only 20 notifications
      }
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const tabs = [
    { id: 'all', label: 'All', icon: 'Bell', count: notifications.length },
    { 
      id: 'investments', 
      label: 'Investments', 
      icon: 'TrendingUp', 
      count: notifications.filter(n => n.category === 'investments').length 
    },
    { 
      id: 'security', 
      label: 'Security', 
      icon: 'Shield', 
      count: notifications.filter(n => n.category === 'security').length 
    },
    { 
      id: 'system', 
      label: 'System', 
      icon: 'Settings', 
      count: notifications.filter(n => n.category === 'system').length 
    }
  ];

  const getFilteredNotifications = () => {
    let filtered = notifications;

    // Filter by tab
    if (activeTab !== 'all') {
      filtered = filtered.filter(n => n.category === activeTab);
    }

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(n => 
        n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.message.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by priority
    if (filterPriority !== 'all') {
      filtered = filtered.filter(n => n.priority === filterPriority);
    }

    // Sort notifications
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'oldest':
          return a.timestamp - b.timestamp;
        case 'priority':
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          return priorityOrder[b.priority] - priorityOrder[a.priority];
        case 'unread':
          if (a.isRead !== b.isRead) return a.isRead - b.isRead;
          return b.timestamp - a.timestamp;
        default: // newest
          return b.timestamp - a.timestamp;
      }
    });

    return filtered;
  };

  const handleNotificationClick = (notification) => {
    // Mark as read
    setNotifications(prev =>
      prev.map(n => n.id === notification.id ? { ...n, isRead: true } : n)
    );

    // Navigate to related page if action URL exists
    if (notification.actionUrl) {
      navigate(notification.actionUrl);
    }
  };

  const handleBulkAction = (action) => {
    const selectedIds = Array.from(selectedNotifications);
    
    switch (action) {
      case 'markRead':
        setNotifications(prev =>
          prev.map(n => selectedIds.includes(n.id) ? { ...n, isRead: true } : n)
        );
        break;
      case 'markUnread':
        setNotifications(prev =>
          prev.map(n => selectedIds.includes(n.id) ? { ...n, isRead: false } : n)
        );
        break;
      case 'delete':
        setNotifications(prev => prev.filter(n => !selectedIds.includes(n.id)));
        break;
      case 'archive':
        // In a real app, this would move to archive
        setNotifications(prev => prev.filter(n => !selectedIds.includes(n.id)));
        break;
    }
    
    setSelectedNotifications(new Set());
  };

  const handleSelectAll = () => {
    const filteredNotifications = getFilteredNotifications();
    if (selectedNotifications.size === filteredNotifications.length) {
      setSelectedNotifications(new Set());
    } else {
      setSelectedNotifications(new Set(filteredNotifications.map(n => n.id)));
    }
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const filteredNotifications = getFilteredNotifications();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b px-4 md:px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Notifications Center</h1>
            <p className="text-muted-foreground">
              Manage all your platform communications and alerts
              {unreadCount > 0 && (
                <span className="ml-2 px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full">
                  {unreadCount} unread
                </span>
              )}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => setShowSettings(!showSettings)}>
              <Icon name="Settings" size={16} />
              <span className="hidden sm:inline ml-2">Settings</span>
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate(getDashboardUrl())}>
              <Icon name="ArrowLeft" size={16} />
              <span className="hidden sm:inline ml-2">Back to Dashboard</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="p-4 md:p-6">
        {showSettings ? (
          <NotificationSettings
            settings={notificationSettings}
            onUpdate={setNotificationSettings}
            onClose={() => setShowSettings(false)}
          />
        ) : (
          <>
            {/* Search and Filters */}
            <SearchFilter
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              filterPriority={filterPriority}
              onFilterChange={setFilterPriority}
              sortBy={sortBy}
              onSortChange={setSortBy}
            />

            {/* Tab Navigation */}
            <NotificationTabs
              tabs={tabs}
              activeTab={activeTab}
              onTabChange={setActiveTab}
            />

            {/* Bulk Actions */}
            {selectedNotifications.size > 0 && (
              <BulkActions
                selectedCount={selectedNotifications.size}
                totalCount={filteredNotifications.length}
                onAction={handleBulkAction}
                onSelectAll={handleSelectAll}
                onClearSelection={() => setSelectedNotifications(new Set())}
              />
            )}

            {/* Notifications List */}
            <NotificationList
              notifications={filteredNotifications}
              selectedNotifications={selectedNotifications}
              onNotificationClick={handleNotificationClick}
              onSelectionChange={(id, selected) => {
                const newSelection = new Set(selectedNotifications);
                if (selected) {
                  newSelection.add(id);
                } else {
                  newSelection.delete(id);
                }
                setSelectedNotifications(newSelection);
              }}
            />
          </>
        )}
      </div>
    </div>
  );
};

export default NotificationsCenter;
