import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const NotificationList = ({ 
  notifications, 
  selectedNotifications, 
  onNotificationClick, 
  onSelectionChange 
}) => {
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return 'text-error';
      case 'medium':
        return 'text-warning';
      default:
        return 'text-muted-foreground';
    }
  };

  const getCategoryIcon = (category) => {
    const icons = {
      investments: 'TrendingUp',
      security: 'Shield',
      system: 'Settings'
    };
    return icons[category] || 'Bell';
  };

  const getCategoryColor = (category) => {
    const colors = {
      investments: 'bg-success/10 text-success',
      security: 'bg-error/10 text-error',
      system: 'bg-primary/10 text-primary'
    };
    return colors[category] || 'bg-muted/10 text-muted-foreground';
  };

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days}d ago`;
    
    return timestamp.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: timestamp.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
    });
  };

  const getNotificationPreview = (notification) => {
    if (notification.relatedData) {
      switch (notification.type) {
        case 'portfolio_update':
          return `+${notification.relatedData.percentage}% this ${notification.relatedData.period}`;
        case 'profit_summary':
          return `$${notification.relatedData.totalProfit} earned`;
        case 'maturity_alert':
          return `Expected: $${notification.relatedData.expectedReturn}`;
        case 'login_attempt':
          return notification.relatedData.location;
        default:
          return null;
      }
    }
    return null;
  };

  if (notifications.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Bell" size={24} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium text-foreground mb-2">No notifications found</h3>
        <p className="text-muted-foreground">
          Your notifications will appear here when they arrive.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {notifications.map((notification) => {
        const isSelected = selectedNotifications.has(notification.id);
        const preview = getNotificationPreview(notification);

        return (
          <div
            key={notification.id}
            className={`group relative bg-card border rounded-lg p-4 transition-all duration-200 hover:shadow-sm ${
              !notification.isRead ? 'border-l-4 border-l-primary' : ''
            } ${isSelected ? 'ring-2 ring-primary/20 bg-primary/5' : ''}`}
          >
            <div className="flex items-start space-x-3">
              {/* Selection Checkbox */}
              <div className="flex items-center mt-1">
                <Checkbox
                  checked={isSelected}
                  onChange={(checked) => onSelectionChange(notification.id, checked)}
                />
              </div>

              {/* Category Icon */}
              <div className={`p-2 rounded-lg ${getCategoryColor(notification.category)} shrink-0`}>
                <Icon name={getCategoryIcon(notification.category)} size={16} />
              </div>

              {/* Notification Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2 flex-1">
                    <h4 className={`font-medium truncate ${
                      !notification.isRead ? 'text-foreground' : 'text-muted-foreground'
                    }`}>
                      {notification.title}
                    </h4>
                    
                    {/* Priority indicator */}
                    {notification.priority === 'high' && (
                      <div className="flex items-center space-x-1">
                        <Icon name="AlertCircle" size={12} className="text-error" />
                      </div>
                    )}
                    
                    {/* Action required indicator */}
                    {notification.actionRequired && (
                      <div className="flex items-center space-x-1">
                        <Icon name="Clock" size={12} className="text-warning" />
                      </div>
                    )}
                    
                    {/* Unread indicator */}
                    {!notification.isRead && (
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    )}
                  </div>

                  <div className="flex items-center space-x-2 text-xs text-muted-foreground ml-4">
                    <Icon name={getPriorityColor(notification.priority)} size={8} className={getPriorityColor(notification.priority)} />
                    <span>{formatTimestamp(notification.timestamp)}</span>
                  </div>
                </div>

                <p className={`text-sm mb-3 line-clamp-2 ${
                  !notification.isRead ? 'text-foreground' : 'text-muted-foreground'
                }`}>
                  {notification.message}
                </p>

                {/* Preview/Additional Info */}
                {preview && (
                  <div className="mb-3">
                    <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-muted/50 text-muted-foreground">
                      {preview}
                    </span>
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onNotificationClick(notification)}
                      className="text-xs"
                    >
                      {notification.actionRequired ? 'Take Action' : 'View Details'}
                      <Icon name="ArrowRight" size={12} className="ml-1" />
                    </Button>
                  </div>

                  <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {!notification.isRead && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          onNotificationClick(notification);
                        }}
                        className="p-1 h-auto"
                      >
                        <Icon name="Check" size={12} />
                      </Button>
                    )}
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Handle archive/delete
                      }}
                      className="p-1 h-auto"
                    >
                      <Icon name="Archive" size={12} />
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Handle more options
                      }}
                      className="p-1 h-auto"
                    >
                      <Icon name="MoreVertical" size={12} />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })}

      {/* Load More */}
      {notifications.length >= 20 && (
        <div className="text-center pt-6">
          <Button variant="outline">
            <Icon name="ChevronDown" size={16} />
            Load More Notifications
          </Button>
        </div>
      )}
    </div>
  );
};

export default NotificationList;