import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import Select from '../../../components/ui/Select';


const NotificationSettings = ({ settings, onUpdate, onClose }) => {
  const [localSettings, setLocalSettings] = useState(settings);
  const [hasChanges, setHasChanges] = useState(false);

  const handleToggle = (path, value) => {
    const newSettings = { ...localSettings };
    const keys = path.split('.');
    let current = newSettings;
    
    for (let i = 0; i < keys.length - 1; i++) {
      current = current[keys[i]];
    }
    
    current[keys[keys.length - 1]] = value;
    setLocalSettings(newSettings);
    setHasChanges(true);
  };

  const handleSave = () => {
    onUpdate(localSettings);
    setHasChanges(false);
    // Show success toast in real app
  };

  const handleReset = () => {
    setLocalSettings(settings);
    setHasChanges(false);
  };

  const timeOptions = Array.from({ length: 24 }, (_, i) => {
    const hour = i.toString().padStart(2, '0');
    return { value: `${hour}:00`, label: `${hour}:00` };
  });

  const categories = [
    {
      id: 'investments',
      label: 'Investment Notifications',
      description: 'Updates about your portfolio, maturity alerts, and profit summaries',
      icon: 'TrendingUp'
    },
    {
      id: 'security',
      label: 'Security Alerts',
      description: 'Login attempts, password changes, and suspicious activities',
      icon: 'Shield'
    },
    {
      id: 'system',
      label: 'System Updates',
      description: 'Maintenance notifications, feature announcements, and policy changes',
      icon: 'Settings'
    }
  ];

  return (
    <div className="bg-card rounded-lg border">
      {/* Header */}
      <div className="border-b p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-foreground">Notification Settings</h2>
            <p className="text-sm text-muted-foreground">
              Customize how and when you receive notifications
            </p>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <Icon name="X" size={16} />
          </Button>
        </div>
      </div>

      <div className="p-6 space-y-8">
        {/* Global Settings */}
        <div>
          <h3 className="text-base font-semibold text-foreground mb-4">Global Preferences</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
              <div className="flex items-center space-x-3">
                <Icon name="Mail" size={20} className="text-primary" />
                <div>
                  <p className="font-medium text-foreground">Email Notifications</p>
                  <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                </div>
              </div>
              <Checkbox
                checked={localSettings.emailNotifications}
                onChange={(checked) => handleToggle('emailNotifications', checked)}
              />
            </div>

            <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
              <div className="flex items-center space-x-3">
                <Icon name="Bell" size={20} className="text-primary" />
                <div>
                  <p className="font-medium text-foreground">Push Notifications</p>
                  <p className="text-sm text-muted-foreground">Receive browser push notifications</p>
                </div>
              </div>
              <Checkbox
                checked={localSettings.pushNotifications}
                onChange={(checked) => handleToggle('pushNotifications', checked)}
              />
            </div>

            <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
              <div className="flex items-center space-x-3">
                <Icon name="MessageSquare" size={20} className="text-primary" />
                <div>
                  <p className="font-medium text-foreground">SMS Notifications</p>
                  <p className="text-sm text-muted-foreground">Receive notifications via SMS</p>
                </div>
              </div>
              <Checkbox
                checked={localSettings.smsNotifications}
                onChange={(checked) => handleToggle('smsNotifications', checked)}
              />
            </div>
          </div>
        </div>

        {/* Category Settings */}
        <div>
          <h3 className="text-base font-semibold text-foreground mb-4">Notification Categories</h3>
          <div className="space-y-4">
            {categories.map((category) => {
              const categorySettings = localSettings.categories[category.id];
              
              return (
                <div key={category.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <Icon name={category.icon} size={20} className="text-primary" />
                      <div>
                        <p className="font-medium text-foreground">{category.label}</p>
                        <p className="text-sm text-muted-foreground">{category.description}</p>
                      </div>
                    </div>
                    <Checkbox
                      checked={categorySettings.enabled}
                      onChange={(checked) => handleToggle(`categories.${category.id}.enabled`, checked)}
                    />
                  </div>

                  {categorySettings.enabled && (
                    <div className="ml-8 space-y-3 pt-3 border-t">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Email</span>
                        <Checkbox
                          checked={categorySettings.email && localSettings.emailNotifications}
                          onChange={(checked) => handleToggle(`categories.${category.id}.email`, checked)}
                          disabled={!localSettings.emailNotifications}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Push</span>
                        <Checkbox
                          checked={categorySettings.push && localSettings.pushNotifications}
                          onChange={(checked) => handleToggle(`categories.${category.id}.push`, checked)}
                          disabled={!localSettings.pushNotifications}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">SMS</span>
                        <Checkbox
                          checked={categorySettings.sms && localSettings.smsNotifications}
                          onChange={(checked) => handleToggle(`categories.${category.id}.sms`, checked)}
                          disabled={!localSettings.smsNotifications}
                        />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Quiet Hours */}
        <div>
          <h3 className="text-base font-semibold text-foreground mb-4">Quiet Hours</h3>
          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <Icon name="Moon" size={20} className="text-primary" />
                <div>
                  <p className="font-medium text-foreground">Enable Quiet Hours</p>
                  <p className="text-sm text-muted-foreground">
                    Pause non-critical notifications during specified hours
                  </p>
                </div>
              </div>
              <Checkbox
                checked={localSettings.quietHours.enabled}
                onChange={(checked) => handleToggle('quietHours.enabled', checked)}
              />
            </div>

            {localSettings.quietHours.enabled && (
              <div className="ml-8 pt-3 border-t">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Start Time
                    </label>
                    <Select
                      value={localSettings.quietHours.start}
                      onChange={(value) => handleToggle('quietHours.start', value)}
                      options={timeOptions}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      End Time
                    </label>
                    <Select
                      value={localSettings.quietHours.end}
                      onChange={(value) => handleToggle('quietHours.end', value)}
                      options={timeOptions}
                    />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Security alerts will still be delivered during quiet hours
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-6 border-t">
          <Button variant="outline" onClick={handleReset} disabled={!hasChanges}>
            <Icon name="RotateCcw" size={16} />
            Reset Changes
          </Button>
          
          <div className="flex space-x-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={!hasChanges}>
              <Icon name="Check" size={16} />
              Save Settings
            </Button>
          </div>
        </div>

        {/* Additional Options */}
        <div className="pt-6 border-t">
          <h3 className="text-base font-semibold text-foreground mb-4">Advanced Options</h3>
          <div className="space-y-3">
            <Button variant="outline" size="sm">
              <Icon name="Download" size={14} />
              Export Notification History
            </Button>
            <Button variant="outline" size="sm">
              <Icon name="Trash2" size={14} />
              Clear All Notifications
            </Button>
            <Button variant="outline" size="sm">
              <Icon name="TestTube" size={14} />
              Send Test Notification
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationSettings;