import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const BulkActions = ({ 
  selectedCount, 
  totalCount, 
  onAction, 
  onSelectAll, 
  onClearSelection 
}) => {
  const actions = [
    {
      id: 'markRead',
      label: 'Mark as Read',
      icon: 'Check',
      variant: 'outline'
    },
    {
      id: 'markUnread',
      label: 'Mark as Unread',
      icon: 'Minus',
      variant: 'outline'
    },
    {
      id: 'archive',
      label: 'Archive',
      icon: 'Archive',
      variant: 'outline'
    },
    {
      id: 'delete',
      label: 'Delete',
      icon: 'Trash2',
      variant: 'outline',
      destructive: true
    }
  ];

  return (
    <div className="bg-card border rounded-lg p-4 mb-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        {/* Selection Info */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={onSelectAll}
              className="text-sm"
            >
              {selectedCount === totalCount ? (
                <>
                  <Icon name="Minus" size={14} />
                  Deselect All
                </>
              ) : (
                <>
                  <Icon name="Check" size={14} />
                  Select All ({totalCount})
                </>
              )}
            </Button>
          </div>
          
          <div className="h-4 w-px bg-border"></div>
          
          <span className="text-sm text-muted-foreground">
            {selectedCount} of {totalCount} selected
          </span>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearSelection}
            className="text-sm"
          >
            <Icon name="X" size={12} />
            Clear
          </Button>
        </div>

        {/* Bulk Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {actions.map((action) => (
            <Button
              key={action.id}
              variant={action.variant}
              size="sm"
              onClick={() => onAction(action.id)}
              className={`${action.destructive ? 'text-error hover:bg-error/10' : ''}`}
            >
              <Icon name={action.icon} size={14} />
              <span className="hidden sm:inline ml-2">{action.label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Progress indicator */}
      <div className="mt-4">
        <div className="w-full bg-muted rounded-full h-1">
          <div
            className="bg-primary h-1 rounded-full transition-all duration-300"
            style={{ width: `${(selectedCount / totalCount) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default BulkActions;