import React from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const SearchFilter = ({ 
  searchQuery, 
  onSearchChange, 
  filterPriority, 
  onFilterChange, 
  sortBy, 
  onSortChange 
}) => {
  const priorityOptions = [
    { value: 'all', label: 'All Priorities' },
    { value: 'high', label: 'High Priority' },
    { value: 'medium', label: 'Medium Priority' },
    { value: 'low', label: 'Low Priority' }
  ];

  const sortOptions = [
    { value: 'newest', label: 'Newest First' },
    { value: 'oldest', label: 'Oldest First' },
    { value: 'priority', label: 'By Priority' },
    { value: 'unread', label: 'Unread First' }
  ];

  const handleClearFilters = () => {
    onSearchChange('');
    onFilterChange('all');
    onSortChange('newest');
  };

  const hasActiveFilters = searchQuery || filterPriority !== 'all' || sortBy !== 'newest';

  return (
    <div className="bg-card border rounded-lg p-4 mb-6">
      <div className="flex flex-col md:flex-row gap-4">
        {/* Search */}
        <div className="flex-1 max-w-md">
          <div className="relative">
            <Icon name="Search" size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search notifications..."
              className="pl-10"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="min-w-40">
            <Select
              value={filterPriority}
              onChange={onFilterChange}
              options={priorityOptions}
              placeholder="Filter by priority"
            />
          </div>
          
          <div className="min-w-40">
            <Select
              value={sortBy}
              onChange={onSortChange}
              options={sortOptions}
              placeholder="Sort by"
            />
          </div>

          {hasActiveFilters && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleClearFilters}
              className="shrink-0"
            >
              <Icon name="X" size={14} />
              Clear
            </Button>
          )}
        </div>
      </div>

      {/* Filter Summary */}
      {hasActiveFilters && (
        <div className="mt-4 pt-4 border-t">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm text-muted-foreground">Active filters:</span>
            
            {searchQuery && (
              <span className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-primary/10 text-primary">
                Search: "{searchQuery}"
                <button
                  onClick={() => onSearchChange('')}
                  className="ml-1 hover:bg-primary/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={10} />
                </button>
              </span>
            )}
            
            {filterPriority !== 'all' && (
              <span className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-warning/10 text-warning">
                Priority: {filterPriority}
                <button
                  onClick={() => onFilterChange('all')}
                  className="ml-1 hover:bg-warning/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={10} />
                </button>
              </span>
            )}
            
            {sortBy !== 'newest' && (
              <span className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-success/10 text-success">
                Sort: {sortOptions.find(opt => opt.value === sortBy)?.label}
                <button
                  onClick={() => onSortChange('newest')}
                  className="ml-1 hover:bg-success/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={10} />
                </button>
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchFilter;