import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminAcceptedDeposits = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [deposits, setDeposits] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState('7days');

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadAcceptedDeposits();
  }, [isAdminAuthenticated, navigate, dateRange]);

  const loadAcceptedDeposits = () => {
    setLoading(true);
    setTimeout(() => {
      const mockDeposits = [
        {
          id: 1,
          transactionId: 'DEP_ACCEPTED_001',
          userId: 'user_001',
          username: 'john_investor',
          fullName: 'John Smith',
          amount: 5000,
          currency: 'USD',
          gateway: 'PayPal',
          approvedDate: '2024-01-14T15:30:00Z',
          approvedBy: 'admin_001',
          processingTime: '2 hours'
        },
        {
          id: 2,
          transactionId: 'DEP_ACCEPTED_002',
          userId: 'user_002',
          username: 'sarah_trader',
          fullName: 'Sarah Johnson',
          amount: 2500,
          currency: 'USD',
          gateway: 'Stripe',
          approvedDate: '2024-01-13T11:20:00Z',
          approvedBy: 'admin_002',
          processingTime: '1 hour'
        }
      ];
      setDeposits(mockDeposits);
      setLoading(false);
    }, 1000);
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Accepted Deposits"
        breadcrumb={[
          { label: "Gateway Management", link: "/admin-payment-gateway" },
          { label: "Accepted Deposits" }
        ]}
        actions={[
          {
            label: "Export Data",
            icon: "Download",
            variant: "outline",
            onClick: () => alert('Export functionality')
          }
        ]}
      />

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Accepted</p>
                <p className="text-2xl font-bold text-foreground">{deposits.length}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Icon name="CheckCircle" size={24} className="text-green-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Value</p>
                <p className="text-2xl font-bold text-foreground">
                  {formatCurrency(deposits.reduce((sum, d) => sum + d.amount, 0))}
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Icon name="DollarSign" size={24} className="text-blue-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">This Week</p>
                <p className="text-2xl font-bold text-foreground">{deposits.length}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Icon name="Calendar" size={24} className="text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-card border rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search accepted deposits..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="7days">Last 7 days</option>
              <option value="30days">Last 30 days</option>
              <option value="90days">Last 90 days</option>
            </select>
          </div>
        </div>

        <div className="bg-card border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Transaction</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">User</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Gateway</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Approved Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Approved By</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {loading ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center">
                      <div className="flex items-center justify-center">
                        <Icon name="Loader" size={20} className="animate-spin mr-2" />
                        Loading accepted deposits...
                      </div>
                    </td>
                  </tr>
                ) : deposits.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center text-muted-foreground">No accepted deposits found</td>
                  </tr>
                ) : (
                  deposits.map((deposit) => (
                    <tr key={deposit.id} className="hover:bg-muted/30">
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-foreground">{deposit.transactionId}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                            <span className="text-xs font-medium text-primary">
                              {deposit.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-foreground">{deposit.fullName}</div>
                            <div className="text-xs text-muted-foreground">@{deposit.username}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-foreground">{formatCurrency(deposit.amount)}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">{deposit.gateway}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">{formatDateTime(deposit.approvedDate)}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">{deposit.approvedBy}</div>
                      </td>
                      <td className="px-6 py-4">
                        <Button size="sm" variant="outline" onClick={() => alert('View details')}>
                          <Icon name="Eye" size={16} />
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminAcceptedDeposits;
