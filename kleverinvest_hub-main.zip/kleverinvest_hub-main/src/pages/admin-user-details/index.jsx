import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminUserDetails = () => {
  const navigate = useNavigate();
  const { userId } = useParams();
  const { isAdminAuthenticated } = useAdminAuth();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadUserDetails();
  }, [isAdminAuthenticated, navigate, userId]);

  const loadUserDetails = () => {
    setLoading(true);
    
    // Load from localStorage
    const userData = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
    const foundUser = userData.find(u => u.id === parseInt(userId));
    
    if (foundUser) {
      setUser(foundUser);
    } else {
      // Mock user data if not found
      setUser({
        id: parseInt(userId),
        username: 'user_example',
        email: 'user@example.com',
        fullName: 'Example User',
        status: 'active',
        lastActive: '2024-01-15T10:30:00Z',
        registrationDate: '2023-12-01T09:00:00Z',
        totalInvestments: 15000,
        balance: 2500,
        kycStatus: 'verified',
        location: 'United States',
        riskLevel: 'medium',
        phone: '+1-555-0123',
        address: '123 Main St, City, State 12345'
      });
    }
    setLoading(false);
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <AdminNavigation title="Loading..." />
        <div className="p-6 flex items-center justify-center">
          <Icon name="Loader" size={24} className="animate-spin mr-2" />
          Loading user details...
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <AdminNavigation title="User Not Found" />
        <div className="p-6 text-center">
          <p className="text-muted-foreground mb-4">User not found</p>
          <Button onClick={() => navigate('/admin-active-users')}>
            Back to Users
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title={`User Details - ${user.fullName}`}
        breadcrumb={[
          { label: "User Management", link: "/admin-active-users" },
          { label: "User Details" }
        ]}
        actions={[
          {
            label: "Edit User",
            icon: "Edit",
            variant: "outline",
            onClick: () => navigate(`/admin-edit-user/${userId}`)
          },
          {
            label: "Send Message",
            icon: "MessageCircle",
            variant: "outline",
            onClick: () => navigate(`/admin-send-message/${userId}`)
          },
          {
            label: "Back to Users",
            icon: "ArrowLeft",
            variant: "outline",
            onClick: () => navigate('/admin-active-users')
          }
        ]}
      />

      <div className="p-6">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* User Profile Card */}
            <div className="lg:col-span-1">
              <div className="bg-card border rounded-lg p-6">
                <div className="text-center">
                  <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-primary">
                      {user.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}
                    </span>
                  </div>
                  <h2 className="text-xl font-semibold text-foreground">{user.fullName}</h2>
                  <p className="text-muted-foreground">@{user.username}</p>
                  <div className="mt-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      user.status === 'active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* User Information */}
            <div className="lg:col-span-2">
              <div className="bg-card border rounded-lg p-6">
                <h3 className="text-lg font-semibold text-foreground mb-6">User Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Email</label>
                    <p className="text-foreground">{user.email}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Phone</label>
                    <p className="text-foreground">{user.phone || 'Not provided'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Location</label>
                    <p className="text-foreground">{user.location}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">KYC Status</label>
                    <p className="text-foreground">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        user.kycStatus === 'verified' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {user.kycStatus.charAt(0).toUpperCase() + user.kycStatus.slice(1)}
                      </span>
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Registration Date</label>
                    <p className="text-foreground">{formatDateTime(user.registrationDate)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Last Active</label>
                    <p className="text-foreground">{formatDateTime(user.lastActive)}</p>
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-sm font-medium text-muted-foreground">Address</label>
                    <p className="text-foreground">{user.address || 'Not provided'}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Financial Summary */}
          <div className="mt-6 bg-card border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">Financial Summary</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{formatCurrency(user.balance || 0)}</div>
                <div className="text-sm text-muted-foreground">Current Balance</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{formatCurrency(user.totalInvestments)}</div>
                <div className="text-sm text-muted-foreground">Total Investments</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className={`text-2xl font-bold ${
                  user.riskLevel === 'low' ? 'text-green-600' :
                  user.riskLevel === 'medium' ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  {user.riskLevel.charAt(0).toUpperCase() + user.riskLevel.slice(1)}
                </div>
                <div className="text-sm text-muted-foreground">Risk Level</div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="mt-6 bg-card border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                variant="outline"
                onClick={() => navigate(`/admin-edit-user/${userId}`)}
                className="h-auto p-4 flex flex-col items-center"
              >
                <Icon name="Edit" size={24} className="mb-2" />
                <span className="text-sm">Edit User</span>
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate(`/admin-send-message/${userId}`)}
                className="h-auto p-4 flex flex-col items-center"
              >
                <Icon name="MessageCircle" size={24} className="mb-2" />
                <span className="text-sm">Send Message</span>
              </Button>
              <Button
                variant="outline"
                onClick={() => alert('Transaction history functionality coming soon')}
                className="h-auto p-4 flex flex-col items-center"
              >
                <Icon name="History" size={24} className="mb-2" />
                <span className="text-sm">View Transactions</span>
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  if (window.confirm(`Suspend ${user.fullName}?`)) {
                    alert('User suspended successfully');
                    navigate('/admin-active-users');
                  }
                }}
                className="h-auto p-4 flex flex-col items-center text-red-600 border-red-200 hover:bg-red-50"
              >
                <Icon name="Ban" size={24} className="mb-2" />
                <span className="text-sm">Suspend User</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminUserDetails;
