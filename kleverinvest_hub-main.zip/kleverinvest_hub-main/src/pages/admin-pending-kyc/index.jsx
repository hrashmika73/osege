import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import AdminDataRefresh from '../../components/AdminDataRefresh';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import { adminKycAPI } from '../../services/adminApiService';

const AdminPendingKYC = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [kycRequests, setKycRequests] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('submissionDate');
  const [filterBy, setFilterBy] = useState('all');
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadPendingKYC();
  }, [isAdminAuthenticated, navigate]);

  const loadPendingKYC = () => {
    setLoading(true);

    // Load from localStorage first, fallback to mock data
    const savedRequests = localStorage.getItem('admin_pending_kyc');

    setTimeout(() => {
      if (savedRequests) {
        const parsedRequests = JSON.parse(savedRequests);
        setKycRequests(parsedRequests);
      } else {
        // Fallback to mock data and save to localStorage
        const mockRequests = [
          {
            id: 1,
            userId: 'user_001',
            username: 'john_investor',
            email: 'john@example.com',
            fullName: 'John Smith',
            submissionDate: '2024-01-14T10:30:00Z',
            documentType: 'passport',
            documentNumber: 'P123456789',
            country: 'United States',
            phoneNumber: '+1-555-0123',
            address: '123 Main St, New York, NY 10001',
            priority: 'high',
            investmentAmount: 50000,
            riskLevel: 'medium',
            documentsSubmitted: ['passport', 'utility_bill', 'bank_statement'],
            verificationStatus: 'pending',
            notes: 'High value investor, expedite review'
          },
          {
            id: 2,
            userId: 'user_002',
            username: 'sarah_trader',
            email: 'sarah@example.com',
            fullName: 'Sarah Johnson',
            submissionDate: '2024-01-13T14:20:00Z',
            documentType: 'drivers_license',
            documentNumber: 'DL987654321',
            country: 'Canada',
            phoneNumber: '+1-604-555-0456',
            address: '456 Maple Ave, Vancouver, BC V6B 1A1',
            priority: 'medium',
            investmentAmount: 25000,
            riskLevel: 'low',
            documentsSubmitted: ['drivers_license', 'utility_bill'],
            verificationStatus: 'pending',
            notes: 'Standard verification required'
          },
          {
            id: 3,
            userId: 'user_003',
            username: 'mike_crypto',
            email: 'mike@example.com',
            fullName: 'Michael Brown',
            submissionDate: '2024-01-12T09:15:00Z',
            documentType: 'national_id',
            documentNumber: 'ID147258369',
            country: 'United Kingdom',
            phoneNumber: '+44-20-7946-0958',
            address: '789 Oxford St, London, UK W1C 1JA',
            priority: 'high',
            investmentAmount: 75000,
            riskLevel: 'high',
            documentsSubmitted: ['national_id', 'passport', 'utility_bill', 'bank_statement', 'proof_of_income'],
            verificationStatus: 'under_review',
            notes: 'Complex case, additional documentation required'
          }
        ];
        setKycRequests(mockRequests);
        // Save mock data to localStorage for persistence
        localStorage.setItem('admin_pending_kyc', JSON.stringify(mockRequests));
      }
      setLoading(false);
    }, 1000);
  };

  const handleKYCAction = (requestId, action) => {
    const request = kycRequests.find(r => r.id === requestId);

    switch (action) {
      case 'approve':
        if (window.confirm(`Are you sure you want to approve KYC for ${request.fullName}?`)) {
          // Remove from pending and add to approved
          const updatedRequests = kycRequests.filter(r => r.id !== requestId);
          setKycRequests(updatedRequests);

          // Save to localStorage
          localStorage.setItem('admin_pending_kyc', JSON.stringify(updatedRequests));

          // Add to approved KYC log
          const approvedKyc = JSON.parse(localStorage.getItem('admin_approved_kyc') || '[]');
          const approvedRequest = {
            ...request,
            status: 'approved',
            approvedDate: new Date().toISOString(),
            approvedBy: 'admin_001'
          };
          approvedKyc.push(approvedRequest);
          localStorage.setItem('admin_approved_kyc', JSON.stringify(approvedKyc));

          // Update user KYC status in user data
          const userData = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
          const updatedUserData = userData.map(u =>
            u.userId === request.userId
              ? { ...u, kycStatus: 'verified' }
              : u
          );
          localStorage.setItem('admin_users_data', JSON.stringify(updatedUserData));

          alert(`KYC approved for ${request.fullName}`);
          loadPendingKYC();
        }
        break;
      case 'reject':
        const reason = prompt(`Enter rejection reason for ${request.fullName}:`);
        if (reason) {
          // Remove from pending and add to rejected
          const updatedRequests = kycRequests.filter(r => r.id !== requestId);
          setKycRequests(updatedRequests);

          // Save to localStorage
          localStorage.setItem('admin_pending_kyc', JSON.stringify(updatedRequests));

          // Add to rejected KYC log
          const rejectedKyc = JSON.parse(localStorage.getItem('admin_rejected_kyc') || '[]');
          const rejectedRequest = {
            ...request,
            status: 'rejected',
            rejectedDate: new Date().toISOString(),
            rejectedBy: 'admin_001',
            rejectionReason: reason
          };
          rejectedKyc.push(rejectedRequest);
          localStorage.setItem('admin_rejected_kyc', JSON.stringify(rejectedKyc));

          alert(`KYC rejected for ${request.fullName}. Reason: ${reason}`);
          loadPendingKYC();
        }
        break;
      case 'request_more':
        const additionalDocs = prompt(`What additional documents are needed for ${request.fullName}?`);
        if (additionalDocs) {
          // Update request status and notes
          const updatedRequests = kycRequests.map(r =>
            r.id === requestId
              ? {
                  ...r,
                  status: 'additional_required',
                  notes: `${r.notes} - Additional docs requested: ${additionalDocs}`,
                  lastUpdated: new Date().toISOString()
                }
              : r
          );
          setKycRequests(updatedRequests);
          localStorage.setItem('admin_pending_kyc', JSON.stringify(updatedRequests));

          alert(`Additional documents requested from ${request.fullName}: ${additionalDocs}`);
        }
        break;
      case 'view':
        setSelectedRequest(request);
        setShowDetails(true);
        break;
      default:
        break;
    }
  };

  const filteredRequests = kycRequests.filter(request => {
    const matchesSearch = request.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.documentNumber.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filterBy === 'all') return matchesSearch;
    if (filterBy === 'high_priority') return matchesSearch && request.priority === 'high';
    if (filterBy === 'high_value') return matchesSearch && request.investmentAmount > 40000;
    if (filterBy === 'under_review') return matchesSearch && request.verificationStatus === 'under_review';
    
    return matchesSearch;
  });

  const sortedRequests = [...filteredRequests].sort((a, b) => {
    switch (sortBy) {
      case 'submissionDate':
        return new Date(a.submissionDate) - new Date(b.submissionDate);
      case 'priority':
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      case 'investmentAmount':
        return b.investmentAmount - a.investmentAmount;
      case 'name':
        return a.fullName.localeCompare(b.fullName);
      default:
        return 0;
    }
  });

  const getPriorityBadge = (priority) => {
    const priorityClasses = {
      high: 'bg-red-100 text-red-800 border-red-200',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      low: 'bg-green-100 text-green-800 border-green-200'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${priorityClasses[priority] || priorityClasses.medium}`}>
        {priority.charAt(0).toUpperCase() + priority.slice(1)}
      </span>
    );
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      pending: 'bg-blue-100 text-blue-800',
      under_review: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusClasses[status] || statusClasses.pending}`}>
        {status.replace('_', ' ').charAt(0).toUpperCase() + status.replace('_', ' ').slice(1)}
      </span>
    );
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getDaysWaiting = (submissionDate) => {
    const now = new Date();
    const submission = new Date(submissionDate);
    const diffTime = Math.abs(now - submission);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Pending KYC Verification"
        breadcrumb={[
          { label: "User Management", link: "/admin-user-management" },
          { label: "Pending KYC" }
        ]}
        actions={[
          {
            label: "Export Pending",
            icon: "Download",
            variant: "outline",
            onClick: () => {
              const csvData = kycRequests.map(request => ({
                Username: request.username,
                'Full Name': request.fullName,
                Email: request.email,
                'Submission Date': formatDateTime(request.submissionDate),
                Priority: request.priority,
                'Investment Amount': request.investmentAmount,
                Country: request.country,
                'Document Type': request.documentType,
                Status: request.verificationStatus
              }));
              const csv = [
                Object.keys(csvData[0]).join(','),
                ...csvData.map(row => Object.values(row).join(','))
              ].join('\n');
              const blob = new Blob([csv], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `pending_kyc_${new Date().toISOString().split('T')[0]}.csv`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }
          },
          {
            label: "Refresh",
            icon: "RefreshCw",
            variant: "outline",
            onClick: loadPendingKYC
          }
        ]}
      />

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Reviews</p>
                <p className="text-2xl font-bold text-foreground">{kycRequests.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Icon name="Clock" size={24} className="text-blue-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">High Priority</p>
                <p className="text-2xl font-bold text-foreground">
                  {kycRequests.filter(r => r.priority === 'high').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Icon name="AlertTriangle" size={24} className="text-red-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Under Review</p>
                <p className="text-2xl font-bold text-foreground">
                  {kycRequests.filter(r => r.verificationStatus === 'under_review').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Icon name="Eye" size={24} className="text-yellow-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg. Wait Time</p>
                <p className="text-2xl font-bold text-foreground">
                  {Math.round(kycRequests.reduce((acc, r) => acc + getDaysWaiting(r.submissionDate), 0) / kycRequests.length || 0)} days
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Icon name="Calendar" size={24} className="text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-card border rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search KYC requests..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={filterBy}
                onChange={(e) => setFilterBy(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="all">All Requests</option>
                <option value="high_priority">High Priority</option>
                <option value="high_value">High Value</option>
                <option value="under_review">Under Review</option>
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="submissionDate">Submission Date</option>
                <option value="priority">Priority</option>
                <option value="investmentAmount">Investment Amount</option>
                <option value="name">Name</option>
              </select>
            </div>
          </div>
        </div>

        {/* KYC Requests Table */}
        <div className="bg-card border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Submission
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Priority
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Investment
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Document Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {loading ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center">
                      <div className="flex items-center justify-center">
                        <Icon name="Loader" size={20} className="animate-spin mr-2" />
                        Loading KYC requests...
                      </div>
                    </td>
                  </tr>
                ) : sortedRequests.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center text-muted-foreground">
                      No pending KYC requests found
                    </td>
                  </tr>
                ) : (
                  sortedRequests.map((request) => (
                    <tr key={request.id} className="hover:bg-muted/30">
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                            <span className="text-sm font-medium text-primary">
                              {request.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-foreground">{request.fullName}</div>
                            <div className="text-sm text-muted-foreground">@{request.username}</div>
                            <div className="text-xs text-muted-foreground">{request.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">{formatDateTime(request.submissionDate)}</div>
                        <div className="text-xs text-muted-foreground">
                          {getDaysWaiting(request.submissionDate)} days ago
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {getPriorityBadge(request.priority)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-foreground">
                          {formatCurrency(request.investmentAmount)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">
                          {request.documentType.replace('_', ' ').toUpperCase()}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {request.documentsSubmitted.length} docs
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {getStatusBadge(request.verificationStatus)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleKYCAction(request.id, 'view')}
                            title="View Details"
                          >
                            <Icon name="Eye" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleKYCAction(request.id, 'approve')}
                            title="Approve KYC"
                            className="text-green-600 border-green-200 hover:bg-green-50"
                          >
                            <Icon name="Check" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleKYCAction(request.id, 'reject')}
                            title="Reject KYC"
                            className="text-red-600 border-red-200 hover:bg-red-50"
                          >
                            <Icon name="X" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleKYCAction(request.id, 'request_more')}
                            title="Request More Documents"
                            className="text-blue-600 border-blue-200 hover:bg-blue-50"
                          >
                            <Icon name="FileText" size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* KYC Details Modal */}
      {showDetails && selectedRequest && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card border rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h3 className="text-lg font-semibold">KYC Details - {selectedRequest.fullName}</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDetails(false)}
              >
                <Icon name="X" size={16} />
              </Button>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase">Full Name</label>
                  <p className="text-sm font-medium">{selectedRequest.fullName}</p>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase">Username</label>
                  <p className="text-sm font-medium">@{selectedRequest.username}</p>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase">Email</label>
                  <p className="text-sm font-medium">{selectedRequest.email}</p>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase">Phone</label>
                  <p className="text-sm font-medium">{selectedRequest.phoneNumber}</p>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase">Country</label>
                  <p className="text-sm font-medium">{selectedRequest.country}</p>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase">Investment Amount</label>
                  <p className="text-sm font-medium">{formatCurrency(selectedRequest.investmentAmount)}</p>
                </div>
                <div className="col-span-2">
                  <label className="text-xs font-medium text-muted-foreground uppercase">Address</label>
                  <p className="text-sm font-medium">{selectedRequest.address}</p>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase">Document Type</label>
                  <p className="text-sm font-medium">{selectedRequest.documentType.replace('_', ' ').toUpperCase()}</p>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase">Document Number</label>
                  <p className="text-sm font-medium">{selectedRequest.documentNumber}</p>
                </div>
                <div className="col-span-2">
                  <label className="text-xs font-medium text-muted-foreground uppercase">Documents Submitted</label>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {selectedRequest.documentsSubmitted.map((doc, index) => (
                      <span key={index} className="px-2 py-1 bg-muted rounded text-xs">
                        {doc.replace('_', ' ').toUpperCase()}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="col-span-2">
                  <label className="text-xs font-medium text-muted-foreground uppercase">Notes</label>
                  <p className="text-sm font-medium">{selectedRequest.notes}</p>
                </div>
              </div>
              <div className="flex space-x-3 pt-4 border-t border-border">
                <Button
                  onClick={() => handleKYCAction(selectedRequest.id, 'approve')}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Icon name="Check" size={16} className="mr-2" />
                  Approve KYC
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleKYCAction(selectedRequest.id, 'reject')}
                  className="text-red-600 border-red-200 hover:bg-red-50"
                >
                  <Icon name="X" size={16} className="mr-2" />
                  Reject KYC
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleKYCAction(selectedRequest.id, 'request_more')}
                >
                  <Icon name="FileText" size={16} className="mr-2" />
                  Request More Docs
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPendingKYC;
