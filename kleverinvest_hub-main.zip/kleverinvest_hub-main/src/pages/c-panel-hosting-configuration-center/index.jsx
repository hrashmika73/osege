import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';


import RoleBasedNavigation from '../../components/ui/RoleBasedNavigation';
import Header from '../../components/ui/Header';
import ServerMetricsWidget from './components/ServerMetricsWidget';
import FileManagerPanel from './components/FileManagerPanel';
import DatabaseManagerPanel from './components/DatabaseManagerPanel';
import SecurityConfigPanel from './components/SecurityConfigPanel';
import BackupManagerPanel from './components/BackupManagerPanel';
import DomainManagerPanel from './components/DomainManagerPanel';

const CPanelHostingConfigurationCenter = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isLoading, setIsLoading] = useState(false);
  const [hostingStatus, setHostingStatus] = useState({
    server: 'online',
    ssl: 'active',
    backup: 'scheduled',
    domain: 'active'
  });
  
  const [serverMetrics, setServerMetrics] = useState({
    cpu: 45,
    memory: 68,
    disk: 34,
    bandwidth: 23,
    uptime: '99.9%',
    requests: 1247
  });

  const [alerts, setAlerts] = useState([
    {
      id: 1,
      type: 'warning',
      message: 'SSL certificate expires in 30 days',
      timestamp: '2025-01-29T10:00:00Z',
      action: 'Renew SSL'
    },
    {
      id: 2,
      type: 'info',
      message: 'Backup completed successfully',
      timestamp: '2025-01-29T09:30:00Z',
      action: 'View Backup'
    }
  ]);

  useEffect(() => {
    // Simulate real-time metrics updates
    const metricsInterval = setInterval(() => {
      setServerMetrics(prev => ({
        ...prev,
        cpu: Math.max(20, Math.min(80, prev.cpu + (Math.random() - 0.5) * 10)),
        memory: Math.max(30, Math.min(90, prev.memory + (Math.random() - 0.5) * 8)),
        requests: prev.requests + Math.floor(Math.random() * 10)
      }));
    }, 5000);

    return () => clearInterval(metricsInterval);
  }, []);

  const handleQuickAction = async (action) => {
    setIsLoading(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      switch (action) {
        case 'restart-server':
          setAlerts(prev => [...prev, {
            id: Date.now(),
            type: 'success',
            message: 'Server restart initiated successfully',
            timestamp: new Date().toISOString(),
            action: 'View Status'
          }]);
          break;
        case 'clear-cache':
          setAlerts(prev => [...prev, {
            id: Date.now(),
            type: 'success',
            message: 'Cache cleared successfully',
            timestamp: new Date().toISOString(),
            action: 'View Performance'
          }]);
          break;
        case 'optimize-db':
          setAlerts(prev => [...prev, {
            id: Date.now(),
            type: 'success',
            message: 'Database optimization completed',
            timestamp: new Date().toISOString(),
            action: 'View Report'
          }]);
          break;
        default:
          break;
      }
    } catch (error) {
      setAlerts(prev => [...prev, {
        id: Date.now(),
        type: 'error',
        message: `Failed to execute ${action}`,
        timestamp: new Date().toISOString(),
        action: 'Retry'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const dismissAlert = (alertId) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId));
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'online': case'active': case'scheduled':
        return 'text-green-400 bg-green-500/10';
      case 'warning':
        return 'text-yellow-400 bg-yellow-500/10';
      case 'offline': case'error':
        return 'text-red-400 bg-red-500/10';
      default:
        return 'text-slate-400 bg-slate-500/10';
    }
  };

  const getAlertIcon = (type) => {
    switch (type) {
      case 'error': return 'AlertTriangle';
      case 'warning': return 'AlertCircle';
      case 'success': return 'CheckCircle';
      case 'info': return 'Info';
      default: return 'Bell';
    }
  };

  const getAlertColor = (type) => {
    switch (type) {
      case 'error': return 'text-red-400 bg-red-500/10 border-red-500/20';
      case 'warning': return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20';
      case 'success': return 'text-green-400 bg-green-500/10 border-green-500/20';
      case 'info': return 'text-blue-400 bg-blue-500/10 border-blue-500/20';
      default: return 'text-slate-400 bg-slate-500/10 border-slate-500/20';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="flex">
        <RoleBasedNavigation />
        
        <main className="flex-1 p-6 ml-64">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  cPanel Hosting Configuration Center
                </h1>
                <p className="text-muted-foreground">
                  Comprehensive hosting environment management and deployment optimization for KleverInvest Hub platform
                </p>
              </div>
              
              <div className="flex items-center space-x-3">
                <Button
                  onClick={() => handleQuickAction('restart-server')}
                  disabled={isLoading}
                  variant="outline"
                  className="border-orange-500/20 text-orange-400"
                >
                  <Icon name="RotateCcw" size={16} className="mr-2" />
                  Restart Server
                </Button>
                
                <Button
                  onClick={() => setActiveTab('backup')}
                  className="gradient-gold text-black"
                >
                  <Icon name="Download" size={16} className="mr-2" />
                  Create Backup
                </Button>
              </div>
            </div>
          </div>

          {/* Real-time Alerts */}
          {alerts.length > 0 && (
            <div className="mb-6 space-y-3">
              {alerts.slice(0, 3).map((alert) => (
                <div key={alert.id} className={`p-4 rounded-lg border ${getAlertColor(alert.type)}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Icon name={getAlertIcon(alert.type)} size={20} />
                      <div>
                        <p className="font-medium">{alert.message}</p>
                        <p className="text-xs opacity-80 mt-1">
                          {new Date(alert.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {alert.action && (
                        <Button size="sm" variant="ghost">
                          {alert.action}
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => dismissAlert(alert.id)}
                        aria-label="Dismiss alert"
                      >
                        <Icon name="X" size={14} />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Server Status Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Server Status</p>
                  <div className="flex items-center mt-2">
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(hostingStatus.server)}`}>
                      {hostingStatus.server.toUpperCase()}
                    </div>
                  </div>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                  <Icon name="Server" size={24} className="text-green-400" />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">SSL Certificate</p>
                  <div className="flex items-center mt-2">
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(hostingStatus.ssl)}`}>
                      {hostingStatus.ssl.toUpperCase()}
                    </div>
                  </div>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
                  <Icon name="Shield" size={24} className="text-blue-400" />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Backup Status</p>
                  <div className="flex items-center mt-2">
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(hostingStatus.backup)}`}>
                      {hostingStatus.backup.toUpperCase()}
                    </div>
                  </div>
                </div>
                <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center">
                  <Icon name="HardDrive" size={24} className="text-orange-400" />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Domain Status</p>
                  <div className="flex items-center mt-2">
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(hostingStatus.domain)}`}>
                      {hostingStatus.domain.toUpperCase()}
                    </div>
                  </div>
                </div>
                <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center">
                  <Icon name="Globe" size={24} className="text-purple-400" />
                </div>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="border-b border-border mb-6">
            <nav className="flex space-x-8 overflow-x-auto" role="tablist">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
                { id: 'files', label: 'File Manager', icon: 'Folder' },
                { id: 'database', label: 'Database', icon: 'Database' },
                { id: 'security', label: 'Security', icon: 'Shield' },
                { id: 'domains', label: 'Domains', icon: 'Globe' },
                { id: 'backup', label: 'Backup', icon: 'Download' },
                { id: 'performance', label: 'Performance', icon: 'Zap' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                  role="tab"
                  aria-selected={activeTab === tab.id}
                  aria-controls={`${tab.id}-panel`}
                >
                  <Icon name={tab.icon} size={16} />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="tab-content">
            {activeTab === 'dashboard' && (
              <div id="dashboard-panel" role="tabpanel" aria-labelledby="dashboard-tab">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <ServerMetricsWidget metrics={serverMetrics} />
                  
                  {/* Quick Actions */}
                  <div className="bg-card rounded-lg p-6 border border-border">
                    <h3 className="text-lg font-semibold mb-4 text-foreground">Quick Actions</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <Button
                        onClick={() => handleQuickAction('clear-cache')}
                        disabled={isLoading}
                        variant="outline"
                        className="h-16 flex-col space-y-2"
                        fullWidth
                      >
                        <Icon name="Trash2" size={20} />
                        <span className="text-xs">Clear Cache</span>
                      </Button>
                      
                      <Button
                        onClick={() => handleQuickAction('optimize-db')}
                        disabled={isLoading}
                        variant="outline"
                        className="h-16 flex-col space-y-2"
                        fullWidth
                      >
                        <Icon name="Database" size={20} />
                        <span className="text-xs">Optimize DB</span>
                      </Button>
                      
                      <Button
                        onClick={() => setActiveTab('security')}
                        variant="outline"
                        className="h-16 flex-col space-y-2"
                        fullWidth
                      >
                        <Icon name="Shield" size={20} />
                        <span className="text-xs">Security Scan</span>
                      </Button>
                      
                      <Button
                        onClick={() => setActiveTab('backup')}
                        variant="outline"
                        className="h-16 flex-col space-y-2"
                        fullWidth
                      >
                        <Icon name="Download" size={20} />
                        <span className="text-xs">Backup Now</span>
                      </Button>
                    </div>
                  </div>

                  {/* Recent Activity */}
                  <div className="bg-card rounded-lg p-6 border border-border lg:col-span-2">
                    <h3 className="text-lg font-semibold mb-4 text-foreground">Recent Activity</h3>
                    <div className="space-y-3">
                      {[
                        { action: 'SSL Certificate renewed', time: '2 hours ago', status: 'success' },
                        { action: 'Database backup completed', time: '4 hours ago', status: 'success' },
                        { action: 'Security scan initiated', time: '6 hours ago', status: 'info' },
                        { action: 'Performance optimization applied', time: '8 hours ago', status: 'success' }
                      ].map((activity, index) => (
                        <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                          <div className="flex items-center space-x-3">
                            <div className={`w-2 h-2 rounded-full ${
                              activity.status === 'success' ? 'bg-green-400' :
                              activity.status === 'warning' ? 'bg-yellow-400' :
                              activity.status === 'error' ? 'bg-red-400' : 'bg-blue-400'
                            }`} />
                            <span className="text-foreground">{activity.action}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">{activity.time}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'files' && (
              <div id="files-panel" role="tabpanel" aria-labelledby="files-tab">
                <FileManagerPanel />
              </div>
            )}

            {activeTab === 'database' && (
              <div id="database-panel" role="tabpanel" aria-labelledby="database-tab">
                <DatabaseManagerPanel />
              </div>
            )}

            {activeTab === 'security' && (
              <div id="security-panel" role="tabpanel" aria-labelledby="security-tab">
                <SecurityConfigPanel />
              </div>
            )}

            {activeTab === 'domains' && (
              <div id="domains-panel" role="tabpanel" aria-labelledby="domains-tab">
                <DomainManagerPanel />
              </div>
            )}

            {activeTab === 'backup' && (
              <div id="backup-panel" role="tabpanel" aria-labelledby="backup-tab">
                <BackupManagerPanel />
              </div>
            )}

            {activeTab === 'performance' && (
              <div id="performance-panel" role="tabpanel" aria-labelledby="performance-tab">
                <div className="bg-card rounded-lg p-6 border border-border">
                  <h3 className="text-lg font-semibold mb-4 text-foreground">Performance Optimization</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Caching Configuration */}
                    <div className="space-y-4">
                      <h4 className="font-medium text-foreground">Caching Configuration</h4>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                          <span className="text-foreground">Browser Caching</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-green-400">Enabled</span>
                            <Icon name="CheckCircle" size={16} className="text-green-400" />
                          </div>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                          <span className="text-foreground">Gzip Compression</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-green-400">Enabled</span>
                            <Icon name="CheckCircle" size={16} className="text-green-400" />
                          </div>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                          <span className="text-foreground">CDN Integration</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-yellow-400">Pending</span>
                            <Icon name="Clock" size={16} className="text-yellow-400" />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Speed Testing */}
                    <div className="space-y-4">
                      <h4 className="font-medium text-foreground">Speed Testing</h4>
                      <div className="space-y-3">
                        <div className="p-4 rounded-lg bg-muted/30">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-foreground">Page Load Time</span>
                            <span className="text-green-400 font-semibold">1.8s</span>
                          </div>
                          <div className="w-full bg-muted rounded-full h-2">
                            <div className="bg-green-500 h-2 rounded-full" style={{ width: '82%' }} />
                          </div>
                        </div>
                        
                        <Button
                          onClick={() => handleQuickAction('speed-test')}
                          variant="outline"
                          className="w-full"
                        >
                          <Icon name="Zap" size={16} className="mr-2" />
                          Run Speed Test
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Mobile Responsive Quick Access (Mobile Only) */}
          <div className="lg:hidden fixed bottom-4 right-4 z-50">
            <div className="bg-card rounded-full p-3 border border-border shadow-lg">
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  onClick={() => setActiveTab('files')}
                  className={activeTab === 'files' ? 'bg-primary' : ''}
                >
                  <Icon name="Folder" size={16} />
                </Button>
                <Button
                  size="sm"
                  onClick={() => setActiveTab('backup')}
                  className={activeTab === 'backup' ? 'bg-primary' : ''}
                >
                  <Icon name="Download" size={16} />
                </Button>
                <Button
                  size="sm"
                  onClick={() => setActiveTab('security')}
                  className={activeTab === 'security' ? 'bg-primary' : ''}
                >
                  <Icon name="Shield" size={16} />
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default CPanelHostingConfigurationCenter;