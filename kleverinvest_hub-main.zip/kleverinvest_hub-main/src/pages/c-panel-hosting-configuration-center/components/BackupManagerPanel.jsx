import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const BackupManagerPanel = () => {
  const [selectedBackup, setSelectedBackup] = useState(null);
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);

  const backups = [
    {
      id: 1,
      name: 'Daily Backup - 2025-01-29',
      type: 'automated',
      size: '1.2 GB',
      created: '2025-01-29 03:00:00',
      status: 'completed',
      includes: ['Files', 'Database', 'Emails']
    },
    {
      id: 2,
      name: 'Pre-deployment Backup',
      type: 'manual',
      size: '1.1 GB',
      created: '2025-01-28 15:30:00',
      status: 'completed',
      includes: ['Files', 'Database']
    },
    {
      id: 3,
      name: 'Weekly Full Backup',
      type: 'automated',
      size: '1.5 GB',
      created: '2025-01-26 02:00:00',
      status: 'completed',
      includes: ['Files', 'Database', 'Emails', 'Logs']
    },
    {
      id: 4,
      name: 'Security Update Backup',
      type: 'manual',
      size: '1.0 GB',
      created: '2025-01-25 10:15:00',
      status: 'completed',
      includes: ['Files', 'Database']
    }
  ];

  const schedules = [
    {
      name: 'Daily Files Backup',
      frequency: 'daily',
      time: '03:00',
      retention: '30 days',
      status: 'active',
      includes: ['Files']
    },
    {
      name: 'Weekly Full Backup',
      frequency: 'weekly',
      time: 'Sunday 02:00',
      retention: '12 weeks',
      status: 'active',
      includes: ['Files', 'Database', 'Emails']
    },
    {
      name: 'Monthly Archive',
      frequency: 'monthly',
      time: '1st day 01:00',
      retention: '12 months',
      status: 'active',
      includes: ['Files', 'Database', 'Emails', 'Logs']
    }
  ];

  const handleCreateBackup = async () => {
    setIsCreatingBackup(true);
    
    // Simulate backup creation
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setIsCreatingBackup(false);
    alert('Manual backup created successfully!');
  };

  const handleRestoreBackup = async (backupId) => {
    setIsRestoring(true);
    setSelectedBackup(backupId);
    
    // Simulate restore process
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    setIsRestoring(false);
    setSelectedBackup(null);
    alert('Backup restored successfully!');
  };

  const handleDownloadBackup = (backup) => {
    console.log('Downloading backup:', backup.name);
    alert(`Downloading ${backup.name}...`);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
      case 'active':
        return 'text-green-400 bg-green-500/10';
      case 'running':
        return 'text-yellow-400 bg-yellow-500/10';
      case 'failed':
        return 'text-red-400 bg-red-500/10';
      case 'inactive':
        return 'text-slate-400 bg-slate-500/10';
      default:
        return 'text-slate-400 bg-slate-500/10';
    }
  };

  const getTypeIcon = (type) => {
    return type === 'automated' ? 'Clock' : 'User';
  };

  return (
    <div className="space-y-6">
      {/* Backup Manager Header */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Backup Management</h3>
            <p className="text-muted-foreground">
              Automated daily backups with manual backup creation and one-click restoration
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <Button
              onClick={handleCreateBackup}
              disabled={isCreatingBackup}
              loading={isCreatingBackup}
              variant="outline"
            >
              <Icon name="Plus" size={16} className="mr-2" />
              {isCreatingBackup ? 'Creating...' : 'Create Backup'}
            </Button>
            
            <Button className="gradient-gold text-black">
              <Icon name="Settings" size={16} className="mr-2" />
              Configure Schedule
            </Button>
          </div>
        </div>
      </div>

      {/* Backup Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Backups</p>
              <p className="text-2xl font-bold text-foreground">{backups.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
              <Icon name="Archive" size={24} className="text-blue-400" />
            </div>
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Storage Used</p>
              <p className="text-2xl font-bold text-foreground">4.8 GB</p>
            </div>
            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
              <Icon name="HardDrive" size={24} className="text-green-400" />
            </div>
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Last Backup</p>
              <p className="text-lg font-semibold text-foreground">29 Jan</p>
            </div>
            <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center">
              <Icon name="Clock" size={24} className="text-orange-400" />
            </div>
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Success Rate</p>
              <p className="text-2xl font-bold text-green-400">100%</p>
            </div>
            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
              <Icon name="CheckCircle" size={24} className="text-green-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Backup List */}
      <div className="bg-card rounded-lg border border-border">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h4 className="text-lg font-semibold text-foreground">Available Backups</h4>
            <div className="flex items-center space-x-2">
              <Select
                value="all"
                onChange={() => {}}
                options={[
                  { value: 'all', label: 'All Backups' },
                  { value: 'automated', label: 'Automated Only' },
                  { value: 'manual', label: 'Manual Only' }
                ]}
                className="min-w-[120px]"
              />
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/30">
              <tr>
                <th className="text-left p-4 font-medium text-foreground">Backup Name</th>
                <th className="text-left p-4 font-medium text-foreground">Type</th>
                <th className="text-left p-4 font-medium text-foreground">Size</th>
                <th className="text-left p-4 font-medium text-foreground">Created</th>
                <th className="text-left p-4 font-medium text-foreground">Includes</th>
                <th className="text-left p-4 font-medium text-foreground">Status</th>
                <th className="text-left p-4 font-medium text-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {backups.map((backup) => (
                <tr key={backup.id} className="border-t border-border hover:bg-muted/20">
                  <td className="p-4">
                    <div className="flex items-center space-x-3">
                      <Icon name="Archive" size={18} className="text-blue-400" />
                      <span className="font-medium text-foreground">{backup.name}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <Icon name={getTypeIcon(backup.type)} size={14} className="text-muted-foreground" />
                      <span className="text-muted-foreground capitalize">{backup.type}</span>
                    </div>
                  </td>
                  <td className="p-4 text-muted-foreground">{backup.size}</td>
                  <td className="p-4 text-muted-foreground">{backup.created}</td>
                  <td className="p-4">
                    <div className="flex flex-wrap gap-1">
                      {backup.includes.map((item, index) => (
                        <span key={index} className="text-xs bg-muted px-2 py-1 rounded">
                          {item}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="p-4">
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(backup.status)}`}>
                      {backup.status.toUpperCase()}
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleRestoreBackup(backup.id)}
                        disabled={isRestoring && selectedBackup === backup.id}
                        loading={isRestoring && selectedBackup === backup.id}
                        aria-label={`Restore ${backup.name}`}
                      >
                        <Icon name="RotateCcw" size={14} />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDownloadBackup(backup)}
                        aria-label={`Download ${backup.name}`}
                      >
                        <Icon name="Download" size={14} />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-red-400 hover:text-red-300"
                        aria-label={`Delete ${backup.name}`}
                      >
                        <Icon name="Trash2" size={14} />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Backup Schedules */}
      <div className="bg-card rounded-lg border border-border">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h4 className="text-lg font-semibold text-foreground">Backup Schedules</h4>
            <Button size="sm" variant="outline">
              <Icon name="Plus" size={14} className="mr-2" />
              Add Schedule
            </Button>
          </div>
        </div>
        
        <div className="p-6">
          <div className="space-y-4">
            {schedules.map((schedule, index) => (
              <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-muted/30">
                <div className="flex items-center space-x-4">
                  <Icon name="Clock" size={20} className="text-blue-400" />
                  <div>
                    <h5 className="font-medium text-foreground">{schedule.name}</h5>
                    <p className="text-sm text-muted-foreground">
                      {schedule.frequency} at {schedule.time} • Retention: {schedule.retention}
                    </p>
                    <div className="flex space-x-2 mt-1">
                      {schedule.includes.map((item, idx) => (
                        <span key={idx} className="text-xs bg-muted px-2 py-1 rounded">
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(schedule.status)}`}>
                    {schedule.status.toUpperCase()}
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <Button size="sm" variant="ghost" aria-label="Edit schedule">
                      <Icon name="Edit" size={14} />
                    </Button>
                    <Button size="sm" variant="ghost" aria-label="Toggle schedule">
                      <Icon name={schedule.status === 'active' ? 'Pause' : 'Play'} size={14} />
                    </Button>
                    <Button size="sm" variant="ghost" className="text-red-400" aria-label="Delete schedule">
                      <Icon name="Trash2" size={14} />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Backup Settings */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <h4 className="text-lg font-semibold text-foreground mb-4">Backup Settings</h4>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h5 className="font-medium text-foreground">Storage Options</h5>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                <span className="text-foreground">Local Storage</span>
                <div className="flex items-center space-x-2">
                  <span className="text-green-400">Enabled</span>
                  <Icon name="CheckCircle" size={16} className="text-green-400" />
                </div>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                <span className="text-foreground">Cloud Storage (AWS S3)</span>
                <div className="flex items-center space-x-2">
                  <span className="text-yellow-400">Configure</span>
                  <Icon name="Settings" size={16} className="text-yellow-400" />
                </div>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                <span className="text-foreground">FTP Backup</span>
                <div className="flex items-center space-x-2">
                  <span className="text-slate-400">Disabled</span>
                  <Icon name="XCircle" size={16} className="text-slate-400" />
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h5 className="font-medium text-foreground">Compression & Encryption</h5>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                <span className="text-foreground">Compression (gzip)</span>
                <div className="flex items-center space-x-2">
                  <span className="text-green-400">Enabled</span>
                  <Icon name="CheckCircle" size={16} className="text-green-400" />
                </div>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                <span className="text-foreground">AES-256 Encryption</span>
                <div className="flex items-center space-x-2">
                  <span className="text-green-400">Enabled</span>
                  <Icon name="Shield" size={16} className="text-green-400" />
                </div>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                <span className="text-foreground">Verification Checksums</span>
                <div className="flex items-center space-x-2">
                  <span className="text-green-400">Enabled</span>
                  <Icon name="CheckCircle" size={16} className="text-green-400" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BackupManagerPanel;