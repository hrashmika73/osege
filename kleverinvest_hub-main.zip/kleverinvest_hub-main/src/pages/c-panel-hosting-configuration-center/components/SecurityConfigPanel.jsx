import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';


const SecurityConfigPanel = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [firewallEnabled, setFirewallEnabled] = useState(true);
  const [sslAutoRenew, setSslAutoRenew] = useState(true);

  const securityFeatures = [
    {
      name: 'Firewall Protection',
      status: firewallEnabled ? 'enabled' : 'disabled',
      description: 'Web Application Firewall with real-time threat detection',
      lastUpdate: '2025-01-29 10:00:00'
    },
    {
      name: 'SSL Certificate',
      status: 'active',
      description: 'Let\'s Encrypt SSL with automatic renewal',
      lastUpdate: '2025-01-15 00:00:00'
    },
    {
      name: 'DDoS Protection',
      status: 'enabled',
      description: 'CloudFlare DDoS mitigation and rate limiting',
      lastUpdate: '2025-01-29 09:30:00'
    },
    {
      name: 'Malware Scanner',
      status: 'enabled',
      description: 'Real-time file system monitoring and threat detection',
      lastUpdate: '2025-01-29 08:00:00'
    }
  ];

  const securityLogs = [
    {
      timestamp: '2025-01-29 10:15:00',
      type: 'blocked',
      event: 'Blocked suspicious IP: 192.168.1.100',
      severity: 'medium'
    },
    {
      timestamp: '2025-01-29 09:45:00',
      type: 'alert',
      event: 'Failed login attempt from unknown device',
      severity: 'high'
    },
    {
      timestamp: '2025-01-29 09:30:00',
      type: 'success',
      event: 'SSL certificate renewed successfully',
      severity: 'low'
    },
    {
      timestamp: '2025-01-29 09:00:00',
      type: 'blocked',
      event: 'Blocked malicious file upload attempt',
      severity: 'high'
    }
  ];

  const blockedIPs = [
    { ip: '192.168.1.100', reason: 'Brute force attack', blocked: '2025-01-29 10:15:00', duration: 'Permanent' },
    { ip: '10.0.0.50', reason: 'Suspicious activity', blocked: '2025-01-29 09:30:00', duration: '24 hours' },
    { ip: '172.16.0.75', reason: 'DDoS attempt', blocked: '2025-01-29 08:45:00', duration: '7 days' }
  ];

  const handleSecurityScan = async () => {
    setIsScanning(true);
    
    // Simulate security scan
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    setIsScanning(false);
    alert('Security scan completed. No threats detected.');
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'enabled': case'active':
        return 'text-green-400 bg-green-500/10';
      case 'disabled':
        return 'text-red-400 bg-red-500/10';
      case 'warning':
        return 'text-yellow-400 bg-yellow-500/10';
      default:
        return 'text-slate-400 bg-slate-500/10';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high':
        return 'text-red-400 bg-red-500/10 border-red-500/20';
      case 'medium':
        return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20';
      case 'low':
        return 'text-green-400 bg-green-500/10 border-green-500/20';
      default:
        return 'text-slate-400 bg-slate-500/10 border-slate-500/20';
    }
  };

  const getLogIcon = (type) => {
    switch (type) {
      case 'blocked': return 'Shield';
      case 'alert': return 'AlertTriangle';
      case 'success': return 'CheckCircle';
      default: return 'Info';
    }
  };

  return (
    <div className="space-y-6">
      {/* Security Overview */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Security Configuration</h3>
            <p className="text-muted-foreground">
              Firewall rules, SSL certificates, and security monitoring
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <Button
              onClick={handleSecurityScan}
              disabled={isScanning}
              loading={isScanning}
              variant="outline"
            >
              <Icon name="Search" size={16} className="mr-2" />
              {isScanning ? 'Scanning...' : 'Security Scan'}
            </Button>
            
            <Button className="gradient-gold text-black">
              <Icon name="Shield" size={16} className="mr-2" />
              Update Security
            </Button>
          </div>
        </div>

        {/* Security Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {securityFeatures.map((feature, index) => (
            <div key={index} className="p-4 rounded-lg bg-muted/30 border border-border">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-foreground">{feature.name}</h4>
                <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(feature.status)}`}>
                  {feature.status.toUpperCase()}
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-2">{feature.description}</p>
              <p className="text-xs text-muted-foreground">Last updated: {feature.lastUpdate}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Firewall Rules */}
      <div className="bg-card rounded-lg border border-border">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h4 className="text-lg font-semibold text-foreground">Firewall Rules</h4>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">Firewall</span>
                <button
                  onClick={() => setFirewallEnabled(!firewallEnabled)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    firewallEnabled ? 'bg-green-500' : 'bg-slate-600'
                  }`}
                  aria-label="Toggle firewall"
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      firewallEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <Button size="sm" variant="outline">
                <Icon name="Plus" size={14} className="mr-2" />
                Add Rule
              </Button>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="space-y-4">
            {[
              { rule: 'Allow HTTP/HTTPS', port: '80, 443', action: 'ALLOW', priority: 1 },
              { rule: 'Block suspicious IPs', port: 'ALL', action: 'BLOCK', priority: 2 },
              { rule: 'Rate limit API calls', port: '3000', action: 'LIMIT', priority: 3 },
              { rule: 'Allow SSH (Admin only)', port: '22', action: 'ALLOW', priority: 4 }
            ].map((rule, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-medium text-foreground">#{rule.priority}</span>
                  <div>
                    <p className="font-medium text-foreground">{rule.rule}</p>
                    <p className="text-sm text-muted-foreground">Port: {rule.port}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className={`px-2 py-1 rounded text-xs font-medium ${
                    rule.action === 'ALLOW' ? 'bg-green-500/20 text-green-400' :
                    rule.action === 'BLOCK'? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {rule.action}
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <Button size="sm" variant="ghost" aria-label="Edit rule">
                      <Icon name="Edit" size={14} />
                    </Button>
                    <Button size="sm" variant="ghost" className="text-red-400" aria-label="Delete rule">
                      <Icon name="Trash2" size={14} />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* SSL Certificate Management */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-lg font-semibold text-foreground">SSL Certificate Management</h4>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">Auto-renew</span>
            <button
              onClick={() => setSslAutoRenew(!sslAutoRenew)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                sslAutoRenew ? 'bg-green-500' : 'bg-slate-600'
              }`}
              aria-label="Toggle SSL auto-renewal"
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  sslAutoRenew ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
              <div className="flex items-center space-x-3 mb-2">
                <Icon name="CheckCircle" size={20} className="text-green-400" />
                <h5 className="font-medium text-green-400">SSL Certificate Active</h5>
              </div>
              <div className="space-y-2 text-sm">
                <p className="text-foreground"><strong>Domain:</strong> kleverinvest.com</p>
                <p className="text-foreground"><strong>Issuer:</strong> Let's Encrypt</p>
                <p className="text-foreground"><strong>Valid Until:</strong> 2025-04-29</p>
                <p className="text-foreground"><strong>Certificate Type:</strong> Domain Validated</p>
              </div>
            </div>

            <Button variant="outline" className="w-full">
              <Icon name="Download" size={16} className="mr-2" />
              Download Certificate
            </Button>
          </div>

          <div className="space-y-4">
            <h5 className="font-medium text-foreground">Security Headers</h5>
            <div className="space-y-2">
              {[
                { header: 'Strict-Transport-Security', status: 'enabled' },
                { header: 'X-Content-Type-Options', status: 'enabled' },
                { header: 'X-Frame-Options', status: 'enabled' },
                { header: 'X-XSS-Protection', status: 'enabled' },
                { header: 'Referrer-Policy', status: 'enabled' }
              ].map((header, index) => (
                <div key={index} className="flex items-center justify-between p-2 rounded bg-muted/20">
                  <span className="text-sm text-foreground">{header.header}</span>
                  <Icon 
                    name="CheckCircle" 
                    size={14} 
                    className={header.status === 'enabled' ? 'text-green-400' : 'text-red-400'} 
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Security Logs & Blocked IPs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Security Logs */}
        <div className="bg-card rounded-lg border border-border">
          <div className="p-6 border-b border-border">
            <h4 className="text-lg font-semibold text-foreground">Security Logs</h4>
          </div>
          
          <div className="p-6">
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {securityLogs.map((log, index) => (
                <div key={index} className={`p-3 rounded-lg border ${getSeverityColor(log.severity)}`}>
                  <div className="flex items-start space-x-3">
                    <Icon name={getLogIcon(log.type)} size={16} className="mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{log.event}</p>
                      <p className="text-xs opacity-80 mt-1">{log.timestamp}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Blocked IPs */}
        <div className="bg-card rounded-lg border border-border">
          <div className="p-6 border-b border-border">
            <div className="flex items-center justify-between">
              <h4 className="text-lg font-semibold text-foreground">Blocked IP Addresses</h4>
              <Button size="sm" variant="outline">
                <Icon name="Plus" size={14} className="mr-2" />
                Block IP
              </Button>
            </div>
          </div>
          
          <div className="p-6">
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {blockedIPs.map((ip, index) => (
                <div key={index} className="p-3 rounded-lg bg-muted/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-foreground">{ip.ip}</p>
                      <p className="text-sm text-muted-foreground">{ip.reason}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Blocked: {ip.blocked} • Duration: {ip.duration}
                      </p>
                    </div>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="text-green-400 hover:text-green-300"
                      aria-label={`Unblock ${ip.ip}`}
                    >
                      <Icon name="Unlock" size={14} />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityConfigPanel;