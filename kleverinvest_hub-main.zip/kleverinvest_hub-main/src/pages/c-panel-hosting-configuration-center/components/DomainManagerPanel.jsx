import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const DomainManagerPanel = () => {
  const [showAddDomain, setShowAddDomain] = useState(false);
  const [showDNSModal, setShowDNSModal] = useState(false);
  const [selectedDomain, setSelectedDomain] = useState(null);

  const domains = [
    {
      name: 'kleverinvest.com',
      type: 'primary',
      status: 'active',
      ssl: 'enabled',
      expiry: '2025-12-15',
      registrar: 'Namecheap'
    },
    {
      name: 'www.kleverinvest.com',
      type: 'subdomain',
      status: 'active',
      ssl: 'enabled',
      expiry: 'N/A',
      registrar: 'N/A'
    },
    {
      name: 'api.kleverinvest.com',
      type: 'subdomain',
      status: 'active',
      ssl: 'enabled',
      expiry: 'N/A',
      registrar: 'N/A'
    },
    {
      name: 'admin.kleverinvest.com',
      type: 'subdomain',
      status: 'active',
      ssl: 'enabled',
      expiry: 'N/A',
      registrar: 'N/A'
    }
  ];

  const dnsRecords = [
    { type: 'A', name: '@', value: '192.168.1.1', ttl: '300' },
    { type: 'A', name: 'www', value: '192.168.1.1', ttl: '300' },
    { type: 'CNAME', name: 'api', value: 'kleverinvest.com', ttl: '300' },
    { type: 'MX', name: '@', value: 'mail.kleverinvest.com', ttl: '300' },
    { type: 'TXT', name: '@', value: 'v=spf1 include:_spf.google.com ~all', ttl: '300' }
  ];

  const emailAccounts = [
    {
      email: 'admin@kleverinvest.com',
      storage: '2.1 GB / 10 GB',
      status: 'active',
      forwarders: 2
    },
    {
      email: 'support@kleverinvest.com',
      storage: '1.5 GB / 5 GB',
      status: 'active',
      forwarders: 1
    },
    {
      email: 'noreply@kleverinvest.com',
      storage: '0.1 GB / 1 GB',
      status: 'active',
      forwarders: 0
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'text-green-400 bg-green-500/10';
      case 'pending':
        return 'text-yellow-400 bg-yellow-500/10';
      case 'expired':
        return 'text-red-400 bg-red-500/10';
      default:
        return 'text-slate-400 bg-slate-500/10';
    }
  };

  const getDomainIcon = (type) => {
    switch (type) {
      case 'primary': return 'Globe';
      case 'subdomain': return 'GitBranch';
      case 'addon': return 'Plus';
      default: return 'Globe';
    }
  };

  const handleDNSEdit = (domain) => {
    setSelectedDomain(domain);
    setShowDNSModal(true);
  };

  return (
    <div className="space-y-6">
      {/* Domain Manager Header */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Domain Management</h3>
            <p className="text-muted-foreground">
              Subdomain configuration, DNS record management, and email account setup
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <Button
              onClick={() => setShowAddDomain(true)}
              variant="outline"
            >
              <Icon name="Plus" size={16} className="mr-2" />
              Add Domain
            </Button>
            
            <Button className="gradient-gold text-black">
              <Icon name="Settings" size={16} className="mr-2" />
              DNS Settings
            </Button>
          </div>
        </div>
      </div>

      {/* Domain Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Domains</p>
              <p className="text-2xl font-bold text-foreground">{domains.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
              <Icon name="Globe" size={24} className="text-blue-400" />
            </div>
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">SSL Certificates</p>
              <p className="text-2xl font-bold text-green-400">{domains.filter(d => d.ssl === 'enabled').length}</p>
            </div>
            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
              <Icon name="Shield" size={24} className="text-green-400" />
            </div>
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Email Accounts</p>
              <p className="text-2xl font-bold text-foreground">{emailAccounts.length}</p>
            </div>
            <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center">
              <Icon name="Mail" size={24} className="text-orange-400" />
            </div>
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">DNS Records</p>
              <p className="text-2xl font-bold text-foreground">{dnsRecords.length}</p>
            </div>
            <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center">
              <Icon name="Server" size={24} className="text-purple-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Domain List */}
      <div className="bg-card rounded-lg border border-border">
        <div className="p-6 border-b border-border">
          <h4 className="text-lg font-semibold text-foreground">Active Domains</h4>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/30">
              <tr>
                <th className="text-left p-4 font-medium text-foreground">Domain Name</th>
                <th className="text-left p-4 font-medium text-foreground">Type</th>
                <th className="text-left p-4 font-medium text-foreground">Status</th>
                <th className="text-left p-4 font-medium text-foreground">SSL</th>
                <th className="text-left p-4 font-medium text-foreground">Expiry</th>
                <th className="text-left p-4 font-medium text-foreground">Registrar</th>
                <th className="text-left p-4 font-medium text-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {domains.map((domain, index) => (
                <tr key={index} className="border-t border-border hover:bg-muted/20">
                  <td className="p-4">
                    <div className="flex items-center space-x-3">
                      <Icon name={getDomainIcon(domain.type)} size={18} className="text-blue-400" />
                      <span className="font-medium text-foreground">{domain.name}</span>
                    </div>
                  </td>
                  <td className="p-4 text-muted-foreground capitalize">{domain.type}</td>
                  <td className="p-4">
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(domain.status)}`}>
                      {domain.status.toUpperCase()}
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <Icon 
                        name={domain.ssl === 'enabled' ? 'Shield' : 'ShieldOff'} 
                        size={16} 
                        className={domain.ssl === 'enabled' ? 'text-green-400' : 'text-red-400'} 
                      />
                      <span className={domain.ssl === 'enabled' ? 'text-green-400' : 'text-red-400'}>
                        {domain.ssl === 'enabled' ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>
                  </td>
                  <td className="p-4 text-muted-foreground">{domain.expiry}</td>
                  <td className="p-4 text-muted-foreground">{domain.registrar}</td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDNSEdit(domain)}
                        aria-label={`Edit DNS for ${domain.name}`}
                      >
                        <Icon name="Settings" size={14} />
                      </Button>
                      <Button size="sm" variant="ghost" aria-label={`Manage SSL for ${domain.name}`}>
                        <Icon name="Shield" size={14} />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="text-red-400 hover:text-red-300"
                        aria-label={`Remove ${domain.name}`}
                      >
                        <Icon name="Trash2" size={14} />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* DNS Records & Email Accounts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* DNS Records */}
        <div className="bg-card rounded-lg border border-border">
          <div className="p-6 border-b border-border">
            <div className="flex items-center justify-between">
              <h4 className="text-lg font-semibold text-foreground">DNS Records</h4>
              <Button size="sm" variant="outline">
                <Icon name="Plus" size={14} className="mr-2" />
                Add Record
              </Button>
            </div>
          </div>
          
          <div className="p-6">
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {dnsRecords.map((record, index) => (
                <div key={index} className="p-3 rounded-lg bg-muted/30">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`px-2 py-1 rounded text-xs font-medium ${
                        record.type === 'A' ? 'bg-blue-500/20 text-blue-400' :
                        record.type === 'CNAME' ? 'bg-green-500/20 text-green-400' :
                        record.type === 'MX'? 'bg-orange-500/20 text-orange-400' : 'bg-purple-500/20 text-purple-400'
                      }`}>
                        {record.type}
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{record.name}</p>
                        <p className="text-sm text-muted-foreground">{record.value}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-muted-foreground">TTL: {record.ttl}</span>
                      <Button size="sm" variant="ghost" aria-label="Edit DNS record">
                        <Icon name="Edit" size={12} />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Email Accounts */}
        <div className="bg-card rounded-lg border border-border">
          <div className="p-6 border-b border-border">
            <div className="flex items-center justify-between">
              <h4 className="text-lg font-semibold text-foreground">Email Accounts</h4>
              <Button size="sm" variant="outline">
                <Icon name="Plus" size={14} className="mr-2" />
                Create Email
              </Button>
            </div>
          </div>
          
          <div className="p-6">
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {emailAccounts.map((account, index) => (
                <div key={index} className="p-3 rounded-lg bg-muted/30">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Icon name="Mail" size={16} className="text-blue-400" />
                      <div>
                        <p className="font-medium text-foreground">{account.email}</p>
                        <p className="text-sm text-muted-foreground">Storage: {account.storage}</p>
                        {account.forwarders > 0 && (
                          <p className="text-xs text-muted-foreground">
                            {account.forwarders} forwarder{account.forwarders !== 1 ? 's' : ''}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(account.status)}`}>
                        {account.status.toUpperCase()}
                      </div>
                      <Button size="sm" variant="ghost" aria-label={`Manage ${account.email}`}>
                        <Icon name="Settings" size={12} />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Add Domain Modal */}
      {showAddDomain && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg p-6 max-w-md w-full mx-4 border border-border">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Add New Domain</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAddDomain(false)}
                aria-label="Close add domain modal"
              >
                <Icon name="X" size={16} />
              </Button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Domain Type
                </label>
                <select className="w-full p-2 border border-border rounded bg-background text-foreground">
                  <option value="subdomain">Subdomain</option>
                  <option value="addon">Addon Domain</option>
                  <option value="parked">Parked Domain</option>
                </select>
              </div>

              <Input
                label="Domain Name"
                placeholder="subdomain.kleverinvest.com"
                required
              />

              <Input
                label="Document Root"
                placeholder="/public_html/subdomain"
                required
              />

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="createSSL"
                  className="rounded"
                  defaultChecked
                />
                <label htmlFor="createSSL" className="text-sm text-foreground">
                  Create SSL certificate automatically
                </label>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowAddDomain(false)}
                >
                  Cancel
                </Button>
                <Button 
                  className="gradient-gold text-black"
                  onClick={() => {
                    console.log('Adding domain...');
                    setShowAddDomain(false);
                  }}
                >
                  Add Domain
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DNS Management Modal */}
      {showDNSModal && selectedDomain && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg p-6 max-w-2xl w-full mx-4 border border-border">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">
                DNS Management - {selectedDomain.name}
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDNSModal(false)}
                aria-label="Close DNS management modal"
              >
                <Icon name="X" size={16} />
              </Button>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium text-foreground">DNS Records</h4>
                <Button size="sm" variant="outline">
                  <Icon name="Plus" size={14} className="mr-2" />
                  Add Record
                </Button>
              </div>

              <div className="max-h-64 overflow-y-auto">
                <table className="w-full">
                  <thead className="bg-muted/30 sticky top-0">
                    <tr>
                      <th className="text-left p-2 text-sm font-medium">Type</th>
                      <th className="text-left p-2 text-sm font-medium">Name</th>
                      <th className="text-left p-2 text-sm font-medium">Value</th>
                      <th className="text-left p-2 text-sm font-medium">TTL</th>
                      <th className="text-left p-2 text-sm font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dnsRecords.map((record, index) => (
                      <tr key={index} className="border-t border-border">
                        <td className="p-2">
                          <span className={`px-2 py-1 rounded text-xs ${
                            record.type === 'A' ? 'bg-blue-500/20 text-blue-400' :
                            record.type === 'CNAME' ? 'bg-green-500/20 text-green-400' :
                            record.type === 'MX'? 'bg-orange-500/20 text-orange-400' : 'bg-purple-500/20 text-purple-400'
                          }`}>
                            {record.type}
                          </span>
                        </td>
                        <td className="p-2 text-sm text-foreground">{record.name}</td>
                        <td className="p-2 text-sm text-foreground">{record.value}</td>
                        <td className="p-2 text-sm text-muted-foreground">{record.ttl}</td>
                        <td className="p-2">
                          <div className="flex items-center space-x-1">
                            <Button size="sm" variant="ghost" aria-label="Edit record">
                              <Icon name="Edit" size={12} />
                            </Button>
                            <Button size="sm" variant="ghost" className="text-red-400" aria-label="Delete record">
                              <Icon name="Trash2" size={12} />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-border">
                <Button
                  variant="outline"
                  onClick={() => setShowDNSModal(false)}
                >
                  Close
                </Button>
                <Button className="gradient-gold text-black">
                  Save Changes
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DomainManagerPanel;