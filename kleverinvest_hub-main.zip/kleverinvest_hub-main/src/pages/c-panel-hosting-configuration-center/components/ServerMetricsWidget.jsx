import React from 'react';
import Icon from '../../../components/AppIcon';

const ServerMetricsWidget = ({ metrics }) => {
  const getMetricColor = (value, type = 'percentage') => {
    if (type === 'percentage') {
      if (value >= 80) return 'text-red-400';
      if (value >= 60) return 'text-yellow-400';
      return 'text-green-400';
    }
    return 'text-blue-400';
  };

  const getProgressColor = (value, type = 'percentage') => {
    if (type === 'percentage') {
      if (value >= 80) return 'bg-red-500';
      if (value >= 60) return 'bg-yellow-500';
      return 'bg-green-500';
    }
    return 'bg-blue-500';
  };

  return (
    <div className="bg-card rounded-lg p-6 border border-border">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-foreground">Server Performance</h3>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-sm text-muted-foreground">Real-time</span>
        </div>
      </div>

      <div className="space-y-4">
        {/* CPU Usage */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Icon name="Cpu" size={16} className="text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">CPU Usage</span>
            </div>
            <span className={`text-sm font-semibold ${getMetricColor(metrics?.cpu)}`}>
              {metrics?.cpu}%
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(metrics?.cpu)}`}
              style={{ width: `${metrics?.cpu}%` }}
            />
          </div>
        </div>

        {/* Memory Usage */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Icon name="MemoryStick" size={16} className="text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">Memory Usage</span>
            </div>
            <span className={`text-sm font-semibold ${getMetricColor(metrics?.memory)}`}>
              {metrics?.memory}%
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(metrics?.memory)}`}
              style={{ width: `${metrics?.memory}%` }}
            />
          </div>
        </div>

        {/* Disk Usage */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Icon name="HardDrive" size={16} className="text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">Disk Usage</span>
            </div>
            <span className={`text-sm font-semibold ${getMetricColor(metrics?.disk)}`}>
              {metrics?.disk}%
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(metrics?.disk)}`}
              style={{ width: `${metrics?.disk}%` }}
            />
          </div>
        </div>

        {/* Bandwidth Usage */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Icon name="Wifi" size={16} className="text-muted-foreground" />
              <span className="text-sm font-medium text-foreground">Bandwidth</span>
            </div>
            <span className={`text-sm font-semibold ${getMetricColor(metrics?.bandwidth)}`}>
              {metrics?.bandwidth}%
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(metrics?.bandwidth)}`}
              style={{ width: `${metrics?.bandwidth}%` }}
            />
          </div>
        </div>

        {/* Additional Metrics */}
        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-1 mb-1">
              <Icon name="Activity" size={14} className="text-green-400" />
              <span className="text-xs text-muted-foreground">Uptime</span>
            </div>
            <span className="text-lg font-semibold text-green-400">{metrics?.uptime}</span>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center space-x-1 mb-1">
              <Icon name="TrendingUp" size={14} className="text-blue-400" />
              <span className="text-xs text-muted-foreground">Requests</span>
            </div>
            <span className="text-lg font-semibold text-blue-400">{metrics?.requests?.toLocaleString()}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServerMetricsWidget;