import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const DatabaseManagerPanel = () => {
  const [activeDatabase, setActiveDatabase] = useState('kleverinvest_main');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [optimizing, setOptimizing] = useState(false);

  const databases = [
    {
      name: 'kleverinvest_main',
      size: '245 MB',
      tables: 23,
      status: 'active',
      lastBackup: '2025-01-29 08:00:00',
      type: 'MySQL 8.0'
    },
    {
      name: 'kleverinvest_analytics',
      size: '89 MB',  
      tables: 12,
      status: 'active',
      lastBackup: '2025-01-29 08:00:00',
      type: 'MySQL 8.0'
    },
    {
      name: 'kleverinvest_cache',
      size: '12 MB',
      tables: 5,
      status: 'active', 
      lastBackup: '2025-01-29 08:00:00',
      type: 'MySQL 8.0'
    }
  ];

  const tables = [
    { name: 'users', rows: 15420, size: '45 MB', engine: 'InnoDB' },
    { name: 'transactions', rows: 89532, size: '123 MB', engine: 'InnoDB' },
    { name: 'investments', rows: 34567, size: '67 MB', engine: 'InnoDB' },
    { name: 'referrals', rows: 8945, size: '12 MB', engine: 'InnoDB' },
    { name: 'notifications', rows: 23456, size: '18 MB', engine: 'InnoDB' }
  ];

  const handleOptimizeDatabase = async () => {
    setOptimizing(true);
    
    // Simulate optimization process
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setOptimizing(false);
    alert('Database optimization completed successfully!');
  };

  const handleBackupDatabase = (dbName) => {
    console.log('Creating backup for:', dbName);
    alert(`Backup initiated for ${dbName}`);
  };

  const getStatusColor = (status) => {
    return status === 'active' ? 'text-green-400 bg-green-500/10' : 'text-red-400 bg-red-500/10';
  };

  return (
    <div className="space-y-6">
      {/* Database Manager Header */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Database Management</h3>
            <p className="text-muted-foreground">
              MySQL performance tuning, backup scheduling, and maintenance
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <Button
              onClick={() => setShowCreateModal(true)}
              variant="outline"
            >
              <Icon name="Plus" size={16} className="mr-2" />
              Create Database
            </Button>
            
            <Button
              onClick={handleOptimizeDatabase}
              disabled={optimizing}
              loading={optimizing}
              className="gradient-gold text-black"
            >
              <Icon name="Zap" size={16} className="mr-2" />
              {optimizing ? 'Optimizing...' : 'Optimize All'}
            </Button>
          </div>
        </div>
      </div>

      {/* Database List */}
      <div className="bg-card rounded-lg border border-border">
        <div className="p-6 border-b border-border">
          <h4 className="text-lg font-semibold text-foreground">Active Databases</h4>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/30">
              <tr>
                <th className="text-left p-4 font-medium text-foreground">Database Name</th>
                <th className="text-left p-4 font-medium text-foreground">Size</th>
                <th className="text-left p-4 font-medium text-foreground">Tables</th>
                <th className="text-left p-4 font-medium text-foreground">Type</th>
                <th className="text-left p-4 font-medium text-foreground">Status</th>
                <th className="text-left p-4 font-medium text-foreground">Last Backup</th>
                <th className="text-left p-4 font-medium text-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {databases.map((db, index) => (
                <tr 
                  key={index} 
                  className={`border-t border-border hover:bg-muted/20 cursor-pointer ${
                    activeDatabase === db.name ? 'bg-primary/5' : ''
                  }`}
                  onClick={() => setActiveDatabase(db.name)}
                >
                  <td className="p-4">
                    <div className="flex items-center space-x-3">
                      <Icon name="Database" size={18} className="text-blue-400" />
                      <span className="font-medium text-foreground">{db.name}</span>
                    </div>
                  </td>
                  <td className="p-4 text-muted-foreground">{db.size}</td>
                  <td className="p-4 text-muted-foreground">{db.tables}</td>
                  <td className="p-4 text-muted-foreground">{db.type}</td>
                  <td className="p-4">
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(db.status)}`}>
                      {db.status.toUpperCase()}
                    </div>
                  </td>
                  <td className="p-4 text-muted-foreground">{db.lastBackup}</td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleBackupDatabase(db.name);
                        }}
                        aria-label={`Backup ${db.name}`}
                      >
                        <Icon name="Download" size={14} />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        aria-label={`Configure ${db.name}`}
                      >
                        <Icon name="Settings" size={14} />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="text-red-400 hover:text-red-300"
                        aria-label={`Delete ${db.name}`}
                      >
                        <Icon name="Trash2" size={14} />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Database Tables (for active database) */}
      <div className="bg-card rounded-lg border border-border">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h4 className="text-lg font-semibold text-foreground">
              Tables in {activeDatabase}
            </h4>
            <div className="flex items-center space-x-2">
              <Button size="sm" variant="outline">
                <Icon name="RefreshCw" size={14} className="mr-2" />
                Refresh
              </Button>
              <Button size="sm" variant="outline">
                <Icon name="Plus" size={14} className="mr-2" />
                Create Table
              </Button>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/30">
              <tr>
                <th className="text-left p-4 font-medium text-foreground">Table Name</th>
                <th className="text-left p-4 font-medium text-foreground">Rows</th>
                <th className="text-left p-4 font-medium text-foreground">Size</th>
                <th className="text-left p-4 font-medium text-foreground">Engine</th>
                <th className="text-left p-4 font-medium text-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {tables.map((table, index) => (
                <tr key={index} className="border-t border-border hover:bg-muted/20">
                  <td className="p-4">
                    <div className="flex items-center space-x-3">
                      <Icon name="Table" size={18} className="text-green-400" />
                      <span className="font-medium text-foreground">{table.name}</span>
                    </div>
                  </td>
                  <td className="p-4 text-muted-foreground">{table.rows.toLocaleString()}</td>
                  <td className="p-4 text-muted-foreground">{table.size}</td>
                  <td className="p-4 text-muted-foreground">{table.engine}</td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <Button size="sm" variant="ghost" aria-label={`View ${table.name}`}>
                        <Icon name="Eye" size={14} />
                      </Button>
                      <Button size="sm" variant="ghost" aria-label={`Edit ${table.name}`}>
                        <Icon name="Edit" size={14} />
                      </Button>
                      <Button size="sm" variant="ghost" aria-label={`Export ${table.name}`}>
                        <Icon name="Download" size={14} />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="text-red-400 hover:text-red-300"
                        aria-label={`Drop ${table.name}`}
                      >
                        <Icon name="Trash2" size={14} />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Database Operations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Operations */}
        <div className="bg-card rounded-lg p-6 border border-border">
          <h4 className="text-lg font-semibold text-foreground mb-4">Quick Operations</h4>
          <div className="space-y-3">
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => console.log('Export database')}
            >
              <Icon name="Download" size={16} className="mr-3" />
              Export Database
            </Button>
            
            <Button
              variant="outline" 
              className="w-full justify-start"
              onClick={() => console.log('Import database')}
            >
              <Icon name="Upload" size={16} className="mr-3" />
              Import Database
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => console.log('Repair database')}
            >
              <Icon name="Wrench" size={16} className="mr-3" />
              Repair Database
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-start text-red-400 border-red-500/20 hover:bg-red-500/10"
              onClick={() => console.log('Drop database')}
            >
              <Icon name="Trash2" size={16} className="mr-3" />
              Drop Database
            </Button>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="bg-card rounded-lg p-6 border border-border">
          <h4 className="text-lg font-semibold text-foreground mb-4">Performance Metrics</h4>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Query Cache Hit Rate</span>
              <span className="text-green-400 font-semibold">94.2%</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Slow Queries</span>
              <span className="text-yellow-400 font-semibold">3</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Connections</span>
              <span className="text-blue-400 font-semibold">45/100</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Buffer Pool Usage</span>
              <span className="text-foreground font-semibold">68%</span>
            </div>

            <Button
              variant="outline"
              className="w-full mt-4"
              onClick={() => console.log('View detailed metrics')}
            >
              <Icon name="BarChart3" size={16} className="mr-2" />
              View Detailed Metrics
            </Button>
          </div>
        </div>
      </div>

      {/* Create Database Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg p-6 max-w-md w-full mx-4 border border-border">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Create New Database</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowCreateModal(false)}
                aria-label="Close create database modal"
              >
                <Icon name="X" size={16} />
              </Button>
            </div>

            <div className="space-y-4">
              <Input
                label="Database Name"
                placeholder="kleverinvest_new"
                required
              />
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Character Set
                </label>
                <select className="w-full p-2 border border-border rounded bg-background text-foreground">
                  <option value="utf8mb4">utf8mb4_unicode_ci</option>
                  <option value="utf8">utf8_general_ci</option>
                  <option value="latin1">latin1_swedish_ci</option>
                </select>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowCreateModal(false)}
                >
                  Cancel
                </Button>
                <Button 
                  className="gradient-gold text-black"
                  onClick={() => {
                    console.log('Creating database...');
                    setShowCreateModal(false);
                  }}
                >
                  Create Database
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DatabaseManagerPanel;