import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';


const FileManagerPanel = () => {
  const [currentPath, setCurrentPath] = useState('/public_html');
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [viewMode, setViewMode] = useState('list'); // list or grid

  const files = [
    { name: 'index.html', type: 'file', size: '2.5 KB', modified: '2025-01-29', permissions: '644' },
    { name: 'assets', type: 'folder', size: '--', modified: '2025-01-28', permissions: '755' },
    { name: 'src', type: 'folder', size: '--', modified: '2025-01-29', permissions: '755' },
    { name: 'package.json', type: 'file', size: '1.8 KB', modified: '2025-01-29', permissions: '644' },
    { name: 'vite.config.js', type: 'file', size: '890 B', modified: '2025-01-28', permissions: '644' },
    { name: '.env', type: 'file', size: '512 B', modified: '2025-01-29', permissions: '600' },
    { name: 'dist', type: 'folder', size: '--', modified: '2025-01-29', permissions: '755' },
    { name: 'README.md', type: 'file', size: '3.2 KB', modified: '2025-01-27', permissions: '644' }
  ];

  const breadcrumbs = currentPath.split('/').filter(Boolean);

  const handleFileSelect = (fileName) => {
    setSelectedFiles(prev => {
      if (prev.includes(fileName)) {
        return prev.filter(name => name !== fileName);
      } else {
        return [...prev, fileName];
      }
    });
  };

  const handleBulkAction = (action) => {
    if (selectedFiles.length === 0) return;
    
    switch (action) {
      case 'delete':
        console.log('Deleting files:', selectedFiles);
        setSelectedFiles([]);
        break;
      case 'download':
        console.log('Downloading files:', selectedFiles);
        break;
      case 'compress': console.log('Compressing files:', selectedFiles);
        break;
      default:
        break;
    }
  };

  const getFileIcon = (type, name) => {
    if (type === 'folder') return 'Folder';
    
    const extension = name?.split('.')?.pop()?.toLowerCase();
    switch (extension) {
      case 'html': return 'FileText';
      case 'js': case 'jsx': return 'FileText';
      case 'css': return 'Palette';
      case 'json': return 'Braces';
      case 'md': return 'FileText';
      case 'png': case 'jpg': case 'jpeg': case 'gif': return 'Image';
      default: return 'File';
    }
  };

  return (
    <div className="space-y-6">
      {/* File Manager Header */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">File Manager</h3>
            
            {/* Breadcrumb Navigation */}
            <nav className="flex items-center space-x-2 text-sm" aria-label="File path">
              <Icon name="Home" size={14} className="text-muted-foreground" />
              <span className="text-muted-foreground">/</span>
              {breadcrumbs.map((crumb, index) => (
                <React.Fragment key={index}>
                  <button
                    onClick={() => setCurrentPath('/' + breadcrumbs.slice(0, index + 1).join('/'))}
                    className="text-blue-400 hover:text-blue-300 transition-colors"
                    aria-label={`Navigate to ${crumb}`}
                  >
                    {crumb}
                  </button>
                  {index < breadcrumbs.length - 1 && (
                    <span className="text-muted-foreground">/</span>
                  )}
                </React.Fragment>
              ))}
            </nav>
          </div>

          <div className="flex items-center space-x-3">
            {/* View Mode Toggle */}
            <div className="flex bg-muted rounded-lg p-1">
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded ${viewMode === 'list' ? 'bg-background shadow-sm' : ''}`}
                aria-label="List view"
              >
                <Icon name="List" size={16} />
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded ${viewMode === 'grid' ? 'bg-background shadow-sm' : ''}`}
                aria-label="Grid view"
              >
                <Icon name="Grid3x3" size={16} />
              </button>
            </div>

            <Button
              onClick={() => setShowUploadModal(true)}
              className="gradient-gold text-black"
            >
              <Icon name="Upload" size={16} className="mr-2" />
              Upload Files
            </Button>
          </div>
        </div>

        {/* Bulk Actions */}
        {selectedFiles.length > 0 && (
          <div className="mt-4 p-3 bg-muted/30 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-foreground">
                {selectedFiles.length} file{selectedFiles.length !== 1 ? 's' : ''} selected
              </span>
              <div className="flex items-center space-x-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleBulkAction('download')}
                >
                  <Icon name="Download" size={14} className="mr-1" />
                  Download
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleBulkAction('compress')}
                >
                  <Icon name="Archive" size={14} className="mr-1" />
                  Compress
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleBulkAction('delete')}
                  className="text-red-400 border-red-500/20 hover:bg-red-500/10"
                >
                  <Icon name="Trash2" size={14} className="mr-1" />
                  Delete
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* File List */}
      <div className="bg-card rounded-lg border border-border overflow-hidden">
        {viewMode === 'list' ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/30">
                <tr>
                  <th className="text-left p-4 font-medium text-foreground">
                    <input
                      type="checkbox"
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedFiles(files.map(f => f.name));
                        } else {
                          setSelectedFiles([]);
                        }
                      }}
                      checked={selectedFiles.length === files.length}
                      className="rounded"
                      aria-label="Select all files"
                    />
                  </th>
                  <th className="text-left p-4 font-medium text-foreground">Name</th>
                  <th className="text-left p-4 font-medium text-foreground">Size</th>
                  <th className="text-left p-4 font-medium text-foreground">Modified</th>
                  <th className="text-left p-4 font-medium text-foreground">Permissions</th>
                  <th className="text-left p-4 font-medium text-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {files.map((file, index) => (
                  <tr key={index} className="border-t border-border hover:bg-muted/20">
                    <td className="p-4">
                      <input
                        type="checkbox"
                        checked={selectedFiles.includes(file.name)}
                        onChange={() => handleFileSelect(file.name)}
                        className="rounded"
                        aria-label={`Select ${file.name}`}
                      />
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <Icon 
                          name={getFileIcon(file.type, file.name)} 
                          size={18} 
                          className={file.type === 'folder' ? 'text-blue-400' : 'text-muted-foreground'} 
                        />
                        <span className="font-medium text-foreground">{file.name}</span>
                      </div>
                    </td>
                    <td className="p-4 text-muted-foreground">{file.size}</td>
                    <td className="p-4 text-muted-foreground">{file.modified}</td>
                    <td className="p-4">
                      <code className="text-xs bg-muted px-2 py-1 rounded">{file.permissions}</code>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <Button size="sm" variant="ghost" aria-label={`Edit ${file.name}`}>
                          <Icon name="Edit" size={14} />
                        </Button>
                        <Button size="sm" variant="ghost" aria-label={`Download ${file.name}`}>
                          <Icon name="Download" size={14} />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="text-red-400 hover:text-red-300"
                          aria-label={`Delete ${file.name}`}
                        >
                          <Icon name="Trash2" size={14} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-6 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {files.map((file, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                  selectedFiles.includes(file.name)
                    ? 'border-primary bg-primary/10' :'border-border hover:bg-muted/30'
                }`}
                onClick={() => handleFileSelect(file.name)}
              >
                <div className="text-center">
                  <Icon 
                    name={getFileIcon(file.type, file.name)} 
                    size={32} 
                    className={`mx-auto mb-2 ${file.type === 'folder' ? 'text-blue-400' : 'text-muted-foreground'}`} 
                  />
                  <p className="text-sm font-medium text-foreground truncate" title={file.name}>
                    {file.name}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">{file.size}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg p-6 max-w-md w-full mx-4 border border-border">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Upload Files</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowUploadModal(false)}
                aria-label="Close upload modal"
              >
                <Icon name="X" size={16} />
              </Button>
            </div>

            <div className="space-y-4">
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                <Icon name="Upload" size={48} className="mx-auto text-muted-foreground mb-4" />
                <p className="text-foreground font-medium mb-2">Drop files here or click to browse</p>
                <p className="text-sm text-muted-foreground">Maximum file size: 10MB</p>
                <Button variant="outline" className="mt-4">
                  <Icon name="FolderOpen" size={16} className="mr-2" />
                  Select Files
                </Button>
              </div>

              <div className="flex items-center justify-end space-x-3">
                <Button
                  variant="outline"
                  onClick={() => setShowUploadModal(false)}
                >
                  Cancel
                </Button>
                <Button className="gradient-gold text-black">
                  Upload Files
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileManagerPanel;