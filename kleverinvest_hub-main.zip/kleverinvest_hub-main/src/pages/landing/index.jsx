import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import LiveBTCBar from '../../components/ui/LiveBTCBar';
import AnimatedBitcoin from '../../components/ui/AnimatedBitcoin';
import TradingViewChart from '../btc-live-trading-interface/components/TradingViewChart';
import BitcoinAnimatedBackground from '../../components/ui/BitcoinAnimatedBackground';

const LandingPage = () => {
  const navigate = useNavigate();
  const [isScrolled, setIsScrolled] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);

  // Load site settings for dynamic content
  const [siteSettings, setSiteSettings] = useState(() => {
    const saved = localStorage.getItem('admin_site_settings');
    return saved ? JSON.parse(saved) : {
      siteName: 'KleverInvest Hub',
      siteDescription: 'Professional Cryptocurrency Investment Platform',
      contactEmail: 'admin@kleverinvest.com',
      registrationEnabled: true
    };
  });

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Listen for site settings changes
  useEffect(() => {
    const handleSettingsChange = (event) => {
      setSiteSettings(event.detail);
    };

    window.addEventListener('siteSettingsChanged', handleSettingsChange);
    return () => window.removeEventListener('siteSettingsChanged', handleSettingsChange);
  }, []);

  // Auto-rotate hero slides
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % 3);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const stats = [
    { label: 'Total Value Locked', value: '$2.4B+', icon: 'Lock' },
    { label: 'Active Users', value: '150K+', icon: 'Users' },
    { label: 'Countries Served', value: '50+', icon: 'Globe' },
    { label: 'Average APY', value: '12.5%', icon: 'TrendingUp' }
  ];

  const features = [
    {
      icon: 'Shield',
      title: 'Bank-Grade Security',
      description: 'Multi-layer security with cold storage and insurance protection'
    },
    {
      icon: 'Zap',
      title: 'Instant Transactions',
      description: 'Lightning-fast deposits and withdrawals with minimal fees'
    },
    {
      icon: 'BarChart3',
      title: 'Advanced Analytics',
      description: 'Real-time portfolio tracking and performance insights'
    },
    {
      icon: 'Headphones',
      title: '24/7 Support',
      description: 'Round-the-clock customer support from crypto experts'
    }
  ];

  const investmentPlans = [
    {
      name: 'Starter',
      apy: '8.5%',
      minInvestment: '$100',
      duration: '30 days',
      features: ['Basic portfolio', 'Email support', 'Mobile app access'],
      popular: false
    },
    {
      name: 'Growth',
      apy: '12.5%',
      minInvestment: '$1,000',
      duration: '90 days',
      features: ['Advanced portfolio', 'Priority support', 'API access', 'Analytics dashboard'],
      popular: true
    },
    {
      name: 'Pro',
      apy: '18.2%',
      minInvestment: '$10,000',
      duration: '180 days',
      features: ['Premium portfolio', 'Dedicated manager', 'Custom strategies', 'Institutional tools'],
      popular: false
    }
  ];

  const heroSlides = [
    {
      title: 'Invest in the Future of Finance',
      subtitle: 'Build wealth with cryptocurrency investments backed by institutional-grade security',
      cta: 'Start Investing'
    },
    {
      title: 'Maximize Your Returns',
      subtitle: 'Earn up to 18.2% APY with our professionally managed investment strategies',
      cta: 'View Plans'
    },
    {
      title: 'Trusted by 150K+ Investors',
      subtitle: 'Join the largest crypto investment platform with $2.4B+ in total value locked',
      cta: 'Join Now'
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <BitcoinAnimatedBackground />
      {/* Header */}
      <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'glass-effect' : 'bg-transparent'
      }`}>
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 gradient-gold rounded-lg flex items-center justify-center relative">
              <AnimatedBitcoin size="sm" animation="float" showGlow />
            </div>
            <span className="font-bold text-xl">{siteSettings.siteName}</span>
          </div>

          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">Home</Link>
            <Link to="/about-company-page" className="text-muted-foreground hover:text-foreground transition-colors">About</Link>
            <Link to="/why-choose-klever-invest" className="text-muted-foreground hover:text-foreground transition-colors">Why Choose</Link>
            <Link to="/investment-plans" className="text-muted-foreground hover:text-foreground transition-colors">Plans</Link>
            <Link to="/how-it-works" className="text-muted-foreground hover:text-foreground transition-colors">How It Works</Link>
            <Link to="/faq" className="text-muted-foreground hover:text-foreground transition-colors">FAQ</Link>
            <Link to="/testimonials" className="text-muted-foreground hover:text-foreground transition-colors">Testimonials</Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => navigate('/login')}>
              Sign In
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/admin-login')}
              className="text-xs text-muted-foreground hover:text-red-400"
            >
              Admin
            </Button>
            <Button className="gradient-gold text-black font-semibold" onClick={() => navigate('/signup')}>
              Sign Up
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 gradient-dark opacity-50"></div>

        {/* Floating Bitcoin animations */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 left-20">
            <AnimatedBitcoin size="lg" animation="float" speed="slow" showGlow />
          </div>
          <div className="absolute top-32 right-32">
            <AnimatedBitcoin size="md" animation="bounce" speed="normal" showGlow />
          </div>
          <div className="absolute bottom-40 left-32">
            <AnimatedBitcoin size="xl" animation="pulse" speed="slow" showGlow />
          </div>
          <div className="absolute bottom-20 right-20">
            <AnimatedBitcoin size="lg" animation="float" speed="fast" showGlow />
          </div>
          <div className="absolute top-1/2 left-10">
            <AnimatedBitcoin size="sm" animation="spin" speed="slow" showGlow />
          </div>
          <div className="absolute top-1/3 right-10">
            <AnimatedBitcoin size="md" animation="bounce" speed="fast" showGlow />
          </div>
          <div className="absolute bottom-1/3 left-1/4">
            <AnimatedBitcoin size="sm" animation="pulse" speed="fast" showGlow />
          </div>
          <div className="absolute top-3/4 right-1/3">
            <AnimatedBitcoin size="lg" animation="float" speed="normal" showGlow />
          </div>
        </div>

        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-72 h-72 bg-orange-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative z-10 container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              {heroSlides[currentSlide].title}
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              {heroSlides[currentSlide].subtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="gradient-gold text-black font-semibold px-8 py-4" onClick={() => navigate('/login')}>
                <AnimatedBitcoin size="sm" animation="pulse" speed="fast" className="mr-2" />
                {heroSlides[currentSlide].cta}
                <Icon name="ArrowRight" size={20} className="ml-2" />
              </Button>
              <Button variant="outline" size="lg" className="px-8 py-4" onClick={() => navigate('/about')}>
                Watch Demo
                <Icon name="Play" size={20} className="ml-2" />
              </Button>
            </div>
          </div>

          {/* Slide Indicators */}
          <div className="flex justify-center space-x-2 mt-12">
            {heroSlides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentSlide ? 'bg-primary' : 'bg-muted'
                }`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 border-t border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center relative">
                <div className="w-16 h-16 gradient-gold rounded-lg flex items-center justify-center mx-auto mb-4 relative">
                  {stat.icon === 'Lock' && <AnimatedBitcoin size="sm" animation="pulse" showGlow />}
                  {stat.icon === 'Users' && <Icon name={stat.icon} size={24} color="black" />}
                  {stat.icon === 'Globe' && <Icon name={stat.icon} size={24} color="black" />}
                  {stat.icon === 'TrendingUp' && <AnimatedBitcoin size="sm" animation="float" showGlow />}
                  {index === 0 && (
                    <div className="absolute -top-1 -right-1">
                      <AnimatedBitcoin size="xs" animation="spin" speed="fast" />
                    </div>
                  )}
                </div>
                <div className="text-3xl font-bold text-primary mb-2">{stat.value}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Live BTC Price Bar - Centered */}
      <section className="py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <LiveBTCBar />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Why Choose KleverInvest</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experience the future of cryptocurrency investing with our cutting-edge platform
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="glass-effect rounded-xl p-6 hover:bg-card/50 transition-all duration-300">
                <div className="w-12 h-12 gradient-gold rounded-lg flex items-center justify-center mb-4">
                  <Icon name={feature.icon} size={24} color="black" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Live Market Analysis */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Live Market Analysis</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Stay ahead of the market with real-time trading data and professional-grade charts
            </p>
          </div>

          <div className="max-w-6xl mx-auto">
            <div className="bg-card border rounded-lg p-6 shadow-lg">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-semibold text-foreground flex items-center">
                  <AnimatedBitcoin size="md" animation="float" showGlow className="mr-3" />
                  Bitcoin Live Chart
                </h3>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">1H</Button>
                  <Button variant="outline" size="sm">4H</Button>
                  <Button variant="outline" size="sm" className="bg-primary text-white">1D</Button>
                  <Button variant="outline" size="sm">1W</Button>
                </div>
              </div>
              <div className="h-96">
                <TradingViewChart symbol="BTCUSD" timeframe="1D" currentPrice={43250.50} />
              </div>
              <div className="mt-6 text-center">
                <Button onClick={() => navigate('/login')} className="gradient-gold text-black font-semibold">
                  <AnimatedBitcoin size="sm" animation="pulse" speed="fast" className="mr-2" />
                  Start Trading Now
                  <Icon name="TrendingUp" size={20} className="ml-2" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Investment Plans */}
      <section id="plans" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Investment Plans</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Choose the perfect plan to start your crypto investment journey
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {investmentPlans.map((plan, index) => (
              <div key={index} className={`relative rounded-xl p-8 border-2 transition-all duration-300 hover:scale-105 ${
                plan.popular 
                  ? 'border-primary bg-card gradient-gold/5' :'border-border bg-card hover:border-primary/50'
              }`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="gradient-gold text-black px-4 py-1 rounded-full text-sm font-semibold">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <div className="text-4xl font-bold text-primary mb-2">{plan.apy}</div>
                  <div className="text-muted-foreground">Annual Percentage Yield</div>
                </div>

                <div className="space-y-2 mb-8">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Minimum Investment</span>
                    <span className="font-semibold">{plan.minInvestment}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Lock Period</span>
                    <span className="font-semibold">{plan.duration}</span>
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Icon name="Check" size={16} className="text-success mr-3" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  className={`w-full ${plan.popular ? 'gradient-gold text-black' : ''}`}
                  variant={plan.popular ? 'default' : 'outline'}
                  onClick={() => navigate('/signup')}
                >
                  Sign Up
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-card/30">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Start Investing?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of investors who are already building wealth with KleverInvest Hub
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="gradient-gold text-black font-semibold px-8 py-4" onClick={() => navigate('/login')}>
              Create Account
              <Icon name="ArrowRight" size={20} className="ml-2" />
            </Button>
            <Button variant="outline" size="lg" className="px-8 py-4" onClick={() => navigate('/contact')}>
              Schedule Demo
              <Icon name="Calendar" size={20} className="ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 gradient-gold rounded-lg flex items-center justify-center">
                  <Icon name="TrendingUp" size={20} color="black" />
                </div>
                <span className="font-bold text-xl">{siteSettings.siteName}</span>
              </div>
              <p className="text-muted-foreground mb-4">
                The future of cryptocurrency investing, built for everyone.
              </p>
              <div className="flex space-x-4">
                <Icon name="Twitter" size={20} className="text-muted-foreground hover:text-foreground cursor-pointer" />
                <Icon name="Github" size={20} className="text-muted-foreground hover:text-foreground cursor-pointer" />
                <Icon name="Linkedin" size={20} className="text-muted-foreground hover:text-foreground cursor-pointer" />
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Features</a></li>
                <li><a href="#" className="hover:text-foreground">Pricing</a></li>
                <li><a href="#" className="hover:text-foreground">API</a></li>
                <li><a href="#" className="hover:text-foreground">Security</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><Link to="/about" className="hover:text-foreground">About</Link></li>
                <li><a href="#" className="hover:text-foreground">Blog</a></li>
                <li><a href="#" className="hover:text-foreground">Careers</a></li>
                <li><Link to="/contact" className="hover:text-foreground">Contact</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Help Center</a></li>
                <li><a href="#" className="hover:text-foreground">Community</a></li>
                <li><a href="#" className="hover:text-foreground">Status</a></li>
                <li><a href="#" className="hover:text-foreground">Terms</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2025 KleverInvest Hub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
