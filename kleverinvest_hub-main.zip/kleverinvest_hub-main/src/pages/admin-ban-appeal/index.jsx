import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminBanAppeal = () => {
  const navigate = useNavigate();
  const { userId } = useParams();
  const { isAdminAuthenticated } = useAdminAuth();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [reviewNote, setReviewNote] = useState('');

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadAppealDetails();
  }, [isAdminAuthenticated, navigate, userId]);

  const loadAppealDetails = () => {
    setLoading(true);
    // Load appeal details from localStorage - only users with pending appeals
    setTimeout(() => {
      const storedUsers = JSON.parse(localStorage.getItem('admin_banned_users') || '[]');
      const foundUser = storedUsers.find(u => u.id === parseInt(userId) && u.appealStatus === 'pending');
      setUser(foundUser);
      setLoading(false);
    }, 500);
  };

  const handleAppealDecision = async (decision) => {
    if (!user || !reviewNote.trim()) {
      alert('Please add a review note before making a decision.');
      return;
    }
    
    setActionLoading(true);
    
    try {
      const confirmMessage = decision === 'approve' 
        ? `Are you sure you want to APPROVE the appeal for ${user.username}? This will unban the user.`
        : `Are you sure you want to REJECT the appeal for ${user.username}?`;
        
      if (window.confirm(confirmMessage)) {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        if (decision === 'approve') {
          alert(`Appeal approved! User ${user.username} has been unbanned and notified.`);
          navigate('/admin-banned-users');
        } else {
          alert(`Appeal rejected. User ${user.username} has been notified with your review notes.`);
          navigate('/admin-banned-users');
        }
      }
    } catch (error) {
      alert('Action failed. Please try again.');
    } finally {
      setActionLoading(false);
    }
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getSecurityScore = (security) => {
    let score = 0;
    if (security.twoFactorEnabled) score += 25;
    if (security.securityQuestions) score += 25;
    if (security.emailVerified) score += 25;
    if (new Date(security.passwordLastChanged) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)) score += 25;
    return score;
  };

  const getSecurityScoreColor = (score) => {
    if (score >= 75) return 'text-green-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <AdminNavigation
          title="Appeal Review"
          breadcrumb={[
            { label: "User Management", link: "/admin-user-management" },
            { label: "Banned Users", link: "/admin-banned-users" },
            { label: "Appeal Review" }
          ]}
        />
        <div className="p-6">
          <div className="flex items-center justify-center py-12">
            <Icon name="Loader2" size={32} className="animate-spin text-primary mr-3" />
            <span className="text-lg">Loading appeal details...</span>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <AdminNavigation
          title="Appeal Review"
          breadcrumb={[
            { label: "User Management", link: "/admin-user-management" },
            { label: "Banned Users", link: "/admin-banned-users" },
            { label: "Appeal Review" }
          ]}
        />
        <div className="p-6">
          <div className="text-center py-12">
            <Icon name="AlertTriangle" size={48} className="text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-foreground mb-2">No Pending Appeal</h2>
            <p className="text-muted-foreground mb-6">This user doesn't have a pending appeal or the user wasn't found.</p>
            <Button onClick={() => navigate('/admin-banned-users')}>
              <Icon name="ArrowLeft" size={16} className="mr-2" />
              Back to Banned Users
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const securityScore = getSecurityScore(user.accountSecurity);

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title={`Appeal Review - ${user.fullName}`}
        breadcrumb={[
          { label: "User Management", link: "/admin-user-management" },
          { label: "Banned Users", link: "/admin-banned-users" },
          { label: `Appeal - ${user.fullName}` }
        ]}
        actions={[
          {
            label: "Back to List",
            icon: "ArrowLeft",
            variant: "outline",
            onClick: () => navigate('/admin-banned-users')
          },
          {
            label: "View Full Ban Details",
            icon: "ExternalLink",
            variant: "outline",
            onClick: () => navigate(`/admin-ban-details/${user.id}`)
          }
        ]}
      />

      <div className="p-6 space-y-6">
        {/* Appeal Overview */}
        <div className="bg-card border rounded-lg p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold text-foreground mb-2">Ban Appeal Review</h1>
              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <span>Submitted: {formatDateTime(user.appealDate)}</span>
                <span>•</span>
                <span>User ID: {user.id}</span>
                <span>•</span>
                <span>Ban Type: {user.banType}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="Clock" size={16} className="text-blue-600" />
                <span className="text-sm font-medium text-blue-600">Pending Review</span>
              </div>
              <div className="text-xs text-muted-foreground">
                {user.previousAppeals.length} previous appeal(s)
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-muted/30 rounded-lg p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{user.userHistory.totalLogins}</div>
              <div className="text-xs text-muted-foreground">Total Logins</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{user.userHistory.successfulInvestments}</div>
              <div className="text-xs text-muted-foreground">Successful Investments</div>
            </div>
            <div className="text-center">
              <div className={`text-2xl font-bold ${getSecurityScoreColor(securityScore)}`}>{securityScore}%</div>
              <div className="text-xs text-muted-foreground">Security Score</div>
            </div>
          </div>
        </div>

        {/* Appeal Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-card border rounded-lg p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">Original Ban Information</h2>
            <div className="space-y-3">
              <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                <div className="text-sm font-medium text-red-800 mb-1">Ban Reason:</div>
                <div className="text-sm text-red-700">{user.banReason}</div>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Ban Date:</span>
                <span className="font-medium">{formatDateTime(user.banDate)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Banned By:</span>
                <span className="font-medium">{user.bannedBy}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Violation Type:</span>
                <span className="font-medium capitalize">{user.violationType}</span>
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">User's Appeal</h2>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="text-sm font-medium text-blue-800 mb-2">Appeal Statement:</div>
              <div className="text-sm text-blue-700 leading-relaxed">{user.appealReason}</div>
            </div>
            
            {user.appealEvidence.length > 0 && (
              <div className="mt-4">
                <div className="text-sm font-medium text-foreground mb-2">Supporting Evidence:</div>
                <div className="space-y-2">
                  {user.appealEvidence.map((evidence, index) => (
                    <div key={index} className="flex items-center justify-between bg-background border rounded p-2">
                      <div className="flex items-center space-x-2">
                        <Icon name="Paperclip" size={14} className="text-muted-foreground" />
                        <span className="text-sm text-foreground">{evidence.name}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {formatDateTime(evidence.uploadDate)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Account Security Review */}
        <div className="bg-card border rounded-lg p-6">
          <h2 className="text-lg font-semibold text-foreground mb-4">Account Security Assessment</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-3">Security Features</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-foreground">Two-Factor Authentication</span>
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={user.accountSecurity.twoFactorEnabled ? "Check" : "X"} 
                      size={16} 
                      className={user.accountSecurity.twoFactorEnabled ? "text-green-600" : "text-red-600"} 
                    />
                    <span className="text-xs text-muted-foreground">
                      {user.accountSecurity.twoFactorEnabled ? "Enabled" : "Disabled"}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-foreground">Security Questions</span>
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={user.accountSecurity.securityQuestions ? "Check" : "X"} 
                      size={16} 
                      className={user.accountSecurity.securityQuestions ? "text-green-600" : "text-red-600"} 
                    />
                    <span className="text-xs text-muted-foreground">
                      {user.accountSecurity.securityQuestions ? "Set" : "Not Set"}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-foreground">Email Verification</span>
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={user.accountSecurity.emailVerified ? "Check" : "X"} 
                      size={16} 
                      className={user.accountSecurity.emailVerified ? "text-green-600" : "text-red-600"} 
                    />
                    <span className="text-xs text-muted-foreground">
                      {user.accountSecurity.emailVerified ? "Verified" : "Unverified"}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-foreground">Password Last Changed</span>
                  <span className="text-xs text-muted-foreground">
                    {formatDateTime(user.accountSecurity.passwordLastChanged)}
                  </span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-3">Account History</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Member Since:</span>
                  <span className="font-medium">{formatDateTime(user.userHistory.registrationDate)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Support Tickets:</span>
                  <span className="font-medium">{user.userHistory.supportTickets}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Community Rep:</span>
                  <span className="font-medium capitalize">{user.userHistory.communityReputation}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Previous Appeals */}
        {user.previousAppeals.length > 0 && (
          <div className="bg-card border rounded-lg p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">Previous Appeals</h2>
            <div className="space-y-3">
              {user.previousAppeals.map((appeal, index) => (
                <div key={index} className="border border-border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-foreground">Appeal #{index + 1}</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs px-2 py-1 bg-red-100 text-red-800 rounded-full">
                        {appeal.status.charAt(0).toUpperCase() + appeal.status.slice(1)}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatDateTime(appeal.date)}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{appeal.reason}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Review Decision */}
        <div className="bg-card border rounded-lg p-6">
          <h2 className="text-lg font-semibold text-foreground mb-4">Review Decision</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Admin Review Notes <span className="text-red-500">*</span>
              </label>
              <textarea
                value={reviewNote}
                onChange={(e) => setReviewNote(e.target.value)}
                placeholder="Provide detailed reasoning for your decision. This will be sent to the user."
                rows={4}
                className="w-full p-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary resize-none"
              />
            </div>
            
            <div className="flex space-x-4 pt-4">
              <Button
                onClick={() => handleAppealDecision('approve')}
                disabled={actionLoading || !reviewNote.trim()}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                {actionLoading ? (
                  <Icon name="Loader2" size={16} className="animate-spin mr-2" />
                ) : (
                  <Icon name="Check" size={16} className="mr-2" />
                )}
                Approve Appeal & Unban
              </Button>
              
              <Button
                variant="outline"
                onClick={() => handleAppealDecision('reject')}
                disabled={actionLoading || !reviewNote.trim()}
                className="text-red-600 border-red-200 hover:bg-red-50"
              >
                {actionLoading ? (
                  <Icon name="Loader2" size={16} className="animate-spin mr-2" />
                ) : (
                  <Icon name="X" size={16} className="mr-2" />
                )}
                Reject Appeal
              </Button>
              
              <Button
                variant="outline"
                onClick={() => navigate('/admin-banned-users')}
                disabled={actionLoading}
              >
                <Icon name="ArrowLeft" size={16} className="mr-2" />
                Back to List
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminBanAppeal;
