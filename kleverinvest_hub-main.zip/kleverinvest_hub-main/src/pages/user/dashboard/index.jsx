import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../../contexts/AuthContext';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import AnimatedBitcoin from '../../../components/ui/AnimatedBitcoin';
import LiveBTCBar from '../../../components/ui/LiveBTCBar';

const UserDashboard = () => {
  const navigate = useNavigate();
  const { user, logout, checkSessionExpiry } = useAuth();
  const [walletData, setWalletData] = useState({
    balance: 0,
    pendingDeposits: 0,
    totalEarnings: 0,
    availableForWithdrawal: 0
  });
  const [investmentPlans, setInvestmentPlans] = useState([]);
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);

  useEffect(() => {
    if (!checkSessionExpiry()) {
      navigate('/user-login');
      return;
    }

    // Simulate loading user dashboard data
    setTimeout(() => {
      setWalletData({
        balance: 25000.50,
        pendingDeposits: 1500.00,
        totalEarnings: 3250.75,
        availableForWithdrawal: 23500.50
      });

      setInvestmentPlans([
        {
          id: 1,
          name: 'Bitcoin Starter',
          minAmount: 100,
          maxAmount: 10000,
          duration: '30 days',
          apy: 8.5,
          risk: 'Low',
          description: 'Perfect for beginners'
        },
        {
          id: 2,
          name: 'Ethereum Growth',
          minAmount: 1000,
          maxAmount: 50000,
          duration: '90 days',
          apy: 12.5,
          risk: 'Medium',
          description: 'Balanced risk and reward'
        },
        {
          id: 3,
          name: 'DeFi Premium',
          minAmount: 5000,
          maxAmount: 100000,
          duration: '180 days',
          apy: 18.2,
          risk: 'High',
          description: 'Maximum returns'
        }
      ]);

      setRecentTransactions([
        {
          id: 1,
          type: 'deposit',
          amount: 5000,
          status: 'completed',
          date: '2024-01-20',
          description: 'Bank transfer deposit'
        },
        {
          id: 2,
          type: 'investment',
          amount: -2500,
          status: 'active',
          date: '2024-01-19',
          description: 'Bitcoin Starter Plan'
        },
        {
          id: 3,
          type: 'earning',
          amount: 125.50,
          status: 'completed',
          date: '2024-01-18',
          description: 'Daily earnings'
        },
        {
          id: 4,
          type: 'withdrawal',
          amount: -1000,
          status: 'pending',
          date: '2024-01-17',
          description: 'Bank withdrawal'
        }
      ]);

      setLoading(false);
    }, 1000);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/user-login');
  };

  const getRiskColor = (risk) => {
    switch (risk) {
      case 'Low': return 'text-green-400';
      case 'Medium': return 'text-yellow-400';
      case 'High': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getTransactionIcon = (type) => {
    switch (type) {
      case 'deposit': return 'ArrowDownLeft';
      case 'withdrawal': return 'ArrowUpRight';
      case 'investment': return 'TrendingUp';
      case 'earning': return 'DollarSign';
      default: return 'CreditCard';
    }
  };

  const getTransactionColor = (type, amount) => {
    if (type === 'earning' || (type === 'deposit' && amount > 0)) {
      return 'text-green-400';
    } else if (type === 'withdrawal' || type === 'investment') {
      return 'text-red-400';
    }
    return 'text-gray-400';
  };

  const getStatusBadge = (status) => {
    const styles = {
      completed: 'bg-green-500/20 text-green-400 border-green-500/30',
      pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      active: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      failed: 'bg-red-500/20 text-red-400 border-red-500/30'
    };
    
    return (
      <span className={`px-2 py-1 text-xs rounded-md border ${styles[status] || styles.pending}`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-300">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 relative">
      {/* Floating Bitcoin Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-10 left-10">
          <AnimatedBitcoin size="sm" animation="float" speed="slow" showGlow />
        </div>
        <div className="absolute top-32 right-20">
          <AnimatedBitcoin size="xs" animation="bounce" speed="normal" />
        </div>
        <div className="absolute bottom-40 left-16">
          <AnimatedBitcoin size="sm" animation="pulse" speed="slow" showGlow />
        </div>
        <div className="absolute bottom-20 right-32">
          <AnimatedBitcoin size="xs" animation="float" speed="fast" />
        </div>
      </div>

      {/* Live BTC Price Bar */}
      <div className="relative z-10">
        <LiveBTCBar />
      </div>

      {/* Header */}
      <div className="bg-gray-800/90 backdrop-blur-sm border-b border-gray-700 px-6 py-4 relative z-10">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-blue-800 rounded-xl flex items-center justify-center shadow-lg relative">
              <AnimatedBitcoin size="lg" animation="float" showGlow />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-white">
                Welcome back, {user?.name?.split(' ')[0] || 'User'}!
              </h1>
              <p className="text-sm text-gray-300 flex items-center">
                <AnimatedBitcoin size="xs" animation="pulse" speed="fast" className="mr-2" />
                Your investment portfolio dashboard
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/user-profile-settings')}
              className="border-gray-600 text-gray-300 hover:text-white"
            >
              <Icon name="Settings" size={16} />
              <span className="hidden sm:inline ml-2">Profile</span>
            </Button>
            <Button
              variant="outline" 
              size="sm"
              onClick={handleLogout}
              className="border-red-600 text-red-400 hover:text-red-300 hover:border-red-500"
            >
              <Icon name="LogOut" size={16} />
              <span className="hidden sm:inline ml-2">Logout</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 relative z-10">
        {/* Wallet Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Balance</p>
                <p className="text-2xl font-bold text-white">${walletData.balance.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <Icon name="Wallet" size={24} className="text-blue-400" />
              </div>
            </div>
          </div>

          <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Pending Deposits</p>
                <p className="text-2xl font-bold text-yellow-400">${walletData.pendingDeposits.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                <Icon name="Clock" size={24} className="text-yellow-400" />
              </div>
            </div>
          </div>

          <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Earnings</p>
                <p className="text-2xl font-bold text-green-400">${walletData.totalEarnings.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                <Icon name="TrendingUp" size={24} className="text-green-400" />
              </div>
            </div>
          </div>

          <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Available</p>
                <p className="text-2xl font-bold text-white">${walletData.availableForWithdrawal.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <Icon name="ArrowUpRight" size={24} className="text-purple-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Button
            onClick={() => setShowDepositModal(true)}
            className="bg-green-600 hover:bg-green-700 h-16 text-left justify-start"
          >
            <Icon name="Plus" size={20} className="mr-3" />
            <div>
              <div className="font-semibold">Deposit Funds</div>
              <div className="text-xs opacity-80">Add money to wallet</div>
            </div>
          </Button>

          <Button
            onClick={() => setShowWithdrawModal(true)}
            className="bg-orange-600 hover:bg-orange-700 h-16 text-left justify-start"
          >
            <Icon name="ArrowUpRight" size={20} className="mr-3" />
            <div>
              <div className="font-semibold">Withdraw</div>
              <div className="text-xs opacity-80">Request payout</div>
            </div>
          </Button>

          <Button
            onClick={() => navigate('/investment-plans')}
            className="bg-blue-600 hover:bg-blue-700 h-16 text-left justify-start"
          >
            <Icon name="TrendingUp" size={20} className="mr-3" />
            <div>
              <div className="font-semibold">Invest Now</div>
              <div className="text-xs opacity-80">Choose a plan</div>
            </div>
          </Button>

          <Button
            onClick={() => navigate('/transaction-history')}
            variant="outline"
            className="border-gray-600 text-gray-300 h-16 text-left justify-start"
          >
            <Icon name="History" size={20} className="mr-3" />
            <div>
              <div className="font-semibold">History</div>
              <div className="text-xs opacity-80">View transactions</div>
            </div>
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Investment Plans */}
          <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white">Investment Plans</h3>
              <Link to="/user/plans" className="text-blue-400 hover:text-blue-300 text-sm">
                View All Plans
              </Link>
            </div>
            <div className="space-y-4">
              {investmentPlans.map((plan) => (
                <div key={plan.id} className="bg-gray-700/50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-white">{plan.name}</h4>
                    <span className={`text-sm font-medium ${getRiskColor(plan.risk)}`}>
                      {plan.risk} Risk
                    </span>
                  </div>
                  <p className="text-sm text-gray-400 mb-3">{plan.description}</p>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-xs text-gray-500">APY</p>
                      <p className="text-lg font-bold text-green-400">{plan.apy}%</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Duration</p>
                      <p className="text-sm text-white">{plan.duration}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-gray-400">
                      ${plan.minAmount.toLocaleString()} - ${plan.maxAmount.toLocaleString()}
                    </p>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Invest
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Transactions */}
          <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white">Recent Transactions</h3>
              <Link to="/user/transactions" className="text-blue-400 hover:text-blue-300 text-sm">
                View All
              </Link>
            </div>
            <div className="space-y-4">
              {recentTransactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      transaction.type === 'earning' || transaction.type === 'deposit' 
                        ? 'bg-green-500/20' : 'bg-red-500/20'
                    }`}>
                      <Icon 
                        name={getTransactionIcon(transaction.type)} 
                        size={16} 
                        className={getTransactionColor(transaction.type, transaction.amount)} 
                      />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">{transaction.description}</p>
                      <p className="text-xs text-gray-400">{transaction.date}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${getTransactionColor(transaction.type, transaction.amount)}`}>
                      {transaction.amount > 0 ? '+' : ''}${Math.abs(transaction.amount).toLocaleString()}
                    </p>
                    {getStatusBadge(transaction.status)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
