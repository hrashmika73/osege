import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminPendingDeposits = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [deposits, setDeposits] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('submissionDate');
  const [filterBy, setFilterBy] = useState('all');

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadPendingDeposits();
  }, [isAdminAuthenticated, navigate]);

  const loadPendingDeposits = () => {
    setLoading(true);
    // Simulate API call with mock data
    setTimeout(() => {
      const mockDeposits = [
        {
          id: 1,
          transactionId: 'DEP_001_2024',
          userId: 'user_001',
          username: 'john_investor',
          fullName: 'John Smith',
          email: 'john@example.com',
          amount: 5000,
          currency: 'USD',
          gateway: 'PayPal',
          gatewayRef: 'PP_REF_123456789',
          submissionDate: '2024-01-15T10:30:00Z',
          paymentMethod: 'paypal',
          status: 'pending_verification',
          priority: 'high',
          notes: 'Large deposit - requires verification',
          attachments: ['receipt.pdf', 'bank_statement.pdf'],
          ipAddress: '192.168.1.100',
          userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        {
          id: 2,
          transactionId: 'DEP_002_2024',
          userId: 'user_002',
          username: 'sarah_trader',
          fullName: 'Sarah Johnson',
          email: 'sarah@example.com',
          amount: 2500,
          currency: 'USD',
          gateway: 'Stripe',
          gatewayRef: 'ST_REF_987654321',
          submissionDate: '2024-01-15T14:20:00Z',
          paymentMethod: 'credit_card',
          status: 'pending_review',
          priority: 'medium',
          notes: 'Standard deposit review',
          attachments: ['transaction_receipt.png'],
          ipAddress: '192.168.1.101',
          userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        },
        {
          id: 3,
          transactionId: 'DEP_003_2024',
          userId: 'user_003',
          username: 'mike_crypto',
          fullName: 'Michael Brown',
          email: 'mike@example.com',
          amount: 10000,
          currency: 'USD',
          gateway: 'Bank Wire',
          gatewayRef: 'WIRE_REF_456789123',
          submissionDate: '2024-01-14T09:15:00Z',
          paymentMethod: 'bank_transfer',
          status: 'pending_verification',
          priority: 'high',
          notes: 'Wire transfer - awaiting bank confirmation',
          attachments: ['wire_receipt.pdf', 'bank_confirmation.pdf'],
          ipAddress: '192.168.1.102',
          userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        {
          id: 4,
          transactionId: 'DEP_004_2024',
          userId: 'user_004',
          username: 'alice_fund',
          fullName: 'Alice Williams',
          email: 'alice@example.com',
          amount: 750,
          currency: 'USD',
          gateway: 'Coinbase',
          gatewayRef: 'CB_REF_789123456',
          submissionDate: '2024-01-13T16:45:00Z',
          paymentMethod: 'cryptocurrency',
          status: 'pending_confirmation',
          priority: 'low',
          notes: 'Crypto deposit - waiting for network confirmations',
          attachments: ['tx_hash.txt'],
          ipAddress: '192.168.1.103',
          userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15'
        }
      ];
      setDeposits(mockDeposits);
      setLoading(false);
    }, 1000);
  };

  const handleDepositAction = (depositId, action) => {
    const deposit = deposits.find(d => d.id === depositId);

    switch (action) {
      case 'approve':
        if (window.confirm(`Are you sure you want to approve deposit ${deposit.transactionId} for ${deposit.fullName}?`)) {
          // Remove from pending deposits
          const updatedDeposits = deposits.filter(d => d.id !== depositId);
          setDeposits(updatedDeposits);
          localStorage.setItem('admin_pending_deposits', JSON.stringify(updatedDeposits));

          // Add to accepted deposits
          const acceptedDeposits = JSON.parse(localStorage.getItem('admin_accepted_deposits') || '[]');
          const approvedDeposit = {
            ...deposit,
            status: 'approved',
            approvedDate: new Date().toISOString(),
            approvedBy: 'admin_001'
          };
          acceptedDeposits.push(approvedDeposit);
          localStorage.setItem('admin_accepted_deposits', JSON.stringify(acceptedDeposits));

          // Update user balance (simulate)
          const userData = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
          const updatedUserData = userData.map(u =>
            u.userId === deposit.userId
              ? { ...u, balance: (u.balance || 0) + deposit.amount }
              : u
          );
          localStorage.setItem('admin_users_data', JSON.stringify(updatedUserData));

          alert(`✅ Deposit approved: ${deposit.transactionId}\\nAmount: $${deposit.amount} added to user balance`);
          loadPendingDeposits();
        }
        break;
      case 'reject':
        const reason = prompt(`Enter rejection reason for deposit ${deposit.transactionId}:`);
        if (reason) {
          // Remove from pending deposits
          const updatedDeposits = deposits.filter(d => d.id !== depositId);
          setDeposits(updatedDeposits);
          localStorage.setItem('admin_pending_deposits', JSON.stringify(updatedDeposits));

          // Add to rejected deposits
          const rejectedDeposits = JSON.parse(localStorage.getItem('admin_rejected_deposits') || '[]');
          const rejectedDeposit = {
            ...deposit,
            status: 'rejected',
            rejectedDate: new Date().toISOString(),
            rejectedBy: 'admin_001',
            rejectionReason: reason
          };
          rejectedDeposits.push(rejectedDeposit);
          localStorage.setItem('admin_rejected_deposits', JSON.stringify(rejectedDeposits));

          alert(`❌ Deposit rejected: ${deposit.transactionId}\\nReason: ${reason}`);
          loadPendingDeposits();
        }
        break;
      case 'request_info':
        const infoNeeded = prompt(`What additional information is needed for ${deposit.transactionId}?`);
        if (infoNeeded) {
          // Update deposit with info request
          const updatedDeposits = deposits.map(d =>
            d.id === depositId
              ? {
                  ...d,
                  status: 'info_required',
                  notes: `${d.notes} - Info requested: ${infoNeeded}`,
                  lastUpdated: new Date().toISOString()
                }
              : d
          );
          setDeposits(updatedDeposits);
          localStorage.setItem('admin_pending_deposits', JSON.stringify(updatedDeposits));

          alert(`📋 Information requested from ${deposit.fullName}:\\n${infoNeeded}`);
        }
        break;
      case 'view_details':
        // Navigate to deposit details page
        navigate(`/admin-deposit-details/${depositId}`);
        break;
      default:
        break;
    }
  };

  const filteredDeposits = deposits.filter(deposit => {
    const matchesSearch = deposit.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         deposit.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         deposit.transactionId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         deposit.gatewayRef.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filterBy === 'all') return matchesSearch;
    if (filterBy === 'high_priority') return matchesSearch && deposit.priority === 'high';
    if (filterBy === 'large_amounts') return matchesSearch && deposit.amount >= 5000;
    if (filterBy === 'crypto') return matchesSearch && deposit.paymentMethod === 'cryptocurrency';
    if (filterBy === 'bank_transfer') return matchesSearch && deposit.paymentMethod === 'bank_transfer';
    
    return matchesSearch;
  });

  const sortedDeposits = [...filteredDeposits].sort((a, b) => {
    switch (sortBy) {
      case 'submissionDate':
        return new Date(a.submissionDate) - new Date(b.submissionDate);
      case 'amount':
        return b.amount - a.amount;
      case 'priority':
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      case 'name':
        return a.fullName.localeCompare(b.fullName);
      default:
        return 0;
    }
  });

  const getPriorityBadge = (priority) => {
    const priorityClasses = {
      high: 'bg-red-100 text-red-800 border-red-200',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      low: 'bg-green-100 text-green-800 border-green-200'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${priorityClasses[priority] || priorityClasses.medium}`}>
        {priority.charAt(0).toUpperCase() + priority.slice(1)}
      </span>
    );
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      pending_verification: 'bg-yellow-100 text-yellow-800',
      pending_review: 'bg-blue-100 text-blue-800',
      pending_confirmation: 'bg-purple-100 text-purple-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusClasses[status] || statusClasses.pending_review}`}>
        {status.replace('_', ' ').charAt(0).toUpperCase() + status.replace('_', ' ').slice(1)}
      </span>
    );
  };

  const getPaymentMethodBadge = (method) => {
    const methodClasses = {
      paypal: 'bg-blue-100 text-blue-800',
      credit_card: 'bg-purple-100 text-purple-800',
      bank_transfer: 'bg-green-100 text-green-800',
      cryptocurrency: 'bg-orange-100 text-orange-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${methodClasses[method] || methodClasses.credit_card}`}>
        {method.replace('_', ' ').toUpperCase()}
      </span>
    );
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getWaitingTime = (submissionDate) => {
    const now = new Date();
    const submission = new Date(submissionDate);
    const diffTime = Math.abs(now - submission);
    const diffHours = Math.ceil(diffTime / (1000 * 60 * 60));
    
    if (diffHours < 24) return `${diffHours} hours`;
    const diffDays = Math.ceil(diffHours / 24);
    return `${diffDays} days`;
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Pending Deposits"
        breadcrumb={[
          { label: "Gateway Management", link: "/admin-payment-gateway" },
          { label: "Pending Deposits" }
        ]}
        actions={[
          {
            label: "Export Pending",
            icon: "Download",
            variant: "outline",
            onClick: () => {
              const csvData = deposits.map(deposit => ({
                'Transaction ID': deposit.transactionId,
                User: deposit.fullName,
                Username: deposit.username,
                Amount: deposit.amount,
                Currency: deposit.currency,
                Gateway: deposit.gateway,
                'Payment Method': deposit.paymentMethod,
                Status: deposit.status,
                Priority: deposit.priority,
                'Submission Date': formatDateTime(deposit.submissionDate),
                Notes: deposit.notes
              }));
              const csv = [
                Object.keys(csvData[0]).join(','),
                ...csvData.map(row => Object.values(row).map(val => `"${val}"`).join(','))
              ].join('\n');
              const blob = new Blob([csv], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `pending_deposits_${new Date().toISOString().split('T')[0]}.csv`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }
          },
          {
            label: "Refresh",
            icon: "RefreshCw",
            variant: "outline",
            onClick: loadPendingDeposits
          }
        ]}
      />

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Deposits</p>
                <p className="text-2xl font-bold text-foreground">{deposits.length}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Icon name="Clock" size={24} className="text-yellow-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Value</p>
                <p className="text-2xl font-bold text-foreground">
                  {formatCurrency(deposits.reduce((sum, d) => sum + d.amount, 0))}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Icon name="DollarSign" size={24} className="text-green-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">High Priority</p>
                <p className="text-2xl font-bold text-foreground">
                  {deposits.filter(d => d.priority === 'high').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Icon name="AlertTriangle" size={24} className="text-red-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg. Wait Time</p>
                <p className="text-2xl font-bold text-foreground">
                  {Math.round(deposits.reduce((acc, d) => {
                    const hours = Math.abs(new Date() - new Date(d.submissionDate)) / (1000 * 60 * 60);
                    return acc + hours;
                  }, 0) / deposits.length || 0)} hrs
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Icon name="Timer" size={24} className="text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-card border rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search deposits..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={filterBy}
                onChange={(e) => setFilterBy(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="all">All Deposits</option>
                <option value="high_priority">High Priority</option>
                <option value="large_amounts">Large Amounts</option>
                <option value="crypto">Cryptocurrency</option>
                <option value="bank_transfer">Bank Transfer</option>
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="submissionDate">Submission Date</option>
                <option value="amount">Amount</option>
                <option value="priority">Priority</option>
                <option value="name">Name</option>
              </select>
            </div>
          </div>
        </div>

        {/* Deposits Table */}
        <div className="bg-card border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Transaction
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Payment Method
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Priority
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Waiting Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {loading ? (
                  <tr>
                    <td colSpan="8" className="px-6 py-8 text-center">
                      <div className="flex items-center justify-center">
                        <Icon name="Loader" size={20} className="animate-spin mr-2" />
                        Loading pending deposits...
                      </div>
                    </td>
                  </tr>
                ) : sortedDeposits.length === 0 ? (
                  <tr>
                    <td colSpan="8" className="px-6 py-8 text-center text-muted-foreground">
                      No pending deposits found
                    </td>
                  </tr>
                ) : (
                  sortedDeposits.map((deposit) => (
                    <tr key={deposit.id} className="hover:bg-muted/30">
                      <td className="px-6 py-4">
                        <div>
                          <div className="text-sm font-medium text-foreground">{deposit.transactionId}</div>
                          <div className="text-xs text-muted-foreground">{deposit.gateway}</div>
                          <div className="text-xs text-muted-foreground">{deposit.gatewayRef}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                            <span className="text-xs font-medium text-primary">
                              {deposit.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-foreground">{deposit.fullName}</div>
                            <div className="text-xs text-muted-foreground">@{deposit.username}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-foreground">
                          {formatCurrency(deposit.amount)}
                        </div>
                        <div className="text-xs text-muted-foreground">{deposit.currency}</div>
                      </td>
                      <td className="px-6 py-4">
                        {getPaymentMethodBadge(deposit.paymentMethod)}
                      </td>
                      <td className="px-6 py-4">
                        {getStatusBadge(deposit.status)}
                      </td>
                      <td className="px-6 py-4">
                        {getPriorityBadge(deposit.priority)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">{getWaitingTime(deposit.submissionDate)}</div>
                        <div className="text-xs text-muted-foreground">
                          {formatDateTime(deposit.submissionDate)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDepositAction(deposit.id, 'view_details')}
                            title="View Details"
                          >
                            <Icon name="Eye" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDepositAction(deposit.id, 'approve')}
                            title="Approve Deposit"
                            className="text-green-600 border-green-200 hover:bg-green-50"
                          >
                            <Icon name="Check" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDepositAction(deposit.id, 'reject')}
                            title="Reject Deposit"
                            className="text-red-600 border-red-200 hover:bg-red-50"
                          >
                            <Icon name="X" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDepositAction(deposit.id, 'request_info')}
                            title="Request Information"
                            className="text-blue-600 border-blue-200 hover:bg-blue-50"
                          >
                            <Icon name="MessageCircle" size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPendingDeposits;
