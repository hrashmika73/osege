import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminEditUser = () => {
  const navigate = useNavigate();
  const { userId } = useParams();
  const { isAdminAuthenticated } = useAdminAuth();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadUser();
  }, [isAdminAuthenticated, navigate, userId]);

  const loadUser = () => {
    const userData = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
    const foundUser = userData.find(u => u.id === parseInt(userId));
    
    if (foundUser) {
      setUser(foundUser);
    } else {
      alert('User not found');
      navigate('/admin-active-users');
    }
  };

  const handleSave = () => {
    setSaving(true);
    
    // Update user data
    const userData = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
    const updatedUsers = userData.map(u => 
      u.id === user.id ? user : u
    );
    
    localStorage.setItem('admin_users_data', JSON.stringify(updatedUsers));
    
    setTimeout(() => {
      setSaving(false);
      alert('User updated successfully!');
      navigate(`/admin-user-details/${userId}`);
    }, 1000);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <AdminNavigation title="User Not Found" />
        <div className="p-6 text-center">
          <p className="text-muted-foreground mb-4">User not found</p>
          <Button onClick={() => navigate('/admin-active-users')}>
            Back to Users
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title={`Edit User - ${user.fullName}`}
        breadcrumb={[
          { label: "User Management", link: "/admin-active-users" },
          { label: "User Details", link: `/admin-user-details/${userId}` },
          { label: "Edit User" }
        ]}
        actions={[
          {
            label: "Cancel",
            icon: "X",
            variant: "outline",
            onClick: () => navigate(`/admin-user-details/${userId}`)
          },
          {
            label: saving ? "Saving..." : "Save Changes",
            icon: saving ? "Loader" : "Save",
            variant: "default",
            onClick: handleSave,
            disabled: saving
          }
        ]}
      />

      <div className="p-6">
        <div className="max-w-2xl mx-auto">
          <div className="bg-card border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">User Information</h3>
            
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Full Name</label>
                  <input
                    type="text"
                    value={user.fullName}
                    onChange={(e) => setUser({...user, fullName: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Username</label>
                  <input
                    type="text"
                    value={user.username}
                    onChange={(e) => setUser({...user, username: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Email</label>
                <input
                  type="email"
                  value={user.email}
                  onChange={(e) => setUser({...user, email: e.target.value})}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Status</label>
                  <select
                    value={user.status}
                    onChange={(e) => setUser({...user, status: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">KYC Status</label>
                  <select
                    value={user.kycStatus}
                    onChange={(e) => setUser({...user, kycStatus: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="pending_documents">Pending Documents</option>
                    <option value="pending">Pending Review</option>
                    <option value="verified">Verified</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Location</label>
                  <input
                    type="text"
                    value={user.location}
                    onChange={(e) => setUser({...user, location: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Risk Level</label>
                  <select
                    value={user.riskLevel}
                    onChange={(e) => setUser({...user, riskLevel: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Balance ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={user.balance || 0}
                    onChange={(e) => setUser({...user, balance: parseFloat(e.target.value) || 0})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Total Investments ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={user.totalInvestments || 0}
                    onChange={(e) => setUser({...user, totalInvestments: parseFloat(e.target.value) || 0})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminEditUser;
