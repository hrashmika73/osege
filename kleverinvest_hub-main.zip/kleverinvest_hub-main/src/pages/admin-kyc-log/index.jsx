import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminKYCLog = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBy, setFilterBy] = useState('all');
  const [dateRange, setDateRange] = useState('7days');

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadKYCLogs();
  }, [isAdminAuthenticated, navigate, dateRange]);

  const loadKYCLogs = () => {
    setLoading(true);
    // Simulate API call with mock data
    setTimeout(() => {
      const mockLogs = [
        {
          id: 1,
          userId: 'user_001',
          username: 'john_investor',
          fullName: 'John Smith',
          action: 'approved',
          actionDate: '2024-01-15T10:30:00Z',
          actionBy: 'admin_001',
          adminName: 'Admin Johnson',
          previousStatus: 'pending',
          newStatus: 'verified',
          documentType: 'passport',
          notes: 'All documents verified successfully',
          processingTime: '2 days',
          ipAddress: '192.168.1.100',
          userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        {
          id: 2,
          userId: 'user_002',
          username: 'sarah_trader',
          fullName: 'Sarah Johnson',
          action: 'rejected',
          actionDate: '2024-01-14T14:20:00Z',
          actionBy: 'admin_002',
          adminName: 'Admin Smith',
          previousStatus: 'pending',
          newStatus: 'rejected',
          documentType: 'drivers_license',
          notes: 'Poor image quality, document not readable',
          processingTime: '1 day',
          ipAddress: '192.168.1.101',
          userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        },
        {
          id: 3,
          userId: 'user_003',
          username: 'mike_crypto',
          fullName: 'Michael Brown',
          action: 'requested_additional',
          actionDate: '2024-01-13T09:15:00Z',
          actionBy: 'admin_001',
          adminName: 'Admin Johnson',
          previousStatus: 'under_review',
          newStatus: 'additional_required',
          documentType: 'national_id',
          notes: 'Requested utility bill and bank statement',
          processingTime: '3 days',
          ipAddress: '192.168.1.102',
          userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        {
          id: 4,
          userId: 'user_004',
          username: 'alice_fund',
          fullName: 'Alice Williams',
          action: 'approved',
          actionDate: '2024-01-12T16:45:00Z',
          actionBy: 'admin_003',
          adminName: 'Admin Wilson',
          previousStatus: 'pending',
          newStatus: 'verified',
          documentType: 'passport',
          notes: 'High-value investor, expedited verification',
          processingTime: '1 day',
          ipAddress: '192.168.1.103',
          userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15'
        },
        {
          id: 5,
          userId: 'user_005',
          username: 'bob_invest',
          fullName: 'Robert Davis',
          action: 'submitted',
          actionDate: '2024-01-11T11:20:00Z',
          actionBy: 'system',
          adminName: 'System',
          previousStatus: 'not_submitted',
          newStatus: 'pending',
          documentType: 'drivers_license',
          notes: 'Initial KYC submission received',
          processingTime: 'N/A',
          ipAddress: '192.168.1.104',
          userAgent: 'Mozilla/5.0 (Linux; Android 14; SM-G981B) AppleWebKit/537.36'
        }
      ];
      setLogs(mockLogs);
      setLoading(false);
    }, 1000);
  };

  const getFilteredLogs = () => {
    let filtered = logs.filter(log => {
      const matchesSearch = log.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           log.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           log.adminName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           log.notes.toLowerCase().includes(searchTerm.toLowerCase());
      
      if (filterBy === 'all') return matchesSearch;
      return matchesSearch && log.action === filterBy;
    });

    // Apply date range filter
    if (dateRange !== 'all') {
      const now = new Date();
      const days = parseInt(dateRange.replace('days', ''));
      const cutoffDate = new Date(now.setDate(now.getDate() - days));
      
      filtered = filtered.filter(log => new Date(log.actionDate) >= cutoffDate);
    }

    return filtered.sort((a, b) => new Date(b.actionDate) - new Date(a.actionDate));
  };

  const getActionBadge = (action) => {
    const actionClasses = {
      approved: 'bg-green-100 text-green-800 border-green-200',
      rejected: 'bg-red-100 text-red-800 border-red-200',
      submitted: 'bg-blue-100 text-blue-800 border-blue-200',
      requested_additional: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      updated: 'bg-purple-100 text-purple-800 border-purple-200'
    };

    const actionLabels = {
      approved: 'Approved',
      rejected: 'Rejected',
      submitted: 'Submitted',
      requested_additional: 'More Info',
      updated: 'Updated'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${actionClasses[action] || actionClasses.updated}`}>
        {actionLabels[action] || action}
      </span>
    );
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      verified: 'bg-green-100 text-green-800',
      pending: 'bg-blue-100 text-blue-800',
      rejected: 'bg-red-100 text-red-800',
      additional_required: 'bg-yellow-100 text-yellow-800',
      under_review: 'bg-purple-100 text-purple-800',
      not_submitted: 'bg-gray-100 text-gray-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusClasses[status] || statusClasses.pending}`}>
        {status.replace('_', ' ').charAt(0).toUpperCase() + status.replace('_', ' ').slice(1)}
      </span>
    );
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleExportLogs = () => {
    const filteredLogs = getFilteredLogs();
    const csvData = filteredLogs.map(log => ({
      Date: formatDateTime(log.actionDate),
      User: log.fullName,
      Username: log.username,
      Action: log.action,
      'Previous Status': log.previousStatus,
      'New Status': log.newStatus,
      'Document Type': log.documentType,
      'Processed By': log.adminName,
      'Processing Time': log.processingTime,
      Notes: log.notes
    }));
    
    const csv = [
      Object.keys(csvData[0]).join(','),
      ...csvData.map(row => Object.values(row).map(val => `"${val}"`).join(','))
    ].join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kyc_log_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const filteredLogs = getFilteredLogs();

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="KYC Activity Log"
        breadcrumb={[
          { label: "User Management", link: "/admin-user-management" },
          { label: "KYC Log" }
        ]}
        actions={[
          {
            label: "Export Log",
            icon: "Download",
            variant: "outline",
            onClick: handleExportLogs
          },
          {
            label: "Refresh",
            icon: "RefreshCw",
            variant: "outline",
            onClick: loadKYCLogs
          }
        ]}
      />

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-6">
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Logs</p>
                <p className="text-2xl font-bold text-foreground">{filteredLogs.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Icon name="FileText" size={24} className="text-blue-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Approved</p>
                <p className="text-2xl font-bold text-foreground">
                  {filteredLogs.filter(l => l.action === 'approved').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Icon name="Check" size={24} className="text-green-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Rejected</p>
                <p className="text-2xl font-bold text-foreground">
                  {filteredLogs.filter(l => l.action === 'rejected').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Icon name="X" size={24} className="text-red-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Submitted</p>
                <p className="text-2xl font-bold text-foreground">
                  {filteredLogs.filter(l => l.action === 'submitted').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Icon name="Upload" size={24} className="text-blue-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">More Info</p>
                <p className="text-2xl font-bold text-foreground">
                  {filteredLogs.filter(l => l.action === 'requested_additional').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Icon name="AlertCircle" size={24} className="text-yellow-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-card border rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search logs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={filterBy}
                onChange={(e) => setFilterBy(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="all">All Actions</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="submitted">Submitted</option>
                <option value="requested_additional">More Info</option>
              </select>
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="7days">Last 7 days</option>
                <option value="30days">Last 30 days</option>
                <option value="90days">Last 90 days</option>
                <option value="all">All time</option>
              </select>
            </div>
          </div>
        </div>

        {/* Activity Log Table */}
        <div className="bg-card border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Date & Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Action
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Status Change
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Document
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Processed By
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Notes
                  </th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {loading ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center">
                      <div className="flex items-center justify-center">
                        <Icon name="Loader" size={20} className="animate-spin mr-2" />
                        Loading KYC logs...
                      </div>
                    </td>
                  </tr>
                ) : filteredLogs.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center text-muted-foreground">
                      No KYC activity logs found
                    </td>
                  </tr>
                ) : (
                  filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-muted/30">
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-foreground">
                          {formatDateTime(log.actionDate)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                            <span className="text-xs font-medium text-primary">
                              {log.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-foreground">{log.fullName}</div>
                            <div className="text-xs text-muted-foreground">@{log.username}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {getActionBadge(log.action)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          {getStatusBadge(log.previousStatus)}
                          <Icon name="ArrowRight" size={14} className="text-muted-foreground" />
                          {getStatusBadge(log.newStatus)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">
                          {log.documentType.replace('_', ' ').toUpperCase()}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-6 h-6 bg-muted rounded-full flex items-center justify-center mr-2">
                            <Icon name={log.actionBy === 'system' ? 'Bot' : 'User'} size={12} />
                          </div>
                          <div>
                            <div className="text-sm text-foreground">{log.adminName}</div>
                            {log.processingTime !== 'N/A' && (
                              <div className="text-xs text-muted-foreground">{log.processingTime}</div>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground max-w-xs truncate" title={log.notes}>
                          {log.notes}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminKYCLog;
