import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../components/AppIcon';
import Button from '../components/ui/Button';

const NotFoundPage = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Check if the current path might be an admin-related route
  const isAdminRoute = location.pathname.toLowerCase().includes('admin');
  
  const suggestions = isAdminRoute ? [
    { path: '/admin-secure-login', label: 'Admin Secure Login' },
    { path: '/admin-dashboard', label: 'Admin Dashboard' }
  ] : [
    { path: '/', label: 'Home Page' },
    { path: '/home-landing-page', label: 'Landing Page' },
    { path: '/user-login-portal', label: 'User Login' },
    { path: '/investment-plans', label: 'Investment Plans' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card/30 to-background flex items-center justify-center p-4">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-orange-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative z-10 text-center max-w-2xl mx-auto">
        {/* 404 Icon */}
        <div className="mb-8">
          <div className="w-32 h-32 mx-auto gradient-gold rounded-full flex items-center justify-center mb-6">
            <Icon name="AlertTriangle" size={64} color="black" />
          </div>
          <h1 className="text-6xl font-bold text-foreground mb-4">404</h1>
          <h2 className="text-2xl font-semibold mb-2">Page Not Found</h2>
          <p className="text-muted-foreground mb-8">
            The page you're looking for doesn't exist. {isAdminRoute && "It seems you're looking for an admin page."}
          </p>
        </div>

        {/* Current Path Info */}
        <div className="glass-effect rounded-xl p-6 border border-orange-500/20 mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Icon name="Link" size={16} className="text-orange-400" />
            <span className="text-sm text-muted-foreground">Requested URL:</span>
          </div>
          <code className="bg-muted/30 px-3 py-1 rounded text-sm">
            {window.location.origin}{location.pathname}
          </code>
        </div>

        {/* Suggestions */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">
            {isAdminRoute ? 'Admin Pages You Might Be Looking For:' : 'Suggested Pages:'}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {suggestions.map((suggestion, index) => (
              <Button
                key={index}
                variant="outline"
                onClick={() => navigate(suggestion.path)}
                className="justify-start"
              >
                <Icon name="ExternalLink" size={16} className="mr-2" />
                {suggestion.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={() => navigate(-1)}
              variant="outline"
              size="lg"
            >
              <Icon name="ArrowLeft" size={16} className="mr-2" />
              Go Back
            </Button>
            <Button
              onClick={() => navigate('/')}
              className="gradient-gold text-black font-semibold"
              size="lg"
            >
              <Icon name="Home" size={16} className="mr-2" />
              Go Home
            </Button>
          </div>

          {/* Special Admin Access */}
          {isAdminRoute && (
            <div className="border-t border-border pt-6 mt-6">
              <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-4">
                <div className="flex items-center justify-center space-x-2 mb-3">
                  <Icon name="Shield" size={16} className="text-orange-400" />
                  <span className="text-sm font-medium">Admin Access</span>
                </div>
                <p className="text-xs text-muted-foreground mb-4">
                  If you're an administrator trying to access the admin panel, use one of these links:
                </p>
                <div className="space-y-2">
                  <Button
                    onClick={() => navigate('/admin-secure-login')}
                    className="w-full gradient-gold text-black font-semibold"
                    size="sm"
                  >
                    <Icon name="Lock" size={14} className="mr-2" />
                    Admin Login
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Help Section */}
        <div className="mt-8 text-center">
          <p className="text-xs text-muted-foreground">
            Still having trouble? Contact our support team or check our help documentation.
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;
