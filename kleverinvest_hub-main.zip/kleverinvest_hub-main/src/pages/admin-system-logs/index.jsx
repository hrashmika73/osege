import React, { useState, useEffect } from 'react';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import AdminNavigation from '../../components/ui/AdminNavigation';

const AdminSystemLogs = () => {
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [logs, setLogs] = useState([]);

  const logTypes = [
    { id: 'all', label: 'All Logs', count: 0, color: 'slate' },
    { id: 'error', label: 'Errors', count: 0, color: 'red' },
    { id: 'warning', label: 'Warnings', count: 0, color: 'yellow' },
    { id: 'info', label: 'Info', count: 0, color: 'blue' },
    { id: 'security', label: 'Security', count: 0, color: 'purple' },
    { id: 'payment', label: 'Payment', count: 0, color: 'green' }
  ];

  // Load logs from localStorage or generate initial logs
  useEffect(() => {
    const savedLogs = localStorage.getItem('system_logs');
    if (savedLogs) {
      setLogs(JSON.parse(savedLogs));
    } else {
      const initialLogs = generateInitialLogs();
      setLogs(initialLogs);
      localStorage.setItem('system_logs', JSON.stringify(initialLogs));
    }
  }, []);

  // Auto-refresh functionality
  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(() => {
        handleRefreshLogs(false); // Silent refresh
      }, 10000); // Refresh every 10 seconds

      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const generateInitialLogs = () => {
    const baseTime = Date.now();
    return [
      {
        id: 1,
        type: 'error',
        level: 'ERROR',
        message: 'Database connection timeout',
        details: 'Connection to primary database failed after 30 seconds',
        timestamp: new Date(baseTime - 300000).toISOString(),
        source: 'database.js:45',
        user: 'system',
        ip: '127.0.0.1'
      },
      {
        id: 2,
        type: 'security',
        level: 'WARNING',
        message: 'Multiple failed login attempts',
        details: 'IP 192.168.1.100 attempted login 5 times with invalid credentials',
        timestamp: new Date(baseTime - 600000).toISOString(),
        source: 'auth.js:128',
        user: 'user@example.com',
        ip: '192.168.1.100'
      },
      {
        id: 3,
        type: 'payment',
        level: 'INFO',
        message: 'Payment processed successfully',
        details: 'Stripe payment $5,000 processed for user ID 1234',
        timestamp: new Date(baseTime - 900000).toISOString(),
        source: 'payment.js:67',
        user: 'john.doe@example.com',
        ip: '203.0.113.45'
      },
      {
        id: 4,
        type: 'warning',
        level: 'WARNING',
        message: 'High CPU usage detected',
        details: 'Server CPU usage exceeded 85% for 5 consecutive minutes',
        timestamp: new Date(baseTime - 1200000).toISOString(),
        source: 'monitor.js:23',
        user: 'system',
        ip: '127.0.0.1'
      },
      {
        id: 5,
        type: 'info',
        level: 'INFO',
        message: 'User registration completed',
        details: 'New user account created and email verification sent',
        timestamp: new Date(baseTime - 1500000).toISOString(),
        source: 'user.js:156',
        user: 'sarah.wilson@example.com',
        ip: '198.51.100.23'
      }
    ];
  };

  const addRandomLog = () => {
    const logTypes = ['error', 'warning', 'info', 'security', 'payment'];
    const messages = {
      error: ['Database connection failed', 'Payment gateway error', 'Server error 500', 'Authentication failed'],
      warning: ['High memory usage', 'Slow query detected', 'API rate limit approaching', 'Disk space low'],
      info: ['User logged in', 'File uploaded successfully', 'Cache cleared', 'Backup completed'],
      security: ['Suspicious activity detected', 'Password changed', 'New device login', 'Admin access granted'],
      payment: ['Payment received', 'Withdrawal processed', 'Refund issued', 'Payment method updated']
    };

    const type = logTypes[Math.floor(Math.random() * logTypes.length)];
    const message = messages[type][Math.floor(Math.random() * messages[type].length)];

    const newLog = {
      id: Date.now(),
      type: type,
      level: type === 'error' ? 'ERROR' : type === 'warning' ? 'WARNING' : 'INFO',
      message: message,
      details: `Generated log entry for ${message.toLowerCase()}`,
      timestamp: new Date().toISOString(),
      source: `${type}.js:${Math.floor(Math.random() * 200)}`,
      user: type === 'system' ? 'system' : `user${Math.floor(Math.random() * 1000)}@example.com`,
      ip: `192.168.1.${Math.floor(Math.random() * 255)}`
    };

    return newLog;
  };

  const handleRefreshLogs = async (showFeedback = true) => {
    if (showFeedback) setIsRefreshing(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Add a few new random logs
      const newLogs = [];
      for (let i = 0; i < Math.floor(Math.random() * 3) + 1; i++) {
        newLogs.push(addRandomLog());
      }

      const updatedLogs = [...newLogs, ...logs].slice(0, 100); // Keep only latest 100 logs
      setLogs(updatedLogs);
      localStorage.setItem('system_logs', JSON.stringify(updatedLogs));

      if (showFeedback) {
        alert(`✅ System Logs Refreshed!\n\nFound ${newLogs.length} new log entries\nTotal logs: ${updatedLogs.length}\nAuto-refresh: ${autoRefresh ? 'ENABLED' : 'DISABLED'}`);
      }
    } catch (error) {
      if (showFeedback) {
        alert('❌ Failed to refresh logs. Please try again.');
      }
    } finally {
      if (showFeedback) setIsRefreshing(false);
    }
  };

  const handleExportLogs = () => {
    try {
      const exportData = {
        timestamp: new Date().toISOString(),
        totalLogs: filteredLogs.length,
        filter: activeFilter,
        searchTerm: searchTerm,
        logs: filteredLogs.map(log => ({
          ...log,
          timestamp: new Date(log.timestamp).toLocaleString()
        }))
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `system_logs_${activeFilter}_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      alert(`✅ System Logs Exported!\n\nFilter: ${activeFilter.toUpperCase()}\nTotal exported: ${filteredLogs.length} logs\nFile downloaded successfully.`);
    } catch (error) {
      alert('❌ Export failed. Please try again.');
    }
  };

  const handleClearLogs = () => {
    if (!confirm(`Clear All System Logs?\n\nThis will permanently delete:\n• ${logs.length} log entries\n• All log history\n• Cannot be undone\n\nProceed?`)) {
      return;
    }

    setLogs([]);
    localStorage.removeItem('system_logs');
    alert('✅ All system logs cleared successfully!');
  };

  const handleArchiveLogs = () => {
    if (!confirm('Archive old logs?\n\nThis will:\n• Export logs older than 7 days\n• Remove them from active view\n• Keep recent logs visible\n\nProceed?')) {
      return;
    }

    const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
    const oldLogs = logs.filter(log => new Date(log.timestamp).getTime() < sevenDaysAgo);
    const recentLogs = logs.filter(log => new Date(log.timestamp).getTime() >= sevenDaysAgo);

    if (oldLogs.length === 0) {
      alert('No logs older than 7 days found.');
      return;
    }

    // Export old logs
    const archiveData = {
      timestamp: new Date().toISOString(),
      archived: true,
      logs: oldLogs
    };

    const blob = new Blob([JSON.stringify(archiveData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `archived_logs_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    // Update logs
    setLogs(recentLogs);
    localStorage.setItem('system_logs', JSON.stringify(recentLogs));

    alert(`✅ Logs Archived!\n\nArchived: ${oldLogs.length} old logs\nRemaining: ${recentLogs.length} recent logs\nArchive file downloaded.`);
  };

  const getLogIcon = (type) => {
    switch (type) {
      case 'error': return 'XCircle';
      case 'warning': return 'AlertTriangle';
      case 'info': return 'Info';
      case 'security': return 'Shield';
      case 'payment': return 'DollarSign';
      default: return 'FileText';
    }
  };

  const getLogColor = (type) => {
    switch (type) {
      case 'error': return 'text-destructive bg-destructive/10 border-destructive/20';
      case 'warning': return 'text-warning bg-warning/10 border-warning/20';
      case 'info': return 'text-primary bg-primary/10 border-primary/20';
      case 'security': return 'text-accent bg-accent/10 border-accent/20';
      case 'payment': return 'text-success bg-success/10 border-success/20';
      default: return 'text-muted-foreground bg-muted border-border';
    }
  };

  const filteredLogs = logs.filter(log => {
    const matchesFilter = activeFilter === 'all' || log.type === activeFilter;
    const matchesSearch = log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.user.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  // Update counts
  const updatedLogTypes = logTypes.map(type => ({
    ...type,
    count: type.id === 'all' ? logs.length : logs.filter(log => log.type === type.id).length
  }));

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="System Logs"
        breadcrumb={[
          { label: "Admin", link: null },
          { label: "System Logs", link: null }
        ]}
        actions={[
          {
            label: autoRefresh ? "Disable Auto-Refresh" : "Enable Auto-Refresh",
            icon: autoRefresh ? "PauseCircle" : "PlayCircle",
            variant: "outline",
            onClick: () => setAutoRefresh(!autoRefresh)
          },
          {
            label: "Refresh",
            icon: "RefreshCw",
            variant: "outline",
            onClick: () => handleRefreshLogs(),
            loading: isRefreshing
          },
          {
            label: "Export",
            icon: "Download",
            variant: "default",
            onClick: handleExportLogs
          }
        ]}
      />

      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6">
            <p className="text-muted-foreground">
              Monitor system activity and troubleshoot issues
              {autoRefresh && (
                <span className="ml-2 text-success">
                  • Auto-refresh enabled (10s interval)
                </span>
              )}
            </p>
          </div>

          {/* Log Type Filters */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
            {updatedLogTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setActiveFilter(type.id)}
                className={`p-4 rounded-lg border text-left transition-all hover:scale-105 ${
                  activeFilter === type.id
                    ? `border-${type.color}-500 bg-${type.color}-50 shadow-lg`
                    : 'border-border hover:border-muted-foreground'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <Icon name={getLogIcon(type.id)} size={20} />
                  <span className="text-2xl font-bold">{type.count}</span>
                </div>
                <div className="text-sm font-medium">{type.label}</div>
              </button>
            ))}
          </div>

          {/* Search and Controls */}
          <div className="bg-card border rounded-lg p-6 mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Search logs by message, details, or user..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-4 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-background"
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={handleArchiveLogs}>
                  <Icon name="Archive" size={16} className="mr-2" />
                  Archive Old
                </Button>
                <Button variant="destructive" onClick={handleClearLogs}>
                  <Icon name="Trash2" size={16} className="mr-2" />
                  Clear All
                </Button>
              </div>
            </div>
          </div>

          {/* Logs List */}
          <div className="bg-card border rounded-lg overflow-hidden">
            <div className="p-6 border-b border-border">
              <h3 className="text-lg font-semibold text-foreground flex items-center">
                <Icon name="FileText" size={20} className="mr-2" />
                System Logs ({filteredLogs.length})
              </h3>
            </div>

            <div className="divide-y divide-border max-h-96 overflow-y-auto">
              {filteredLogs.length === 0 ? (
                <div className="p-8 text-center">
                  <Icon name="FileText" size={48} className="mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium text-foreground mb-2">No logs found</h3>
                  <p className="text-muted-foreground">
                    {searchTerm ? 'Try adjusting your search terms' : 'No logs available for the selected filter'}
                  </p>
                </div>
              ) : (
                filteredLogs.map((log) => (
                  <div key={log.id} className="p-4 hover:bg-muted/20 transition-colors">
                    <div className="flex items-start space-x-4">
                      <div className={`p-2 rounded-lg border ${getLogColor(log.type)}`}>
                        <Icon name={getLogIcon(log.type)} size={16} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className={`px-2 py-1 rounded text-xs font-medium ${getLogColor(log.type)}`}>
                            {log.level}
                          </span>
                          <span className="text-sm text-muted-foreground">
                            {new Date(log.timestamp).toLocaleString()}
                          </span>
                          <span className="text-sm text-muted-foreground">•</span>
                          <span className="text-sm text-muted-foreground">{log.source}</span>
                        </div>
                        <div className="font-medium text-foreground mb-1">{log.message}</div>
                        <div className="text-sm text-muted-foreground mb-2">{log.details}</div>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <span>User: {log.user}</span>
                          <span>IP: {log.ip}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSystemLogs;
