import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ResponsiveBiometricAuth from '../../components/ResponsiveBiometricAuth';
import { enhancedBiometricAuth, deviceDetection } from '../../utils/crossPlatformBiometric';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const BiometricDemo = () => {
  const navigate = useNavigate();
  const [deviceInfo, setDeviceInfo] = useState(null);
  const [testResults, setTestResults] = useState([]);
  const [showDemo, setShowDemo] = useState(false);

  useEffect(() => {
    detectDevice();
  }, []);

  const detectDevice = async () => {
    const deviceType = deviceDetection.getDeviceType();
    const isMobile = deviceDetection.isMobile();
    const hasTouch = deviceDetection.hasTouch();
    const capabilities = await enhancedBiometricAuth.getCapabilities();
    const biometricAvailable = await enhancedBiometricAuth.isAvailable();

    setDeviceInfo({
      type: deviceType,
      isMobile,
      hasTouch,
      capabilities,
      biometricAvailable
    });
  };

  const runCompatibilityTest = () => {
    const tests = [
      {
        name: 'WebAuthn Support',
        test: () => !!window.PublicKeyCredential,
        description: 'Browser supports Web Authentication API'
      },
      {
        name: 'Platform Authenticator',
        test: async () => {
          try {
            return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
          } catch {
            return false;
          }
        },
        description: 'Device has built-in biometric authenticator'
      },
      {
        name: 'Secure Context',
        test: () => window.isSecureContext,
        description: 'Page is served over HTTPS or localhost'
      },
      {
        name: 'Touch Support',
        test: () => deviceDetection.hasTouch(),
        description: 'Device supports touch interaction'
      },
      {
        name: 'Mobile Device',
        test: () => deviceDetection.isMobile(),
        description: 'Running on mobile device'
      }
    ];

    Promise.all(
      tests.map(async (test) => ({
        ...test,
        result: typeof test.test === 'function' ? await test.test() : test.test
      }))
    ).then(setTestResults);
  };

  useEffect(() => {
    if (deviceInfo) {
      runCompatibilityTest();
    }
  }, [deviceInfo]);

  if (!deviceInfo) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Icon name="Loader2" size={48} className="animate-spin text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Detecting device capabilities...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Icon name="Fingerprint" size={16} className="text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-foreground">Biometric Authentication Demo</h1>
                <p className="text-xs text-muted-foreground">Cross-platform biometric testing</p>
              </div>
            </div>
            
            <Button
              onClick={() => navigate('/admin-secure-login')}
              variant="outline"
              size="sm"
            >
              <Icon name="ArrowLeft" size={14} className="mr-2" />
              Back to Login
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6 space-y-6">
        {/* Device Information */}
        <div className="bg-card border rounded-lg p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Device Information</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <span className="text-sm font-medium">Device Type</span>
                <span className="text-sm text-muted-foreground">{deviceInfo.type}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <span className="text-sm font-medium">Mobile Device</span>
                <span className={`text-sm ${deviceInfo.isMobile ? 'text-green-600' : 'text-gray-600'}`}>
                  {deviceInfo.isMobile ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <span className="text-sm font-medium">Touch Support</span>
                <span className={`text-sm ${deviceInfo.hasTouch ? 'text-green-600' : 'text-gray-600'}`}>
                  {deviceInfo.hasTouch ? 'Yes' : 'No'}
                </span>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <span className="text-sm font-medium">Biometric Available</span>
                <span className={`text-sm ${
                  deviceInfo.biometricAvailable && deviceInfo.biometricAvailable.available 
                    ? 'text-green-600' : 'text-red-600'
                }`}>
                  {deviceInfo.biometricAvailable && deviceInfo.biometricAvailable.available ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <span className="text-sm font-medium">User Agent</span>
                <span className="text-xs text-muted-foreground truncate max-w-[200px]">
                  {navigator.userAgent}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Compatibility Test Results */}
        <div className="bg-card border rounded-lg p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Compatibility Tests</h2>
          
          <div className="space-y-3">
            {testResults.map((test, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div>
                  <div className="font-medium text-sm">{test.name}</div>
                  <div className="text-xs text-muted-foreground">{test.description}</div>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon 
                    name={test.result ? "CheckCircle" : "XCircle"} 
                    size={20} 
                    className={test.result ? "text-green-600" : "text-red-600"} 
                  />
                  <span className={`text-sm font-medium ${
                    test.result ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {test.result ? 'Pass' : 'Fail'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Device Capabilities */}
        {deviceInfo.capabilities && (
          <div className="bg-card border rounded-lg p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Device Capabilities</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {Object.entries(deviceInfo.capabilities).map(([key, value]) => (
                <div key={key} className="p-3 bg-muted/50 rounded-lg text-center">
                  <div className="text-xs font-medium capitalize">{key.replace(/([A-Z])/g, ' $1')}</div>
                  <div className={`text-sm mt-1 ${value ? 'text-green-600' : 'text-gray-600'}`}>
                    {value ? 'Available' : 'Not Available'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Biometric Demo */}
        <div className="bg-card border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-foreground">Biometric Authentication Test</h2>
            <Button
              onClick={() => setShowDemo(!showDemo)}
              variant="outline"
              size="sm"
            >
              {showDemo ? 'Hide Demo' : 'Show Demo'}
            </Button>
          </div>
          
          {showDemo && (
            <div className="max-w-md mx-auto">
              <ResponsiveBiometricAuth
                userId="demo_user"
                userName="Demo User"
                onSuccess={(result) => {
                  console.log('Demo biometric success:', result);
                  alert(`Biometric authentication successful on ${result.deviceType}!`);
                }}
                onError={(error) => {
                  console.warn('Demo biometric error:', error);
                  alert(`Biometric authentication failed: ${error.error}`);
                }}
                onFallback={() => {
                  alert('Fallback to alternative authentication method');
                }}
              />
            </div>
          )}
        </div>

        {/* Instructions */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-blue-900 mb-3">Testing Instructions</h2>
          
          <div className="space-y-2 text-sm text-blue-800">
            <div className="flex items-start space-x-2">
              <Icon name="Info" size={16} className="text-blue-600 mt-0.5 flex-shrink-0" />
              <span>This demo tests biometric authentication compatibility across different devices</span>
            </div>
            <div className="flex items-start space-x-2">
              <Icon name="Smartphone" size={16} className="text-blue-600 mt-0.5 flex-shrink-0" />
              <span>On mobile: Test with fingerprint sensor, Face ID, or face unlock</span>
            </div>
            <div className="flex items-start space-x-2">
              <Icon name="Monitor" size={16} className="text-blue-600 mt-0.5 flex-shrink-0" />
              <span>On desktop: Test with Windows Hello, Touch ID, or fingerprint reader</span>
            </div>
            <div className="flex items-start space-x-2">
              <Icon name="Shield" size={16} className="text-blue-600 mt-0.5 flex-shrink-0" />
              <span>All biometric data is stored locally and never transmitted</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BiometricDemo;
