import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminLanguageManager = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [languages, setLanguages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showAddLanguage, setShowAddLanguage] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadLanguages();
  }, [isAdminAuthenticated, navigate]);

  const loadLanguages = () => {
    setLoading(true);
    setTimeout(() => {
      const mockLanguages = [
        {
          id: 1,
          code: 'en',
          name: 'English',
          nativeName: 'English',
          flag: '🇺🇸',
          isDefault: true,
          isEnabled: true,
          progress: 100,
          totalKeys: 1247,
          translatedKeys: 1247,
          lastUpdated: '2024-01-15T10:00:00Z'
        },
        {
          id: 2,
          code: 'es',
          name: 'Spanish',
          nativeName: 'Español',
          flag: '🇪🇸',
          isDefault: false,
          isEnabled: true,
          progress: 89,
          totalKeys: 1247,
          translatedKeys: 1110,
          lastUpdated: '2024-01-12T14:30:00Z'
        },
        {
          id: 3,
          code: 'fr',
          name: 'French',
          nativeName: 'Français',
          flag: '🇫🇷',
          isDefault: false,
          isEnabled: true,
          progress: 76,
          totalKeys: 1247,
          translatedKeys: 948,
          lastUpdated: '2024-01-10T09:15:00Z'
        },
        {
          id: 4,
          code: 'de',
          name: 'German',
          nativeName: 'Deutsch',
          flag: '🇩🇪',
          isDefault: false,
          isEnabled: false,
          progress: 45,
          totalKeys: 1247,
          translatedKeys: 561,
          lastUpdated: '2024-01-08T16:20:00Z'
        },
        {
          id: 5,
          code: 'zh',
          name: 'Chinese',
          nativeName: '中文',
          flag: '🇨🇳',
          isDefault: false,
          isEnabled: false,
          progress: 23,
          totalKeys: 1247,
          translatedKeys: 287,
          lastUpdated: '2024-01-05T11:45:00Z'
        }
      ];
      setLanguages(mockLanguages);
      setLoading(false);
    }, 1000);
  };

  const handleLanguageAction = (languageId, action) => {
    const language = languages.find(l => l.id === languageId);
    switch (action) {
      case 'toggle':
        if (language.isDefault) {
          alert('Cannot disable the default language');
          return;
        }
        const newStatus = !language.isEnabled;
        if (window.confirm(`Are you sure you want to ${newStatus ? 'enable' : 'disable'} ${language.name}?`)) {
          setLanguages(languages.map(l => 
            l.id === languageId ? {...l, isEnabled: newStatus} : l
          ));
        }
        break;
      case 'edit':
        setSelectedLanguage(language);
        break;
      case 'delete':
        if (language.isDefault) {
          alert('Cannot delete the default language');
          return;
        }
        if (window.confirm(`Are you sure you want to delete ${language.name}? This action cannot be undone.`)) {
          setLanguages(languages.filter(l => l.id !== languageId));
        }
        break;
      case 'setDefault':
        if (window.confirm(`Set ${language.name} as the default language?`)) {
          setLanguages(languages.map(l => ({
            ...l,
            isDefault: l.id === languageId
          })));
        }
        break;
      case 'export':
        alert(`Exporting translation file for ${language.name}`);
        break;
      case 'import':
        alert(`Opening import dialog for ${language.name}`);
        break;
      default:
        break;
    }
  };

  const getProgressColor = (progress) => {
    if (progress >= 90) return 'bg-green-500';
    if (progress >= 70) return 'bg-yellow-500';
    if (progress >= 50) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const getStatusBadge = (language) => {
    if (language.isDefault) {
      return <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">Default</span>;
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
        language.isEnabled 
          ? 'bg-green-100 text-green-800' 
          : 'bg-gray-100 text-gray-800'
      }`}>
        {language.isEnabled ? 'Enabled' : 'Disabled'}
      </span>
    );
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const filteredLanguages = languages.filter(lang =>
    lang.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lang.nativeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lang.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Language Manager"
        breadcrumb={[
          { label: "Controls", link: "/admin-controls" },
          { label: "Language Manager" }
        ]}
        actions={[
          {
            label: "Add Language",
            icon: "Plus",
            variant: "default",
            onClick: () => setShowAddLanguage(true)
          },
          {
            label: "Export All",
            icon: "Download",
            variant: "outline",
            onClick: () => alert('Exporting all translation files')
          },
          {
            label: "Refresh",
            icon: "RefreshCw",
            variant: "outline",
            onClick: loadLanguages
          }
        ]}
      />

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Languages</p>
                <p className="text-2xl font-bold text-foreground">{languages.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Icon name="Globe" size={24} className="text-blue-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Enabled</p>
                <p className="text-2xl font-bold text-foreground">
                  {languages.filter(l => l.isEnabled).length}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Icon name="CheckCircle" size={24} className="text-green-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg. Progress</p>
                <p className="text-2xl font-bold text-foreground">
                  {Math.round(languages.reduce((acc, l) => acc + l.progress, 0) / languages.length || 0)}%
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Icon name="TrendingUp" size={24} className="text-purple-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Translation Keys</p>
                <p className="text-2xl font-bold text-foreground">1,247</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Icon name="Key" size={24} className="text-yellow-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="bg-card border rounded-lg p-6 mb-6">
          <div className="relative">
            <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search languages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        </div>

        {/* Languages Table */}
        <div className="bg-card border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Language
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Code
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Progress
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Translation Keys
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Last Updated
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {loading ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center">
                      <div className="flex items-center justify-center">
                        <Icon name="Loader" size={20} className="animate-spin mr-2" />
                        Loading languages...
                      </div>
                    </td>
                  </tr>
                ) : filteredLanguages.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center text-muted-foreground">
                      No languages found
                    </td>
                  </tr>
                ) : (
                  filteredLanguages.map((language) => (
                    <tr key={language.id} className="hover:bg-muted/30">
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <span className="text-2xl mr-3">{language.flag}</span>
                          <div>
                            <div className="text-sm font-medium text-foreground">{language.name}</div>
                            <div className="text-sm text-muted-foreground">{language.nativeName}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 bg-muted rounded font-mono text-sm">{language.code}</span>
                      </td>
                      <td className="px-6 py-4">
                        {getStatusBadge(language)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-24 bg-gray-200 rounded-full h-2 mr-3">
                            <div
                              className={`h-2 rounded-full ${getProgressColor(language.progress)}`}
                              style={{ width: `${language.progress}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium text-foreground">{language.progress}%</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">
                          {language.translatedKeys} / {language.totalKeys}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {language.totalKeys - language.translatedKeys} missing
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">{formatDateTime(language.lastUpdated)}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleLanguageAction(language.id, 'edit')}
                            title="Edit Translations"
                          >
                            <Icon name="Edit" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleLanguageAction(language.id, 'export')}
                            title="Export"
                            className="text-blue-600 border-blue-200 hover:bg-blue-50"
                          >
                            <Icon name="Download" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleLanguageAction(language.id, 'toggle')}
                            title={language.isEnabled ? 'Disable' : 'Enable'}
                            className={language.isEnabled ? 'text-red-600 border-red-200 hover:bg-red-50' : 'text-green-600 border-green-200 hover:bg-green-50'}
                            disabled={language.isDefault}
                          >
                            <Icon name={language.isEnabled ? 'EyeOff' : 'Eye'} size={16} />
                          </Button>
                          {!language.isDefault && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleLanguageAction(language.id, 'setDefault')}
                              title="Set as Default"
                              className="text-purple-600 border-purple-200 hover:bg-purple-50"
                            >
                              <Icon name="Star" size={16} />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Language Modal */}
      {showAddLanguage && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card border rounded-lg max-w-md w-full">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h3 className="text-lg font-semibold">Add New Language</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAddLanguage(false)}
              >
                <Icon name="X" size={16} />
              </Button>
            </div>
            <div className="p-6">
              <p className="text-sm text-muted-foreground mb-4">
                Language management interface will be available in the next update. Please contact system administrator to add new languages.
              </p>
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  onClick={() => setShowAddLanguage(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    alert('Language management interface coming soon!');
                    setShowAddLanguage(false);
                  }}
                  className="flex-1"
                >
                  Contact Admin
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Language Modal */}
      {selectedLanguage && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card border rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h3 className="text-lg font-semibold">
                Edit Translations - {selectedLanguage.name}
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedLanguage(null)}
              >
                <Icon name="X" size={16} />
              </Button>
            </div>
            <div className="p-6">
              <p className="text-sm text-muted-foreground mb-4">
                Translation editor interface will be available in the next update. For now, you can export the translation file, edit it, and re-import it.
              </p>
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  onClick={() => handleLanguageAction(selectedLanguage.id, 'export')}
                >
                  <Icon name="Download" size={16} className="mr-2" />
                  Export Translations
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleLanguageAction(selectedLanguage.id, 'import')}
                >
                  <Icon name="Upload" size={16} className="mr-2" />
                  Import Translations
                </Button>
                <Button
                  onClick={() => setSelectedLanguage(null)}
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminLanguageManager;
