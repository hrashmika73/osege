import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';


const UserLoginPortal = () => {
  const navigate = useNavigate();
  const { login, user, loginAttempts, lockoutUntil } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberDevice: false,
    twoFactorCode: ''
  });
  const [showTwoFactor, setShowTwoFactor] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [lockoutTimeRemaining, setLockoutTimeRemaining] = useState(0);
  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      navigate('/user-dashboard');
    }
  }, [user, navigate]);

  // Handle lockout timer
  useEffect(() => {
    if (lockoutUntil) {
      const timer = setInterval(() => {
        const remaining = Math.max(0, Math.ceil((lockoutUntil - Date.now()) / 1000));
        setLockoutTimeRemaining(remaining);
        if (remaining === 0) {
          clearInterval(timer);
        }
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [lockoutUntil]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.email) {
      newErrors.email = 'Email or username is required';
    } else if (formData.email.includes('@') && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    if (showTwoFactor && !formData.twoFactorCode) {
      newErrors.twoFactorCode = 'Two-factor authentication code is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    if (lockoutTimeRemaining > 0) {
      setErrors({
        general: `Account locked. Try again in ${Math.ceil(lockoutTimeRemaining / 60)} minutes.`
      });
      return;
    }

    setIsLoading(true);

    try {
      const credentials = {
        email: formData.email,
        password: formData.password
      };

      const result = await login(credentials);

      if (result.success) {
        navigate('/user-dashboard');
      }
    } catch (error) {
      setErrors({ general: error.message });
    } finally {
      setIsLoading(false);
    }
  };



  const handleBackToLogin = () => {
    setShowTwoFactor(false);
    setFormData(prev => ({ ...prev, twoFactorCode: '' }));
    setErrors({});
  };

  const handleForgotPassword = () => {
    navigate('/password-recovery');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-orange-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full h-full bg-gradient-to-r from-orange-500/5 to-blue-500/5 rotate-12"></div>
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-14 h-14 bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg">
              <Icon name="TrendingUp" size={28} color="white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">KleverInvest Hub</h1>
              <p className="text-sm text-orange-400 font-medium">Professional Trading Platform</p>
            </div>
          </div>
          <p className="text-slate-300">
            {showTwoFactor 
              ? 'Enter your two-factor authentication code' :'Welcome back! Sign in to your investment account'
            }
          </p>
        </div>

        {/* Login Form */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            {!showTwoFactor ? (
              <>
                {/* Email/Username Input */}
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-2 text-white">
                    Email or Username
                  </label>
                  <Input
                    id="email"
                    name="email"
                    type="text"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="Enter your email or username"
                    className={`bg-white/10 border-white/20 text-white placeholder-slate-400 ${errors.email ? 'border-red-400' : ''}`}
                    disabled={isLoading}
                  />
                  {errors.email && (
                    <p className="text-red-400 text-sm mt-1">{errors.email}</p>
                  )}
                </div>

                {/* Password Input */}
                <div>
                  <label htmlFor="password" className="block text-sm font-medium mb-2 text-white">
                    Password
                  </label>
                  <div className="relative">
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? 'text' : 'password'}
                      value={formData.password}
                      onChange={handleInputChange}
                      placeholder="Enter your password"
                      className={`bg-white/10 border-white/20 text-white placeholder-slate-400 pr-12 ${errors.password ? 'border-red-400' : ''}`}
                      disabled={isLoading}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-white transition-colors"
                    >
                      <Icon name={showPassword ? 'EyeOff' : 'Eye'} size={18} />
                    </button>
                  </div>
                  {errors.password && (
                    <p className="text-red-400 text-sm mt-1">{errors.password}</p>
                  )}
                </div>

                {/* Remember Device */}
                <div className="flex items-center justify-between">
                  <label className="flex items-center space-x-2 text-sm text-white">
                    <input
                      type="checkbox"
                      name="rememberDevice"
                      checked={formData.rememberDevice}
                      onChange={handleInputChange}
                      className="rounded border-white/20 bg-white/10 text-orange-500 focus:ring-orange-500 focus:ring-offset-0"
                    />
                    <span>Remember this device</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleForgotPassword}
                    className="text-orange-400 hover:text-orange-300 text-sm transition-colors"
                  >
                    Forgot password?
                  </button>
                </div>
              </>
            ) : (
              <>
                {/* Two-Factor Authentication */}
                <div>
                  <label htmlFor="twoFactorCode" className="block text-sm font-medium mb-2 text-white">
                    Two-Factor Authentication Code
                  </label>
                  <Input
                    id="twoFactorCode"
                    name="twoFactorCode"
                    type="text"
                    value={formData.twoFactorCode}
                    onChange={handleInputChange}
                    placeholder="Enter 6-digit code"
                    maxLength="6"
                    className={`text-center text-2xl tracking-widest bg-white/10 border-white/20 text-white placeholder-slate-400 ${errors.twoFactorCode ? 'border-red-400' : ''}`}
                    disabled={isLoading}
                  />
                  {errors.twoFactorCode && (
                    <p className="text-red-400 text-sm mt-1">{errors.twoFactorCode}</p>
                  )}
                  <p className="text-xs text-slate-400 mt-2">
                    Check your authenticator app for the 6-digit code
                  </p>
                </div>
              </>
            )}

            {/* Security Status */}
            {lockoutTimeRemaining > 0 && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <Icon name="Shield" size={16} className="text-red-400" />
                  <p className="text-red-400 text-sm">
                    Account locked for security. Try again in {Math.ceil(lockoutTimeRemaining / 60)} minutes.
                  </p>
                </div>
              </div>
            )}

            {loginAttempts > 0 && lockoutTimeRemaining === 0 && (
              <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <Icon name="AlertTriangle" size={16} className="text-yellow-400" />
                  <p className="text-yellow-400 text-sm">
                    {loginAttempts} failed login attempt{loginAttempts > 1 ? 's' : ''}. Account will lock after 5 attempts.
                  </p>
                </div>
              </div>
            )}

            {/* General Error */}
            {errors.general && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <Icon name="AlertTriangle" size={16} className="text-red-400" />
                  <p className="text-red-400 text-sm">{errors.general}</p>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-4">
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold"
                size="lg"
                disabled={isLoading}
                loading={isLoading}
              >
                {showTwoFactor ? 'Verify & Access Account' : 'Sign In to Account'}
                <Icon name="ArrowRight" size={16} className="ml-2" />
              </Button>

              {showTwoFactor && (
                <Button
                  type="button"
                  variant="outline"
                  className="w-full border-white/20 text-white hover:bg-white/10"
                  onClick={handleBackToLogin}
                  disabled={isLoading}
                >
                  <Icon name="ArrowLeft" size={16} className="mr-2" />
                  Back to Login
                </Button>
              )}
            </div>
          </form>



        </div>

        {/* Security Features */}
        <div className="mt-8 text-center">
          <div className="flex items-center justify-center space-x-6 text-xs text-slate-400">
            <div className="flex items-center space-x-1">
              <Icon name="Shield" size={14} className="text-green-400" />
              <span>Bank-Level Security</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Lock" size={14} className="text-blue-400" />
              <span>Encrypted Data</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Smartphone" size={14} className="text-orange-400" />
              <span>2FA Protected</span>
            </div>
          </div>
        </div>

        {/* Registration Link */}
        <div className="mt-6 text-center">
          <p className="text-slate-400 text-sm">
            Don't have an account?{' '}
            <button
              onClick={() => navigate('/register')}
              className="text-orange-400 hover:text-orange-300 font-medium transition-colors"
            >
              Create Account
            </button>
          </p>
        </div>

        {/* Back to Home */}
        <div className="mt-6 text-center">
          <Button
            variant="ghost"
            onClick={() => navigate('/home-landing-page')}
            className="text-slate-400 hover:text-white"
          >
            <Icon name="ArrowLeft" size={16} className="mr-2" />
            Back to Homepage
          </Button>
        </div>
      </div>
    </div>
  );
};

export default UserLoginPortal;
