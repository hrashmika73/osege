import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import AdminNavigation from '../../components/ui/AdminNavigation';
import PaymentGatewaySettings from './components/PaymentGatewaySettings';

const AdminPaymentGateway = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [activeGateway, setActiveGateway] = useState('stripe');
  const [showSettings, setShowSettings] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(Date.now());

  // Check admin authentication
  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
  }, [isAdminAuthenticated, navigate]);

  // Listen for payment settings changes
  useEffect(() => {
    const handleSettingsChange = () => {
      setLastUpdate(Date.now());
      // Trigger a refresh of gateway data
      window.location.reload();
    };

    window.addEventListener('paymentSettingsChanged', handleSettingsChange);
    return () => window.removeEventListener('paymentSettingsChanged', handleSettingsChange);
  }, []);

  // Load gateway settings from localStorage to reflect actual configuration
  const [gatewaySettings, setGatewaySettings] = useState(() => {
    const savedSettings = localStorage.getItem('payment_gateway_settings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        return {
          stripe: {
            enabled: parsed.stripe?.enabled || false,
            apiKey: parsed.stripe?.secretKey ? '••••••••••••' + parsed.stripe.secretKey.slice(-4) : '',
            webhook: parsed.stripe?.webhookSecret ? 'configured' : 'not_configured'
          },
          paypal: {
            enabled: parsed.paypal?.enabled || false,
            clientId: parsed.paypal?.clientId || '',
            clientSecret: parsed.paypal?.clientSecret ? '••••••••••••' : ''
          },
          coinbase: {
            enabled: parsed.coinbase?.enabled || false,
            apiKey: parsed.coinbase?.apiKey ? '••••••••••••' + parsed.coinbase.apiKey.slice(-4) : '',
            webhook: parsed.coinbase?.webhookSecret ? 'configured' : 'not_configured'
          },
          bank: {
            enabled: parsed.bank?.enabled || false,
            routingNumber: parsed.bank?.routingNumber || '',
            accountNumber: parsed.bank?.accountNumber ? '••••••••' + parsed.bank.accountNumber.slice(-4) : ''
          }
        };
      } catch (e) {
        console.error('Error parsing saved settings:', e);
      }
    }
    // Default settings if no saved data
    return {
      stripe: { enabled: false, apiKey: '', webhook: 'not_configured' },
      paypal: { enabled: false, clientId: '', clientSecret: '' },
      coinbase: { enabled: false, apiKey: '', webhook: 'not_configured' },
      bank: { enabled: false, routingNumber: '', accountNumber: '' }
    };
  });

  const gateways = [
    {
      id: 'stripe',
      name: 'Stripe',
      icon: 'CreditCard',
      description: 'Credit/Debit Cards, ACH transfers',
      fees: '2.9% + $0.30',
      status: 'active'
    },
    {
      id: 'paypal',
      name: 'PayPal',
      icon: 'Wallet',
      description: 'PayPal payments and transfers',
      fees: '3.49% + $0.49',
      status: 'inactive'
    },
    {
      id: 'coinbase',
      name: 'Coinbase Commerce',
      icon: 'Bitcoin',
      description: 'Cryptocurrency payments',
      fees: '1% + network fees',
      status: 'active'
    },
    {
      id: 'bank',
      name: 'Bank Transfer',
      icon: 'Building2',
      description: 'Direct bank transfers',
      fees: '0% (3-5 business days)',
      status: 'active'
    }
  ];

  const transactions = [
    { id: '001', user: 'John Doe', amount: '$5,000', gateway: 'Stripe', status: 'completed', time: '2 min ago' },
    { id: '002', user: 'Sarah Wilson', amount: '$2,500', gateway: 'Coinbase', status: 'pending', time: '5 min ago' },
    { id: '003', user: 'Mike Johnson', amount: '$10,000', gateway: 'Bank Transfer', status: 'processing', time: '1 hour ago' },
    { id: '004', user: 'Emma Davis', amount: '$1,200', gateway: 'PayPal', status: 'failed', time: '2 hours ago' }
  ];

  const handleAddGateway = () => {
    // Create a new gateway configuration
    const newGateway = {
      id: `gateway_${Date.now()}`,
      name: 'New Gateway',
      icon: 'CreditCard',
      description: 'Custom payment gateway',
      fees: 'Configure fees',
      status: 'inactive'
    };

    // In a real app, this would call an API
    console.log('Adding new gateway:', newGateway);
    const proceed = confirm(`New gateway "${newGateway.name}" added successfully!\n\nStatus: ${newGateway.status}\nNext: Configure gateway settings\n\nWould you like to go to Site Settings to configure the new gateway?`);
    if (proceed) {
      navigate('/admin-site-settings');
    }
  };

  const handleExport = () => {
    // Generate CSV data from transactions
    const csvHeaders = ['ID', 'User', 'Amount', 'Gateway', 'Status', 'Time'];
    const csvData = transactions.map(t => [
      t.id,
      t.user,
      t.amount,
      t.gateway,
      t.status,
      t.time
    ]);

    const csvContent = [csvHeaders, ...csvData]
      .map(row => row.join(','))
      .join('\n');

    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `payment_transactions_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);

    alert('Transaction data exported successfully!');
  };

  const handleSyncGateways = () => {
    // Simulate gateway sync process
    const syncPromise = new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          stripe: 'synced',
          paypal: 'synced',
          coinbase: 'synced',
          bank: 'synced'
        });
      }, 2000);
    });

    alert('Starting gateway synchronization...');

    syncPromise.then((results) => {
      const syncCount = Object.values(results).filter(status => status === 'synced').length;
      const proceed = confirm(`Synchronization complete!\n${syncCount} gateways updated\n\nStripe: Connected\nPayPal: Connected\nCoinbase: Connected\nBank Transfer: Connected\n\nWould you like to view system analytics?`);
      if (proceed) {
        navigate('/admin-system-analytics');
      }
    });
  };

  const handleReviewFailed = () => {
    // Filter failed transactions
    const failedTransactions = transactions.filter(t => t.status === 'failed');

    if (failedTransactions.length === 0) {
      const proceed = confirm('No failed transactions found!\n\nAll recent transactions completed successfully.\n\nWould you like to view transaction management?');
      if (proceed) {
        navigate('/admin-transaction-management');
      }
      return;
    }

    const failedSummary = failedTransactions.map(t =>
      `• ${t.user}: ${t.amount} via ${t.gateway} (${t.time})`
    ).join('\n');

    const proceed = confirm(`Found ${failedTransactions.length} failed transaction(s):\n\n${failedSummary}\n\nRecommended Actions:\n• Contact affected users\n• Review gateway logs\n• Retry failed payments\n\nWould you like to go to Transaction Management to resolve these?`);
    if (proceed) {
      navigate('/admin-transaction-management');
    }
  };

  const handleGenerateReport = () => {
    // Calculate report data
    const totalAmount = transactions.reduce((sum, t) => {
      const amount = parseFloat(t.amount.replace(/[$,]/g, ''));
      return sum + (t.status === 'completed' ? amount : 0);
    }, 0);

    const completedCount = transactions.filter(t => t.status === 'completed').length;
    const failedCount = transactions.filter(t => t.status === 'failed').length;
    const successRate = ((completedCount / transactions.length) * 100).toFixed(1);

    const gatewayBreakdown = transactions.reduce((acc, t) => {
      acc[t.gateway] = (acc[t.gateway] || 0) + 1;
      return acc;
    }, {});

    const reportContent = `PAYMENT ANALYTICS REPORT\n` +
      `Generated: ${new Date().toLocaleString()}\n\n` +
      `SUMMARY:\n` +
      `• Total Processed: $${totalAmount.toLocaleString()}\n` +
      `• Completed Transactions: ${completedCount}\n` +
      `• Failed Transactions: ${failedCount}\n` +
      `• Success Rate: ${successRate}%\n\n` +
      `GATEWAY BREAKDOWN:\n` +
      Object.entries(gatewayBreakdown).map(([gateway, count]) =>
        `• ${gateway}: ${count} transactions`
      ).join('\n');

    // Create and download report
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `payment_analytics_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);

    const proceed = confirm(`Analytics report generated!\n\nTotal Processed: $${totalAmount.toLocaleString()}\nSuccess Rate: ${successRate}%\nReport downloaded as file.\n\nWould you like to view detailed system analytics?`);
    if (proceed) {
      navigate('/admin-system-analytics');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Navigation */}
      <AdminNavigation
        title="Payment Gateway Management"
        breadcrumb={[
          { label: "Admin", link: null },
          { label: "Payment Gateway", link: null }
        ]}
        actions={[
          {
            label: "Gateway Settings",
            icon: "Settings",
            variant: "default",
            onClick: () => setShowSettings(true)
          },
          {
            label: "Add Gateway",
            icon: "Plus",
            variant: "outline",
            onClick: handleAddGateway
          },
          {
            label: "Export Data",
            icon: "Download",
            variant: "outline",
            onClick: handleExport
          }
        ]}
      />

      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <p className="text-muted-foreground">Configure and monitor payment processing systems</p>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-card rounded-lg p-6 border">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                  <Icon name="DollarSign" size={24} className="text-success" />
                </div>
                <span className="text-success text-sm font-medium">+12.5%</span>
              </div>
              <h3 className="text-2xl font-bold text-foreground">$847,590</h3>
              <p className="text-muted-foreground text-sm">Total Processed Today</p>
            </div>

            <div className="bg-card rounded-lg p-6 border">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Icon name="Activity" size={24} className="text-primary" />
                </div>
                <span className="text-primary text-sm font-medium">+5.2%</span>
              </div>
              <h3 className="text-2xl font-bold text-foreground">1,247</h3>
              <p className="text-muted-foreground text-sm">Transactions Today</p>
            </div>

            <div className="bg-card rounded-lg p-6 border">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                  <Icon name="AlertTriangle" size={24} className="text-warning" />
                </div>
                <span className="text-warning text-sm font-medium">-2.1%</span>
              </div>
              <h3 className="text-2xl font-bold text-foreground">23</h3>
              <p className="text-muted-foreground text-sm">Failed Transactions</p>
            </div>

            <div className="bg-card rounded-lg p-6 border">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <Icon name="Percent" size={24} className="text-accent" />
                </div>
                <span className="text-success text-sm font-medium">98.5%</span>
              </div>
              <h3 className="text-2xl font-bold text-foreground">98.5%</h3>
              <p className="text-muted-foreground text-sm">Success Rate</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Payment Gateways */}
            <div className="bg-card rounded-lg border p-6">
              <h3 className="text-lg font-semibold text-foreground mb-6">Payment Gateways</h3>
              
              <div className="space-y-4">
                {gateways.map(gateway => (
                  <div key={gateway.id} className="border border-border rounded-lg p-4 hover:bg-muted/20 transition-colors">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                          <Icon name={gateway.icon} size={20} className="text-muted-foreground" />
                        </div>
                        <div>
                          <h4 className="font-medium text-foreground">{gateway.name}</h4>
                          <p className="text-sm text-muted-foreground">{gateway.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          gateway.status === 'active' ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'
                        }`}>
                          {gateway.status}
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          type="button"
                          className="hover:bg-muted/80 transition-colors cursor-pointer z-10 relative"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            setShowSettings(true);
                          }}
                        >
                          <Icon name="Settings" size={16} />
                        </Button>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Processing Fee: <span className="font-medium">{gateway.fees}</span>
                    </div>
                  </div>
                ))}
              </div>

              <Button
                className="w-full mt-6 hover:bg-primary/90 transition-colors cursor-pointer"
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  console.log('Add Gateway clicked');
                  handleAddGateway();
                }}
              >
                <Icon name="Plus" size={16} />
                <span className="ml-2">Add New Gateway</span>
              </Button>
            </div>

            {/* Recent Transactions */}
            <div className="bg-card rounded-lg border p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-foreground">Recent Transactions</h3>
                <Button variant="outline" size="sm" onClick={handleExport}>
                  <Icon name="Download" size={16} />
                  <span className="ml-2">Export</span>
                </Button>
              </div>

              <div className="space-y-4">
                {transactions.map(transaction => (
                  <div key={transaction.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <div className="font-medium text-foreground">{transaction.user}</div>
                      <div className="text-sm text-muted-foreground">{transaction.gateway} • {transaction.time}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-foreground">{transaction.amount}</div>
                      <div className={`text-xs px-2 py-1 rounded-full ${
                        transaction.status === 'completed' ? 'bg-success/10 text-success' :
                        transaction.status === 'pending' ? 'bg-warning/10 text-warning' :
                        transaction.status === 'processing' ? 'bg-primary/10 text-primary' :
                        'bg-destructive/10 text-destructive'
                      }`}>
                        {transaction.status}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <Button variant="outline" className="w-full mt-4" onClick={() => navigate('/admin-transaction-management')}>
                View All Transactions
              </Button>
            </div>
          </div>

          {/* Gateway Configuration */}
          <div className="mt-8 bg-card rounded-lg border p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">Quick Actions</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button
                className="p-4 h-auto hover:bg-primary/90 transition-colors"
                onClick={handleSyncGateways}
                type="button"
              >
                <div className="text-center">
                  <Icon name="RefreshCw" size={24} className="mx-auto mb-2" />
                  <div className="font-medium">Sync All Gateways</div>
                  <div className="text-xs opacity-75">Update payment status</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="p-4 h-auto hover:bg-muted/50 transition-colors"
                onClick={handleReviewFailed}
                type="button"
              >
                <div className="text-center">
                  <Icon name="AlertTriangle" size={24} className="mx-auto mb-2" />
                  <div className="font-medium">Review Failed</div>
                  <div className="text-xs text-muted-foreground">Check failed transactions</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="p-4 h-auto hover:bg-muted/50 transition-colors"
                onClick={handleGenerateReport}
                type="button"
              >
                <div className="text-center">
                  <Icon name="BarChart3" size={24} className="mx-auto mb-2" />
                  <div className="font-medium">Generate Report</div>
                  <div className="text-xs text-muted-foreground">Payment analytics</div>
                </div>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Gateway Settings Modal */}
      {showSettings && (
        <PaymentGatewaySettings
          onClose={() => {
            setShowSettings(false);
            // Trigger update event
            window.dispatchEvent(new CustomEvent('paymentSettingsChanged'));
          }}
        />
      )}
    </div>
  );
};

export default AdminPaymentGateway;
