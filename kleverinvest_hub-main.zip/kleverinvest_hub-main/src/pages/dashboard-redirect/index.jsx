import React from 'react';
import { Navigate } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import Icon from '../../components/AppIcon';

const DashboardRedirect = () => {
  const { user, loading: userLoading, isUserAuthenticated } = useUserAuth();
  const { admin, loading: adminLoading, isAdminAuthenticated } = useAdminAuth();

  const loading = userLoading || adminLoading;

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary/10 rounded-full mx-auto mb-4 flex items-center justify-center">
            <Icon name="Loader" size={32} className="text-primary animate-spin" />
          </div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (isAdminAuthenticated) {
    return <Navigate to="/admin-dashboard" replace />;
  }

  if (isUserAuthenticated) {
    return <Navigate to="/user-dashboard" replace />;
  }

  // No authentication found
  return <Navigate to="/login-selection" replace />;
};

export default DashboardRedirect;
