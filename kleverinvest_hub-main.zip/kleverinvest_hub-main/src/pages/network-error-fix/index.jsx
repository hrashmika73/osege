import React from 'react';
import { Helmet } from 'react-helmet';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import NetworkErrorFixManager from '../../components/NetworkErrorFixManager';

const NetworkErrorFixPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Fix NetworkErrors - KleverInvest Hub</title>
        <meta name="description" content="Diagnose and fix NetworkError issues" />
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="AlertTriangle" size={32} className="text-destructive" />
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-4">
              NetworkError Fix Center
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Comprehensive tool to diagnose, monitor, and fix "NetworkError when attempting to fetch resource" issues
            </p>
          </div>

          <NetworkErrorFixManager />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            {/* Common Solutions */}
            <div className="bg-card border rounded-lg p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <Icon name="Lightbulb" className="mr-2 text-warning" />
                Common Solutions
              </h2>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <Icon name="CheckCircle" className="text-success mt-1" size={16} />
                  <div>
                    <h3 className="font-medium">Clear Browser Cache</h3>
                    <p className="text-sm text-muted-foreground">Remove cached files that might be causing conflicts</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Icon name="CheckCircle" className="text-success mt-1" size={16} />
                  <div>
                    <h3 className="font-medium">Disable Ad Blockers</h3>
                    <p className="text-sm text-muted-foreground">Some ad blockers interfere with legitimate requests</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Icon name="CheckCircle" className="text-success mt-1" size={16} />
                  <div>
                    <h3 className="font-medium">Check Internet Connection</h3>
                    <p className="text-sm text-muted-foreground">Verify your network connectivity is stable</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Icon name="CheckCircle" className="text-success mt-1" size={16} />
                  <div>
                    <h3 className="font-medium">Try Incognito Mode</h3>
                    <p className="text-sm text-muted-foreground">Test without browser extensions</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Error Types */}
            <div className="bg-card border rounded-lg p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <Icon name="AlertCircle" className="mr-2 text-destructive" />
                Error Types We Fix
              </h2>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <Icon name="Globe" className="text-primary mt-1" size={16} />
                  <div>
                    <h3 className="font-medium">API Network Errors</h3>
                    <p className="text-sm text-muted-foreground">Failed API calls and database connections</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Icon name="Package" className="text-primary mt-1" size={16} />
                  <div>
                    <h3 className="font-medium">Chunk Loading Errors</h3>
                    <p className="text-sm text-muted-foreground">Failed to load JavaScript/CSS chunks</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Icon name="Type" className="text-primary mt-1" size={16} />
                  <div>
                    <h3 className="font-medium">Font Loading Errors</h3>
                    <p className="text-sm text-muted-foreground">Google Fonts and external fonts</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Icon name="Shield" className="text-primary mt-1" size={16} />
                  <div>
                    <h3 className="font-medium">OAuth Loading Errors</h3>
                    <p className="text-sm text-muted-foreground">Google and Apple OAuth scripts</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Manual Steps */}
          <div className="bg-card border rounded-lg p-6 mt-8">
            <h2 className="text-lg font-semibold mb-4 flex items-center">
              <Icon name="Settings" className="mr-2 text-primary" />
              Manual Troubleshooting Steps
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium mb-3">Browser Steps</h3>
                <ol className="space-y-2 text-sm">
                  <li className="flex items-start space-x-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mt-0.5">1</span>
                    <span>Open browser Developer Tools (F12)</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mt-0.5">2</span>
                    <span>Go to Network tab and reload the page</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mt-0.5">3</span>
                    <span>Look for failed requests (red entries)</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mt-0.5">4</span>
                    <span>Check Console tab for error messages</span>
                  </li>
                </ol>
              </div>
              <div>
                <h3 className="font-medium mb-3">System Steps</h3>
                <ol className="space-y-2 text-sm">
                  <li className="flex items-start space-x-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mt-0.5">1</span>
                    <span>Restart your router/modem</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mt-0.5">2</span>
                    <span>Flush DNS cache (ipconfig /flushdns)</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mt-0.5">3</span>
                    <span>Try a different browser</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mt-0.5">4</span>
                    <span>Disable VPN/proxy temporarily</span>
                  </li>
                </ol>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="text-center mt-8">
            <div className="flex justify-center space-x-4">
              <Button variant="outline" onClick={() => window.location.href = '/'}>
                <Icon name="Home" size={16} className="mr-2" />
                Home
              </Button>
              <Button variant="outline" onClick={() => window.location.href = '/auth-debug'}>
                <Icon name="Bug" size={16} className="mr-2" />
                Auth Debug
              </Button>
              <Button variant="outline" onClick={() => window.location.href = '/user-dashboard-test'}>
                <Icon name="TestTube" size={16} className="mr-2" />
                Test Dashboard
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NetworkErrorFixPage;
