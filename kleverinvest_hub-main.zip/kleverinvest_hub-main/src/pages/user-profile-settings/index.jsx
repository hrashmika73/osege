import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import ChatWidget from '../../components/ui/ChatWidget';
import KYCGuard from '../../components/KYCGuard';
import PersonalInfoSection from './components/PersonalInfoSection';
import SecuritySection from './components/SecuritySection';
import PreferencesSection from './components/PreferencesSection';
import ActivityLogSection from './components/ActivityLogSection';
import DangerZoneSection from './components/DangerZoneSection';
import Icon from '../../components/AppIcon';

const UserProfileSettings = () => {
  const [expandedSections, setExpandedSections] = useState({
    personal: true,
    security: false,
    preferences: false,
    activity: false,
    danger: false
  });

  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    // Check localStorage for saved language preference
    const savedLanguage = localStorage.getItem('userLanguage') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const expandAllSections = () => {
    setExpandedSections({
      personal: true,
      security: true,
      preferences: true,
      activity: true,
      danger: true
    });
  };

  const collapseAllSections = () => {
    setExpandedSections({
      personal: false,
      security: false,
      preferences: false,
      activity: false,
      danger: false
    });
  };

  return (
    <KYCGuard>
      <Helmet>
        <title>Profile Settings - KleverInvest Hub</title>
        <meta name="description" content="Manage your account settings, security preferences, and personal information on KleverInvest Hub" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        {/* Main Content */}
        <main className="pt-16">
          <div className="container mx-auto px-4 py-8 max-w-4xl">
            {/* Page Header */}
            <div className="mb-8">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h1 className="text-3xl font-bold text-foreground mb-2">Profile Settings</h1>
                  <p className="text-muted-foreground">
                    Manage your account information, security settings, and preferences
                  </p>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={expandAllSections}
                    className="flex items-center space-x-2 px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors duration-150"
                  >
                    <Icon name="ChevronDown" size={16} />
                    <span>Expand All</span>
                  </button>
                  <button
                    onClick={collapseAllSections}
                    className="flex items-center space-x-2 px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors duration-150"
                  >
                    <Icon name="ChevronUp" size={16} />
                    <span>Collapse All</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Settings Sections */}
            <div className="space-y-6">
              {/* Personal Information Section */}
              <PersonalInfoSection
                isExpanded={expandedSections.personal}
                onToggle={() => toggleSection('personal')}
              />

              {/* Security Settings Section */}
              <SecuritySection
                isExpanded={expandedSections.security}
                onToggle={() => toggleSection('security')}
              />

              {/* Account Preferences Section */}
              <PreferencesSection
                isExpanded={expandedSections.preferences}
                onToggle={() => toggleSection('preferences')}
              />

              {/* Activity Log Section */}
              <ActivityLogSection
                isExpanded={expandedSections.activity}
                onToggle={() => toggleSection('activity')}
              />

              {/* Danger Zone Section */}
              <DangerZoneSection
                isExpanded={expandedSections.danger}
                onToggle={() => toggleSection('danger')}
              />
            </div>

            {/* Help Section */}
            <div className="mt-12 p-6 bg-muted/30 rounded-lg border">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Icon name="HelpCircle" size={20} className="text-primary" />
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground mb-2">Need Help?</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    If you have questions about your account settings or need assistance with any features, our support team is here to help.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <a
                      href="/support-chat-system"
                      className="inline-flex items-center space-x-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors duration-150 text-sm font-medium"
                    >
                      <Icon name="MessageCircle" size={16} />
                      <span>Contact Support</span>
                    </a>
                    <a
                      href="#"
                      className="inline-flex items-center space-x-2 px-4 py-2 border border-border text-foreground rounded-md hover:bg-muted transition-colors duration-150 text-sm font-medium"
                    >
                      <Icon name="Book" size={16} />
                      <span>View Help Center</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>

        <ChatWidget />
      </div>
    </KYCGuard>
  );
};

export default UserProfileSettings;
