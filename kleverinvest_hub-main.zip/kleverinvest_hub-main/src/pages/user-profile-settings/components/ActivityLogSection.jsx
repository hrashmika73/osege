import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const ActivityLogSection = ({ isExpanded, onToggle }) => {
  const [filterType, setFilterType] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const activityData = [
    {
      id: 1,
      type: 'login',
      action: 'Successful Login',
      device: 'MacBook Pro - Chrome 119.0',
      location: 'New York, NY, USA',
      ip: '192.168.1.100',
      timestamp: '2025-01-29 09:15:23',
      status: 'success'
    },
    {
      id: 2,
      type: 'security',
      action: 'Password Changed',
      device: 'MacBook Pro - Chrome 119.0',
      location: 'New York, NY, USA',
      ip: '192.168.1.100',
      timestamp: '2025-01-28 14:30:45',
      status: 'success'
    },
    {
      id: 3,
      type: 'login',
      action: 'Failed Login Attempt',
      device: 'Unknown Device - Chrome 118.0',
      location: 'Los Angeles, CA, USA',
      ip: '203.0.113.45',
      timestamp: '2025-01-28 02:15:12',
      status: 'failed'
    },
    {
      id: 4,
      type: 'profile',
      action: 'Profile Information Updated',
      device: 'iPhone 15 - Safari Mobile',
      location: 'New York, NY, USA',
      ip: '192.168.1.101',
      timestamp: '2025-01-27 18:45:30',
      status: 'success'
    },
    {
      id: 5,
      type: 'security',
      action: '2FA Enabled',
      device: 'MacBook Pro - Chrome 119.0',
      location: 'New York, NY, USA',
      ip: '192.168.1.100',
      timestamp: '2025-01-27 10:20:15',
      status: 'success'
    },
    {
      id: 6,
      type: 'login',
      action: 'Successful Login',
      device: 'iPhone 15 - Safari Mobile',
      location: 'New York, NY, USA',
      ip: '192.168.1.101',
      timestamp: '2025-01-26 16:30:00',
      status: 'success'
    },
    {
      id: 7,
      type: 'security',
      action: 'Device Added to Trusted List',
      device: 'iPad Pro - Safari',
      location: 'New York, NY, USA',
      ip: '192.168.1.102',
      timestamp: '2025-01-25 12:15:45',
      status: 'success'
    },
    {
      id: 8,
      type: 'profile',
      action: 'Email Address Verified',
      device: 'MacBook Pro - Chrome 119.0',
      location: 'New York, NY, USA',
      ip: '192.168.1.100',
      timestamp: '2025-01-24 09:30:20',
      status: 'success'
    }
  ];

  const filterOptions = [
    { value: 'all', label: 'All Activities' },
    { value: 'login', label: 'Login Activities' },
    { value: 'security', label: 'Security Events' },
    { value: 'profile', label: 'Profile Changes' }
  ];

  const filteredActivities = activityData.filter(activity => 
    filterType === 'all' || activity.type === filterType
  );

  const totalPages = Math.ceil(filteredActivities.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedActivities = filteredActivities.slice(startIndex, startIndex + itemsPerPage);

  const getActivityIcon = (type, status) => {
    const iconMap = {
      login: status === 'success' ? 'LogIn' : 'AlertTriangle',
      security: 'Shield',
      profile: 'User'
    };
    return iconMap[type] || 'Activity';
  };

  const getActivityColor = (type, status) => {
    if (status === 'failed') return 'text-destructive';
    
    const colorMap = {
      login: 'text-primary',
      security: 'text-warning',
      profile: 'text-success'
    };
    return colorMap[type] || 'text-muted-foreground';
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      success: { color: 'bg-success', text: 'Success' },
      failed: { color: 'bg-destructive', text: 'Failed' }
    };
    
    const config = statusConfig[status];
    return (
      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${config.color} text-white`}>
        {config.text}
      </span>
    );
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const exportActivityLog = () => {
    // Simulate CSV export
    const csvContent = [
      'Timestamp,Action,Device,Location,IP Address,Status',
      ...filteredActivities.map(activity => 
        `${activity.timestamp},"${activity.action}","${activity.device}","${activity.location}",${activity.ip},${activity.status}`
      )
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'activity-log.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-card border rounded-lg">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/50 transition-colors duration-150"
      >
        <div className="flex items-center space-x-3">
          <Icon name="Activity" size={20} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Account Activity</h3>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-muted-foreground" 
        />
      </button>

      {isExpanded && (
        <div className="px-6 pb-6 border-t space-y-4">
          {/* Filter and Export Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <Select
              label="Filter by type"
              options={filterOptions}
              value={filterType}
              onChange={setFilterType}
              className="sm:w-48"
            />
            
            <Button
              variant="outline"
              size="sm"
              onClick={exportActivityLog}
              iconName="Download"
              iconPosition="left"
            >
              Export Log
            </Button>
          </div>

          {/* Activity List */}
          <div className="space-y-3">
            {paginatedActivities.map((activity) => (
              <div key={activity.id} className="p-4 bg-muted/30 rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className={`mt-1 ${getActivityColor(activity.type, activity.status)}`}>
                      <Icon name={getActivityIcon(activity.type, activity.status)} size={18} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <h5 className="font-medium text-foreground">{activity.action}</h5>
                        {getStatusBadge(activity.status)}
                      </div>
                      <div className="space-y-1 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-2">
                          <Icon name="Monitor" size={14} />
                          <span>{activity.device}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Icon name="MapPin" size={14} />
                          <span>{activity.location}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Icon name="Globe" size={14} />
                          <span>{activity.ip}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground text-right">
                    <div>{new Date(activity.timestamp).toLocaleDateString()}</div>
                    <div>{new Date(activity.timestamp).toLocaleTimeString()}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-4 border-t">
              <div className="text-sm text-muted-foreground">
                Showing {startIndex + 1}-{Math.min(startIndex + itemsPerPage, filteredActivities.length)} of {filteredActivities.length} activities
              </div>
              
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                  iconName="ChevronLeft"
                />
                
                <div className="flex items-center space-x-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "outline"}
                      size="sm"
                      onClick={() => handlePageChange(page)}
                      className="w-8 h-8 p-0"
                    >
                      {page}
                    </Button>
                  ))}
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  iconName="ChevronRight"
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ActivityLogSection;