import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Checkbox from '../../../components/ui/Checkbox';

const SecuritySection = ({ isExpanded, onToggle }) => {
  const [securitySettings, setSecuritySettings] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(true);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [showPasswords, setShowPasswords] = useState(false);
  const [kycStatus, setKycStatus] = useState("verified"); // verified, pending, not_started

  const trustedDevices = [
    {
      id: 1,
      device: "MacBook Pro",
      browser: "Chrome 119.0",
      location: "New York, NY",
      lastActive: "2025-01-29 09:15:00",
      current: true
    },
    {
      id: 2,
      device: "iPhone 15",
      browser: "Safari Mobile",
      location: "New York, NY",
      lastActive: "2025-01-28 18:30:00",
      current: false
    }
  ];

  const handlePasswordChange = (field, value) => {
    setSecuritySettings(prev => ({
      ...prev,
      [field]: value
    }));

    if (field === 'newPassword') {
      calculatePasswordStrength(value);
    }
  };

  const calculatePasswordStrength = (password) => {
    let strength = 0;
    if (password.length >= 8) strength += 25;
    if (/[A-Z]/.test(password)) strength += 25;
    if (/[0-9]/.test(password)) strength += 25;
    if (/[^A-Za-z0-9]/.test(password)) strength += 25;
    setPasswordStrength(strength);
  };

  const getPasswordStrengthColor = () => {
    if (passwordStrength < 50) return "bg-destructive";
    if (passwordStrength < 75) return "bg-warning";
    return "bg-success";
  };

  const getPasswordStrengthText = () => {
    if (passwordStrength < 25) return "Very Weak";
    if (passwordStrength < 50) return "Weak";
    if (passwordStrength < 75) return "Good";
    return "Strong";
  };

  const handlePasswordUpdate = async () => {
    setIsChangingPassword(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsChangingPassword(false);
    setSecuritySettings({
      currentPassword: "",
      newPassword: "",
      confirmPassword: ""
    });
    setPasswordStrength(0);
  };

  const getKycStatusBadge = () => {
    const statusConfig = {
      verified: { color: "bg-success", text: "Verified", icon: "CheckCircle" },
      pending: { color: "bg-warning", text: "Pending Review", icon: "Clock" },
      not_started: { color: "bg-muted", text: "Not Started", icon: "AlertCircle" }
    };
    
    const config = statusConfig[kycStatus];
    return (
      <div className={`inline-flex items-center space-x-2 px-3 py-1 rounded-full text-sm font-medium ${config.color} text-white`}>
        <Icon name={config.icon} size={14} />
        <span>{config.text}</span>
      </div>
    );
  };

  return (
    <div className="bg-card border rounded-lg">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/50 transition-colors duration-150"
      >
        <div className="flex items-center space-x-3">
          <Icon name="Shield" size={20} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Security Settings</h3>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-muted-foreground" 
        />
      </button>

      {isExpanded && (
        <div className="px-6 pb-6 border-t space-y-6">
          {/* KYC Verification Status */}
          <div className="p-4 bg-muted/30 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-foreground">Account Verification</h4>
              {getKycStatusBadge()}
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Complete your identity verification to unlock all platform features and increase your transaction limits.
            </p>
            {kycStatus !== "verified" && (
              <Button variant="outline" size="sm">
                {kycStatus === "not_started" ? "Start Verification" : "View Status"}
              </Button>
            )}
          </div>

          {/* Password Change */}
          <div className="space-y-4">
            <h4 className="font-medium text-foreground">Change Password</h4>
            
            <Input
              label="Current Password"
              type={showPasswords ? "text" : "password"}
              value={securitySettings.currentPassword}
              onChange={(e) => handlePasswordChange('currentPassword', e.target.value)}
              required
            />
            
            <Input
              label="New Password"
              type={showPasswords ? "text" : "password"}
              value={securitySettings.newPassword}
              onChange={(e) => handlePasswordChange('newPassword', e.target.value)}
              required
              description="Password must be at least 8 characters with uppercase, lowercase, numbers, and symbols"
            />
            
            {securitySettings.newPassword && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Password Strength:</span>
                  <span className={`font-medium ${passwordStrength >= 75 ? 'text-success' : passwordStrength >= 50 ? 'text-warning' : 'text-destructive'}`}>
                    {getPasswordStrengthText()}
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${getPasswordStrengthColor()}`}
                    style={{ width: `${passwordStrength}%` }}
                  />
                </div>
              </div>
            )}
            
            <Input
              label="Confirm New Password"
              type={showPasswords ? "text" : "password"}
              value={securitySettings.confirmPassword}
              onChange={(e) => handlePasswordChange('confirmPassword', e.target.value)}
              required
              error={
                securitySettings.confirmPassword && 
                securitySettings.newPassword !== securitySettings.confirmPassword 
                  ? "Passwords do not match" 
                  : ""
              }
            />
            
            <Checkbox
              label="Show passwords"
              checked={showPasswords}
              onChange={(e) => setShowPasswords(e.target.checked)}
            />
            
            <Button
              variant="default"
              onClick={handlePasswordUpdate}
              loading={isChangingPassword}
              disabled={
                !securitySettings.currentPassword || 
                !securitySettings.newPassword || 
                securitySettings.newPassword !== securitySettings.confirmPassword ||
                passwordStrength < 50
              }
            >
              Update Password
            </Button>
          </div>

          {/* Two-Factor Authentication */}
          <div className="space-y-4 pt-6 border-t">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-foreground">Two-Factor Authentication</h4>
                <p className="text-sm text-muted-foreground">
                  Add an extra layer of security to your account
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <span className={`text-sm font-medium ${twoFactorEnabled ? 'text-success' : 'text-muted-foreground'}`}>
                  {twoFactorEnabled ? 'Enabled' : 'Disabled'}
                </span>
                <Button
                  variant={twoFactorEnabled ? "destructive" : "default"}
                  size="sm"
                  onClick={() => setTwoFactorEnabled(!twoFactorEnabled)}
                >
                  {twoFactorEnabled ? 'Disable' : 'Enable'}
                </Button>
              </div>
            </div>
          </div>

          {/* Trusted Devices */}
          <div className="space-y-4 pt-6 border-t">
            <h4 className="font-medium text-foreground">Trusted Devices</h4>
            <div className="space-y-3">
              {trustedDevices.map((device) => (
                <div key={device.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Icon name="Monitor" size={20} className="text-muted-foreground" />
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium text-foreground">{device.device}</span>
                        {device.current && (
                          <span className="px-2 py-1 bg-success text-white text-xs rounded-full">
                            Current
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {device.browser} • {device.location}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Last active: {new Date(device.lastActive).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  {!device.current && (
                    <Button variant="outline" size="sm">
                      Remove
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SecuritySection;