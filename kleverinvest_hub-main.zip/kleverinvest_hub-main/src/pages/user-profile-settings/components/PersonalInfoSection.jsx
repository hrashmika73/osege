import React, { useState, useEffect } from 'react';
import { useUserAuth } from '../../../contexts/UserAuthContext';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { defaultAvatars } from '../../../utils/avatarHelper';

const PersonalInfoSection = ({ isExpanded, onToggle }) => {
  const { user, updateUser } = useUserAuth();
  const [personalInfo, setPersonalInfo] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    dateOfBirth: "",
    address: ""
  });

  // Load user data when component mounts or user changes
  useEffect(() => {
    if (user) {
      setPersonalInfo({
        firstName: user.firstName || user.name?.split(' ')[0] || '',
        lastName: user.lastName || user.name?.split(' ').slice(1).join(' ') || '',
        email: user.email || '',
        phone: user.phone || '',
        dateOfBirth: user.dateOfBirth || '',
        address: user.address || ''
      });
    }
  }, [user]);
  
  const [isEditing, setIsEditing] = useState(false);
  const [profileImage, setProfileImage] = useState(null);
  const [isEmailVerified, setIsEmailVerified] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  // Generate user initials for avatar
  const getUserInitials = () => {
    if (!user) return 'US';
    const firstName = personalInfo.firstName || user.firstName || user.name?.split(' ')[0] || '';
    const lastName = personalInfo.lastName || user.lastName || user.name?.split(' ')[1] || '';
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase() || user.email?.charAt(0).toUpperCase() || 'U';
  };

  const handleInputChange = (field, value) => {
    setPersonalInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Update user data in context and localStorage
      const updatedUserData = {
        ...user,
        firstName: personalInfo.firstName,
        lastName: personalInfo.lastName,
        name: `${personalInfo.firstName} ${personalInfo.lastName}`.trim(),
        email: personalInfo.email,
        phone: personalInfo.phone,
        dateOfBirth: personalInfo.dateOfBirth,
        address: personalInfo.address,
        profileComplete: true
      };

      // Update in user context
      updateUser(updatedUserData);

      // Also update in admin system for consistency
      try {
        const userDataManager = await import('../../../utils/userDataManager');
        const { updateUser: updateAdminUser } = userDataManager;
        updateAdminUser(user.id || user.userId, {
          fullName: `${personalInfo.firstName} ${personalInfo.lastName}`.trim(),
          firstName: personalInfo.firstName,
          lastName: personalInfo.lastName,
          email: personalInfo.email,
          phone: personalInfo.phone,
          dateOfBirth: personalInfo.dateOfBirth,
          address: personalInfo.address
        });
      } catch (adminError) {
        console.warn('Failed to update admin system:', adminError);
        // Continue anyway as user context was updated
      }

      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Error saving profile:', error);
      alert('Error saving profile. Please try again.');
    } finally {
      setIsSaving(false);
      setIsEditing(false);
    }
  };

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const sendVerificationEmail = () => {
    // Simulate sending verification email
    setIsEmailVerified(false);
    setTimeout(() => {
      setIsEmailVerified(true);
    }, 3000);
  };

  return (
    <div className="bg-card border rounded-lg">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/50 transition-colors duration-150"
      >
        <div className="flex items-center space-x-3">
          <Icon name="User" size={20} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Personal Information</h3>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-muted-foreground" 
        />
      </button>

      {isExpanded && (
        <div className="px-6 pb-6 border-t">
          <div className="space-y-6">
            {/* Profile Photo Section */}
            <div className="flex flex-col sm:flex-row sm:items-center space-y-4 sm:space-y-0 sm:space-x-6">
              <div className="relative">
                <div className="w-24 h-24 rounded-full overflow-hidden bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  {profileImage ? (
                    <Image
                      src={profileImage}
                      alt="Profile"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-2xl font-bold text-white">
                      {getUserInitials()}
                    </span>
                  )}
                </div>
                <label className="absolute -bottom-2 -right-2 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center cursor-pointer hover:bg-primary/90 transition-colors duration-150">
                  <Icon name="Camera" size={16} />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-foreground">Profile Photo</h4>
                <p className="text-sm text-muted-foreground mt-1">
                  Upload a clear photo of yourself. JPG, PNG or GIF. Max size 5MB.
                </p>
              </div>
            </div>

            {/* Personal Details Form */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="First Name"
                type="text"
                value={personalInfo.firstName}
                onChange={(e) => handleInputChange('firstName', e.target.value)}
                disabled={!isEditing}
                required
              />
              
              <Input
                label="Last Name"
                type="text"
                value={personalInfo.lastName}
                onChange={(e) => handleInputChange('lastName', e.target.value)}
                disabled={!isEditing}
                required
              />
              
              <div className="md:col-span-2">
                <Input
                  label="Email Address"
                  type="email"
                  value={personalInfo.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  disabled={!isEditing}
                  required
                  description={
                    isEmailVerified 
                      ? "Your email is verified" 
                      : "Please verify your email address"
                  }
                />
                {!isEmailVerified && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={sendVerificationEmail}
                    className="mt-2"
                  >
                    Send Verification Email
                  </Button>
                )}
              </div>
              
              <Input
                label="Phone Number"
                type="tel"
                value={personalInfo.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                disabled={!isEditing}
              />
              
              <Input
                label="Date of Birth"
                type="date"
                value={personalInfo.dateOfBirth}
                onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                disabled={!isEditing}
              />
              
              <div className="md:col-span-2">
                <Input
                  label="Address"
                  type="text"
                  value={personalInfo.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  disabled={!isEditing}
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t">
              {!isEditing ? (
                <Button
                  variant="default"
                  onClick={() => setIsEditing(true)}
                  iconName="Edit"
                  iconPosition="left"
                >
                  Edit Information
                </Button>
              ) : (
                <>
                  <Button
                    variant="default"
                    onClick={handleSave}
                    loading={isSaving}
                    iconName="Save"
                    iconPosition="left"
                  >
                    Save Changes
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsEditing(false)}
                    disabled={isSaving}
                  >
                    Cancel
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PersonalInfoSection;
