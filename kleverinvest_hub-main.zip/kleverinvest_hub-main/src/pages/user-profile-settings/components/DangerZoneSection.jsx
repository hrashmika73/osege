import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const DangerZoneSection = ({ isExpanded, onToggle }) => {
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [confirmationText, setConfirmationText] = useState('');
  const [isDeactivating, setIsDeactivating] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportOptions, setExportOptions] = useState({
    profile: true,
    transactions: true,
    investments: true,
    activity: false
  });

  const handleDeactivateAccount = async () => {
    if (confirmationText !== 'DELETE MY ACCOUNT') return;
    
    setIsDeactivating(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 3000));
    setIsDeactivating(false);
    setShowDeactivateModal(false);
    setConfirmationText('');
    
    // In a real app, this would redirect to a confirmation page or logout
    alert('Account deactivation request submitted. You will receive a confirmation email.');
  };

  const handleExportData = async () => {
    setIsExporting(true);
    // Simulate data export
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Create mock export file
    const exportData = {
      profile: exportOptions.profile ? {
        name: 'John Doe',
        email: 'john.doe@example.com',
        phone: '+1 (555) 123-4567',
        joinDate: '2024-01-15'
      } : null,
      transactions: exportOptions.transactions ? [
        { id: 1, type: 'deposit', amount: 1000, date: '2025-01-20' },
        { id: 2, type: 'investment', amount: 500, date: '2025-01-22' }
      ] : null,
      investments: exportOptions.investments ? [
        { id: 1, plan: 'Gold Plan', amount: 500, returns: 75, date: '2025-01-22' }
      ] : null,
      activity: exportOptions.activity ? [
        { action: 'Login', timestamp: '2025-01-29 09:15:23', ip: '192.168.1.100' }
      ] : null
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'account-data-export.json';
    a.click();
    window.URL.revokeObjectURL(url);
    
    setIsExporting(false);
    setShowExportModal(false);
  };

  const handleExportOptionChange = (option, checked) => {
    setExportOptions(prev => ({
      ...prev,
      [option]: checked
    }));
  };

  return (
    <>
      <div className="bg-card border border-destructive/20 rounded-lg">
        <button
          onClick={onToggle}
          className="w-full flex items-center justify-between p-6 text-left hover:bg-destructive/5 transition-colors duration-150"
        >
          <div className="flex items-center space-x-3">
            <Icon name="AlertTriangle" size={20} className="text-destructive" />
            <h3 className="text-lg font-semibold text-foreground">Danger Zone</h3>
          </div>
          <Icon 
            name={isExpanded ? "ChevronUp" : "ChevronDown"} 
            size={20} 
            className="text-muted-foreground" 
          />
        </button>

        {isExpanded && (
          <div className="px-6 pb-6 border-t border-destructive/20 space-y-6">
            {/* Data Export */}
            <div className="p-4 border border-warning/20 rounded-lg bg-warning/5">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-foreground mb-2">Export Account Data</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Download a copy of your account data including profile information, transaction history, and activity logs. This may take a few minutes to process.
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => setShowExportModal(true)}
                    iconName="Download"
                    iconPosition="left"
                  >
                    Export Data
                  </Button>
                </div>
                <Icon name="Download" size={24} className="text-warning mt-1" />
              </div>
            </div>

            {/* Account Deactivation */}
            <div className="p-4 border border-destructive/20 rounded-lg bg-destructive/5">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-foreground mb-2">Deactivate Account</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Permanently deactivate your account and delete all associated data. This action cannot be undone. All investments will be liquidated and funds returned to your registered payment method.
                  </p>
                  <div className="space-y-2 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center space-x-2">
                      <Icon name="AlertCircle" size={14} className="text-destructive" />
                      <span>All investment positions will be closed</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Icon name="AlertCircle" size={14} className="text-destructive" />
                      <span>Referral earnings will be forfeited</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Icon name="AlertCircle" size={14} className="text-destructive" />
                      <span>Account recovery will not be possible</span>
                    </div>
                  </div>
                  <Button
                    variant="destructive"
                    onClick={() => setShowDeactivateModal(true)}
                    iconName="Trash2"
                    iconPosition="left"
                  >
                    Deactivate Account
                  </Button>
                </div>
                <Icon name="Trash2" size={24} className="text-destructive mt-1" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Export Data Modal */}
      {showExportModal && (
        <>
          <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm" />
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="bg-card border rounded-lg shadow-elevation-3 w-full max-w-md">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-foreground">Export Account Data</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowExportModal(false)}
                  >
                    <Icon name="X" size={16} />
                  </Button>
                </div>
                
                <p className="text-sm text-muted-foreground mb-6">
                  Select the data you want to include in your export:
                </p>
                
                <div className="space-y-3 mb-6">
                  <Checkbox
                    label="Profile Information"
                    description="Name, email, phone, and account settings"
                    checked={exportOptions.profile}
                    onChange={(e) => handleExportOptionChange('profile', e.target.checked)}
                  />
                  
                  <Checkbox
                    label="Transaction History"
                    description="Deposits, withdrawals, and transfers"
                    checked={exportOptions.transactions}
                    onChange={(e) => handleExportOptionChange('transactions', e.target.checked)}
                  />
                  
                  <Checkbox
                    label="Investment Records"
                    description="Investment plans, earnings, and performance"
                    checked={exportOptions.investments}
                    onChange={(e) => handleExportOptionChange('investments', e.target.checked)}
                  />
                  
                  <Checkbox
                    label="Activity Logs"
                    description="Login history and security events"
                    checked={exportOptions.activity}
                    onChange={(e) => handleExportOptionChange('activity', e.target.checked)}
                  />
                </div>
                
                <div className="flex space-x-3">
                  <Button
                    variant="default"
                    onClick={handleExportData}
                    loading={isExporting}
                    disabled={!Object.values(exportOptions).some(Boolean)}
                    className="flex-1"
                  >
                    Export Selected Data
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowExportModal(false)}
                    disabled={isExporting}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Deactivate Account Modal */}
      {showDeactivateModal && (
        <>
          <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm" />
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="bg-card border rounded-lg shadow-elevation-3 w-full max-w-md">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-destructive">Deactivate Account</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowDeactivateModal(false)}
                  >
                    <Icon name="X" size={16} />
                  </Button>
                </div>
                
                <div className="space-y-4 mb-6">
                  <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon name="AlertTriangle" size={16} className="text-destructive" />
                      <span className="font-medium text-destructive">Warning</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      This action is permanent and cannot be undone. All your data will be permanently deleted.
                    </p>
                  </div>
                  
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>Before proceeding, please note:</p>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>Your account will be permanently deleted</li>
                      <li>All investments will be liquidated</li>
                      <li>Pending transactions will be cancelled</li>
                      <li>Referral earnings will be forfeited</li>
                    </ul>
                  </div>
                  
                  <Input
                    label="Type 'DELETE MY ACCOUNT' to confirm"
                    type="text"
                    value={confirmationText}
                    onChange={(e) => setConfirmationText(e.target.value)}
                    placeholder="DELETE MY ACCOUNT"
                    required
                  />
                </div>
                
                <div className="flex space-x-3">
                  <Button
                    variant="destructive"
                    onClick={handleDeactivateAccount}
                    loading={isDeactivating}
                    disabled={confirmationText !== 'DELETE MY ACCOUNT'}
                    className="flex-1"
                  >
                    Permanently Delete Account
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowDeactivateModal(false);
                      setConfirmationText('');
                    }}
                    disabled={isDeactivating}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default DangerZoneSection;