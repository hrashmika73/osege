import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Checkbox from '../../../components/ui/Checkbox';

const PreferencesSection = ({ isExpanded, onToggle }) => {
  const [preferences, setPreferences] = useState({
    language: 'en',
    currency: 'USD',
    timezone: 'America/New_York',
    theme: 'light'
  });

  const [notifications, setNotifications] = useState({
    email: {
      transactions: true,
      investments: true,
      security: true,
      marketing: false,
      newsletter: true
    },
    sms: {
      transactions: true,
      investments: false,
      security: true,
      marketing: false
    },
    push: {
      transactions: true,
      investments: true,
      security: true,
      marketing: false
    }
  });

  const [isSaving, setIsSaving] = useState(false);

  const languageOptions = [
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Español' },
    { value: 'fr', label: 'Français' },
    { value: 'de', label: 'Deutsch' },
    { value: 'zh', label: '中文' },
    { value: 'ja', label: '日本語' }
  ];

  const currencyOptions = [
    { value: 'USD', label: 'US Dollar (USD)' },
    { value: 'EUR', label: 'Euro (EUR)' },
    { value: 'GBP', label: 'British Pound (GBP)' },
    { value: 'JPY', label: 'Japanese Yen (JPY)' },
    { value: 'BTC', label: 'Bitcoin (BTC)' },
    { value: 'ETH', label: 'Ethereum (ETH)' }
  ];

  const timezoneOptions = [
    { value: 'America/New_York', label: 'Eastern Time (ET)' },
    { value: 'America/Chicago', label: 'Central Time (CT)' },
    { value: 'America/Denver', label: 'Mountain Time (MT)' },
    { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
    { value: 'Europe/London', label: 'Greenwich Mean Time (GMT)' },
    { value: 'Europe/Paris', label: 'Central European Time (CET)' },
    { value: 'Asia/Tokyo', label: 'Japan Standard Time (JST)' }
  ];

  const themeOptions = [
    { value: 'light', label: 'Light Mode' },
    { value: 'dark', label: 'Dark Mode' },
    { value: 'auto', label: 'Auto (System)' }
  ];

  const handlePreferenceChange = (field, value) => {
    setPreferences(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleNotificationChange = (type, category, value) => {
    setNotifications(prev => ({
      ...prev,
      [type]: {
        ...prev[type],
        [category]: value
      }
    }));
  };

  const handleSavePreferences = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSaving(false);
  };

  const notificationCategories = [
    {
      key: 'transactions',
      label: 'Transaction Alerts',
      description: 'Deposits, withdrawals, and transfers'
    },
    {
      key: 'investments',
      label: 'Investment Updates',
      description: 'Portfolio changes and earnings'
    },
    {
      key: 'security',
      label: 'Security Alerts',
      description: 'Login attempts and security events'
    },
    {
      key: 'marketing',
      label: 'Marketing Communications',
      description: 'Promotional offers and updates'
    },
    {
      key: 'newsletter',
      label: 'Newsletter',
      description: 'Weekly market insights and tips',
      emailOnly: true
    }
  ];

  return (
    <div className="bg-card border rounded-lg">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/50 transition-colors duration-150"
      >
        <div className="flex items-center space-x-3">
          <Icon name="Settings" size={20} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Account Preferences</h3>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-muted-foreground" 
        />
      </button>

      {isExpanded && (
        <div className="px-6 pb-6 border-t space-y-6">
          {/* General Preferences */}
          <div className="space-y-4">
            <h4 className="font-medium text-foreground">General Settings</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Select
                label="Language"
                options={languageOptions}
                value={preferences.language}
                onChange={(value) => handlePreferenceChange('language', value)}
                description="Choose your preferred language"
              />
              
              <Select
                label="Display Currency"
                options={currencyOptions}
                value={preferences.currency}
                onChange={(value) => handlePreferenceChange('currency', value)}
                description="Primary currency for displaying values"
              />
              
              <Select
                label="Timezone"
                options={timezoneOptions}
                value={preferences.timezone}
                onChange={(value) => handlePreferenceChange('timezone', value)}
                description="Used for transaction timestamps"
                searchable
              />
              
              <Select
                label="Theme"
                options={themeOptions}
                value={preferences.theme}
                onChange={(value) => handlePreferenceChange('theme', value)}
                description="Choose your preferred theme"
              />
            </div>
          </div>

          {/* Notification Preferences */}
          <div className="space-y-4 pt-6 border-t">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-foreground">Notification Preferences</h4>
              <Button variant="outline" size="sm">
                Test Notifications
              </Button>
            </div>
            
            <p className="text-sm text-muted-foreground">
              Choose how you want to receive notifications for different types of activities.
            </p>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 pr-4 font-medium text-foreground">Notification Type</th>
                    <th className="text-center py-3 px-2 font-medium text-foreground">Email</th>
                    <th className="text-center py-3 px-2 font-medium text-foreground">SMS</th>
                    <th className="text-center py-3 px-2 font-medium text-foreground">Push</th>
                  </tr>
                </thead>
                <tbody>
                  {notificationCategories.map((category) => (
                    <tr key={category.key} className="border-b last:border-b-0">
                      <td className="py-4 pr-4">
                        <div>
                          <div className="font-medium text-foreground">{category.label}</div>
                          <div className="text-sm text-muted-foreground">{category.description}</div>
                        </div>
                      </td>
                      <td className="text-center py-4 px-2">
                        <Checkbox
                          checked={notifications.email[category.key] || false}
                          onChange={(e) => handleNotificationChange('email', category.key, e.target.checked)}
                        />
                      </td>
                      <td className="text-center py-4 px-2">
                        {!category.emailOnly && (
                          <Checkbox
                            checked={notifications.sms[category.key] || false}
                            onChange={(e) => handleNotificationChange('sms', category.key, e.target.checked)}
                          />
                        )}
                      </td>
                      <td className="text-center py-4 px-2">
                        {!category.emailOnly && (
                          <Checkbox
                            checked={notifications.push[category.key] || false}
                            onChange={(e) => handleNotificationChange('push', category.key, e.target.checked)}
                          />
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Privacy Settings */}
          <div className="space-y-4 pt-6 border-t">
            <h4 className="font-medium text-foreground">Privacy Settings</h4>
            
            <div className="space-y-3">
              <Checkbox
                label="Allow analytics tracking"
                description="Help us improve the platform by sharing anonymous usage data"
                checked
                onChange={() => {}}
              />
              
              <Checkbox
                label="Show online status"
                description="Let other users see when you're active on the platform"
               
                onChange={() => {}}
              />
              
              <Checkbox
                label="Allow third-party integrations"
                description="Enable connections with external financial services"
                checked
                onChange={() => {}}
              />
            </div>
          </div>

          {/* Save Button */}
          <div className="pt-6 border-t">
            <Button
              variant="default"
              onClick={handleSavePreferences}
              loading={isSaving}
              iconName="Save"
              iconPosition="left"
            >
              Save Preferences
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PreferencesSection;