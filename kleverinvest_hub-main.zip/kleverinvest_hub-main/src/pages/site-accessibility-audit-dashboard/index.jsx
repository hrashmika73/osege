import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Select from '../../components/ui/Select';
import RoleBasedNavigation from '../../components/ui/RoleBasedNavigation';
import Header from '../../components/ui/Header';

const SiteAccessibilityAuditDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [auditData, setAuditData] = useState({
    overallScore: 85,
    wcagCompliance: {
      level_a: 95,
      level_aa: 87,
      level_aaa: 68
    },
    issues: {
      critical: 3,
      major: 12,
      minor: 28
    },
    lastScan: '2025-01-29T10:30:00Z'
  });
  const [selectedSeverity, setSelectedSeverity] = useState('all');
  const [selectedPage, setSelectedPage] = useState('all');
  const [isScanning, setIsScanning] = useState(false);

  const auditResults = [
    {
      id: 1,
      page: 'Home Landing Page',
      path: '/home-landing-page',
      issues: [
        { type: 'Color Contrast', severity: 'critical', description: 'Text contrast ratio 3.2:1 (minimum 4.5:1)', element: '.hero-text' },
        { type: 'Missing Alt Text', severity: 'major', description: 'Investment chart image missing alt attribute', element: 'img.chart-image' },
        { type: 'Focus Indicator', severity: 'minor', description: 'CTA button focus outline insufficient', element: '.cta-button' }
      ]
    },
    {
      id: 2,
      page: 'Admin Dashboard',
      path: '/admin-dashboard',
      issues: [
        { type: 'ARIA Labels', severity: 'major', description: 'Navigation menu missing aria-label', element: 'nav.main-nav' },
        { type: 'Keyboard Navigation', severity: 'major', description: 'Modal dialog not keyboard accessible', element: '.modal-dialog' },
        { type: 'Form Labels', severity: 'minor', description: 'Search input missing associated label', element: '#search-input' }
      ]
    },
    {
      id: 3,
      page: 'User Login Portal',
      path: '/user-login-portal',
      issues: [
        { type: 'Touch Target Size', severity: 'critical', description: 'Login button too small for touch (38px minimum)', element: '.login-btn' },
        { type: 'Screen Reader', severity: 'major', description: 'Password visibility toggle missing description', element: '.password-toggle' }
      ]
    }
  ];

  const wcagGuidelines = [
    { id: '1.1.1', title: 'Non-text Content', level: 'A', status: 'pass', description: 'All images have appropriate alt text' },
    { id: '1.4.3', title: 'Contrast (Minimum)', level: 'AA', status: 'fail', description: '3 elements fail contrast requirements' },
    { id: '2.1.1', title: 'Keyboard', level: 'A', status: 'warning', description: 'Some interactive elements need keyboard support' },
    { id: '2.4.3', title: 'Focus Order', level: 'A', status: 'pass', description: 'Focus order is logical and intuitive' },
    { id: '3.3.2', title: 'Labels or Instructions', level: 'A', status: 'warning', description: 'Some form fields missing labels' }
  ];

  const manualTestChecklist = [
    { id: 1, test: 'Screen Reader Navigation', completed: true, notes: 'NVDA and JAWS compatibility verified' },
    { id: 2, test: 'Keyboard-Only Navigation', completed: false, notes: 'Modal dialogs need keyboard trap implementation' },
    { id: 3, test: 'Color Blind Accessibility', completed: true, notes: 'Deuteranopia and Protanopia testing passed' },
    { id: 4, test: 'Mobile Touch Accessibility', completed: false, notes: 'Touch target sizes need adjustment on mobile' },
    { id: 5, test: 'Voice Control Compatibility', completed: true, notes: 'Dragon NaturallySpeaking compatibility confirmed' }
  ];

  const startAutomatedScan = async () => {
    setIsScanning(true);
    
    // Simulate scan process
    setTimeout(() => {
      setAuditData(prev => ({
        ...prev,
        lastScan: new Date().toISOString(),
        overallScore: Math.floor(Math.random() * 10) + 80
      }));
      setIsScanning(false);
    }, 5000);
  };

  const exportReport = (format) => {
    const reportData = {
      timestamp: new Date().toISOString(),
      overallScore: auditData.overallScore,
      wcagCompliance: auditData.wcagCompliance,
      issues: auditResults,
      guidelines: wcagGuidelines
    };
    
    if (format === 'json') {
      const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `accessibility-audit-${Date.now()}.json`;
      a.click();
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-red-400 bg-red-500/10 border-red-500/20';
      case 'major': return 'text-orange-400 bg-orange-500/10 border-orange-500/20';
      case 'minor': return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20';
      default: return 'text-slate-400 bg-slate-500/10 border-slate-500/20';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pass': return 'text-green-400 bg-green-500/10';
      case 'fail': return 'text-red-400 bg-red-500/10';
      case 'warning': return 'text-yellow-400 bg-yellow-500/10';
      default: return 'text-slate-400 bg-slate-500/10';
    }
  };

  const filteredResults = auditResults.filter(result => {
    if (selectedPage !== 'all' && result.path !== selectedPage) return false;
    if (selectedSeverity !== 'all') {
      return result.issues.some(issue => issue.severity === selectedSeverity);
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="flex">
        <RoleBasedNavigation />
        
        <main className="flex-1 p-6 ml-64">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  Site Accessibility Audit Dashboard
                </h1>
                <p className="text-muted-foreground">
                  Comprehensive WCAG 2.1 compliance monitoring and accessibility standards management
                </p>
              </div>
              
              <div className="flex items-center space-x-3">
                <Button
                  onClick={startAutomatedScan}
                  disabled={isScanning}
                  loading={isScanning}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Icon name="Search" size={16} className="mr-2" />
                  {isScanning ? 'Scanning...' : 'Run Scan'}
                </Button>
                
                <Select
                  value="json"
                  onChange={(value) => exportReport(value)}
                  options={[
                    { value: 'json', label: 'Export JSON' },
                    { value: 'pdf', label: 'Export PDF' },
                    { value: 'csv', label: 'Export CSV' }
                  ]}
                />
              </div>
            </div>
          </div>

          {/* Metrics Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Overall Score</p>
                  <p className="text-3xl font-bold text-foreground">{auditData.overallScore}%</p>
                </div>
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${auditData.overallScore >= 90 ? 'bg-green-500/20' : auditData.overallScore >= 70 ? 'bg-orange-500/20' : 'bg-red-500/20'}`}>
                  <Icon name="TrendingUp" size={24} className={auditData.overallScore >= 90 ? 'text-green-400' : auditData.overallScore >= 70 ? 'text-orange-400' : 'text-red-400'} />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Critical Issues</p>
                  <p className="text-3xl font-bold text-red-400">{auditData.issues.critical}</p>
                </div>
                <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center">
                  <Icon name="AlertTriangle" size={24} className="text-red-400" />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">WCAG Level AA</p>
                  <p className="text-3xl font-bold text-foreground">{auditData.wcagCompliance.level_aa}%</p>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
                  <Icon name="CheckCircle" size={24} className="text-blue-400" />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Last Scan</p>
                  <p className="text-lg font-semibold text-foreground">
                    {new Date(auditData.lastScan).toLocaleDateString()}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                  <Icon name="Clock" size={24} className="text-green-400" />
                </div>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="border-b border-border mb-6">
            <nav className="flex space-x-8" role="tablist">
              {[
                { id: 'overview', label: 'Overview', icon: 'BarChart3' },
                { id: 'issues', label: 'Issues', icon: 'AlertCircle' },
                { id: 'wcag', label: 'WCAG Guidelines', icon: 'Shield' },
                { id: 'manual', label: 'Manual Testing', icon: 'CheckSquare' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                  role="tab"
                  aria-selected={activeTab === tab.id}
                  aria-controls={`${tab.id}-panel`}
                >
                  <Icon name={tab.icon} size={16} />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="tab-content">
            {activeTab === 'overview' && (
              <div id="overview-panel" role="tabpanel" aria-labelledby="overview-tab">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* WCAG Compliance Chart */}
                  <div className="bg-card rounded-lg p-6 border border-border">
                    <h3 className="text-lg font-semibold mb-4 text-foreground">WCAG Compliance Levels</h3>
                    <div className="space-y-4">
                      {Object.entries(auditData.wcagCompliance).map(([level, score]) => (
                        <div key={level}>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-sm font-medium text-foreground">
                              Level {level.replace('level_', '').toUpperCase()}
                            </span>
                            <span className="text-sm text-muted-foreground">{score}%</span>
                          </div>
                          <div className="w-full bg-muted rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${score >= 90 ? 'bg-green-500' : score >= 70 ? 'bg-orange-500' : 'bg-red-500'}`}
                              style={{ width: `${score}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Issues Breakdown */}
                  <div className="bg-card rounded-lg p-6 border border-border">
                    <h3 className="text-lg font-semibold mb-4 text-foreground">Issues by Severity</h3>
                    <div className="space-y-4">
                      {Object.entries(auditData.issues).map(([severity, count]) => (
                        <div key={severity} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                          <div className="flex items-center space-x-3">
                            <div className={`w-3 h-3 rounded-full ${getSeverityColor(severity).split(' ')[0].replace('text-', 'bg-')}`} />
                            <span className="font-medium capitalize text-foreground">{severity}</span>
                          </div>
                          <span className="text-lg font-semibold text-foreground">{count}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'issues' && (
              <div id="issues-panel" role="tabpanel" aria-labelledby="issues-tab">
                {/* Filters */}
                <div className="flex flex-wrap gap-4 mb-6">
                  <Select
                    value={selectedSeverity}
                    onChange={setSelectedSeverity}
                    options={[
                      { value: 'all', label: 'All Severities' },
                      { value: 'critical', label: 'Critical' },
                      { value: 'major', label: 'Major' },
                      { value: 'minor', label: 'Minor' }
                    ]}
                    className="min-w-[150px]"
                  />
                  
                  <Select
                    value={selectedPage}
                    onChange={setSelectedPage}
                    options={[
                      { value: 'all', label: 'All Pages' },
                      ...auditResults.map(result => ({
                        value: result.path,
                        label: result.page
                      }))
                    ]}
                    className="min-w-[150px]"
                  />
                </div>

                {/* Issues List */}
                <div className="space-y-4">
                  {filteredResults.map(result => (
                    <div key={result.id} className="bg-card rounded-lg border border-border">
                      <div className="p-4 border-b border-border">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-semibold text-foreground">{result.page}</h3>
                          <span className="text-sm text-muted-foreground">{result.path}</span>
                        </div>
                      </div>
                      
                      <div className="p-4">
                        <div className="space-y-3">
                          {result.issues.map((issue, index) => (
                            <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-muted/30">
                              <div className={`px-2 py-1 rounded text-xs font-medium border ${getSeverityColor(issue.severity)}`}>
                                {issue.severity}
                              </div>
                              
                              <div className="flex-1">
                                <h4 className="font-medium text-foreground">{issue.type}</h4>
                                <p className="text-sm text-muted-foreground mt-1">{issue.description}</p>
                                <code className="text-xs bg-muted px-2 py-1 rounded mt-2 inline-block">
                                  {issue.element}
                                </code>
                              </div>
                              
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => navigate(result.path)}
                              >
                                <Icon name="ExternalLink" size={14} className="mr-1" />
                                View
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'wcag' && (
              <div id="wcag-panel" role="tabpanel" aria-labelledby="wcag-tab">
                <div className="bg-card rounded-lg border border-border">
                  <div className="p-6 border-b border-border">
                    <h3 className="text-lg font-semibold text-foreground">WCAG 2.1 Guidelines Compliance</h3>
                  </div>
                  
                  <div className="p-6">
                    <div className="space-y-4">
                      {wcagGuidelines.map(guideline => (
                        <div key={guideline.id} className="flex items-center justify-between p-4 rounded-lg bg-muted/30">
                          <div className="flex items-center space-x-4">
                            <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(guideline.status)}`}>
                              {guideline.status.toUpperCase()}
                            </div>
                            
                            <div>
                              <div className="flex items-center space-x-2">
                                <span className="font-semibold text-foreground">{guideline.id}</span>
                                <span className="text-sm bg-muted px-2 py-1 rounded">
                                  Level {guideline.level}
                                </span>
                              </div>
                              <h4 className="font-medium text-foreground mt-1">{guideline.title}</h4>
                              <p className="text-sm text-muted-foreground mt-1">{guideline.description}</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <Icon 
                              name={guideline.status === 'pass' ? 'CheckCircle' : guideline.status === 'fail' ? 'XCircle' : 'AlertCircle'} 
                              size={20} 
                              className={guideline.status === 'pass' ? 'text-green-400' : guideline.status === 'fail' ? 'text-red-400' : 'text-yellow-400'} 
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'manual' && (
              <div id="manual-panel" role="tabpanel" aria-labelledby="manual-tab">
                <div className="bg-card rounded-lg border border-border">
                  <div className="p-6 border-b border-border">
                    <h3 className="text-lg font-semibold text-foreground">Manual Testing Checklist</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Systematic review of complex interactions and user flow accessibility
                    </p>
                  </div>
                  
                  <div className="p-6">
                    <div className="space-y-4">
                      {manualTestChecklist.map(test => (
                        <div key={test.id} className="flex items-start space-x-4 p-4 rounded-lg bg-muted/30">
                          <div className="flex items-center mt-1">
                            <Icon 
                              name={test.completed ? 'CheckCircle' : 'Circle'} 
                              size={20} 
                              className={test.completed ? 'text-green-400' : 'text-muted-foreground'} 
                            />
                          </div>
                          
                          <div className="flex-1">
                            <h4 className={`font-medium ${test.completed ? 'text-foreground' : 'text-muted-foreground'}`}>
                              {test.test}
                            </h4>
                            <p className="text-sm text-muted-foreground mt-1">{test.notes}</p>
                          </div>
                          
                          <Button
                            size="sm"
                            variant={test.completed ? "outline" : "default"}
                            onClick={() => {
                              // Toggle completion status
                              const updatedChecklist = manualTestChecklist.map(item =>
                                item.id === test.id ? { ...item, completed: !item.completed } : item
                              );
                              // In real app, update state
                              console.log('Updated checklist:', updatedChecklist);
                            }}
                          >
                            {test.completed ? 'Retest' : 'Mark Complete'}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default SiteAccessibilityAuditDashboard;