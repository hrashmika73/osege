import React from 'react';
import Icon from '../../../components/AppIcon';

const AccessibilityScoreCard = ({ score, title, description, icon, color = 'blue' }) => {
  const getColorClasses = (colorName, score) => {
    if (score >= 90) {
      return {
        bg: 'bg-green-500/20',
        text: 'text-green-400',
        icon: 'text-green-400'
      };
    } else if (score >= 70) {
      return {
        bg: 'bg-orange-500/20',
        text: 'text-orange-400',
        icon: 'text-orange-400'
      };
    } else {
      return {
        bg: 'bg-red-500/20',
        text: 'text-red-400',
        icon: 'text-red-400'
      };
    }
  };

  const colors = getColorClasses(color, score);

  return (
    <div className="bg-card rounded-lg p-6 border border-border">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{title}</p>
          <p className={`text-3xl font-bold ${colors.text}`}>{score}%</p>
          {description && (
            <p className="text-xs text-muted-foreground mt-1">{description}</p>
          )}
        </div>
        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${colors.bg}`}>
          <Icon name={icon} size={24} className={colors.icon} />
        </div>
      </div>
    </div>
  );
};

export default AccessibilityScoreCard;