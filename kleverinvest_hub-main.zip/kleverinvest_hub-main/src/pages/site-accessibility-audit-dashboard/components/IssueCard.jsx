import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const IssueCard = ({ issue, onViewDetails, onMarkResolved }) => {
  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-red-400 bg-red-500/10 border-red-500/20';
      case 'major': return 'text-orange-400 bg-orange-500/10 border-orange-500/20';
      case 'minor': return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20';
      default: return 'text-slate-400 bg-slate-500/10 border-slate-500/20';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'critical': return 'AlertTriangle';
      case 'major': return 'AlertCircle';
      case 'minor': return 'Info';
      default: return 'HelpCircle';
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-4">
      <div className="flex items-start space-x-3">
        <div className={`p-2 rounded-full ${getSeverityColor(issue.severity).split(' ')[1]} ${getSeverityColor(issue.severity).split(' ')[2]}`}>
          <Icon 
            name={getSeverityIcon(issue.severity)} 
            size={16} 
            className={getSeverityColor(issue.severity).split(' ')[0]} 
          />
        </div>
        
        <div className="flex-1">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-semibold text-foreground">{issue.type}</h4>
            <div className={`px-2 py-1 rounded text-xs font-medium border ${getSeverityColor(issue.severity)}`}>
              {issue.severity}
            </div>
          </div>
          
          <p className="text-sm text-muted-foreground mb-3">{issue.description}</p>
          
          <div className="flex items-center justify-between">
            <code className="text-xs bg-muted px-2 py-1 rounded font-mono">
              {issue.element}
            </code>
            
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => onViewDetails(issue)}
              >
                <Icon name="Eye" size={14} className="mr-1" />
                Details
              </Button>
              
              <Button
                size="sm"
                variant="default"
                onClick={() => onMarkResolved(issue)}
              >
                <Icon name="Check" size={14} className="mr-1" />
                Resolve
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IssueCard;