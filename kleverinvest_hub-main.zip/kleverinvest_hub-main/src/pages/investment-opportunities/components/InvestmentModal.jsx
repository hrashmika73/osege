import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';
import { cn } from '../../../utils/cn';

const InvestmentModal = ({ opportunity, onClose }) => {
  const [investmentAmount, setInvestmentAmount] = useState(opportunity.minAmount);
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1); // 1: Details, 2: Amount, 3: Confirmation

  const getRiskColor = (riskLevel) => {
    switch (riskLevel) {
      case 'low':
        return 'bg-success/10 text-success border-success/20';
      case 'medium':
        return 'bg-warning/10 text-warning border-warning/20';
      case 'high':
        return 'bg-error/10 text-error border-error/20';
      default:
        return 'bg-muted/10 text-muted-foreground border-muted/20';
    }
  };

  const calculateProjectedReturn = () => {
    const principal = parseFloat(investmentAmount) || 0;
    const rate = opportunity.expectedReturn / 100;
    const time = opportunity.duration / 365;
    return principal * rate * time;
  };

  const handleAmountChange = (value) => {
    const numValue = parseFloat(value) || 0;
    if (numValue >= opportunity.minAmount && numValue <= opportunity.maxAmount) {
      setInvestmentAmount(numValue);
    }
  };

  const handleInvest = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setLoading(false);
    onClose();
    // Navigate to success page or show success message
  };

  const isValidAmount = investmentAmount >= opportunity.minAmount && 
                       investmentAmount <= opportunity.maxAmount;

  const projectedReturn = calculateProjectedReturn();
  const totalReturn = parseFloat(investmentAmount) + projectedReturn;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-card border rounded-lg w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-foreground">{opportunity.name}</h2>
              <div className="flex items-center space-x-2 mt-1">
                <span className={cn(
                  "px-2 py-1 rounded-full text-xs font-medium border capitalize",
                  getRiskColor(opportunity.riskLevel)
                )}>
                  {opportunity.riskLevel} Risk
                </span>
                <span className="text-sm text-muted-foreground">
                  {opportunity.duration} days • {opportunity.expectedReturn}% APY
                </span>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <Icon name="X" size={20} />
            </Button>
          </div>
        </div>

        <div className="overflow-auto max-h-[calc(90vh-200px)]">
          {step === 1 && (
            <div className="p-6 space-y-6">
              {/* Investment Overview */}
              <div>
                <h3 className="font-semibold text-foreground mb-3">Investment Overview</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Expected Return</p>
                    <p className="text-lg font-bold text-success">{opportunity.expectedReturn}%</p>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Duration</p>
                    <p className="text-lg font-bold text-foreground">{opportunity.duration} days</p>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Min Investment</p>
                    <p className="text-lg font-bold text-foreground">${opportunity.minAmount.toLocaleString()}</p>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Available</p>
                    <p className="text-lg font-bold text-foreground">{opportunity.availableSlots}</p>
                  </div>
                </div>
              </div>

              {/* Asset Allocation */}
              <div>
                <h3 className="font-semibold text-foreground mb-3">Asset Allocation</h3>
                <div className="space-y-2">
                  {Object.entries(opportunity.assetAllocation || {}).map(([asset, percentage]) => (
                    <div key={asset} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 bg-primary rounded"></div>
                        <span className="font-medium text-foreground">{asset}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-muted rounded-full h-2">
                          <div
                            className="bg-primary h-2 rounded-full"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        <span className="text-sm font-medium text-foreground w-8">{percentage}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Key Features */}
              <div>
                <h3 className="font-semibold text-foreground mb-3">Key Features</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {opportunity.features?.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2 p-3 bg-muted/50 rounded-lg">
                      <Icon name="CheckCircle" size={16} className="text-success flex-shrink-0" />
                      <span className="text-sm text-foreground">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Risk Information */}
              <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <Icon name="AlertTriangle" size={20} className="text-warning flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-warning mb-1">Risk Disclosure</h4>
                    <p className="text-sm text-foreground">
                      This is a <strong>{opportunity.riskLevel}</strong> risk investment. 
                      Cryptocurrency investments are subject to market volatility and you may lose 
                      some or all of your investment. Past performance does not guarantee future results.
                    </p>
                  </div>
                </div>
              </div>

              {/* Manager Information */}
              <div>
                <h3 className="font-semibold text-foreground mb-3">Fund Manager</h3>
                <div className="flex items-center space-x-4 p-4 bg-muted/50 rounded-lg">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <Icon name="User" size={24} className="text-primary" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-foreground">{opportunity.manager}</h4>
                    <div className="flex items-center space-x-2">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Icon
                            key={i}
                            name="Star"
                            size={14}
                            className={cn(
                              i < Math.floor(opportunity.managerRating) 
                                ? "text-warning fill-current" :"text-muted-foreground"
                            )}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {opportunity.managerRating} rating
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="p-6 space-y-6">
              <div>
                <h3 className="font-semibold text-foreground mb-3">Investment Amount</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Choose your investment amount between ${opportunity.minAmount.toLocaleString()} and ${opportunity.maxAmount.toLocaleString()}
                </p>
              </div>

              {/* Amount Input */}
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Investment Amount (USD)
                </label>
                <Input
                  type="number"
                  value={investmentAmount}
                  onChange={(e) => handleAmountChange(e.target.value)}
                  min={opportunity.minAmount}
                  max={opportunity.maxAmount}
                  className="text-lg"
                />
                <div className="flex justify-between mt-2">
                  <span className="text-xs text-muted-foreground">
                    Min: ${opportunity.minAmount.toLocaleString()}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    Max: ${opportunity.maxAmount.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Quick Amount Buttons */}
              <div>
                <p className="text-sm font-medium text-foreground mb-2">Quick Select</p>
                <div className="grid grid-cols-4 gap-2">
                  {[opportunity.minAmount, 5000, 10000, 25000].filter(amount => 
                    amount >= opportunity.minAmount && amount <= opportunity.maxAmount
                  ).map((amount) => (
                    <Button
                      key={amount}
                      variant={investmentAmount === amount ? "default" : "outline"}
                      size="sm"
                      onClick={() => setInvestmentAmount(amount)}
                    >
                      ${amount.toLocaleString()}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Investment Summary */}
              {isValidAmount && (
                <div className="bg-muted/50 rounded-lg p-4 space-y-3">
                  <h4 className="font-medium text-foreground">Investment Summary</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Investment Amount</span>
                      <span className="text-sm font-medium text-foreground">
                        ${parseFloat(investmentAmount).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Expected Return</span>
                      <span className="text-sm font-medium text-success">
                        +${projectedReturn.toLocaleString(undefined, { 
                          minimumFractionDigits: 2, 
                          maximumFractionDigits: 2 
                        })}
                      </span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span className="font-medium text-foreground">Total at Maturity</span>
                      <span className="font-bold text-foreground">
                        ${totalReturn.toLocaleString(undefined, { 
                          minimumFractionDigits: 2, 
                          maximumFractionDigits: 2 
                        })}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Terms Agreement */}
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="terms"
                    checked={agreeToTerms}
                    onChange={setAgreeToTerms}
                    className="mt-0.5"
                  />
                  <label htmlFor="terms" className="text-sm text-foreground">
                    I agree to the{' '}
                    <button className="text-primary hover:underline">Terms of Service</button>
                    {' '}and{' '}
                    <button className="text-primary hover:underline">Risk Disclosure</button>
                    . I understand that cryptocurrency investments carry risk and I may lose some or all of my investment.
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t bg-muted/20">
          <div className="flex justify-between items-center">
            {step === 1 && (
              <>
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button onClick={() => setStep(2)}>
                  Continue to Investment
                  <Icon name="ArrowRight" size={16} className="ml-2" />
                </Button>
              </>
            )}
            
            {step === 2 && (
              <>
                <Button variant="outline" onClick={() => setStep(1)}>
                  <Icon name="ArrowLeft" size={16} className="mr-2" />
                  Back
                </Button>
                <Button
                  onClick={handleInvest}
                  disabled={!isValidAmount || !agreeToTerms || loading}
                  loading={loading}
                >
                  {loading ? 'Processing...' : `Invest $${parseFloat(investmentAmount).toLocaleString()}`}
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvestmentModal;