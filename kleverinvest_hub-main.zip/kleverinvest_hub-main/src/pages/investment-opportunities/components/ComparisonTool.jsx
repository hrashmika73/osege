import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { cn } from '../../../utils/cn';

const ComparisonTool = ({ opportunities, onClose, onInvestClick }) => {
  const getRiskColor = (riskLevel) => {
    switch (riskLevel) {
      case 'low':
        return 'text-success';
      case 'medium':
        return 'text-warning';
      case 'high':
        return 'text-error';
      default:
        return 'text-muted-foreground';
    }
  };

  const comparisonMetrics = [
    { key: 'expectedReturn', label: 'Expected Return', suffix: '%', highlight: 'max' },
    { key: 'duration', label: 'Duration', suffix: ' days', highlight: 'min' },
    { key: 'minAmount', label: 'Min Investment', prefix: '$', highlight: 'min' },
    { key: 'riskLevel', label: 'Risk Level', highlight: 'none' },
    { key: 'availableSlots', label: 'Available Slots', highlight: 'max' },
    { key: 'managerRating', label: 'Manager Rating', suffix: ' ★', highlight: 'max' },
    { key: 'apy', label: 'APY', suffix: '%', highlight: 'max' },
    { key: 'volatility', label: 'Volatility', highlight: 'none' }
  ];

  const getBestValue = (metric, opportunities) => {
    if (metric.highlight === 'none') return null;
    
    const values = opportunities.map(op => {
      let value = op[metric.key];
      if (metric.key === 'minAmount') value = value;
      if (metric.key === 'expectedReturn' || metric.key === 'apy') value = value;
      if (metric.key === 'duration') value = value;
      if (metric.key === 'availableSlots') value = value;
      if (metric.key === 'managerRating') value = value;
      return value;
    });

    if (metric.highlight === 'max') {
      return Math.max(...values);
    } else if (metric.highlight === 'min') {
      return Math.min(...values);
    }
    return null;
  };

  const formatValue = (value, metric) => {
    if (metric.key === 'minAmount') {
      return `${metric.prefix || ''}${value.toLocaleString()}${metric.suffix || ''}`;
    }
    if (metric.key === 'riskLevel') {
      return value.charAt(0).toUpperCase() + value.slice(1);
    }
    return `${metric.prefix || ''}${value}${metric.suffix || ''}`;
  };

  const isHighlighted = (value, metric, opportunities) => {
    const bestValue = getBestValue(metric, opportunities);
    return bestValue !== null && value === bestValue;
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-card border rounded-lg w-full max-w-6xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-foreground">Compare Investments</h2>
              <p className="text-sm text-muted-foreground">
                Side-by-side comparison of {opportunities.length} opportunities
              </p>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <Icon name="X" size={20} />
            </Button>
          </div>
        </div>

        {/* Comparison Table */}
        <div className="overflow-auto max-h-[calc(90vh-200px)]">
          <div className="p-6">
            {/* Opportunity Headers */}
            <div className="grid gap-4 mb-6" style={{ gridTemplateColumns: `200px repeat(${opportunities.length}, 1fr)` }}>
              <div></div>
              {opportunities.map((opportunity) => (
                <div key={opportunity.id} className="bg-muted/50 rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2 leading-tight">
                    {opportunity.name}
                  </h3>
                  <div className="flex items-center space-x-2 mb-2">
                    {opportunity.featured && (
                      <span className="bg-primary/10 text-primary border border-primary/20 px-2 py-1 rounded-full text-xs font-medium">
                        Featured
                      </span>
                    )}
                    {opportunity.trending && (
                      <span className="bg-accent/10 text-accent border border-accent/20 px-2 py-1 rounded-full text-xs font-medium">
                        Trending
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mb-3">
                    {opportunity.description}
                  </p>
                  <Button
                    size="sm"
                    className="w-full"
                    onClick={() => onInvestClick(opportunity)}
                  >
                    <Icon name="Plus" size={16} />
                    Invest
                  </Button>
                </div>
              ))}
            </div>

            {/* Comparison Metrics */}
            <div className="space-y-4">
              {comparisonMetrics.map((metric) => (
                <div
                  key={metric.key}
                  className="grid gap-4 py-3 border-b border-border/50"
                  style={{ gridTemplateColumns: `200px repeat(${opportunities.length}, 1fr)` }}
                >
                  <div className="font-medium text-foreground flex items-center">
                    {metric.label}
                  </div>
                  {opportunities.map((opportunity) => {
                    let value = opportunity[metric.key];
                    const highlighted = isHighlighted(value, metric, opportunities);
                    
                    return (
                      <div
                        key={`${opportunity.id}-${metric.key}`}
                        className={cn(
                          "text-sm flex items-center justify-center p-2 rounded",
                          highlighted && "bg-success/10 border border-success/20 font-semibold",
                          !highlighted && "text-muted-foreground"
                        )}
                      >
                        {metric.key === 'riskLevel' ? (
                          <span className={cn(
                            "px-2 py-1 rounded-full text-xs font-medium border capitalize",
                            metric.key === 'riskLevel' && getRiskColor(value) === 'text-success' && 'bg-success/10 text-success border-success/20',
                            metric.key === 'riskLevel' && getRiskColor(value) === 'text-warning' && 'bg-warning/10 text-warning border-warning/20',
                            metric.key === 'riskLevel' && getRiskColor(value) === 'text-error' && 'bg-error/10 text-error border-error/20'
                          )}>
                            {formatValue(value, metric)}
                          </span>
                        ) : (
                          <span className={cn(highlighted && "text-success")}>
                            {formatValue(value, metric)}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              ))}

              {/* Asset Allocation */}
              <div
                className="grid gap-4 py-3 border-b border-border/50"
                style={{ gridTemplateColumns: `200px repeat(${opportunities.length}, 1fr)` }}
              >
                <div className="font-medium text-foreground flex items-center">
                  Asset Allocation
                </div>
                {opportunities.map((opportunity) => (
                  <div key={`${opportunity.id}-assets`} className="text-center">
                    <div className="flex flex-wrap gap-1 justify-center">
                      {Object.entries(opportunity.assetAllocation || {}).map(([asset, percentage]) => (
                        <span
                          key={asset}
                          className="bg-muted text-foreground px-2 py-1 rounded text-xs"
                        >
                          {asset}: {percentage}%
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Features */}
              <div
                className="grid gap-4 py-3"
                style={{ gridTemplateColumns: `200px repeat(${opportunities.length}, 1fr)` }}
              >
                <div className="font-medium text-foreground flex items-center">
                  Key Features
                </div>
                {opportunities.map((opportunity) => (
                  <div key={`${opportunity.id}-features`} className="text-center">
                    <div className="space-y-1">
                      {opportunity.features?.slice(0, 3).map((feature, index) => (
                        <div
                          key={index}
                          className="text-xs bg-muted/50 text-foreground px-2 py-1 rounded"
                        >
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t bg-muted/20">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              Compare key metrics to make informed investment decisions
            </p>
            <Button variant="outline" onClick={onClose}>
              Close Comparison
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComparisonTool;