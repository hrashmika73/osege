import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { cn } from '../../../utils/cn';

const OpportunityCard = ({ 
  opportunity, 
  isSelected, 
  onCompareToggle, 
  onInvestClick, 
  showCompareButton 
}) => {
  const getRiskColor = (riskLevel) => {
    switch (riskLevel) {
      case 'low':
        return 'bg-success/10 text-success border-success/20';
      case 'medium':
        return 'bg-warning/10 text-warning border-warning/20';
      case 'high':
        return 'bg-error/10 text-error border-error/20';
      default:
        return 'bg-muted/10 text-muted-foreground border-muted/20';
    }
  };

  const getAvailabilityColor = (available, total) => {
    const percentage = (available / total) * 100;
    if (percentage > 50) return 'text-success';
    if (percentage > 20) return 'text-warning';
    return 'text-error';
  };

  const availabilityPercentage = (opportunity.availableSlots / opportunity.totalSlots) * 100;

  return (
    <div className={cn(
      "bg-card border rounded-lg overflow-hidden hover:shadow-lg transition-all duration-200 relative",
      isSelected && "ring-2 ring-primary"
    )}>
      {/* Header with badges */}
      <div className="relative p-4 pb-0">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-2">
            {opportunity.featured && (
              <span className="bg-primary/10 text-primary border border-primary/20 px-2 py-1 rounded-full text-xs font-medium">
                Featured
              </span>
            )}
            {opportunity.trending && (
              <span className="bg-accent/10 text-accent border border-accent/20 px-2 py-1 rounded-full text-xs font-medium flex items-center">
                <Icon name="TrendingUp" size={12} className="mr-1" />
                Trending
              </span>
            )}
          </div>
          
          {showCompareButton && (
            <Button
              variant={isSelected ? "default" : "ghost"}
              size="xs"
              onClick={onCompareToggle}
            >
              <Icon name="GitCompare" size={14} />
            </Button>
          )}
        </div>

        <h3 className="text-lg font-semibold text-foreground mb-1">
          {opportunity.name}
        </h3>
        <p className="text-sm text-muted-foreground mb-3">
          {opportunity.description}
        </p>
      </div>

      {/* Key Metrics */}
      <div className="px-4 pb-4">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Expected Return</p>
            <p className="text-xl font-bold text-success">
              {opportunity.expectedReturn}%
            </p>
            <p className="text-xs text-muted-foreground">APY</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Duration</p>
            <p className="text-xl font-bold text-foreground">
              {opportunity.duration}
            </p>
            <p className="text-xs text-muted-foreground">days</p>
          </div>
        </div>

        {/* Risk Level */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">Risk Level:</span>
            <span className={cn(
              "px-2 py-1 rounded-full text-xs font-medium border capitalize",
              getRiskColor(opportunity.riskLevel)
            )}>
              {opportunity.riskLevel}
            </span>
          </div>
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Icon
                key={i}
                name="Star"
                size={12}
                className={cn(
                  i < Math.floor(opportunity.managerRating) 
                    ? "text-warning fill-current" :"text-muted-foreground"
                )}
              />
            ))}
          </div>
        </div>

        {/* Investment Range */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-muted-foreground">Investment Range</span>
            <span className="text-xs font-medium text-foreground">
              ${opportunity.minAmount.toLocaleString()} - ${opportunity.maxAmount.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Availability */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-muted-foreground">Availability</span>
            <span className={cn(
              "text-xs font-medium",
              getAvailabilityColor(opportunity.availableSlots, opportunity.totalSlots)
            )}>
              {opportunity.availableSlots}/{opportunity.totalSlots} slots
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className={cn(
                "h-2 rounded-full transition-all duration-300",
                availabilityPercentage > 50 ? "bg-success" :
                availabilityPercentage > 20 ? "bg-warning" : "bg-error"
              )}
              style={{ width: `${100 - availabilityPercentage}%` }}
            />
          </div>
        </div>

        {/* Asset Allocation Preview */}
        <div className="mb-4">
          <p className="text-xs text-muted-foreground mb-2">Assets</p>
          <div className="flex flex-wrap gap-1">
            {opportunity.assets.slice(0, 3).map((asset) => (
              <span
                key={asset}
                className="bg-muted/50 text-foreground px-2 py-1 rounded text-xs font-medium"
              >
                {asset}
              </span>
            ))}
            {opportunity.assets.length > 3 && (
              <span className="bg-muted/50 text-muted-foreground px-2 py-1 rounded text-xs">
                +{opportunity.assets.length - 3} more
              </span>
            )}
          </div>
        </div>

        {/* Time Remaining */}
        {opportunity.timeRemaining !== 'Always available' && (
          <div className="mb-4 p-2 bg-warning/10 border border-warning/20 rounded">
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={14} className="text-warning" />
              <span className="text-xs font-medium text-warning">
                {opportunity.timeRemaining} remaining
              </span>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
          >
            <Icon name="Info" size={16} />
            Details
          </Button>
          <Button
            size="sm"
            className="flex-1"
            onClick={onInvestClick}
            disabled={opportunity.availableSlots === 0}
          >
            <Icon name="Plus" size={16} />
            Invest
          </Button>
        </div>

        {/* Manager Info */}
        <div className="mt-3 pt-3 border-t flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center">
              <Icon name="User" size={12} className="text-primary" />
            </div>
            <span className="text-xs text-muted-foreground">{opportunity.manager}</span>
          </div>
          <div className="text-xs text-muted-foreground">
            {opportunity.managerRating} ★
          </div>
        </div>
      </div>
    </div>
  );
};

export default OpportunityCard;