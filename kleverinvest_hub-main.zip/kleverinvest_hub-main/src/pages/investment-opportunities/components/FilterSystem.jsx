import React from 'react';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';

const FilterSystem = ({ selectedFilters, onFiltersChange, sortBy, onSortChange }) => {
  const updateFilter = (key, value) => {
    onFiltersChange(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const clearFilters = () => {
    onFiltersChange({
      riskLevel: 'all',
      returnRange: 'all',
      duration: 'all',
      minAmount: ''
    });
  };

  const hasActiveFilters = Object.values(selectedFilters).some(value => 
    value !== 'all' && value !== ''
  );

  return (
    <div className="bg-card border rounded-lg p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-medium text-foreground">Filters</h3>
        {hasActiveFilters && (
          <Button variant="ghost" size="xs" onClick={clearFilters}>
            <Icon name="X" size={14} />
            Clear All
          </Button>
        )}
      </div>

      {/* Mobile: Stacked filters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Risk Level Filter */}
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Risk Level</label>
          <Select
            value={selectedFilters.riskLevel}
            onValueChange={(value) => updateFilter('riskLevel', value)}
            className="w-full"
          >
            <option value="all">All Risks</option>
            <option value="low">Low Risk</option>
            <option value="medium">Medium Risk</option>
            <option value="high">High Risk</option>
          </Select>
        </div>

        {/* Return Range Filter */}
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Expected Return</label>
          <Select
            value={selectedFilters.returnRange}
            onValueChange={(value) => updateFilter('returnRange', value)}
            className="w-full"
          >
            <option value="all">All Returns</option>
            <option value="low">Below 15%</option>
            <option value="medium">15% - 30%</option>
            <option value="high">Above 30%</option>
          </Select>
        </div>

        {/* Duration Filter */}
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Duration</label>
          <Select
            value={selectedFilters.duration}
            onValueChange={(value) => updateFilter('duration', value)}
            className="w-full"
          >
            <option value="all">All Durations</option>
            <option value="short">≤ 60 days</option>
            <option value="medium">61-120 days</option>
            <option value="long">&gt; 120 days</option>
          </Select>
        </div>

        {/* Min Amount Filter */}
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Max Min. Amount</label>
          <Input
            type="number"
            placeholder="Enter amount"
            value={selectedFilters.minAmount}
            onChange={(e) => updateFilter('minAmount', e.target.value)}
            className="w-full"
          />
        </div>
      </div>

      {/* Quick Filter Tags */}
      <div className="flex flex-wrap gap-2">
        <Button
          variant={selectedFilters.riskLevel === 'low' ? 'default' : 'outline'}
          size="xs"
          onClick={() => updateFilter('riskLevel', selectedFilters.riskLevel === 'low' ? 'all' : 'low')}
        >
          Low Risk
        </Button>
        <Button
          variant={selectedFilters.returnRange === 'high' ? 'default' : 'outline'}
          size="xs"
          onClick={() => updateFilter('returnRange', selectedFilters.returnRange === 'high' ? 'all' : 'high')}
        >
          High Return
        </Button>
        <Button
          variant={selectedFilters.duration === 'short' ? 'default' : 'outline'}
          size="xs"
          onClick={() => updateFilter('duration', selectedFilters.duration === 'short' ? 'all' : 'short')}
        >
          Short Term
        </Button>
      </div>

      {/* Active Filter Summary */}
      {hasActiveFilters && (
        <div className="pt-2 border-t">
          <div className="flex flex-wrap gap-2">
            {selectedFilters.riskLevel !== 'all' && (
              <span className="bg-primary/10 text-primary px-2 py-1 rounded-full text-xs flex items-center">
                Risk: {selectedFilters.riskLevel}
                <button
                  onClick={() => updateFilter('riskLevel', 'all')}
                  className="ml-1 hover:bg-primary/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={10} />
                </button>
              </span>
            )}
            {selectedFilters.returnRange !== 'all' && (
              <span className="bg-success/10 text-success px-2 py-1 rounded-full text-xs flex items-center">
                Return: {selectedFilters.returnRange}
                <button
                  onClick={() => updateFilter('returnRange', 'all')}
                  className="ml-1 hover:bg-success/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={10} />
                </button>
              </span>
            )}
            {selectedFilters.duration !== 'all' && (
              <span className="bg-warning/10 text-warning px-2 py-1 rounded-full text-xs flex items-center">
                Duration: {selectedFilters.duration}
                <button
                  onClick={() => updateFilter('duration', 'all')}
                  className="ml-1 hover:bg-warning/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={10} />
                </button>
              </span>
            )}
            {selectedFilters.minAmount && (
              <span className="bg-accent/10 text-accent px-2 py-1 rounded-full text-xs flex items-center">
                Max Min: ${selectedFilters.minAmount}
                <button
                  onClick={() => updateFilter('minAmount', '')}
                  className="ml-1 hover:bg-accent/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={10} />
                </button>
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterSystem;