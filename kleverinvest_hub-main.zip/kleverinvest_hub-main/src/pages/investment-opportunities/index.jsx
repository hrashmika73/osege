import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Select from '../../components/ui/Select';
import Input from '../../components/ui/Input';
import OpportunityCard from './components/OpportunityCard';
import FilterSystem from './components/FilterSystem';
import ComparisonTool from './components/ComparisonTool';
import InvestmentModal from './components/InvestmentModal';

const InvestmentOpportunities = () => {
  const navigate = useNavigate();
  const [opportunities, setOpportunities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilters, setSelectedFilters] = useState({
    riskLevel: 'all',
    returnRange: 'all',
    duration: 'all',
    minAmount: ''
  });
  const [sortBy, setSortBy] = useState('featured');
  const [selectedForComparison, setSelectedForComparison] = useState([]);
  const [showComparison, setShowComparison] = useState(false);
  const [selectedInvestment, setSelectedInvestment] = useState(null);
  const [showInvestmentModal, setShowInvestmentModal] = useState(false);

  // Simulate data loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setOpportunities(mockOpportunities);
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  // Mock opportunities data
  const mockOpportunities = [
    {
      id: 1,
      name: 'Bitcoin Growth Package',
      description: 'Conservative long-term Bitcoin investment strategy',
      category: 'Cryptocurrency',
      expectedReturn: 18.5,
      duration: 90,
      minAmount: 1000,
      maxAmount: 50000,
      riskLevel: 'medium',
      riskScore: 6,
      availableSlots: 45,
      totalSlots: 100,
      assets: ['BTC', 'ETH'],
      assetAllocation: { BTC: 70, ETH: 30 },
      historicalPerformance: [12, 15, 18, 22, 18],
      fees: { management: 1.5, performance: 10 },
      features: ['Auto-rebalancing', 'Compound returns', 'Risk management'],
      featured: true,
      trending: true,
      timeRemaining: '5 days',
      manager: 'Elite Crypto Fund',
      managerRating: 4.8,
      apy: 18.5,
      volatility: 'Medium'
    },
    {
      id: 2,
      name: 'DeFi Yield Farming Plus',
      description: 'High-yield DeFi strategies with automated optimization',
      category: 'DeFi',
      expectedReturn: 35.2,
      duration: 60,
      minAmount: 500,
      maxAmount: 25000,
      riskLevel: 'high',
      riskScore: 8,
      availableSlots: 23,
      totalSlots: 50,
      assets: ['USDC', 'DAI', 'COMP', 'AAVE'],
      assetAllocation: { USDC: 40, DAI: 30, COMP: 15, AAVE: 15 },
      historicalPerformance: [25, 30, 35, 42, 35],
      fees: { management: 2.0, performance: 15 },
      features: ['Yield optimization', 'Auto-compounding', 'Liquidity farming'],
      featured: true,
      trending: false,
      timeRemaining: '2 days',
      manager: 'DeFi Masters',
      managerRating: 4.6,
      apy: 35.2,
      volatility: 'High'
    },
    {
      id: 3,
      name: 'Stablecoin Savings Pool',
      description: 'Low-risk stablecoin investment with steady returns',
      category: 'Stablecoin',
      expectedReturn: 8.5,
      duration: 30,
      minAmount: 100,
      maxAmount: 100000,
      riskLevel: 'low',
      riskScore: 2,
      availableSlots: 150,
      totalSlots: 200,
      assets: ['USDT', 'USDC', 'BUSD'],
      assetAllocation: { USDT: 40, USDC: 35, BUSD: 25 },
      historicalPerformance: [6, 7, 8, 9, 8.5],
      fees: { management: 0.5, performance: 5 },
      features: ['Capital protection', 'Daily interest', 'Instant liquidity'],
      featured: false,
      trending: true,
      timeRemaining: 'Always available',
      manager: 'Stable Returns LLC',
      managerRating: 4.9,
      apy: 8.5,
      volatility: 'Very Low'
    },
    {
      id: 4,
      name: 'Altcoin Discovery Fund',
      description: 'Diversified portfolio of emerging altcoins with high potential',
      category: 'Altcoins',
      expectedReturn: 45.8,
      duration: 120,
      minAmount: 2000,
      maxAmount: 30000,
      riskLevel: 'high',
      riskScore: 9,
      availableSlots: 12,
      totalSlots: 25,
      assets: ['SOL', 'AVAX', 'MATIC', 'DOT', 'LINK'],
      assetAllocation: { SOL: 25, AVAX: 20, MATIC: 20, DOT: 20, LINK: 15 },
      historicalPerformance: [30, 40, 45, 55, 46],
      fees: { management: 2.5, performance: 20 },
      features: ['Expert selection', 'Research-backed', 'Early access'],
      featured: true,
      trending: false,
      timeRemaining: '1 day',
      manager: 'Crypto Pioneers',
      managerRating: 4.4,
      apy: 45.8,
      volatility: 'Very High'
    },
    {
      id: 5,
      name: 'Ethereum Staking Rewards',
      description: 'Participate in Ethereum 2.0 staking with guaranteed returns',
      category: 'Staking',
      expectedReturn: 12.8,
      duration: 180,
      minAmount: 800,
      maxAmount: 40000,
      riskLevel: 'low',
      riskScore: 3,
      availableSlots: 78,
      totalSlots: 120,
      assets: ['ETH'],
      assetAllocation: { ETH: 100 },
      historicalPerformance: [10, 11, 12, 13, 12.8],
      fees: { management: 1.0, performance: 8 },
      features: ['Network rewards', 'Validator selection', 'Slashing protection'],
      featured: false,
      trending: true,
      timeRemaining: '10 days',
      manager: 'Ethereum Validators',
      managerRating: 4.7,
      apy: 12.8,
      volatility: 'Low'
    },
    {
      id: 6,
      name: 'NFT Market Maker Fund',
      description: 'Generate returns through NFT trading and market making',
      category: 'NFT',
      expectedReturn: 28.4,
      duration: 90,
      minAmount: 1500,
      maxAmount: 20000,
      riskLevel: 'high',
      riskScore: 8,
      availableSlots: 8,
      totalSlots: 15,
      assets: ['ETH', 'WETH'],
      assetAllocation: { ETH: 60, WETH: 40 },
      historicalPerformance: [20, 25, 28, 32, 28],
      fees: { management: 3.0, performance: 25 },
      features: ['NFT expertise', 'Market analysis', 'Exclusive access'],
      featured: false,
      trending: false,
      timeRemaining: '3 days',
      manager: 'NFT Traders Pro',
      managerRating: 4.2,
      apy: 28.4,
      volatility: 'High'
    }
  ];

  // Filter and sort opportunities
  const filteredOpportunities = opportunities.filter(opportunity => {
    const matchesSearch = opportunity.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         opportunity.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRisk = selectedFilters.riskLevel === 'all' || opportunity.riskLevel === selectedFilters.riskLevel;
    
    const matchesReturn = selectedFilters.returnRange === 'all' || 
      (selectedFilters.returnRange === 'low' && opportunity.expectedReturn < 15) ||
      (selectedFilters.returnRange === 'medium' && opportunity.expectedReturn >= 15 && opportunity.expectedReturn < 30) ||
      (selectedFilters.returnRange === 'high' && opportunity.expectedReturn >= 30);
    
    const matchesDuration = selectedFilters.duration === 'all' ||
      (selectedFilters.duration === 'short' && opportunity.duration <= 60) ||
      (selectedFilters.duration === 'medium' && opportunity.duration > 60 && opportunity.duration <= 120) ||
      (selectedFilters.duration === 'long' && opportunity.duration > 120);
    
    const matchesMinAmount = !selectedFilters.minAmount || 
      opportunity.minAmount <= parseInt(selectedFilters.minAmount);

    return matchesSearch && matchesRisk && matchesReturn && matchesDuration && matchesMinAmount;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'return':
        return b.expectedReturn - a.expectedReturn;
      case 'risk':
        return a.riskScore - b.riskScore;
      case 'duration':
        return a.duration - b.duration;
      case 'amount':
        return a.minAmount - b.minAmount;
      default: // featured
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || b.expectedReturn - a.expectedReturn;
    }
  });

  const handleCompareToggle = (opportunityId) => {
    setSelectedForComparison(prev => {
      if (prev.includes(opportunityId)) {
        return prev.filter(id => id !== opportunityId);
      } else if (prev.length < 3) {
        return [...prev, opportunityId];
      }
      return prev;
    });
  };

  const handleInvestClick = (opportunity) => {
    setSelectedInvestment(opportunity);
    setShowInvestmentModal(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading investment opportunities...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-foreground">Investment Opportunities</h1>
            <p className="text-sm sm:text-base text-muted-foreground">
              Discover curated cryptocurrency investment packages
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => navigate('/investment-portfolio-dashboard')}>
              <Icon name="ArrowLeft" size={16} />
              <span className="hidden sm:inline ml-2">Portfolio</span>
            </Button>
            {selectedForComparison.length > 0 && (
              <Button size="sm" onClick={() => setShowComparison(true)}>
                <Icon name="GitCompare" size={16} />
                <span className="hidden sm:inline ml-2">Compare ({selectedForComparison.length})</span>
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="p-4 sm:p-6">
        {/* Search and Filter Section */}
        <div className="mb-6 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search investment opportunities..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Filter System */}
          <FilterSystem
            selectedFilters={selectedFilters}
            onFiltersChange={setSelectedFilters}
            sortBy={sortBy}
            onSortChange={setSortBy}
          />
        </div>

        {/* Results Summary */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-sm text-muted-foreground">
            Showing {filteredOpportunities.length} of {opportunities.length} opportunities
          </p>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">Sort by:</span>
            <Select
              value={sortBy}
              onValueChange={setSortBy}
              className="w-32"
            >
              <option value="featured">Featured</option>
              <option value="return">Return %</option>
              <option value="risk">Risk Level</option>
              <option value="duration">Duration</option>
              <option value="amount">Min Amount</option>
            </Select>
          </div>
        </div>

        {/* Opportunities Grid */}
        {filteredOpportunities.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredOpportunities.map((opportunity) => (
              <OpportunityCard
                key={opportunity.id}
                opportunity={opportunity}
                isSelected={selectedForComparison.includes(opportunity.id)}
                onCompareToggle={() => handleCompareToggle(opportunity.id)}
                onInvestClick={() => handleInvestClick(opportunity)}
                showCompareButton={selectedForComparison.length < 3 || selectedForComparison.includes(opportunity.id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-muted/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="Search" size={32} className="text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">No Opportunities Found</h3>
            <p className="text-muted-foreground mb-4">Try adjusting your filters or search terms</p>
            <Button variant="outline" onClick={() => {
              setSearchTerm('');
              setSelectedFilters({
                riskLevel: 'all',
                returnRange: 'all',
                duration: 'all',
                minAmount: ''
              });
            }}>
              Clear Filters
            </Button>
          </div>
        )}
      </div>

      {/* Comparison Tool Modal */}
      {showComparison && (
        <ComparisonTool
          opportunities={opportunities.filter(op => selectedForComparison.includes(op.id))}
          onClose={() => setShowComparison(false)}
          onInvestClick={handleInvestClick}
        />
      )}

      {/* Investment Modal */}
      {showInvestmentModal && selectedInvestment && (
        <InvestmentModal
          opportunity={selectedInvestment}
          onClose={() => {
            setShowInvestmentModal(false);
            setSelectedInvestment(null);
          }}
        />
      )}
    </div>
  );
};

export default InvestmentOpportunities;