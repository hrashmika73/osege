import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isEmailSent, setIsEmailSent] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email.trim()) {
      setError('Email address is required');
      return;
    }
    
    if (!/\S+@\S+\.\S+/.test(email)) {
      setError('Please enter a valid email address');
      return;
    }

    setIsLoading(true);
    setError('');
    
    // Simulate password reset email sending
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsLoading(false);
    setIsEmailSent(true);
  };

  if (isEmailSent) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-success/10 rounded-full mx-auto mb-4 flex items-center justify-center">
              <Icon name="Mail" size={32} className="text-success" />
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Check Your Email</h1>
            <p className="text-muted-foreground">We've sent password reset instructions to your email</p>
          </div>

          <div className="bg-card border rounded-lg shadow-lg p-8">
            <div className="text-center space-y-4">
              <div className="bg-success/10 border border-success/20 rounded-lg p-4">
                <h3 className="font-semibold text-foreground mb-2">Email Sent Successfully!</h3>
                <p className="text-sm text-muted-foreground">
                  We've sent a password reset link to <strong>{email}</strong>
                </p>
              </div>
              
              <div className="text-sm text-muted-foreground space-y-2">
                <p>• Check your inbox (and spam folder)</p>
                <p>• Click the reset link in the email</p>
                <p>• Create a new secure password</p>
                <p>• The link will expire in 24 hours</p>
              </div>
              
              <div className="pt-4">
                <Button 
                  variant="outline" 
                  className="w-full mb-3"
                  onClick={() => setIsEmailSent(false)}
                >
                  <Icon name="RotateCcw" size={20} />
                  Send Another Email
                </Button>
                
                <Link to="/login">
                  <Button className="w-full">
                    <Icon name="ArrowLeft" size={20} />
                    Back to Login
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          
          {/* Support Contact */}
          <div className="mt-6 bg-muted/50 border rounded-lg p-4">
            <div className="text-center">
              <h3 className="text-sm font-medium text-foreground mb-2">Need Help?</h3>
              <p className="text-xs text-muted-foreground mb-3">
                If you don't receive the email within a few minutes, contact our support team.
              </p>
              <Link to="/contact">
                <Button variant="outline" size="sm">
                  <Icon name="MessageCircle" size={16} />
                  Contact Support
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary rounded-full mx-auto mb-4 flex items-center justify-center">
            <Icon name="KeyRound" size={32} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Forgot Password?</h1>
          <p className="text-muted-foreground">Enter your email to reset your password</p>
        </div>

        {/* Reset Form */}
        <div className="bg-card border rounded-lg shadow-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Email Address"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address"
              required
              error={error}
              icon="Mail"
            />

            <Button 
              type="submit" 
              size="lg" 
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Icon name="Loader" size={20} className="animate-spin" />
                  Sending Reset Link...
                </>
              ) : (
                <>
                  <Icon name="Send" size={20} />
                  Send Reset Link
                </>
              )}
            </Button>
          </form>

          {/* Back to Login */}
          <div className="mt-6 text-center">
            <Link 
              to="/login" 
              className="text-sm text-muted-foreground hover:text-foreground flex items-center justify-center space-x-1"
            >
              <Icon name="ArrowLeft" size={16} />
              <span>Back to Login</span>
            </Link>
          </div>
        </div>

        {/* Security Notice */}
        <div className="mt-6 bg-muted/50 border rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <Icon name="Shield" size={20} className="text-primary mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="text-sm font-medium text-foreground">Security Notice</h3>
              <p className="text-xs text-muted-foreground mt-1">
                For security reasons, we'll only send password reset links to verified email addresses 
                associated with existing accounts.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;
