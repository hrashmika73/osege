import React from 'react';
import Icon from '../../../components/AppIcon';

const BalanceCard = ({ currency, icon, total, available, locked, color = 'primary' }) => {
  const getColorClasses = () => {
    switch (color) {
      case 'success':
        return 'bg-success/10 text-success border-success/20';
      case 'warning':
        return 'bg-warning/10 text-warning border-warning/20';
      case 'error':
        return 'bg-error/10 text-error border-error/20';
      case 'muted':
        return 'bg-muted/50 text-muted-foreground border-muted/20';
      default:
        return 'bg-primary/10 text-primary border-primary/20';
    }
  };

  const formatAmount = (amount) => {
    if (currency === 'USD' || currency === 'USDT') {
      return `$${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    return `${amount.toFixed(6)} ${currency}`;
  };

  const getAvailablePercentage = () => {
    return total > 0 ? (available / total) * 100 : 0;
  };

  return (
    <div className="bg-card border rounded-lg p-4 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-center justify-between mb-3">
        <div className={`p-2 rounded-lg ${getColorClasses()}`}>
          <Icon name={icon} size={20} />
        </div>
        <div className="text-right">
          <p className="text-xs text-muted-foreground">Total Balance</p>
          <p className="text-sm font-semibold text-foreground">{formatAmount(total)}</p>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">Available</span>
          <span className="text-sm font-medium text-success">{formatAmount(available)}</span>
        </div>
        
        {locked > 0 && (
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Locked</span>
            <span className="text-sm font-medium text-warning">{formatAmount(locked)}</span>
          </div>
        )}

        {/* Progress bar */}
        <div className="w-full bg-muted rounded-full h-2 mt-3">
          <div
            className="bg-success h-2 rounded-full transition-all duration-300"
            style={{ width: `${getAvailablePercentage()}%` }}
          />
        </div>
        
        <p className="text-xs text-muted-foreground text-center">
          {getAvailablePercentage().toFixed(1)}% available for withdrawal
        </p>
      </div>
    </div>
  );
};

export default BalanceCard;