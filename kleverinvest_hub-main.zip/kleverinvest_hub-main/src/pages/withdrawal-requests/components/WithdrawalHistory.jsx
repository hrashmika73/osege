import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const WithdrawalHistory = ({ history, onRetry }) => {
  const [filter, setFilter] = useState('all');
  const [sortBy, setSortBy] = useState('newest');

  const statusColors = {
    pending: 'bg-warning/10 text-warning border-warning/20',
    completed: 'bg-success/10 text-success border-success/20',
    failed: 'bg-error/10 text-error border-error/20',
    processing: 'bg-primary/10 text-primary border-primary/20'
  };

  const statusIcons = {
    pending: 'Clock',
    completed: 'CheckCircle',
    failed: 'XCircle',
    processing: 'Loader'
  };

  const filterOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'pending', label: 'Pending' },
    { value: 'completed', label: 'Completed' },
    { value: 'failed', label: 'Failed' }
  ];

  const sortOptions = [
    { value: 'newest', label: 'Newest First' },
    { value: 'oldest', label: 'Oldest First' },
    { value: 'amount_high', label: 'Amount: High to Low' },
    { value: 'amount_low', label: 'Amount: Low to High' }
  ];

  const filteredHistory = history
    .filter(item => filter === 'all' || item.status === filter)
    .sort((a, b) => {
      switch (sortBy) {
        case 'oldest':
          return a.timestamp - b.timestamp;
        case 'amount_high':
          return (b.amount * b.exchangeRate) - (a.amount * a.exchangeRate);
        case 'amount_low':
          return (a.amount * a.exchangeRate) - (b.amount * b.exchangeRate);
        default:
          return b.timestamp - a.timestamp;
      }
    });

  const formatAmount = (amount, currency) => {
    if (currency === 'USD' || currency === 'USDT') {
      return `$${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    return `${amount.toFixed(6)} ${currency}`;
  };

  const formatAddress = (address) => {
    if (address.length > 20) {
      return `${address.slice(0, 8)}...${address.slice(-8)}`;
    }
    return address;
  };

  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusText = (status) => {
    const statusMap = {
      pending: 'Pending Confirmation',
      completed: 'Successfully Completed',
      failed: 'Transaction Failed',
      processing: 'Processing'
    };
    return statusMap[status] || status;
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    // Could add toast notification here
  };

  if (history.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Send" size={24} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium text-foreground mb-2">No withdrawal history</h3>
        <p className="text-muted-foreground">Your withdrawal transactions will appear here.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <Select
            value={filter}
            onChange={setFilter}
            options={filterOptions}
            placeholder="Filter by status"
          />
        </div>
        <div className="flex-1">
          <Select
            value={sortBy}
            onChange={setSortBy}
            options={sortOptions}
            placeholder="Sort by"
          />
        </div>
      </div>

      {/* History List */}
      <div className="space-y-4">
        {filteredHistory.map((withdrawal) => (
          <div key={withdrawal.id} className="bg-card border rounded-lg p-4 hover:shadow-sm transition-shadow duration-200">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              {/* Main Info */}
              <div className="flex-1">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[withdrawal.status]}`}>
                      <div className="flex items-center space-x-1">
                        <Icon name={statusIcons[withdrawal.status]} size={12} />
                        <span>{getStatusText(withdrawal.status)}</span>
                      </div>
                    </div>
                    <span className="text-sm text-muted-foreground">#{withdrawal.id}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">{formatTime(withdrawal.timestamp)}</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Amount</p>
                    <p className="font-medium text-foreground">{formatAmount(withdrawal.amount, withdrawal.currency)}</p>
                    <p className="text-xs text-muted-foreground">
                      ≈ ${(withdrawal.amount * withdrawal.exchangeRate).toLocaleString()}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Destination</p>
                    <div className="flex items-center space-x-2">
                      <p className="font-mono text-sm text-foreground">{formatAddress(withdrawal.destination)}</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(withdrawal.destination)}
                        className="p-1 h-auto"
                      >
                        <Icon name="Copy" size={12} />
                      </Button>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground">Network Fee</p>
                    <p className="text-sm text-foreground">{formatAmount(withdrawal.networkFee, withdrawal.currency)}</p>
                  </div>

                  {withdrawal.estimatedCompletion && (
                    <div>
                      <p className="text-sm text-muted-foreground">
                        {withdrawal.status === 'completed' ? 'Completed' : 'Estimated Completion'}
                      </p>
                      <p className="text-sm text-foreground">{formatTime(withdrawal.estimatedCompletion)}</p>
                    </div>
                  )}
                </div>

                {/* Transaction Hash */}
                {withdrawal.transactionHash && (
                  <div className="mt-3 pt-3 border-t">
                    <p className="text-sm text-muted-foreground mb-1">Transaction Hash</p>
                    <div className="flex items-center space-x-2">
                      <p className="font-mono text-sm text-foreground break-all">{withdrawal.transactionHash}</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(withdrawal.transactionHash)}
                        className="p-1 h-auto shrink-0"
                      >
                        <Icon name="Copy" size={12} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => window.open(`https://explorer.example.com/tx/${withdrawal.transactionHash}`, '_blank')}
                        className="p-1 h-auto shrink-0"
                      >
                        <Icon name="ExternalLink" size={12} />
                      </Button>
                    </div>
                  </div>
                )}

                {/* Failure Reason */}
                {withdrawal.status === 'failed' && withdrawal.failureReason && (
                  <div className="mt-3 p-3 bg-error/5 border border-error/20 rounded-lg">
                    <div className="flex items-start space-x-2">
                      <Icon name="AlertCircle" size={16} className="text-error mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-error">Transaction Failed</p>
                        <p className="text-sm text-muted-foreground">{withdrawal.failureReason}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex items-center space-x-2 lg:flex-col lg:space-x-0 lg:space-y-2">
                {withdrawal.status === 'failed' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onRetry(withdrawal.id)}
                  >
                    <Icon name="RotateCcw" size={14} />
                    Retry
                  </Button>
                )}
                
                {withdrawal.status === 'pending' && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-error hover:bg-error/10"
                  >
                    <Icon name="X" size={14} />
                    Cancel
                  </Button>
                )}
                
                <Button variant="ghost" size="sm">
                  <Icon name="MoreVertical" size={14} />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Load More */}
      {filteredHistory.length >= 10 && (
        <div className="text-center">
          <Button variant="outline">
            Load More History
          </Button>
        </div>
      )}
    </div>
  );
};

export default WithdrawalHistory;