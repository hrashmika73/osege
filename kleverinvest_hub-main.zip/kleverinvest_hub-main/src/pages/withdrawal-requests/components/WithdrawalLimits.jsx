import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const WithdrawalLimits = ({ limits, onUpgradeVerification }) => {
  const getDailyProgress = () => {
    return (limits.daily.used / limits.daily.limit) * 100;
  };

  const getMonthlyProgress = () => {
    return (limits.monthly.used / limits.monthly.limit) * 100;
  };

  const getRemainingDaily = () => {
    return limits.daily.limit - limits.daily.used;
  };

  const getRemainingMonthly = () => {
    return limits.monthly.limit - limits.monthly.used;
  };

  const verificationLevels = [
    {
      level: 'Level 1',
      status: 'completed',
      dailyLimit: '$10,000',
      monthlyLimit: '$100,000',
      requirements: ['Email verification', 'Phone verification'],
      current: limits.verificationLevel === 'Level 1'
    },
    {
      level: 'Level 2',
      status: 'completed',
      dailyLimit: '$50,000',
      monthlyLimit: '$500,000',
      requirements: ['Identity document', 'Address proof'],
      current: limits.verificationLevel === 'Level 2'
    },
    {
      level: 'Level 3',
      status: 'available',
      dailyLimit: '$100,000',
      monthlyLimit: '$1,000,000',
      requirements: ['Video call verification', 'Source of funds'],
      current: false
    }
  ];

  const formatCurrency = (amount) => {
    return `$${amount.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
  };

  return (
    <div className="space-y-6">
      {/* Current Limits Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Daily Limit */}
        <div className="bg-muted/30 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <Icon name="Calendar" size={20} className="text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Daily Limit</h3>
                <p className="text-sm text-muted-foreground">Resets at midnight UTC</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-foreground">{formatCurrency(limits.daily.limit)}</p>
              <p className="text-sm text-muted-foreground">Per day</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Used today:</span>
              <span className="text-foreground font-medium">{formatCurrency(limits.daily.used)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Remaining:</span>
              <span className="text-success font-medium">{formatCurrency(getRemainingDaily())}</span>
            </div>
            
            <div className="w-full bg-muted rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all duration-300 ${
                  getDailyProgress() > 80 ? 'bg-error' : getDailyProgress() > 60 ? 'bg-warning' : 'bg-success'
                }`}
                style={{ width: `${Math.min(getDailyProgress(), 100)}%` }}
              />
            </div>
            <p className="text-xs text-center text-muted-foreground">
              {getDailyProgress().toFixed(1)}% of daily limit used
            </p>
          </div>
        </div>

        {/* Monthly Limit */}
        <div className="bg-muted/30 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-success/10 rounded-full flex items-center justify-center">
                <Icon name="CalendarDays" size={20} className="text-success" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Monthly Limit</h3>
                <p className="text-sm text-muted-foreground">Resets on 1st of each month</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-foreground">{formatCurrency(limits.monthly.limit)}</p>
              <p className="text-sm text-muted-foreground">Per month</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Used this month:</span>
              <span className="text-foreground font-medium">{formatCurrency(limits.monthly.used)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Remaining:</span>
              <span className="text-success font-medium">{formatCurrency(getRemainingMonthly())}</span>
            </div>
            
            <div className="w-full bg-muted rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all duration-300 ${
                  getMonthlyProgress() > 80 ? 'bg-error' : getMonthlyProgress() > 60 ? 'bg-warning' : 'bg-success'
                }`}
                style={{ width: `${Math.min(getMonthlyProgress(), 100)}%` }}
              />
            </div>
            <p className="text-xs text-center text-muted-foreground">
              {getMonthlyProgress().toFixed(1)}% of monthly limit used
            </p>
          </div>
        </div>
      </div>

      {/* Verification Levels */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Verification Levels</h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full"></div>
            <span className="text-sm text-muted-foreground">Current: {limits.verificationLevel}</span>
          </div>
        </div>

        <div className="space-y-4">
          {verificationLevels.map((level, index) => (
            <div
              key={level.level}
              className={`border rounded-lg p-6 transition-all duration-200 ${
                level.current
                  ? 'border-success bg-success/5'
                  : level.status === 'completed' ?'border-muted bg-muted/30' :'border-primary bg-primary/5 hover:shadow-sm'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    level.current
                      ? 'bg-success text-success-foreground'
                      : level.status === 'completed' ?'bg-muted text-muted-foreground' :'bg-primary text-primary-foreground'
                  }`}>
                    <Icon
                      name={level.current ? 'CheckCircle' : level.status === 'completed' ? 'Check' : 'Lock'}
                      size={16}
                    />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">{level.level}</h4>
                    <p className="text-sm text-muted-foreground">
                      {level.current ? 'Current level' : level.status === 'completed' ? 'Completed' : 'Available for upgrade'}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">Daily: {level.dailyLimit}</p>
                  <p className="text-sm text-muted-foreground">Monthly: {level.monthlyLimit}</p>
                </div>
              </div>

              <div className="mb-4">
                <p className="text-sm text-muted-foreground mb-2">Requirements:</p>
                <div className="flex flex-wrap gap-2">
                  {level.requirements.map((req, reqIndex) => (
                    <span
                      key={reqIndex}
                      className={`px-2 py-1 rounded-md text-xs ${
                        level.status === 'completed'
                          ? 'bg-success/10 text-success' :'bg-muted text-muted-foreground'
                      }`}
                    >
                      {level.status === 'completed' && <Icon name="Check" size={10} className="inline mr-1" />}
                      {req}
                    </span>
                  ))}
                </div>
              </div>

              {level.status === 'available' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onUpgradeVerification}
                  className="w-full"
                >
                  <Icon name="ArrowUp" size={14} />
                  Upgrade to {level.level}
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Upgrade Benefits */}
      {limits.nextLevelBenefit && (
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-6">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mt-0.5">
              <Icon name="TrendingUp" size={16} className="text-primary" />
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-2">Upgrade Your Verification</h4>
              <p className="text-sm text-muted-foreground mb-4">{limits.nextLevelBenefit}</p>
              <Button onClick={onUpgradeVerification}>
                <Icon name="ShieldCheck" size={16} />
                Start Verification Process
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Important Notes */}
      <div className="bg-muted/30 rounded-lg p-6">
        <h4 className="font-semibold text-foreground mb-3">Important Information</h4>
        <div className="space-y-2 text-sm text-muted-foreground">
          <div className="flex items-start space-x-2">
            <Icon name="Info" size={14} className="mt-0.5 text-primary" />
            <p>Withdrawal limits are calculated based on USD equivalent at the time of withdrawal.</p>
          </div>
          <div className="flex items-start space-x-2">
            <Icon name="Clock" size={14} className="mt-0.5 text-primary" />
            <p>Daily limits reset at 00:00 UTC. Monthly limits reset on the 1st of each month.</p>
          </div>
          <div className="flex items-start space-x-2">
            <Icon name="Shield" size={14} className="mt-0.5 text-primary" />
            <p>Higher verification levels provide increased limits and enhanced security features.</p>
          </div>
          <div className="flex items-start space-x-2">
            <Icon name="AlertTriangle" size={14} className="mt-0.5 text-warning" />
            <p>Suspended accounts may have temporary limit restrictions. Contact support if you experience issues.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WithdrawalLimits;