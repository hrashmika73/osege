import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const TwoFactorAuth = ({ withdrawalData, onSuccess, onCancel }) => {
  const [code, setCode] = useState('');
  const [method, setMethod] = useState('app'); // 'app', 'sms', 'email'
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [timeLeft]);

  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleVerify = async () => {
    if (code.length !== 6) {
      setError('Please enter a 6-digit code');
      return;
    }

    setIsVerifying(true);
    setError('');

    try {
      // Simulate API call for verification
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock verification - in real app, this would validate against backend
      if (code === '123456' || code === '000000') {
        onSuccess();
      } else {
        setError('Invalid verification code. Please try again.');
      }
    } catch (err) {
      setError('Verification failed. Please try again.');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleResend = () => {
    if (resendCooldown > 0) return;
    
    setResendCooldown(30);
    setTimeLeft(300);
    setError('');
    // In real app, would trigger API call to resend code
  };

  const switchMethod = (newMethod) => {
    setMethod(newMethod);
    setCode('');
    setError('');
    setTimeLeft(300);
  };

  const formatAmount = (amount, currency) => {
    if (currency === 'USD' || currency === 'USDT') {
      return `$${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    return `${amount.toFixed(6)} ${currency}`;
  };

  const methods = {
    app: {
      title: 'Authenticator App',
      description: 'Enter the 6-digit code from your authenticator app',
      icon: 'Smartphone'
    },
    sms: {
      title: 'SMS Verification',
      description: 'Enter the code sent to your phone number ending in ****1234',
      icon: 'MessageSquare'
    },
    email: {
      title: 'Email Verification',
      description: 'Enter the code sent to your email address',
      icon: 'Mail'
    }
  };

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card border rounded-lg shadow-lg w-full max-w-md mx-auto">
        {/* Header */}
        <div className="border-b p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-warning/10 rounded-full flex items-center justify-center">
                <Icon name="Shield" size={20} className="text-warning" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Two-Factor Authentication</h2>
                <p className="text-sm text-muted-foreground">Verify your identity to proceed</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onCancel}>
              <Icon name="X" size={16} />
            </Button>
          </div>
        </div>

        {/* Withdrawal Summary */}
        <div className="p-6 border-b bg-muted/30">
          <h3 className="font-medium text-foreground mb-3">Withdrawal Summary</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Amount:</span>
              <span className="text-foreground font-medium">
                {formatAmount(withdrawalData?.amount, withdrawalData?.currency)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Network Fee:</span>
              <span className="text-foreground">
                {formatAmount(withdrawalData?.networkFee, withdrawalData?.currency)}
              </span>
            </div>
            <div className="flex justify-between border-t pt-2">
              <span className="text-muted-foreground">Total:</span>
              <span className="text-foreground font-medium">
                {formatAmount(withdrawalData?.totalAmount, withdrawalData?.currency)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Destination:</span>
              <span className="text-foreground font-mono text-xs">
                {withdrawalData?.destination?.slice(0, 10)}...{withdrawalData?.destination?.slice(-6)}
              </span>
            </div>
          </div>
        </div>

        {/* Verification Methods */}
        <div className="p-6">
          <div className="flex space-x-2 mb-4">
            {Object.entries(methods).map(([key, method]) => (
              <Button
                key={key}
                variant={method === key ? 'default' : 'outline'}
                size="sm"
                onClick={() => switchMethod(key)}
                className="flex-1"
              >
                <Icon name={method.icon} size={14} />
                <span className="hidden sm:inline ml-2">{method.title.split(' ')[0]}</span>
              </Button>
            ))}
          </div>

          <div className="mb-6">
            <div className="flex items-center space-x-2 mb-3">
              <Icon name={methods[method].icon} size={16} className="text-primary" />
              <span className="font-medium text-foreground">{methods[method].title}</span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">{methods[method].description}</p>

            <div className="space-y-4">
              <div>
                <Input
                  type="text"
                  value={code}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                    setCode(value);
                    setError('');
                  }}
                  placeholder="Enter 6-digit code"
                  className="text-center text-lg tracking-widest"
                  maxLength={6}
                  error={error}
                />
              </div>

              {/* Timer */}
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  Code expires in: <span className="font-medium text-foreground">{formatTime(timeLeft)}</span>
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleResend}
                  disabled={resendCooldown > 0}
                >
                  {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : 'Resend Code'}
                </Button>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex space-x-3">
            <Button variant="outline" onClick={onCancel} className="flex-1">
              Cancel
            </Button>
            <Button
              onClick={handleVerify}
              disabled={code.length !== 6 || isVerifying}
              className="flex-1"
            >
              {isVerifying ? (
                <>
                  <Icon name="Loader" size={16} className="animate-spin" />
                  Verifying...
                </>
              ) : (
                <>
                  <Icon name="CheckCircle" size={16} />
                  Verify & Withdraw
                </>
              )}
            </Button>
          </div>

          {/* Security Notice */}
          <div className="mt-4 p-3 bg-muted/50 rounded-lg">
            <div className="flex items-start space-x-2">
              <Icon name="Info" size={14} className="text-primary mt-0.5" />
              <p className="text-xs text-muted-foreground">
                Never share your verification codes with anyone. Our support team will never ask for these codes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TwoFactorAuth;