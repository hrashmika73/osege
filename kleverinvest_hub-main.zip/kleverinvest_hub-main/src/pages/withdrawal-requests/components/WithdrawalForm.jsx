import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const WithdrawalForm = ({ balances, onSubmit }) => {
  const [formData, setFormData] = useState({
    currency: 'BTC',
    amount: '',
    destination: '',
    memo: ''
  });
  const [errors, setErrors] = useState({});
  const [networkFee, setNetworkFee] = useState(0);
  const [exchangeRate, setExchangeRate] = useState(1);
  const [estimatedTime, setEstimatedTime] = useState('');
  const [addressValidation, setAddressValidation] = useState({ isValid: false, message: '' });

  const currencies = [
    { value: 'BTC', label: 'Bitcoin (BTC)', networkFee: 0.0005, confirmations: '2-6 blocks' },
    { value: 'ETH', label: 'Ethereum (ETH)', networkFee: 0.02, confirmations: '12-35 blocks' },
    { value: 'USDT', label: 'Tether (USDT)', networkFee: 2.5, confirmations: '12-35 blocks' },
    { value: 'USD', label: 'US Dollar (USD)', networkFee: 5, confirmations: '1-3 business days' }
  ];

  useEffect(() => {
    const selectedCurrency = currencies.find(c => c.value === formData.currency);
    if (selectedCurrency) {
      setNetworkFee(selectedCurrency.networkFee);
      setEstimatedTime(selectedCurrency.confirmations);
      
      // Mock exchange rates
      const rates = { BTC: 45000, ETH: 3200, USDT: 1, USD: 1 };
      setExchangeRate(rates[formData.currency] || 1);
    }
  }, [formData.currency]);

  useEffect(() => {
    // Validate destination address
    if (formData.destination) {
      validateAddress(formData.destination, formData.currency);
    } else {
      setAddressValidation({ isValid: false, message: '' });
    }
  }, [formData.destination, formData.currency]);

  const validateAddress = (address, currency) => {
    // Simple address validation patterns
    const patterns = {
      BTC: /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/,
      ETH: /^0x[a-fA-F0-9]{40}$/,
      USDT: /^0x[a-fA-F0-9]{40}$/,
      USD: /^[A-Z0-9]{8,20}$/ // Bank account format
    };

    const pattern = patterns[currency];
    if (pattern && pattern.test(address)) {
      setAddressValidation({ isValid: true, message: 'Valid address format' });
    } else {
      setAddressValidation({ isValid: false, message: 'Invalid address format' });
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  const handleMaxAmount = () => {
    const available = balances[formData.currency.toLowerCase()]?.available || 0;
    const maxWithdrawal = Math.max(0, available - networkFee);
    setFormData(prev => ({ ...prev, amount: maxWithdrawal.toString() }));
  };

  const validateForm = () => {
    const newErrors = {};
    const available = balances[formData.currency.toLowerCase()]?.available || 0;
    const amount = parseFloat(formData.amount);

    if (!formData.amount || amount <= 0) {
      newErrors.amount = 'Please enter a valid amount';
    } else if (amount > available) {
      newErrors.amount = 'Insufficient balance';
    } else if (amount + networkFee > available) {
      newErrors.amount = 'Amount plus network fee exceeds available balance';
    }

    if (!formData.destination) {
      newErrors.destination = 'Destination address is required';
    } else if (!addressValidation.isValid) {
      newErrors.destination = 'Please enter a valid destination address';
    }

    // Minimum withdrawal amounts
    const minAmounts = { BTC: 0.001, ETH: 0.01, USDT: 10, USD: 10 };
    if (amount < minAmounts[formData.currency]) {
      newErrors.amount = `Minimum withdrawal: ${minAmounts[formData.currency]} ${formData.currency}`;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      onSubmit({
        ...formData,
        amount: parseFloat(formData.amount),
        networkFee,
        exchangeRate,
        estimatedTime,
        totalAmount: parseFloat(formData.amount) + networkFee
      });
    }
  };

  const getTotalWithFee = () => {
    const amount = parseFloat(formData.amount) || 0;
    return amount + networkFee;
  };

  const getUSDValue = () => {
    const amount = parseFloat(formData.amount) || 0;
    return amount * exchangeRate;
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-2">New Withdrawal</h3>
        <p className="text-sm text-muted-foreground">
          Enter withdrawal details below. All transactions require two-factor authentication.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Currency Selection */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Currency
          </label>
          <Select
            value={formData.currency}
            onChange={(value) => handleInputChange('currency', value)}
            options={currencies}
            placeholder="Select currency"
          />
        </div>

        {/* Amount Input */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Amount
          </label>
          <div className="relative">
            <Input
              type="number"
              value={formData.amount}
              onChange={(e) => handleInputChange('amount', e.target.value)}
              placeholder="0.00"
              error={errors.amount}
              step="any"
              min="0"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleMaxAmount}
              className="absolute right-2 top-1/2 -translate-y-1/2"
            >
              Max
            </Button>
          </div>
          {formData.amount && (
            <div className="mt-2 space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">USD Value:</span>
                <span className="text-foreground">${getUSDValue().toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Network Fee:</span>
                <span className="text-foreground">{networkFee} {formData.currency}</span>
              </div>
              <div className="flex justify-between text-sm font-medium border-t pt-1">
                <span className="text-foreground">Total:</span>
                <span className="text-foreground">{getTotalWithFee().toFixed(6)} {formData.currency}</span>
              </div>
            </div>
          )}
        </div>

        {/* Destination Address */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Destination Address
            {formData.currency === 'USD' && <span className="text-muted-foreground"> (Bank Account)</span>}
          </label>
          <Input
            value={formData.destination}
            onChange={(e) => handleInputChange('destination', e.target.value)}
            placeholder={
              formData.currency === 'USD' 
                ? "Enter bank account number" :"Enter wallet address"
            }
            error={errors.destination}
          />
          {formData.destination && (
            <div className={`mt-2 flex items-center space-x-2 text-sm ${
              addressValidation.isValid ? 'text-success' : 'text-error'
            }`}>
              <Icon name={addressValidation.isValid ? 'CheckCircle' : 'AlertCircle'} size={14} />
              <span>{addressValidation.message}</span>
            </div>
          )}
        </div>

        {/* Memo/Note (optional) */}
        {(formData.currency === 'USDT' || formData.currency === 'USD') && (
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Memo/Note <span className="text-muted-foreground">(Optional)</span>
            </label>
            <Input
              value={formData.memo}
              onChange={(e) => handleInputChange('memo', e.target.value)}
              placeholder="Enter memo or reference number"
            />
          </div>
        )}

        {/* Transaction Details */}
        {formData.amount && (
          <div className="bg-muted/50 rounded-lg p-4 space-y-3">
            <h4 className="font-medium text-foreground">Transaction Details</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Processing Time:</span>
                <span className="text-foreground">{estimatedTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Exchange Rate:</span>
                <span className="text-foreground">
                  {formData.currency !== 'USD' ? `$${exchangeRate.toLocaleString()}` : '$1.00'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Security Notice */}
        <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <Icon name="Shield" size={20} className="text-warning mt-0.5" />
            <div>
              <h4 className="font-medium text-warning mb-1">Security Notice</h4>
              <p className="text-sm text-muted-foreground">
                Withdrawals require two-factor authentication and cannot be reversed once processed. 
                Please verify all details carefully before proceeding.
              </p>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          size="lg"
          className="w-full"
          disabled={!formData.amount || !formData.destination || !addressValidation.isValid}
        >
          <Icon name="Send" size={16} />
          Proceed to Withdrawal
        </Button>
      </form>
    </div>
  );
};

export default WithdrawalForm;