import React from 'react';
import Icon from '../../../components/AppIcon';


const QuickWithdrawals = ({ amounts, onSelect }) => {
  const getCurrencyIcon = (currency) => {
    const icons = {
      BTC: 'Bitcoin',
      ETH: 'Ethereum', 
      USDT: 'DollarSign',
      USD: 'DollarSign'
    };
    return icons[currency] || 'DollarSign';
  };

  const getCurrencyColor = (currency) => {
    const colors = {
      BTC: 'bg-warning/10 text-warning border-warning/20 hover:bg-warning/20',
      ETH: 'bg-primary/10 text-primary border-primary/20 hover:bg-primary/20',
      USDT: 'bg-success/10 text-success border-success/20 hover:bg-success/20',
      USD: 'bg-muted text-muted-foreground border-muted hover:bg-muted/80'
    };
    return colors[currency] || 'bg-muted text-muted-foreground border-muted hover:bg-muted/80';
  };

  return (
    <div className="border-t pt-6">
      <div className="mb-4">
        <h4 className="font-semibold text-foreground mb-2">Quick Withdrawals</h4>
        <p className="text-sm text-muted-foreground">
          Select a preset amount for faster withdrawals
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {amounts.map((amount, index) => (
          <button
            key={index}
            onClick={() => onSelect(amount)}
            className={`p-4 rounded-lg border text-left transition-all duration-200 ${getCurrencyColor(amount.currency)}`}
          >
            <div className="flex items-center justify-between mb-2">
              <Icon name={getCurrencyIcon(amount.currency)} size={20} />
              <span className="text-xs font-medium opacity-60">{amount.currency}</span>
            </div>
            <div>
              <p className="font-semibold text-lg">{amount.label}</p>
              <p className="text-xs opacity-80">
                {amount.currency === 'USD' ? 'Instant' : 'Network fee applies'}
              </p>
            </div>
          </button>
        ))}
      </div>

      <div className="mt-4 p-3 bg-muted/30 rounded-lg">
        <div className="flex items-start space-x-2">
          <Icon name="Zap" size={14} className="text-primary mt-0.5" />
          <p className="text-xs text-muted-foreground">
            Quick withdrawals use your default withdrawal addresses. You can modify the destination before confirming.
          </p>
        </div>
      </div>
    </div>
  );
};

export default QuickWithdrawals;