import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';


import WithdrawalForm from './components/WithdrawalForm';
import WithdrawalHistory from './components/WithdrawalHistory';
import TwoFactorAuth from './components/TwoFactorAuth';
import WithdrawalLimits from './components/WithdrawalLimits';
import BalanceCard from './components/BalanceCard';
import QuickWithdrawals from './components/QuickWithdrawals';

const WithdrawalRequests = () => {
  const navigate = useNavigate();
  const { isUserAuthenticated } = useUserAuth();
  const { isAdminAuthenticated } = useAdminAuth();

  // Determine correct dashboard URL based on authentication
  const getDashboardUrl = () => {
    if (isAdminAuthenticated) return '/admin-dashboard';
    if (isUserAuthenticated) return '/user-dashboard';
    return '/login-selection'; // fallback
  };
  const [activeTab, setActiveTab] = useState('withdraw');
  const [showTwoFactorAuth, setShowTwoFactorAuth] = useState(false);
  const [pendingWithdrawal, setPendingWithdrawal] = useState(null);
  const [balances, setBalances] = useState({
    btc: { total: 2.45678, available: 2.23456, locked: 0.22222 },
    eth: { total: 15.789, available: 14.567, locked: 1.222 },
    usdt: { total: 50000, available: 45000, locked: 5000 },
    usd: { total: 25000, available: 23500, locked: 1500 }
  });

  const [withdrawalHistory, setWithdrawalHistory] = useState([
    {
      id: 'WD001',
      currency: 'BTC',
      amount: 0.5,
      destination: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
      status: 'pending',
      timestamp: new Date(Date.now() - 300000),
      networkFee: 0.0005,
      exchangeRate: 45000,
      estimatedCompletion: new Date(Date.now() + 1800000),
      transactionHash: null
    },
    {
      id: 'WD002',
      currency: 'USDT',
      amount: 1000,
      destination: '0x742f35Cc6606532D3C82b0c24bC16c5C4E0D6f2f',
      status: 'completed',
      timestamp: new Date(Date.now() - 86400000),
      networkFee: 2.5,
      exchangeRate: 1,
      estimatedCompletion: new Date(Date.now() - 84600000),
      transactionHash: '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
    },
    {
      id: 'WD003',
      currency: 'ETH',
      amount: 2.0,
      destination: '0x742f35Cc6606532D3C82b0c24bC16c5C4E0D6f2f',
      status: 'failed',
      timestamp: new Date(Date.now() - 172800000),
      networkFee: 0.02,
      exchangeRate: 3200,
      estimatedCompletion: null,
      transactionHash: null,
      failureReason: 'Insufficient network fees'
    }
  ]);

  const [withdrawalLimits] = useState({
    daily: { used: 15000, limit: 50000 },
    monthly: { used: 125000, limit: 500000 },
    verificationLevel: 'Level 2',
    nextLevelBenefit: 'Increase daily limit to $100,000'
  });

  const [quickAmounts] = useState([
    { label: '$1,000', currency: 'USD', amount: 1000 },
    { label: '$5,000', currency: 'USD', amount: 5000 },
    { label: '0.1 BTC', currency: 'BTC', amount: 0.1 },
    { label: '1 ETH', currency: 'ETH', amount: 1 }
  ]);

  useEffect(() => {
    // Simulate real-time balance updates
    const interval = setInterval(() => {
      setBalances(prev => ({
        ...prev,
        btc: {
          ...prev.btc,
          total: prev.btc.total + Math.random() * 0.001 - 0.0005
        }
      }));
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const handleWithdrawalSubmit = (withdrawalData) => {
    setPendingWithdrawal(withdrawalData);
    setShowTwoFactorAuth(true);
  };

  const handleTwoFactorSuccess = () => {
    if (pendingWithdrawal) {
      const newWithdrawal = {
        id: `WD${String(Date.now()).slice(-3)}`,
        ...pendingWithdrawal,
        status: 'pending',
        timestamp: new Date(),
        estimatedCompletion: new Date(Date.now() + 1800000),
        transactionHash: null
      };

      setWithdrawalHistory(prev => [newWithdrawal, ...prev]);
      
      // Update balances
      setBalances(prev => ({
        ...prev,
        [pendingWithdrawal.currency.toLowerCase()]: {
          ...prev[pendingWithdrawal.currency.toLowerCase()],
          available: prev[pendingWithdrawal.currency.toLowerCase()].available - pendingWithdrawal.amount,
          locked: prev[pendingWithdrawal.currency.toLowerCase()].locked + pendingWithdrawal.amount
        }
      }));
    }

    setShowTwoFactorAuth(false);
    setPendingWithdrawal(null);
    setActiveTab('history');
  };

  const handleQuickWithdrawal = (quickAmount) => {
    const withdrawalData = {
      currency: quickAmount.currency,
      amount: quickAmount.amount,
      destination: '',
      networkFee: quickAmount.currency === 'BTC' ? 0.0005 : quickAmount.currency === 'ETH' ? 0.02 : 2.5
    };
    setPendingWithdrawal(withdrawalData);
    setShowTwoFactorAuth(true);
  };

  const tabs = [
    { id: 'withdraw', label: 'Withdraw', icon: 'Send' },
    { id: 'history', label: 'History', icon: 'Clock' },
    { id: 'limits', label: 'Limits', icon: 'Shield' }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b px-4 md:px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Withdrawal Requests</h1>
            <p className="text-muted-foreground">
              Securely withdraw your cryptocurrency and fiat funds
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={() => navigate(getDashboardUrl())}>
            <Icon name="ArrowLeft" size={16} />
            <span className="hidden sm:inline ml-2">Back to Dashboard</span>
          </Button>
        </div>
      </div>

      <div className="p-4 md:p-6">
        {/* Balance Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <BalanceCard
            currency="BTC"
            icon="Bitcoin"
            total={balances.btc.total}
            available={balances.btc.available}
            locked={balances.btc.locked}
            color="warning"
          />
          <BalanceCard
            currency="ETH"
            icon="Ethereum"
            total={balances.eth.total}
            available={balances.eth.available}
            locked={balances.eth.locked}
            color="primary"
          />
          <BalanceCard
            currency="USDT"
            icon="DollarSign"
            total={balances.usdt.total}
            available={balances.usdt.available}
            locked={balances.usdt.locked}
            color="success"
          />
          <BalanceCard
            currency="USD"
            icon="DollarSign"
            total={balances.usd.total}
            available={balances.usd.available}
            locked={balances.usd.locked}
            color="muted"
          />
        </div>

        {/* Tab Navigation */}
        <div className="bg-card rounded-lg border mb-6">
          <div className="border-b">
            <nav className="flex space-x-0">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 md:px-6 py-4 text-sm font-medium border-b-2 transition-colors duration-200 ${
                    activeTab === tab.id
                      ? 'border-primary text-primary bg-primary/5' :'border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
                >
                  <Icon name={tab.icon} size={16} />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'withdraw' && (
              <div className="space-y-6">
                <WithdrawalForm
                  balances={balances}
                  onSubmit={handleWithdrawalSubmit}
                />
                <QuickWithdrawals
                  amounts={quickAmounts}
                  onSelect={handleQuickWithdrawal}
                />
              </div>
            )}

            {activeTab === 'history' && (
              <WithdrawalHistory
                history={withdrawalHistory}
                onRetry={(id) => {
                  // Handle retry logic
                  console.log('Retry withdrawal:', id);
                }}
              />
            )}

            {activeTab === 'limits' && (
              <WithdrawalLimits
                limits={withdrawalLimits}
                onUpgradeVerification={() => {
                  navigate('/user-profile-settings');
                }}
              />
            )}
          </div>
        </div>
      </div>

      {/* Two-Factor Authentication Modal */}
      {showTwoFactorAuth && (
        <TwoFactorAuth
          withdrawalData={pendingWithdrawal}
          onSuccess={handleTwoFactorSuccess}
          onCancel={() => {
            setShowTwoFactorAuth(false);
            setPendingWithdrawal(null);
          }}
        />
      )}
    </div>
  );
};

export default WithdrawalRequests;
