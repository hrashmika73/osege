import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import {
  initializeSecurity,
  biometricAuth,
  adminRateLimiter,
  generateDeviceFingerprint
} from '../../utils/adminSecurity';
import ResponsiveBiometricAuth from '../../components/ResponsiveBiometricAuth';
import { enhancedBiometricAuth, deviceDetection } from '../../utils/crossPlatformBiometric';
// import { pageStatePreservation } from '../../utils/pageStatePreservation'; // Temporarily disabled

const AdminSecureLogin = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { admin, adminLogin, isAdminAuthenticated, loginAttempts, lockoutUntil } = useAdminAuth();
  const [formData, setFormData] = useState({
    username: '', // No auto-fill to prevent bypassing
    email: '',    // No auto-fill to prevent bypassing
    password: '',
    mfaCode: '',
    biometric: false
  });
  const [authStep, setAuthStep] = useState('credentials'); // credentials, mfa, biometric
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [securityFeatures, setSecurityFeatures] = useState({
    biometricAvailable: false,
    deviceSecurity: 'unknown',
    rateLimitStatus: null,
    deviceFingerprint: null
  });
  const [showSecurityInfo, setShowSecurityInfo] = useState(false);
  const securityInitialized = useRef(false);

  // Initialize security features
  useEffect(() => {
    const initSecurity = async () => {
      if (securityInitialized.current) return;

      securityInitialized.current = true;

      try {
        const security = await initializeSecurity();

        // Enhanced biometric detection
        const biometricAvailability = await enhancedBiometricAuth.isAvailable();
        const deviceType = deviceDetection.getDeviceType();
        const isMobile = deviceDetection.isMobile();

        setSecurityFeatures({
          biometricAvailable: biometricAvailability && biometricAvailability.available,
          deviceSecurity: security.securityLevel,
          rateLimitStatus: 'active',
          deviceFingerprint: security.deviceFingerprint,
          deviceType: deviceType,
          isMobile: isMobile,
          biometricCapabilities: biometricAvailability.capabilities || {}
        });

        // Log security status
        console.log('Admin login security initialized:', {
          biometric: security.biometricAvailable,
          deviceSecurity: security.securityLevel
        });
      } catch (error) {
        console.error('Security initialization failed:', error);
        setSecurityFeatures({
          biometricAvailable: false,
          deviceSecurity: 'low',
          rateLimitStatus: 'error',
          deviceFingerprint: null
        });
      }
    };

    initSecurity();
  }, []);

  // Only redirect after successful login - not on page load
  // Removed auto-redirect to prevent bypassing login form

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrors({});

    try {
      if (authStep === 'credentials') {
        // Strict validation - require both username/email AND password
        const hasValidUsername = formData.username && formData.username.trim().length > 0;
        const hasValidEmail = formData.email && formData.email.trim().length > 0;
        const hasValidPassword = formData.password && formData.password.trim().length > 0;

        if (!hasValidUsername && !hasValidEmail) {
          throw new Error('Username or email is required and cannot be empty');
        }
        if (!hasValidPassword) {
          throw new Error('Password is required and cannot be empty');
        }

        // Additional validation for proper credentials
        if (hasValidPassword && formData.password.length < 6) {
          throw new Error('Password must be at least 6 characters long');
        }

        // Check advanced rate limiting
        const clientIP = '127.0.0.1'; // In production, get from server
        const rateLimitCheck = await adminRateLimiter.isAllowed(clientIP, securityFeatures.deviceFingerprint);

        if (!rateLimitCheck.allowed) {
          if (rateLimitCheck.reason === 'IP_BLACKLISTED') {
            throw new Error('Access denied: IP address blocked due to suspicious activity');
          } else {
            const resetMinutes = Math.ceil((rateLimitCheck.resetTime - Date.now()) / 1000 / 60);
            throw new Error(`Too many failed attempts. Try again in ${resetMinutes} minutes.`);
          }
        }

        // Check for lockout
        if (lockoutUntil && Date.now() < lockoutUntil) {
          const remainingTime = Math.ceil((lockoutUntil - Date.now()) / 1000 / 60);
          throw new Error(`Account locked. Try again in ${remainingTime} minutes.`);
        }

        // Attempt admin login
        const credentials = {
          email: formData.email || formData.username,
          username: formData.username,
          password: formData.password,
          deviceFingerprint: securityFeatures.deviceFingerprint,
          securityLevel: securityFeatures.deviceSecurity
        };

        try {
          await adminLogin(credentials);

          // Record successful attempt
          await adminRateLimiter.recordAttempt(clientIP, securityFeatures.deviceFingerprint, true);

          // If login successful, proceed to biometric (if available) or MFA
          if (securityFeatures.biometricAvailable && (securityFeatures.isMobile || securityFeatures.deviceType !== 'unknown')) {
            setAuthStep('biometric');
          } else {
            setAuthStep('mfa');
          }
        } catch (loginError) {
          // Record failed attempt
          await adminRateLimiter.recordAttempt(clientIP, securityFeatures.deviceFingerprint, false);
          throw loginError;
        }

      } else if (authStep === 'biometric') {
        // Biometric authentication is handled by the ResponsiveBiometricAuth component
        // This case should not be reached through form submission
        console.log('Biometric authentication in progress...');
        return;

      } else if (authStep === 'mfa') {
        // Validate MFA code
        if (!formData.mfaCode || formData.mfaCode.length !== 6) {
          throw new Error('Valid 6-digit MFA code is required');
        }

        // Simulate MFA verification (in real app, verify with backend)
        await new Promise(resolve => setTimeout(resolve, 1000));

        // For demo purposes, accept specific codes
        const validCodes = ['123456', '000000', '111111'];
        if (!validCodes.includes(formData.mfaCode)) {
          throw new Error('Invalid MFA code. Try: 123456, 000000, or 111111');
        }

        // Check for preserved page state first, then redirect URL, then default
        // const preservedPage = pageStatePreservation.getStoredPage(); // Temporarily disabled
        const redirectURL = sessionStorage.getItem('adminRedirectURL');

        // Simplified redirect logic for now
        if (redirectURL) {
          sessionStorage.removeItem('adminRedirectURL');
          navigate(redirectURL);
        } else {
          // Default to admin dashboard
          navigate('/admin-dashboard');
        }
      }
    } catch (error) {
      setErrors({ general: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle biometric quick login
  const handleBiometricLogin = async () => {
    if (!securityFeatures.biometricAvailable) return;

    setIsLoading(true);
    setErrors({});

    try {
      const userId = formData.username || formData.email || 'admin';

      if (biometricAuth.isRegistered(userId)) {
        const result = await biometricAuth.authenticate(userId);

        if (result.success) {
          // Also need to do regular login
          const credentials = {
            email: userId.includes('@') ? userId : 'admin@kleverinvest.com',
            username: userId,
            password: 'Admin@123!', // In production, this would be handled differently
            biometricAuth: true
          };

          await adminLogin(credentials);

          // Check for redirect URL or go to dashboard
          const redirectURL = sessionStorage.getItem('adminRedirectURL');
          if (redirectURL) {
            sessionStorage.removeItem('adminRedirectURL');
            navigate(redirectURL);
          } else {
            navigate('/admin-dashboard');
          }
        } else {
          throw new Error('Biometric authentication failed');
        }
      } else {
        throw new Error('Biometric not registered. Please login normally first.');
      }
    } catch (error) {
      setErrors({ general: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-red-800 to-slate-900 flex items-center justify-center p-4">
      <div className={`w-full ${securityFeatures.isMobile ? 'max-w-sm' : 'max-w-md'}`}>
        <div className={`text-center ${securityFeatures.isMobile ? 'mb-6' : 'mb-8'}`}>
          <div className={`${securityFeatures.isMobile ? 'w-12 h-12' : 'w-16 h-16'} bg-red-600 rounded-xl mx-auto mb-4 flex items-center justify-center`}>
            <Icon name="Shield" size={securityFeatures.isMobile ? 24 : 32} color="white" />
          </div>
          <h1 className={`${securityFeatures.isMobile ? 'text-xl' : 'text-2xl'} font-bold text-white mb-2`}>
            Secure Admin Access
          </h1>
          <p className={`text-red-200 ${securityFeatures.isMobile ? 'text-sm' : ''}`}>
            High-security administrative portal
          </p>

          {/* Device indicator */}
          {securityFeatures.deviceType && (
            <div className="mt-2">
              <span className="inline-flex items-center space-x-1 text-xs text-red-300 bg-red-500/20 px-2 py-1 rounded-full">
                <Icon name={securityFeatures.isMobile ? "Smartphone" : "Monitor"} size={12} />
                <span>{securityFeatures.deviceType}</span>
              </span>
            </div>
          )}
        </div>

        <div className={`bg-white/10 backdrop-blur-lg rounded-2xl ${securityFeatures.isMobile ? 'p-6' : 'p-8'} border border-red-500/20 shadow-2xl`}>
          <form onSubmit={handleSubmit} className="space-y-6">
            {authStep === 'credentials' && (
              <>
                <div>
                  <label className="block text-sm font-medium mb-2 text-white">
                    Admin Email or Username
                  </label>
                  <Input
                    name="username"
                    type="text"
                    value={formData.username}
                    onChange={handleInputChange}
                    placeholder="admin@kleverinvest.com or admin"
                    className="bg-white/10 border-red-500/30 text-white placeholder-slate-400"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2 text-white">
                    Secure Password
                  </label>
                  <Input
                    name="password"
                    type="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder="Enter secure password"
                    className="bg-white/10 border-red-500/30 text-white placeholder-slate-400"
                    required
                  />
                </div>

                {/* Security Info */}
                <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
                  <div className="flex items-center space-x-2 mb-2">
                    <Icon name="AlertTriangle" size={16} className="text-red-400" />
                    <span className="text-red-400 text-sm font-medium">Authentication Required</span>
                  </div>
                  <div className="text-xs text-red-200 space-y-1">
                    <div>⚠ Valid admin credentials must be entered</div>
                    <div>⚠ No auto-login or credential bypass allowed</div>
                    <div>⚠ Login attempts remaining: {Math.max(0, 3 - loginAttempts)}</div>
                    <div className="mt-2 pt-2 border-t border-red-500/20">
                      <div className="text-red-300 font-medium">Test Credentials:</div>
                      <div>📧 admin@kleverinvest.com | 🔑 Admin@123!</div>
                      <div>📧 superadmin@kleverinvest.com | 🔑 SuperAdmin@456!</div>
                    </div>
                  </div>
                </div>
              </>
            )}

            {authStep === 'biometric' && (
              <ResponsiveBiometricAuth
                userId={formData.username || formData.email || 'admin'}
                userName={formData.username || formData.email || 'admin'}
                onSuccess={(result) => {
                  console.log('Biometric authentication successful:', result);
                  // Navigate to dashboard or intended page
                  const redirectURL = sessionStorage.getItem('adminRedirectURL');
                  if (redirectURL) {
                    sessionStorage.removeItem('adminRedirectURL');
                    navigate(redirectURL);
                  } else {
                    navigate('/admin-dashboard');
                  }
                }}
                onError={(error) => {
                  console.warn('Biometric authentication failed:', error);
                  setErrors({ general: `Biometric authentication failed: ${error.error}` });
                  // Fall back to MFA after a delay
                  setTimeout(() => {
                    setErrors({});
                    setAuthStep('mfa');
                  }, 3000);
                }}
                onFallback={() => {
                  setAuthStep('mfa');
                }}
                className="bg-white/5 backdrop-blur-sm"
              />
            )}

            {authStep === 'mfa' && (
              <div>
                <label className="block text-sm font-medium mb-2 text-white">
                  Multi-Factor Authentication Code
                </label>
                <Input
                  name="mfaCode"
                  type="text"
                  value={formData.mfaCode}
                  onChange={handleInputChange}
                  placeholder="Enter 6-digit MFA code"
                  className="bg-white/10 border-red-500/30 text-white placeholder-slate-400 text-center text-2xl tracking-widest"
                  maxLength="6"
                />
                <div className="text-xs text-red-200 mt-2 space-y-1">
                  <p>For demo, use: 123456, 000000, or 111111</p>
                  <p>Check your authenticator app for the security code</p>
                </div>
              </div>
            )}

            {errors.general && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
                <p className="text-red-400 text-sm">{errors.general}</p>
              </div>
            )}

            {authStep !== 'biometric' && (
              <Button
                type="submit"
                className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold"
                size="lg"
                disabled={isLoading}
                loading={isLoading}
              >
                {authStep === 'credentials' ? 'Verify Credentials' : 'Access Admin Panel'}
              </Button>
            )}

            {/* Biometric login only available after credential verification */}
            {authStep === 'credentials' && securityFeatures.biometricAvailable && formData.username && formData.password && (
              <div className="mt-3 p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="Fingerprint" size={14} className="text-blue-400" />
                  <span className="text-blue-400 text-xs font-medium">Biometric Available</span>
                </div>
                <p className="text-xs text-blue-200">
                  Biometric authentication will be available after credential verification
                </p>
              </div>
            )}
          </form>

          {/* Security Features Display */}
          <div className="mt-6 space-y-3">
            <div className="grid grid-cols-3 gap-2 text-xs text-red-200">
              <div className="text-center">
                <Icon name="Key" size={16} className="mx-auto mb-1" />
                <span>Encrypted</span>
              </div>
              <div className="text-center">
                <Icon
                  name="Fingerprint"
                  size={16}
                  className={`mx-auto mb-1 ${
                    securityFeatures.biometricAvailable ? 'text-green-400' : 'text-red-400'
                  }`}
                />
                <span>{securityFeatures.biometricAvailable ? 'Available' : 'Unavailable'}</span>
              </div>
              <div className="text-center">
                <Icon
                  name="Activity"
                  size={16}
                  className={`mx-auto mb-1 ${
                    securityFeatures.rateLimitStatus === 'active' ? 'text-green-400' : 'text-yellow-400'
                  }`}
                />
                <span>Monitored</span>
              </div>
            </div>

            {/* Security Status */}
            <div className="bg-black/20 rounded-lg p-3 text-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-red-300">Security Level:</span>
                <span className={`font-semibold ${
                  securityFeatures.deviceSecurity === 'high' ? 'text-green-400' :
                  securityFeatures.deviceSecurity === 'medium' ? 'text-yellow-400' : 'text-red-400'
                }`}>
                  {securityFeatures.deviceSecurity?.toUpperCase() || 'UNKNOWN'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-red-300">Device ID:</span>
                <span className="text-red-200 font-mono text-xs">
                  {securityFeatures.deviceFingerprint?.id?.substring(0, 8) || 'Unknown'}...
                </span>
              </div>
            </div>

            {/* Security Info Toggle */}
            <button
              type="button"
              onClick={() => setShowSecurityInfo(!showSecurityInfo)}
              className="w-full text-xs text-red-300 hover:text-red-200 transition-colors"
            >
              {showSecurityInfo ? 'Hide' : 'Show'} Security Details
            </button>

            {showSecurityInfo && (
              <div className="bg-black/20 rounded-lg p-3 text-xs space-y-2">
                <div className="text-red-300 font-semibold mb-2">Advanced Security Features:</div>
                <div className="space-y-1 text-red-200">
                  <div>✓ Device fingerprinting active</div>
                  <div>✓ Progressive rate limiting</div>
                  <div>✓ IP monitoring and blacklisting</div>
                  <div>✓ Biometric authentication support</div>
                  <div>✓ Multi-factor authentication</div>
                  <div>✓ Session security headers</div>
                  <div>✓ Brute force protection</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSecureLogin;
