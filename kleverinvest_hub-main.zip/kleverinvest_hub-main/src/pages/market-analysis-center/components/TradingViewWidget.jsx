import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const TradingViewWidget = ({ 
  symbol = 'BTCUSD', 
  height = '400px', 
  compact = false,
  interval = '1H',
  theme = 'dark'
}) => {
  const [mockPrice, setMockPrice] = useState(43250.50);
  const [mockChange, setMockChange] = useState(2.45);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate loading and price updates
  useEffect(() => {
    // Simulate loading time
    const loadingTimer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    // Simulate price updates
    const priceInterval = setInterval(() => {
      setMockPrice(prev => {
        const change = (Math.random() - 0.5) * 100;
        return Math.max(prev + change, 35000);
      });
      setMockChange((Math.random() - 0.5) * 10);
    }, 3000);

    return () => {
      clearTimeout(loadingTimer);
      clearInterval(priceInterval);
    };
  }, []);

  const isPositive = mockChange >= 0;

  if (isLoading) {
    return (
      <div 
        className="w-full bg-card rounded-lg flex items-center justify-center"
        style={{ height }}
      >
        <div className="flex items-center space-x-2 text-muted-foreground">
          <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
          <span className="text-sm">Loading chart...</span>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="w-full bg-card rounded-lg border border-border overflow-hidden"
      style={{ height }}
    >
      {/* Chart Header */}
      <div className="p-4 border-b border-border bg-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center text-xs font-bold text-white">
                ₿
              </div>
              <span className="font-medium text-foreground">{symbol}</span>
            </div>
            {!compact && (
              <div className="flex space-x-2">
                {['1H', '4H', '1D', '1W'].map(tf => (
                  <button
                    key={tf}
                    className={`px-2 py-1 text-xs rounded ${
                      tf === interval 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-muted text-muted-foreground hover:bg-muted/80'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-foreground">
              ${mockPrice.toLocaleString(undefined, { 
                minimumFractionDigits: 2, 
                maximumFractionDigits: 2 
              })}
            </div>
            <div className={`text-sm flex items-center justify-end space-x-1 ${
              isPositive ? 'text-success' : 'text-destructive'
            }`}>
              <Icon 
                name={isPositive ? 'TrendingUp' : 'TrendingDown'} 
                size={14} 
              />
              <span>
                {isPositive ? '+' : ''}{mockChange.toFixed(2)}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Mock Chart Area */}
      <div className="relative flex-1 bg-gradient-to-br from-card to-muted/20" style={{ height: 'calc(100% - 80px)' }}>
        {/* Grid lines */}
        <svg className="absolute inset-0 w-full h-full opacity-10">
          <defs>
            <pattern id="grid" width="50" height="40" patternUnits="userSpaceOnUse">
              <path d="M 50 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>

        {/* Mock candlestick chart */}
        <svg className="absolute inset-0 w-full h-full">
          {Array.from({length: 20}, (_, i) => {
            const x = (i + 1) * (100 / 21);
            const isUp = Math.random() > 0.5;
            const height = Math.random() * 30 + 10;
            const y = 20 + Math.random() * 40;
            
            return (
              <g key={i}>
                {/* Candlestick body */}
                <rect
                  x={`${x - 1}%`}
                  y={`${y}%`}
                  width="2%"
                  height={`${height}%`}
                  fill={isUp ? '#00D084' : '#F6465D'}
                  opacity={0.8}
                />
                {/* Wicks */}
                <line
                  x1={`${x}%`}
                  y1={`${y - 5}%`}
                  x2={`${x}%`}
                  y2={`${y + height + 5}%`}
                  stroke={isUp ? '#00D084' : '#F6465D'}
                  strokeWidth="1"
                  opacity={0.6}
                />
              </g>
            );
          })}
        </svg>

        {/* Chart overlay info */}
        <div className="absolute top-4 left-4 bg-background/80 backdrop-blur-sm border border-border rounded-lg p-3">
          <div className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
            {symbol} • {interval}
          </div>
          <div className="text-sm font-medium text-foreground">
            Live Trading Chart
          </div>
          {!compact && (
            <div className="text-xs text-muted-foreground mt-1">
              Demo mode - Real TradingView integration available
            </div>
          )}
        </div>

        {/* Volume indicator */}
        {!compact && (
          <div className="absolute bottom-4 left-4 flex space-x-1">
            {Array.from({length: 10}, (_, i) => (
              <div
                key={i}
                className="w-2 bg-primary/60"
                style={{ height: `${Math.random() * 20 + 5}px` }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Chart footer */}
      {!compact && (
        <div className="p-3 border-t border-border bg-muted/20">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Demo Chart • Real-time data available with TradingView integration</span>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
              <span>Live</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TradingViewWidget;
