import React, { useState, useEffect } from 'react';
        import Icon from '../../../components/AppIcon';
        import Button from '../../../components/ui/Button';
        import Input from '../../../components/ui/Input';

        const MarketScreener = ({ mobile = false }) => {
          const [filters, setFilters] = useState({
            priceChange: { min: '', max: '' },
            volume: { min: '', max: '' },
            marketCap: { min: '', max: '' },
            pattern: 'all'
          });
          const [results, setResults] = useState([]);
          const [sortBy, setSortBy] = useState('marketCap');
          const [sortOrder, setSortOrder] = useState('desc');
          const [isLoading, setIsLoading] = useState(false);

          // Mock cryptocurrency data
          const mockCryptoData = [
            {
              symbol: 'BTC',
              name: 'Bitcoin',
              price: 45780.25,
              change24h: 2.45,
              volume: 28500000000,
              marketCap: 876000000000,
              pattern: 'bullish_flag'
            },
            {
              symbol: 'ETH',
              name: 'Ethereum',
              price: 2890.50,
              change24h: -1.25,
              volume: 15200000000,
              marketCap: 347000000000,
              pattern: 'ascending_triangle'
            },
            {
              symbol: 'ADA',
              name: 'Cardano',
              price: 0.485,
              change24h: 5.67,
              volume: 1200000000,
              marketCap: 16200000000,
              pattern: 'breakout'
            },
            {
              symbol: 'DOT',
              name: 'Polkadot',
              price: 8.75,
              change24h: -3.12,
              volume: 850000000,
              marketCap: 9800000000,
              pattern: 'double_bottom'
            },
            {
              symbol: 'LINK',
              name: 'Chainlink',
              price: 15.24,
              change24h: 1.89,
              volume: 1100000000,
              marketCap: 8900000000,
              pattern: 'head_shoulders'
            }
          ];

          useEffect(() => {
            applyFilters();
          }, [filters, sortBy, sortOrder]);

          const applyFilters = () => {
            setIsLoading(true);
            
            setTimeout(() => {
              let filtered = mockCryptoData.filter(crypto => {
                const priceChangeMatch = (!filters.priceChange.min || crypto.change24h >= parseFloat(filters.priceChange.min)) &&
                                      (!filters.priceChange.max || crypto.change24h <= parseFloat(filters.priceChange.max));
                
                const volumeMatch = (!filters.volume.min || crypto.volume >= parseFloat(filters.volume.min) * 1000000) &&
                                  (!filters.volume.max || crypto.volume <= parseFloat(filters.volume.max) * 1000000);
                
                const marketCapMatch = (!filters.marketCap.min || crypto.marketCap >= parseFloat(filters.marketCap.min) * 1000000) &&
                                     (!filters.marketCap.max || crypto.marketCap <= parseFloat(filters.marketCap.max) * 1000000);
                
                const patternMatch = filters.pattern === 'all' || crypto.pattern === filters.pattern;
                
                return priceChangeMatch && volumeMatch && marketCapMatch && patternMatch;
              });

              // Sort results
              filtered.sort((a, b) => {
                const aVal = a[sortBy];
                const bVal = b[sortBy];
                return sortOrder === 'desc' ? bVal - aVal : aVal - bVal;
              });

              setResults(filtered);
              setIsLoading(false);
            }, 500);
          };

          const resetFilters = () => {
            setFilters({
              priceChange: { min: '', max: '' },
              volume: { min: '', max: '' },
              marketCap: { min: '', max: '' },
              pattern: 'all'
            });
          };

          const formatNumber = (num) => {
            if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
            if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
            if (num >= 1e3) return `$${(num / 1e3).toFixed(2)}K`;
            return `$${num.toFixed(2)}`;
          };

          const getPatternDisplay = (pattern) => {
            const patterns = {
              'bullish_flag': { name: 'Bullish Flag', color: 'text-green-600' },
              'ascending_triangle': { name: 'Ascending Triangle', color: 'text-blue-600' },
              'breakout': { name: 'Breakout', color: 'text-purple-600' },
              'double_bottom': { name: 'Double Bottom', color: 'text-orange-600' },
              'head_shoulders': { name: 'Head & Shoulders', color: 'text-red-600' }
            };
            return patterns[pattern] || { name: pattern, color: 'text-gray-600' };
          };

          return (
            <div className={`bg-card rounded-lg border ${mobile ? 'p-4' : 'p-6'}`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold flex items-center">
                  <Icon name="Search" size={20} className="mr-2" />
                  Market Screener
                </h3>
                <Button variant="ghost" size="sm" onClick={resetFilters}>
                  <Icon name="RotateCcw" size={16} />
                  <span className="ml-1">Reset</span>
                </Button>
              </div>

              {/* Filters */}
              <div className="space-y-4 mb-6">
                {/* Price Change Filter */}
                <div>
                  <label className="text-sm font-medium text-muted-foreground mb-2 block">
                    24h Price Change (%)
                  </label>
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Min"
                      value={filters.priceChange.min}
                      onChange={(e) => setFilters(prev => ({
                        ...prev,
                        priceChange: { ...prev.priceChange, min: e.target.value }
                      }))}
                      className="flex-1"
                    />
                    <Input
                      placeholder="Max"
                      value={filters.priceChange.max}
                      onChange={(e) => setFilters(prev => ({
                        ...prev,
                        priceChange: { ...prev.priceChange, max: e.target.value }
                      }))}
                      className="flex-1"
                    />
                  </div>
                </div>

                {/* Volume Filter */}
                <div>
                  <label className="text-sm font-medium text-muted-foreground mb-2 block">
                    Volume (Million USD)
                  </label>
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Min"
                      value={filters.volume.min}
                      onChange={(e) => setFilters(prev => ({
                        ...prev,
                        volume: { ...prev.volume, min: e.target.value }
                      }))}
                      className="flex-1"
                    />
                    <Input
                      placeholder="Max"
                      value={filters.volume.max}
                      onChange={(e) => setFilters(prev => ({
                        ...prev,
                        volume: { ...prev.volume, max: e.target.value }
                      }))}
                      className="flex-1"
                    />
                  </div>
                </div>

                {/* Technical Pattern Filter */}
                <div>
                  <label className="text-sm font-medium text-muted-foreground mb-2 block">
                    Technical Pattern
                  </label>
                  <select 
                    value={filters.pattern}
                    onChange={(e) => setFilters(prev => ({ ...prev, pattern: e.target.value }))}
                    className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm"
                  >
                    <option value="all">All Patterns</option>
                    <option value="bullish_flag">Bullish Flag</option>
                    <option value="ascending_triangle">Ascending Triangle</option>
                    <option value="breakout">Breakout</option>
                    <option value="double_bottom">Double Bottom</option>
                    <option value="head_shoulders">Head & Shoulders</option>
                  </select>
                </div>
              </div>

              {/* Sort Controls */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">Sort by:</span>
                  <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="bg-background border border-border rounded px-2 py-1 text-sm"
                  >
                    <option value="marketCap">Market Cap</option>
                    <option value="volume">Volume</option>
                    <option value="change24h">24h Change</option>
                    <option value="price">Price</option>
                  </select>
                  <Button
                    variant="ghost"
                    size="xs"
                    onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
                  >
                    <Icon name={sortOrder === 'desc' ? 'ArrowDown' : 'ArrowUp'} size={14} />
                  </Button>
                </div>
                
                <span className="text-sm text-muted-foreground">
                  {results.length} results
                </span>
              </div>

              {/* Results */}
              <div className="space-y-2">
                {isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  </div>
                ) : results.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No cryptocurrencies match your filters
                  </div>
                ) : (
                  results.map((crypto) => {
                    const pattern = getPatternDisplay(crypto.pattern);
                    return (
                      <div key={crypto.symbol} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <span className="font-medium">{crypto.symbol}</span>
                            <span className="text-sm text-muted-foreground">{crypto.name}</span>
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            <span className={pattern.color}>{pattern.name}</span>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="font-medium">
                            {formatNumber(crypto.price)}
                          </div>
                          <div className={`text-sm ${crypto.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h.toFixed(2)}%
                          </div>
                        </div>
                        
                        <div className="text-right ml-4">
                          <div className="text-sm text-muted-foreground">
                            Vol: {formatNumber(crypto.volume)}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Cap: {formatNumber(crypto.marketCap)}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        };

        export default MarketScreener;