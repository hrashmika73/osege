import React, { useState } from 'react';
        import Icon from '../../../components/AppIcon';
        import Button from '../../../components/ui/Button';
        import Input from '../../../components/ui/Input';

        const BookmarkManager = ({ bookmarks = [], onSave, onLoad }) => {
          const [isOpen, setIsOpen] = useState(false);
          const [saveDialogOpen, setSaveDialogOpen] = useState(false);
          const [bookmarkName, setBookmarkName] = useState('');

          const handleSave = () => {
            if (bookmarkName.trim()) {
              onSave?.({ name: bookmarkName.trim() });
              setBookmarkName('');
              setSaveDialogOpen(false);
            }
          };

          const handleLoad = (bookmark) => {
            onLoad?.(bookmark);
            setIsOpen(false);
          };

          const formatDate = (dateString) => {
            return new Date(dateString).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            });
          };

          return (
            <div className="relative">
              {/* Main Bookmark Button */}
              <div className="flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSaveDialogOpen(true)}
                  title="Save current setup"
                >
                  <Icon name="Bookmark" size={16} />
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(!isOpen)}
                  title="Load saved setup"
                >
                  <Icon name="FolderOpen" size={16} />
                  {bookmarks.length > 0 && (
                    <span className="ml-1 text-xs bg-primary text-primary-foreground rounded-full px-1.5 py-0.5 min-w-[18px] h-[18px] flex items-center justify-center">
                      {bookmarks.length}
                    </span>
                  )}
                </Button>
              </div>

              {/* Save Dialog */}
              {saveDialogOpen && (
                <div className="absolute top-full right-0 mt-2 w-80 bg-card border rounded-lg shadow-lg z-50 p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium">Save Analysis Setup</h3>
                    <Button
                      variant="ghost"
                      size="xs"
                      onClick={() => setSaveDialogOpen(false)}
                    >
                      <Icon name="X" size={16} />
                    </Button>
                  </div>
                  
                  <div className="space-y-3">
                    <Input
                      placeholder="Enter bookmark name..."
                      value={bookmarkName}
                      onChange={(e) => setBookmarkName(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSave()}
                      autoFocus
                    />
                    
                    <div className="flex items-center justify-end space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSaveDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button
                        size="sm"
                        onClick={handleSave}
                        disabled={!bookmarkName.trim()}
                      >
                        <Icon name="Save" size={16} />
                        <span className="ml-2">Save</span>
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Bookmarks Dropdown */}
              {isOpen && (
                <div className="absolute top-full right-0 mt-2 w-96 bg-card border rounded-lg shadow-lg z-50">
                  <div className="flex items-center justify-between p-4 border-b">
                    <h3 className="font-medium flex items-center">
                      <Icon name="Bookmark" size={18} className="mr-2" />
                      Saved Analysis Setups
                    </h3>
                    <Button
                      variant="ghost"
                      size="xs"
                      onClick={() => setIsOpen(false)}
                    >
                      <Icon name="X" size={16} />
                    </Button>
                  </div>

                  <div className="max-h-80 overflow-y-auto">
                    {bookmarks.length === 0 ? (
                      <div className="p-8 text-center text-muted-foreground">
                        <Icon name="Bookmark" size={48} className="mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No saved setups yet</p>
                        <p className="text-xs mt-1">Save your current analysis configuration to access it later</p>
                      </div>
                    ) : (
                      <div className="p-2">
                        {bookmarks.map((bookmark) => (
                          <div
                            key={bookmark.id}
                            className="flex items-center justify-between p-3 hover:bg-muted/50 rounded-lg transition-colors group"
                          >
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center space-x-2 mb-1">
                                <Icon name="Bookmark" size={14} className="text-primary" />
                                <span className="font-medium text-sm truncate">
                                  {bookmark.name}
                                </span>
                              </div>
                              
                              <div className="text-xs text-muted-foreground">
                                <span>{bookmark.assets?.join(', ') || 'No assets'}</span>
                                <span className="mx-2">•</span>
                                <span>{bookmark.layout || 'Default layout'}</span>
                              </div>
                              
                              <div className="text-xs text-muted-foreground mt-1">
                                Saved {formatDate(bookmark.timestamp)}
                              </div>
                            </div>

                            <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button
                                variant="ghost"
                                size="xs"
                                onClick={() => handleLoad(bookmark)}
                                title="Load this setup"
                              >
                                <Icon name="Play" size={14} />
                              </Button>
                              
                              <Button
                                variant="ghost"
                                size="xs"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  // Handle delete bookmark
                                }}
                                title="Delete bookmark"
                                className="text-red-600 hover:text-red-700"
                              >
                                <Icon name="Trash2" size={14} />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {bookmarks.length > 0 && (
                    <div className="p-3 border-t bg-muted/30">
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>{bookmarks.length} saved setup{bookmarks.length !== 1 ? 's' : ''}</span>
                        <Button variant="ghost" size="xs" className="text-xs">
                          <Icon name="Download" size={12} />
                          <span className="ml-1">Export All</span>
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Backdrop */}
              {(isOpen || saveDialogOpen) && (
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => {
                    setIsOpen(false);
                    setSaveDialogOpen(false);
                  }}
                />
              )}
            </div>
          );
        };

        export default BookmarkManager;