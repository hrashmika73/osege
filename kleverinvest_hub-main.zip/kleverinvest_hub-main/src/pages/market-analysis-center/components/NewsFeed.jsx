import React, { useState, useEffect } from 'react';
        import Icon from '../../../components/AppIcon';
        import Button from '../../../components/ui/Button';

        const NewsFeed = ({ mobile = false }) => {
          const [news, setNews] = useState([]);
          const [filter, setFilter] = useState('all');
          const [isLoading, setIsLoading] = useState(true);

          // Mock news data
          const mockNewsData = [
            {
              id: 1,
              title: 'Bitcoin Surges 5% Following Major Institution Adoption',
              summary: 'Leading financial institution announces plans to add Bitcoin to treasury reserves, signaling growing institutional confidence...',
              source: 'CryptoNews Pro',
              credibility: 'high',
              impact: 'high',
              category: 'market',
              timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
              url: '#'
            },
            {
              id: 2,
              title: 'New SEC Guidance on Cryptocurrency Regulation Released',
              summary: 'Securities and Exchange Commission provides clearer framework for digital asset compliance, potentially reducing regulatory uncertainty...',
              source: 'Regulatory Watch',
              credibility: 'very-high',
              impact: 'medium',
              category: 'regulatory',
              timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
              url: '#'
            },
            {
              id: 3,
              title: 'Ethereum 2.0 Staking Reaches New Milestone',
              summary: 'Over 15 million ETH now staked in Ethereum 2.0 contracts, representing significant network security improvement...',
              source: 'DeFi Analytics',
              credibility: 'high',
              impact: 'medium',
              category: 'technical',
              timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
              url: '#'
            },
            {
              id: 4,
              title: 'Major DeFi Protocol Experiences Flash Loan Attack',
              summary: 'Decentralized finance protocol loses $12M in sophisticated flash loan exploit, highlighting ongoing smart contract risks...',
              source: 'Security Alert',
              credibility: 'medium',
              impact: 'high',
              category: 'security',
              timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
              url: '#'
            },
            {
              id: 5,
              title: 'Central Bank Digital Currency Pilot Program Expands',
              summary: 'Three additional countries join CBDC testing initiative, exploring potential for digital currency implementation...',
              source: 'Global Finance',
              credibility: 'high',
              impact: 'low',
              category: 'regulatory',
              timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
              url: '#'
            }
          ];

          useEffect(() => {
            // Simulate loading
            setIsLoading(true);
            setTimeout(() => {
              setNews(mockNewsData);
              setIsLoading(false);
            }, 1000);
          }, []);

          const filteredNews = news.filter(item => 
            filter === 'all' || item.category === filter
          );

          const getTimeSince = (timestamp) => {
            const now = new Date();
            const time = new Date(timestamp);
            const diffInMinutes = Math.floor((now - time) / (1000 * 60));
            
            if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
            if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
            return `${Math.floor(diffInMinutes / 1440)}d ago`;
          };

          const getCredibilityColor = (credibility) => {
            const colors = {
              'very-high': 'bg-green-100 text-green-800 border-green-200',
              'high': 'bg-blue-100 text-blue-800 border-blue-200',
              'medium': 'bg-yellow-100 text-yellow-800 border-yellow-200',
              'low': 'bg-red-100 text-red-800 border-red-200'
            };
            return colors[credibility] || colors.medium;
          };

          const getImpactColor = (impact) => {
            const colors = {
              'high': 'text-red-600',
              'medium': 'text-orange-600',
              'low': 'text-green-600'
            };
            return colors[impact] || colors.medium;
          };

          const getCategoryIcon = (category) => {
            const icons = {
              'market': 'TrendingUp',
              'regulatory': 'Shield',
              'technical': 'Code',
              'security': 'AlertTriangle'
            };
            return icons[category] || 'FileText';
          };

          return (
            <div className={`bg-card rounded-lg border ${mobile ? 'p-4' : 'p-6'}`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold flex items-center">
                  <Icon name="Newspaper" size={20} className="mr-2" />
                  Market News
                </h3>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-xs text-muted-foreground">Live</span>
                </div>
              </div>

              {/* Category Filters */}
              <div className="flex flex-wrap gap-2 mb-4">
                {[
                  { key: 'all', label: 'All', icon: 'Globe' },
                  { key: 'market', label: 'Market', icon: 'TrendingUp' },
                  { key: 'regulatory', label: 'Regulatory', icon: 'Shield' },
                  { key: 'technical', label: 'Technical', icon: 'Code' },
                  { key: 'security', label: 'Security', icon: 'AlertTriangle' }
                ].map((category) => (
                  <Button
                    key={category.key}
                    variant={filter === category.key ? "default" : "ghost"}
                    size="xs"
                    onClick={() => setFilter(category.key)}
                  >
                    <Icon name={category.icon} size={14} />
                    <span className="ml-1">{category.label}</span>
                  </Button>
                ))}
              </div>

              {/* News List */}
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  </div>
                ) : filteredNews.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No news available for selected category
                  </div>
                ) : (
                  filteredNews.map((item) => (
                    <div key={item.id} className="border-b pb-4 last:border-b-0 last:pb-0">
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center mt-1">
                          <Icon name={getCategoryIcon(item.category)} size={16} className="text-muted-foreground" />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-1">
                            <span className={`text-xs px-2 py-1 rounded-full border ${getCredibilityColor(item.credibility)}`}>
                              {item.credibility.replace('-', ' ')}
                            </span>
                            <span className={`text-xs font-medium ${getImpactColor(item.impact)}`}>
                              {item.impact.toUpperCase()} IMPACT
                            </span>
                          </div>
                          
                          <h4 className="font-medium text-sm leading-tight mb-2 hover:text-primary cursor-pointer">
                            {item.title}
                          </h4>
                          
                          <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                            {item.summary}
                          </p>
                          
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>{item.source}</span>
                            <span>{getTimeSince(item.timestamp)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* View More Button */}
              {!mobile && filteredNews.length > 0 && (
                <div className="mt-4 pt-4 border-t">
                  <Button variant="ghost" size="sm" className="w-full">
                    <Icon name="ExternalLink" size={16} />
                    <span className="ml-2">View All News</span>
                  </Button>
                </div>
              )}
            </div>
          );
        };

        export default NewsFeed;