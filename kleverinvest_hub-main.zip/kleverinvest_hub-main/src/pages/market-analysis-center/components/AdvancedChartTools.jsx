import React, { useState } from 'react';
        import Icon from '../../../components/AppIcon';
        import Button from '../../../components/ui/Button';

        const AdvancedChartTools = () => {
          const [selectedTool, setSelectedTool] = useState('patterns');
          const [activePatterns, setActivePatterns] = useState([]);
          const [customIndicators, setCustomIndicators] = useState([]);
          const [supportResistance, setSupportResistance] = useState({ enabled: true, levels: [] });

          const patternTypes = [
            { id: 'head_shoulders', name: 'Head & Shoulders', accuracy: 85 },
            { id: 'double_top', name: 'Double Top', accuracy: 78 },
            { id: 'triangle', name: 'Triangle', accuracy: 82 },
            { id: 'flag', name: 'Flag Pattern', accuracy: 73 },
            { id: 'cup_handle', name: 'Cup & Handle', accuracy: 79 }
          ];

          const indicators = [
            { id: 'custom_rsi', name: 'Custom RSI', type: 'oscillator', status: 'active' },
            { id: 'bollinger_custom', name: 'Bollinger Bands+', type: 'volatility', status: 'inactive' },
            { id: 'macd_histogram', name: 'MACD Histogram', type: 'momentum', status: 'active' },
            { id: 'fibonacci_auto', name: 'Auto Fibonacci', type: 'retracement', status: 'inactive' }
          ];

          const supportResistanceLevels = [
            { price: 45780, type: 'resistance', strength: 'strong', touches: 5 },
            { price: 44200, type: 'support', strength: 'medium', touches: 3 },
            { price: 47500, type: 'resistance', strength: 'weak', touches: 2 },
            { price: 43000, type: 'support', strength: 'strong', touches: 7 }
          ];

          const togglePattern = (patternId) => {
            setActivePatterns(prev => 
              prev.includes(patternId) 
                ? prev.filter(id => id !== patternId)
                : [...prev, patternId]
            );
          };

          const toggleIndicator = (indicatorId) => {
            setCustomIndicators(prev => 
              prev.map(indicator => 
                indicator.id === indicatorId 
                  ? { ...indicator, status: indicator.status === 'active' ? 'inactive' : 'active' }
                  : indicator
              )
            );
          };

          const getToolIcon = (tool) => {
            const icons = {
              'patterns': 'Scan',
              'indicators': 'BarChart3',
              'support_resistance': 'GitBranch',
              'drawing': 'Edit3'
            };
            return icons[tool] || 'Tool';
          };

          const getStrengthColor = (strength) => {
            const colors = {
              'strong': 'text-green-600 bg-green-100',
              'medium': 'text-yellow-600 bg-yellow-100',
              'weak': 'text-red-600 bg-red-100'
            };
            return colors[strength] || colors.medium;
          };

          const toolCategories = [
            { key: 'patterns', label: 'Patterns', icon: 'Scan' },
            { key: 'indicators', label: 'Indicators', icon: 'BarChart3' },
            { key: 'support_resistance', label: 'S/R Levels', icon: 'GitBranch' },
            { key: 'drawing', label: 'Drawing', icon: 'Edit3' }
          ];

          return (
            <div className="bg-card rounded-lg border p-6 h-full">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold flex items-center">
                  <Icon name="Wrench" size={20} className="mr-2" />
                  Advanced Tools
                </h3>
                <Button variant="ghost" size="sm">
                  <Icon name="Settings" size={16} />
                </Button>
              </div>

              {/* Tool Categories */}
              <div className="flex flex-wrap gap-1 mb-4 bg-muted rounded-lg p-1">
                {toolCategories.map((category) => (
                  <Button
                    key={category.key}
                    variant={selectedTool === category.key ? "default" : "ghost"}
                    size="xs"
                    onClick={() => setSelectedTool(category.key)}
                  >
                    <Icon name={category.icon} size={14} />
                    <span className="ml-1 text-xs">{category.label}</span>
                  </Button>
                ))}
              </div>

              {/* Tool Content */}
              <div className="space-y-4 max-h-48 overflow-y-auto">
                {selectedTool === 'patterns' && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-medium">Pattern Recognition</h4>
                      <Button variant="ghost" size="xs">
                        <Icon name="Play" size={14} />
                        <span className="ml-1">Scan</span>
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {patternTypes.map((pattern) => (
                        <div key={pattern.id} className="flex items-center justify-between p-2 bg-muted/30 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              checked={activePatterns.includes(pattern.id)}
                              onChange={() => togglePattern(pattern.id)}
                              className="w-4 h-4 text-primary bg-background border border-border rounded focus:ring-primary"
                            />
                            <div>
                              <div className="text-sm font-medium">{pattern.name}</div>
                              <div className="text-xs text-muted-foreground">
                                {pattern.accuracy}% accuracy
                              </div>
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {activePatterns.includes(pattern.id) ? 'Active' : 'Inactive'}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {selectedTool === 'indicators' && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-medium">Custom Indicators</h4>
                      <Button variant="ghost" size="xs">
                        <Icon name="Plus" size={14} />
                        <span className="ml-1">Create</span>
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {indicators.map((indicator) => (
                        <div key={indicator.id} className="flex items-center justify-between p-2 bg-muted/30 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${
                              indicator.status === 'active' ? 'bg-green-500' : 'bg-gray-400'
                            }`} />
                            <div>
                              <div className="text-sm font-medium">{indicator.name}</div>
                              <div className="text-xs text-muted-foreground capitalize">
                                {indicator.type}
                              </div>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="xs"
                            onClick={() => toggleIndicator(indicator.id)}
                          >
                            {indicator.status === 'active' ? 'Disable' : 'Enable'}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {selectedTool === 'support_resistance' && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-medium">Support/Resistance</h4>
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={supportResistance.enabled}
                          onChange={(e) => setSupportResistance(prev => ({ ...prev, enabled: e.target.checked }))}
                          className="w-4 h-4 text-primary bg-background border border-border rounded focus:ring-primary"
                        />
                        <span className="text-xs text-muted-foreground">Auto-detect</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {supportResistanceLevels.map((level, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-muted/30 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <div className={`w-3 h-3 rounded-full ${
                              level.type === 'support' ? 'bg-green-500' : 'bg-red-500'
                            }`} />
                            <div>
                              <div className="text-sm font-medium">${level.price.toLocaleString()}</div>
                              <div className="text-xs text-muted-foreground capitalize">
                                {level.type} • {level.touches} touches
                              </div>
                            </div>
                          </div>
                          <span className={`text-xs px-2 py-1 rounded-full ${getStrengthColor(level.strength)}`}>
                            {level.strength}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {selectedTool === 'drawing' && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-medium">Drawing Tools</h4>
                      <Button variant="ghost" size="xs">
                        <Icon name="Trash2" size={14} />
                        <span className="ml-1">Clear</span>
                      </Button>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { name: 'Trend Line', icon: 'Minus' },
                        { name: 'Rectangle', icon: 'Square' },
                        { name: 'Circle', icon: 'Circle' },
                        { name: 'Arrow', icon: 'ArrowRight' },
                        { name: 'Text', icon: 'Type' },
                        { name: 'Fibonacci', icon: 'GitBranch' }
                      ].map((tool) => (
                        <Button key={tool.name} variant="ghost" size="sm" className="justify-start">
                          <Icon name={tool.icon} size={16} />
                          <span className="ml-2 text-xs">{tool.name}</span>
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Quick Actions */}
              <div className="mt-4 pt-4 border-t">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Quick Actions</span>
                  <div className="flex space-x-1">
                    <Button variant="ghost" size="xs">
                      <Icon name="Save" size={14} />
                    </Button>
                    <Button variant="ghost" size="xs">
                      <Icon name="Download" size={14} />
                    </Button>
                    <Button variant="ghost" size="xs">
                      <Icon name="Share" size={14} />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          );
        };

        export default AdvancedChartTools;