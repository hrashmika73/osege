import React, { useState, useEffect } from 'react';
        import Icon from '../../../components/AppIcon';
        import Button from '../../../components/ui/Button';

        const EconomicCalendar = ({ mobile = false }) => {
          const [events, setEvents] = useState([]);
          const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
          const [filterImportance, setFilterImportance] = useState('all');
          const [isLoading, setIsLoading] = useState(true);

          // Mock economic events data
          const mockEventsData = [
            {
              id: 1,
              title: 'Federal Reserve Interest Rate Decision',
              time: '14:00',
              date: new Date().toISOString().split('T')[0],
              importance: 'high',
              impact: 'high',
              previous: '5.25%',
              forecast: '5.50%',
              actual: null,
              country: 'US',
              category: 'monetary_policy',
              description: 'Central bank monetary policy decision affecting global crypto markets'
            },
            {
              id: 2,
              title: 'EU Consumer Price Index (CPI)',
              time: '10:00',
              date: new Date().toISOString().split('T')[0],
              importance: 'medium',
              impact: 'medium',
              previous: '2.4%',
              forecast: '2.6%',
              actual: '2.8%',
              country: 'EU',
              category: 'inflation',
              description: 'Inflation data impacting European monetary policy'
            },
            {
              id: 3,
              title: 'Bitcoin ETF Approval Hearing',
              time: '16:30',
              date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              importance: 'high',
              impact: 'high',
              previous: null,
              forecast: null,
              actual: null,
              country: 'US',
              category: 'regulatory',
              description: 'SEC hearing on major Bitcoin ETF application'
            },
            {
              id: 4,
              title: 'Japan Bank of Japan Meeting',
              time: '03:00',
              date: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString().split('T')[0],
              importance: 'medium',
              impact: 'low',
              previous: '-0.10%',
              forecast: '-0.10%',
              actual: null,
              country: 'JP',
              category: 'monetary_policy',
              description: 'Central bank policy meeting affecting Asian crypto markets'
            },
            {
              id: 5,
              title: 'UK GDP Growth Rate',
              time: '07:00',
              date: new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString().split('T')[0],
              importance: 'medium',
              impact: 'medium',
              previous: '0.2%',
              forecast: '0.3%',
              actual: null,
              country: 'UK',
              category: 'growth',
              description: 'Economic growth data influencing market sentiment'
            }
          ];

          useEffect(() => {
            setIsLoading(true);
            setTimeout(() => {
              setEvents(mockEventsData);
              setIsLoading(false);
            }, 800);
          }, []);

          const filteredEvents = events.filter(event => {
            const dateMatch = event.date === selectedDate;
            const importanceMatch = filterImportance === 'all' || event.importance === filterImportance;
            return dateMatch && importanceMatch;
          });

          const getImportanceColor = (importance) => {
            const colors = {
              'high': 'bg-red-100 text-red-800 border-red-200',
              'medium': 'bg-yellow-100 text-yellow-800 border-yellow-200',
              'low': 'bg-green-100 text-green-800 border-green-200'
            };
            return colors[importance] || colors.medium;
          };

          const getImpactIcon = (impact) => {
            const icons = {
              'high': 'AlertTriangle',
              'medium': 'Info',
              'low': 'CheckCircle'
            };
            return icons[impact] || 'Info';
          };

          const getCategoryIcon = (category) => {
            const icons = {
              'monetary_policy': 'Landmark',
              'inflation': 'TrendingUp',
              'regulatory': 'Shield',
              'growth': 'BarChart3'
            };
            return icons[category] || 'Calendar';
          };

          const getCountryFlag = (country) => {
            const flags = {
              'US': '🇺🇸',
              'EU': '🇪🇺',
              'JP': '🇯🇵',
              'UK': '🇬🇧'
            };
            return flags[country] || '🌍';
          };

          const getNextWeekDates = () => {
            const dates = [];
            const today = new Date();
            for (let i = 0; i < 7; i++) {
              const date = new Date(today);
              date.setDate(today.getDate() + i);
              dates.push({
                value: date.toISOString().split('T')[0],
                label: date.toLocaleDateString('en-US', { 
                  weekday: 'short', 
                  month: 'short', 
                  day: 'numeric' 
                })
              });
            }
            return dates;
          };

          return (
            <div className={`bg-card rounded-lg border ${mobile ? 'p-4' : 'p-6'} h-full`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold flex items-center">
                  <Icon name="Calendar" size={20} className="mr-2" />
                  Economic Calendar
                </h3>
                <Button variant="ghost" size="sm">
                  <Icon name="Settings" size={16} />
                </Button>
              </div>

              {/* Date Navigation */}
              <div className="mb-4 space-y-3">
                <div className="flex overflow-x-auto scrollbar-hide space-x-2">
                  {getNextWeekDates().map((date) => (
                    <Button
                      key={date.value}
                      variant={selectedDate === date.value ? "default" : "ghost"}
                      size="sm"
                      className="whitespace-nowrap"
                      onClick={() => setSelectedDate(date.value)}
                    >
                      {date.label}
                    </Button>
                  ))}
                </div>

                {/* Importance Filter */}
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">Filter:</span>
                  {[
                    { key: 'all', label: 'All' },
                    { key: 'high', label: 'High Impact' },
                    { key: 'medium', label: 'Medium Impact' },
                    { key: 'low', label: 'Low Impact' }
                  ].map((filter) => (
                    <Button
                      key={filter.key}
                      variant={filterImportance === filter.key ? "default" : "ghost"}
                      size="xs"
                      onClick={() => setFilterImportance(filter.key)}
                    >
                      {filter.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Events List */}
              <div className="space-y-3 overflow-y-auto max-h-64">
                {isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  </div>
                ) : filteredEvents.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Icon name="Calendar" size={48} className="mx-auto mb-2 opacity-50" />
                    <p>No events scheduled for selected date</p>
                  </div>
                ) : (
                  filteredEvents.map((event) => (
                    <div key={event.id} className="border rounded-lg p-4 hover:bg-muted/50 transition-colors">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <span className="text-lg">{getCountryFlag(event.country)}</span>
                          <span className="font-medium text-sm">{event.time}</span>
                          <span className={`text-xs px-2 py-1 rounded-full border ${getImportanceColor(event.importance)}`}>
                            {event.importance.toUpperCase()}
                          </span>
                        </div>
                        <Icon name={getImpactIcon(event.impact)} size={16} className="text-muted-foreground" />
                      </div>

                      <h4 className="font-medium mb-2 flex items-center">
                        <Icon name={getCategoryIcon(event.category)} size={16} className="mr-2" />
                        {event.title}
                      </h4>

                      <p className="text-xs text-muted-foreground mb-3">
                        {event.description}
                      </p>

                      {/* Event Data */}
                      <div className="grid grid-cols-3 gap-3 text-xs">
                        {event.previous && (
                          <div>
                            <span className="text-muted-foreground block">Previous</span>
                            <span className="font-medium">{event.previous}</span>
                          </div>
                        )}
                        {event.forecast && (
                          <div>
                            <span className="text-muted-foreground block">Forecast</span>
                            <span className="font-medium">{event.forecast}</span>
                          </div>
                        )}
                        {event.actual && (
                          <div>
                            <span className="text-muted-foreground block">Actual</span>
                            <span className={`font-medium ${
                              event.actual > event.forecast ? 'text-green-600' : 
                              event.actual < event.forecast ? 'text-red-600' : 'text-foreground'
                            }`}>
                              {event.actual}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        };

        export default EconomicCalendar;