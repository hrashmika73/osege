import React, { useState, useEffect } from 'react';
        import Icon from '../../../components/AppIcon';
        import Button from '../../../components/ui/Button';

        const SocialSentiment = ({ mobile = false }) => {
          const [sentimentData, setSentimentData] = useState({});
          const [trendingTopics, setTrendingTopics] = useState([]);
          const [selectedTimeframe, setSelectedTimeframe] = useState('24h');
          const [isLoading, setIsLoading] = useState(true);

          // Mock sentiment data
          const mockSentimentData = {
            overall: {
              score: 72,
              trend: 'positive',
              change: '+5.2%'
            },
            sources: {
              twitter: { score: 75, volume: 15420, trend: 'positive' },
              reddit: { score: 68, volume: 8750, trend: 'neutral' },
              telegram: { score: 78, volume: 12300, trend: 'positive' },
              discord: { score: 71, volume: 6890, trend: 'positive' }
            },
            coins: {
              'BTC': { score: 76, volume: 25000, trend: 'positive', change: '+3.1%' },
              'ETH': { score: 69, volume: 18500, trend: 'neutral', change: '-1.2%' },
              'ADA': { score: 82, volume: 12400, trend: 'positive', change: '+8.7%' },
              'DOT': { score: 65, volume: 8900, trend: 'neutral', change: '-2.3%' }
            }
          };

          const mockTrendingTopics = [
            { topic: '#BitcoinETF', mentions: 45200, sentiment: 'positive', change: '+120%' },
            { topic: 'Ethereum 2.0', mentions: 32100, sentiment: 'positive', change: '+45%' },
            { topic: 'DeFi Protocol', mentions: 28900, sentiment: 'neutral', change: '+12%' },
            { topic: 'Regulatory News', mentions: 21500, sentiment: 'negative', change: '-8%' },
            { topic: 'NFT Market', mentions: 18700, sentiment: 'neutral', change: '-15%' }
          ];

          useEffect(() => {
            setIsLoading(true);
            setTimeout(() => {
              setSentimentData(mockSentimentData);
              setTrendingTopics(mockTrendingTopics);
              setIsLoading(false);
            }, 1000);
          }, [selectedTimeframe]);

          const getSentimentColor = (sentiment) => {
            const colors = {
              'positive': 'text-green-600',
              'neutral': 'text-yellow-600',
              'negative': 'text-red-600'
            };
            return colors[sentiment] || colors.neutral;
          };

          const getSentimentIcon = (sentiment) => {
            const icons = {
              'positive': 'TrendingUp',
              'neutral': 'Minus',
              'negative': 'TrendingDown'
            };
            return icons[sentiment] || icons.neutral;
          };

          const getSourceIcon = (source) => {
            const icons = {
              'twitter': 'Twitter',
              'reddit': 'MessageCircle',
              'telegram': 'Send',
              'discord': 'MessageSquare'
            };
            return icons[source] || 'MessageCircle';
          };

          const getSentimentScoreColor = (score) => {
            if (score >= 70) return 'text-green-600 bg-green-100';
            if (score >= 50) return 'text-yellow-600 bg-yellow-100';
            return 'text-red-600 bg-red-100';
          };

          const timeframes = [
            { key: '1h', label: '1H' },
            { key: '4h', label: '4H' },
            { key: '24h', label: '24H' },
            { key: '7d', label: '7D' }
          ];

          return (
            <div className={`bg-card rounded-lg border ${mobile ? 'p-4' : 'p-6'}`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold flex items-center">
                  <Icon name="Heart" size={20} className="mr-2" />
                  Social Sentiment
                </h3>
                <div className="flex items-center space-x-2">
                  {timeframes.map((timeframe) => (
                    <Button
                      key={timeframe.key}
                      variant={selectedTimeframe === timeframe.key ? "default" : "ghost"}
                      size="xs"
                      onClick={() => setSelectedTimeframe(timeframe.key)}
                    >
                      {timeframe.label}
                    </Button>
                  ))}
                </div>
              </div>

              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Overall Sentiment */}
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center justify-center mb-2">
                      <div className={`text-4xl font-bold ${getSentimentScoreColor(sentimentData.overall?.score)} px-4 py-2 rounded-lg`}>
                        {sentimentData.overall?.score}
                      </div>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <Icon 
                        name={getSentimentIcon(sentimentData.overall?.trend)} 
                        size={16} 
                        className={getSentimentColor(sentimentData.overall?.trend)} 
                      />
                      <span className="text-sm text-muted-foreground">Overall Sentiment</span>
                      <span className={`text-sm font-medium ${getSentimentColor(sentimentData.overall?.trend)}`}>
                        {sentimentData.overall?.change}
                      </span>
                    </div>
                  </div>

                  {/* Source Breakdown */}
                  <div>
                    <h4 className="text-sm font-medium mb-3">Source Analysis</h4>
                    <div className="grid grid-cols-2 gap-3">
                      {Object.entries(sentimentData.sources || {}).map(([source, data]) => (
                        <div key={source} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <Icon name={getSourceIcon(source)} size={16} className="text-muted-foreground" />
                            <div>
                              <div className="text-sm font-medium capitalize">{source}</div>
                              <div className="text-xs text-muted-foreground">
                                {data.volume?.toLocaleString()} posts
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className={`text-sm font-bold ${getSentimentScoreColor(data.score)}`}>
                              {data.score}
                            </div>
                            <div className={`text-xs ${getSentimentColor(data.trend)}`}>
                              {data.trend}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Coin Sentiment */}
                  <div>
                    <h4 className="text-sm font-medium mb-3">Cryptocurrency Sentiment</h4>
                    <div className="space-y-2">
                      {Object.entries(sentimentData.coins || {}).map(([coin, data]) => (
                        <div key={coin} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                              <span className="text-xs font-bold">{coin}</span>
                            </div>
                            <div>
                              <div className="text-sm font-medium">{coin}</div>
                              <div className="text-xs text-muted-foreground">
                                {data.volume?.toLocaleString()} mentions
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className={`text-sm font-bold ${getSentimentScoreColor(data.score)}`}>
                              {data.score}
                            </div>
                            <div className={`text-xs font-medium ${
                              data.change?.startsWith('+') ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {data.change}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Trending Topics */}
                  <div>
                    <h4 className="text-sm font-medium mb-3">Trending Topics</h4>
                    <div className="space-y-2">
                      {trendingTopics.map((topic, index) => (
                        <div key={index} className="flex items-center justify-between p-2 hover:bg-muted/50 rounded-lg transition-colors">
                          <div className="flex items-center space-x-3">
                            <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center">
                              <span className="text-xs font-bold">{index + 1}</span>
                            </div>
                            <div>
                              <div className="text-sm font-medium">{topic.topic}</div>
                              <div className="text-xs text-muted-foreground">
                                {topic.mentions?.toLocaleString()} mentions
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Icon 
                              name={getSentimentIcon(topic.sentiment)} 
                              size={14} 
                              className={getSentimentColor(topic.sentiment)} 
                            />
                            <span className={`text-xs font-medium ${
                              topic.change?.startsWith('+') ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {topic.change}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        };

        export default SocialSentiment;