import React, { useState, useEffect } from 'react';
        import { useNavigate } from 'react-router-dom';
        import Icon from '../../components/AppIcon';
        import Button from '../../components/ui/Button';
        import TradingViewWidget from './components/TradingViewWidget';
        import MarketScreener from './components/MarketScreener';
        import NewsFeed from './components/NewsFeed';
        import EconomicCalendar from './components/EconomicCalendar';
        import SocialSentiment from './components/SocialSentiment';
        import AdvancedChartTools from './components/AdvancedChartTools';
        import BookmarkManager from './components/BookmarkManager';

        const MarketAnalysisCenter = () => {
          const navigate = useNavigate();
          const [activeView, setActiveView] = useState('overview');
          const [selectedAssets, setSelectedAssets] = useState(['BTCUSD', 'ETHUSD', 'ADAUSD', 'DOTUSD']);
          const [chartLayout, setChartLayout] = useState('grid-4');
          const [bookmarkedSetups, setBookmarkedSetups] = useState([]);
          const [realTimeData, setRealTimeData] = useState({});

          // Simulate real-time data updates
          useEffect(() => {
            const interval = setInterval(() => {
              const mockData = {};
              selectedAssets.forEach(asset => {
                mockData[asset] = {
                  price: Math.random() * 50000 + 20000,
                  change: (Math.random() - 0.5) * 5,
                  volume: Math.random() * 1000000000,
                  lastUpdate: new Date().toISOString()
                };
              });
              setRealTimeData(mockData);
            }, 5000);

            return () => clearInterval(interval);
          }, [selectedAssets]);

          const breadcrumbItems = [
            { label: 'Trading', path: '/trading-dashboard' },
            { label: 'Analysis', path: '/market-analysis-center' },
            { label: 'Market Overview', path: '/market-analysis-center' }
          ];

          const chartLayouts = [
            { id: 'single', label: 'Single Chart', cols: 1 },
            { id: 'grid-2', label: '2x1 Grid', cols: 2 },
            { id: 'grid-4', label: '2x2 Grid', cols: 4 },
            { id: 'grid-6', label: '3x2 Grid', cols: 6 }
          ];

          const mobileViews = [
            { key: 'overview', label: 'Overview', icon: 'BarChart3' },
            { key: 'screener', label: 'Screener', icon: 'Search' },
            { key: 'news', label: 'News', icon: 'Newspaper' },
            { key: 'calendar', label: 'Calendar', icon: 'Calendar' },
            { key: 'sentiment', label: 'Sentiment', icon: 'TrendingUp' }
          ];

          const saveBookmark = (setup) => {
            const bookmark = {
              id: Date.now(),
              name: setup.name || `Analysis ${bookmarkedSetups.length + 1}`,
              assets: selectedAssets,
              layout: chartLayout,
              timestamp: new Date().toISOString()
            };
            setBookmarkedSetups([...bookmarkedSetups, bookmark]);
          };

          const loadBookmark = (bookmark) => {
            setSelectedAssets(bookmark.assets);
            setChartLayout(bookmark.layout);
          };

          return (
            <div className="min-h-screen bg-background">
              {/* Header with Navigation */}
              <div className="bg-card border-b px-4 sm:px-6 py-4">
                <div className="flex flex-col space-y-4">
                  {/* Breadcrumb */}
                  <nav className="flex" aria-label="Breadcrumb">
                    <ol className="inline-flex items-center space-x-1 md:space-x-3">
                      {breadcrumbItems.map((item, index) => (
                        <li key={index} className="inline-flex items-center">
                          {index > 0 && (
                            <Icon name="ChevronRight" size={14} className="text-muted-foreground mx-2" />
                          )}
                          <button
                            onClick={() => navigate(item.path)}
                            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                          >
                            {item.label}
                          </button>
                        </li>
                      ))}
                    </ol>
                  </nav>

                  {/* Page Title and Controls */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                          <Icon name="TrendingUp" size={20} className="text-white" />
                        </div>
                        <div>
                          <h1 className="text-xl sm:text-2xl font-bold text-foreground">Market Analysis Center</h1>
                          <p className="text-sm text-muted-foreground">Comprehensive cryptocurrency market research & technical analysis</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <BookmarkManager 
                        bookmarks={bookmarkedSetups}
                        onSave={saveBookmark}
                        onLoad={loadBookmark}
                      />
                      <Button variant="outline" size="sm" onClick={() => navigate('/btc-live-trading-interface')}>
                        <Icon name="ShoppingCart" size={16} />
                        <span className="hidden sm:inline ml-2">Live Trading</span>
                      </Button>
                    </div>
                  </div>

                  {/* Desktop Layout Controls */}
                  <div className="hidden lg:flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-muted-foreground">Layout:</span>
                        {chartLayouts.map((layout) => (
                          <Button
                            key={layout.id}
                            variant={chartLayout === layout.id ? "default" : "ghost"}
                            size="xs"
                            onClick={() => setChartLayout(layout.id)}
                          >
                            {layout.label}
                          </Button>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-muted-foreground">Real-time</span>
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                    </div>
                  </div>

                  {/* Mobile View Tabs */}
                  <div className="flex lg:hidden overflow-x-auto scrollbar-hide">
                    <div className="flex space-x-1 bg-muted rounded-lg p-1 min-w-max">
                      {mobileViews.map((view) => (
                        <Button
                          key={view.key}
                          variant={activeView === view.key ? "default" : "ghost"}
                          size="sm"
                          className="whitespace-nowrap"
                          onClick={() => setActiveView(view.key)}
                        >
                          <Icon name={view.icon} size={16} />
                          <span className="ml-2">{view.label}</span>
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Desktop Layout */}
              <div className="hidden lg:block">
                <div className="flex h-[calc(100vh-180px)]">
                  {/* Main Chart Area */}
                  <div className="flex-1 border-r">
                    <div className="h-full flex flex-col">
                      {/* Chart Grid */}
                      <div className="flex-1 p-4">
                        <div className={`h-full grid gap-4 ${
                          chartLayout === 'single' ? 'grid-cols-1' :
                          chartLayout === 'grid-2' ? 'grid-cols-2' :
                          chartLayout === 'grid-4'? 'grid-cols-2 grid-rows-2' : 'grid-cols-3 grid-rows-2'
                        }`}>
                          {selectedAssets.slice(0, chartLayouts.find(l => l.id === chartLayout)?.cols || 4).map((asset, index) => (
                            <div key={asset} className="bg-card rounded-lg border overflow-hidden">
                              <div className="flex items-center justify-between p-3 border-b bg-muted/50">
                                <div className="flex items-center space-x-2">
                                  <span className="font-medium text-sm">{asset}</span>
                                  {realTimeData[asset] && (
                                    <span className={`text-xs font-medium ${
                                      realTimeData[asset].change >= 0 ? 'text-green-600' : 'text-red-600'
                                    }`}>
                                      {realTimeData[asset].change >= 0 ? '+' : ''}
                                      {realTimeData[asset].change.toFixed(2)}%
                                    </span>
                                  )}
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Button variant="ghost" size="xs">
                                    <Icon name="Settings" size={14} />
                                  </Button>
                                  <Button variant="ghost" size="xs">
                                    <Icon name="Maximize2" size={14} />
                                  </Button>
                                </div>
                              </div>
                              <div className="h-64 lg:h-full">
                                <TradingViewWidget 
                                  symbol={asset}
                                  height="100%"
                                  compact={chartLayout !== 'single'}
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Analysis Sidebar */}
                  <div className="w-80 bg-card overflow-y-auto">
                    <div className="p-4 space-y-6">
                      <MarketScreener />
                      <NewsFeed />
                      <SocialSentiment />
                    </div>
                  </div>
                </div>

                {/* Bottom Panel */}
                <div className="h-64 border-t bg-card">
                  <div className="flex h-full">
                    <div className="flex-1 border-r">
                      <EconomicCalendar />
                    </div>
                    <div className="w-80">
                      <AdvancedChartTools />
                    </div>
                  </div>
                </div>
              </div>

              {/* Mobile Layout */}
              <div className="lg:hidden">
                {activeView === 'overview' && (
                  <div className="p-4 space-y-4">
                    {/* Single Chart Focus */}
                    <div className="bg-card rounded-lg border overflow-hidden">
                      <div className="flex items-center justify-between p-3 border-b">
                        <h3 className="font-medium">Primary Analysis</h3>
                        <div className="flex items-center space-x-2">
                          <select 
                            value={selectedAssets[0]}
                            onChange={(e) => setSelectedAssets([e.target.value, ...selectedAssets.slice(1)])}
                            className="text-sm bg-background border rounded px-2 py-1"
                          >
                            <option value="BTCUSD">BTC/USD</option>
                            <option value="ETHUSD">ETH/USD</option>
                            <option value="ADAUSD">ADA/USD</option>
                            <option value="DOTUSD">DOT/USD</option>
                          </select>
                        </div>
                      </div>
                      <div className="h-80">
                        <TradingViewWidget symbol={selectedAssets[0]} height="100%" />
                      </div>
                    </div>

                    {/* Quick Market Data */}
                    <div className="grid grid-cols-2 gap-4">
                      {selectedAssets.slice(0, 4).map((asset) => (
                        <div key={asset} className="bg-card rounded-lg border p-4">
                          <div className="text-sm text-muted-foreground mb-1">{asset}</div>
                          <div className="font-bold">
                            ${realTimeData[asset]?.price?.toLocaleString(undefined, { 
                              minimumFractionDigits: 2, 
                              maximumFractionDigits: 2 
                            }) || '---'}
                          </div>
                          <div className={`text-xs ${
                            (realTimeData[asset]?.change || 0) >= 0 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {(realTimeData[asset]?.change || 0) >= 0 ? '+' : ''}
                            {(realTimeData[asset]?.change || 0).toFixed(2)}%
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeView === 'screener' && (
                  <div className="p-4">
                    <MarketScreener mobile />
                  </div>
                )}

                {activeView === 'news' && (
                  <div className="p-4">
                    <NewsFeed mobile />
                  </div>
                )}

                {activeView === 'calendar' && (
                  <div className="p-4">
                    <EconomicCalendar mobile />
                  </div>
                )}

                {activeView === 'sentiment' && (
                  <div className="p-4">
                    <SocialSentiment mobile />
                  </div>
                )}
              </div>
            </div>
          );
        };

        export default MarketAnalysisCenter;