import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const HeroSection = () => {
  const navigate = useNavigate();

  const differentiators = [
    { icon: 'Shield', text: 'Advanced Security Protocols' },
    { icon: 'CheckCircle', text: 'Regulatory Compliance' },
    { icon: 'TrendingUp', text: 'Proven Investment Returns' }
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-32 h-32 gradient-gold rounded-full opacity-10 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-24 h-24 bg-orange-500 rounded-full opacity-20 animate-bounce"></div>
        <motion.div
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        >
          <div className="w-64 h-64 border border-orange-500/20 rounded-full"></div>
        </motion.div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-4xl md:text-6xl font-bold mb-6"
          >
            Why Choose{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              KleverInvest?
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
          >
            Experience the future of cryptocurrency investment with institutional-grade security, 
            transparent processes, and proven performance.
          </motion.p>

          {/* Key Differentiators */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="flex flex-wrap justify-center gap-6 mb-12"
          >
            {differentiators.map((item, index) => (
              <div
                key={index}
                className="flex items-center space-x-2 glass-effect px-4 py-2 rounded-full"
              >
                <div className="w-8 h-8 gradient-gold rounded-full flex items-center justify-center">
                  <Icon name={item.icon} size={16} color="black" />
                </div>
                <span className="text-sm font-medium">{item.text}</span>
              </div>
            ))}
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            className="flex flex-col sm:flex-row justify-center gap-4"
          >
            <Button
              className="gradient-gold text-black font-semibold px-8 py-3 hover:scale-105 transition-transform"
              onClick={() => navigate('/signup')}
            >
              Start Investing Today
              <Icon name="ArrowRight" size={16} className="ml-2" />
            </Button>
            <Button
              variant="outline"
              className="border-orange-500 text-orange-400 hover:bg-orange-500/10 px-8 py-3"
              onClick={() => navigate('/investment-plans')}
            >
              View Our Plans
              <Icon name="Eye" size={16} className="ml-2" />
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
