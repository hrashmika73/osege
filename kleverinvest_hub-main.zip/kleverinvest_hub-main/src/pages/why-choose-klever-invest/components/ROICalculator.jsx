import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ROICalculator = () => {
  const navigate = useNavigate();
  const [investment, setInvestment] = useState(1000);
  const [timeHorizon, setTimeHorizon] = useState(12);
  const [btcPrice, setBtcPrice] = useState(45000);
  const [results, setResults] = useState({});

  // Simulate BTC price integration (in real app, this would be from an API)
  useEffect(() => {
    const interval = setInterval(() => {
      setBtcPrice(prev => prev + (Math.random() - 0.5) * 1000);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    calculateReturns();
  }, [investment, timeHorizon, btcPrice]);

  const calculateReturns = () => {
    const plans = [
      { name: 'Starter Plan', rate: 0.09, risk: 'Low' },
      { name: 'Professional Plan', rate: 0.15, risk: 'Moderate' },
      { name: 'Elite Plan', rate: 0.215, risk: 'Higher' }
    ];

    const calculatedResults = plans.map(plan => {
      const monthlyRate = plan.rate / 12;
      const futureValue = investment * Math.pow(1 + monthlyRate, timeHorizon);
      const totalReturn = futureValue - investment;
      const roi = (totalReturn / investment) * 100;
      
      return {
        ...plan,
        futureValue,
        totalReturn,
        roi,
        monthlyReturn: totalReturn / timeHorizon
      };
    });

    setResults({ plans: calculatedResults });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const investmentPresets = [500, 1000, 5000, 10000, 25000];
  const timePresets = [6, 12, 24, 36, 60];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            ROI <span className="text-orange-400">Calculator</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            See your potential returns with real BTC price integration and compound interest calculation
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Calculator Input */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="glass-effect rounded-xl p-8"
          >
            {/* Live BTC Price */}
            <div className="flex items-center justify-between mb-8 p-4 bg-orange-500/10 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 gradient-gold rounded-full flex items-center justify-center">
                  <span className="text-black font-bold text-sm">₿</span>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Live BTC Price</div>
                  <div className="font-bold text-orange-400">{formatCurrency(btcPrice)}</div>
                </div>
              </div>
              <div className="text-green-400 text-sm flex items-center">
                <Icon name="TrendingUp" size={16} className="mr-1" />
                Live
              </div>
            </div>

            {/* Investment Amount */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-3">Investment Amount</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                  $
                </div>
                <Input
                  type="number"
                  value={investment}
                  onChange={(e) => setInvestment(Number(e.target.value))}
                  className="pl-8"
                  min="100"
                  max="1000000"
                />
              </div>
              <div className="flex flex-wrap gap-2 mt-3">
                {investmentPresets.map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setInvestment(preset)}
                    className={`px-3 py-1 rounded-full text-sm transition-colors ${
                      investment === preset
                        ? 'bg-orange-500 text-black' :'bg-muted text-muted-foreground hover:bg-orange-500/20'
                    }`}
                  >
                    ${preset.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>

            {/* Time Horizon */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-3">
                Time Horizon ({timeHorizon} months)
              </label>
              <input
                type="range"
                min="6"
                max="60"
                value={timeHorizon}
                onChange={(e) => setTimeHorizon(Number(e.target.value))}
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #F0B90B 0%, #F0B90B ${((timeHorizon - 6) / 54) * 100}%, #1E2329 ${((timeHorizon - 6) / 54) * 100}%, #1E2329 100%)`
                }}
              />
              <div className="flex flex-wrap gap-2 mt-3">
                {timePresets.map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setTimeHorizon(preset)}
                    className={`px-3 py-1 rounded-full text-sm transition-colors ${
                      timeHorizon === preset
                        ? 'bg-orange-500 text-black' :'bg-muted text-muted-foreground hover:bg-orange-500/20'
                    }`}
                  >
                    {preset}m
                  </button>
                ))}
              </div>
            </div>

            {/* Investment Summary */}
            <div className="bg-card rounded-lg p-4">
              <h3 className="font-semibold mb-3">Investment Summary</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Initial Investment:</span>
                  <span className="font-medium">{formatCurrency(investment)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Investment Period:</span>
                  <span className="font-medium">{timeHorizon} months</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Current BTC Price:</span>
                  <span className="font-medium">{formatCurrency(btcPrice)}</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Results */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-6"
          >
            {results.plans?.map((plan, index) => (
              <div key={index} className="glass-effect rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">{plan.name}</h3>
                    <div className="flex items-center space-x-2 text-sm">
                      <span className="text-muted-foreground">Risk Level:</span>
                      <span className={`px-2 py-0.5 rounded-full text-xs ${
                        plan.risk === 'Low' ? 'bg-green-500/20 text-green-400' :
                        plan.risk === 'Moderate'? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {plan.risk}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-orange-400">
                      {plan.rate * 100}%
                    </div>
                    <div className="text-sm text-muted-foreground">Annual Rate</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="text-center p-3 bg-card rounded-lg">
                    <div className="text-lg font-bold text-green-400">
                      {formatCurrency(plan.futureValue)}
                    </div>
                    <div className="text-xs text-muted-foreground">Final Value</div>
                  </div>
                  <div className="text-center p-3 bg-card rounded-lg">
                    <div className="text-lg font-bold text-orange-400">
                      {formatCurrency(plan.totalReturn)}
                    </div>
                    <div className="text-xs text-muted-foreground">Total Profit</div>
                  </div>
                </div>

                <div className="text-center mb-4">
                  <div className="text-3xl font-bold text-orange-400 mb-1">
                    +{plan.roi.toFixed(1)}%
                  </div>
                  <div className="text-sm text-muted-foreground">Total ROI</div>
                  <div className="text-xs text-muted-foreground">
                    ~{formatCurrency(plan.monthlyReturn)}/month
                  </div>
                </div>

                <Button
                  className={`w-full ${
                    index === 1
                      ? 'gradient-gold text-black font-semibold' :'bg-card hover:bg-muted text-foreground'
                  }`}
                  onClick={() => navigate('/signup')}
                >
                  {index === 1 ? 'Recommended Plan' : 'Select Plan'}
                  <Icon name="ArrowRight" size={16} className="ml-2" />
                </Button>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Disclaimer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-12 text-center"
        >
          <div className="max-w-3xl mx-auto p-6 bg-card/30 rounded-xl">
            <div className="flex items-start space-x-3">
              <Icon name="AlertTriangle" size={20} className="text-yellow-400 mt-0.5" />
              <div className="text-sm text-muted-foreground text-left">
                <strong className="text-foreground">Investment Disclaimer:</strong> 
                Past performance does not guarantee future results. Cryptocurrency investments carry inherent risks. 
                Projected returns are estimates based on historical data and current market conditions. 
                Please consult with financial advisors and review our risk disclosure before investing.
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ROICalculator;
