import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TrustIndicators = () => {
  const navigate = useNavigate();
  const trustMetrics = [
    {
      category: 'Regulatory Badges',
      items: [
        { name: 'FCA Licensed', description: 'UK Financial Conduct Authority', verified: true },
        { name: 'CYSEC Regulated', description: 'Cyprus Securities Exchange Commission', verified: true },
        { name: 'ASIC Authorized', description: 'Australian Securities & Investments Commission', verified: true },
        { name: 'FinCEN Registered', description: 'Financial Crimes Enforcement Network', verified: true }
      ]
    },
    {
      category: 'Security Certifications',
      items: [
        { name: 'SOC 2 Type II', description: 'Security & Availability Controls', verified: true },
        { name: 'ISO 27001', description: 'Information Security Management', verified: true },
        { name: 'PCI DSS Level 1', description: 'Payment Card Industry Standards', verified: true },
        { name: 'CCSS Level 3', description: 'Cryptocurrency Security Standard', verified: true }
      ]
    },
    {
      category: 'Insurance Coverage',
      items: [
        { name: '$100M USD Coverage', description: 'Digital Asset Insurance by Lloyd\'s of London', amount: true },
        { name: 'Cold Storage Protection', description: '95% of funds in offline storage', verified: true },
        { name: 'Hot Wallet Insurance', description: 'Full coverage for online operations', verified: true },
        { name: 'Cyber Liability', description: 'Protection against security breaches', verified: true }
      ]
    },
    {
      category: 'Third-Party Audits',
      items: [
        { name: 'Quarterly Security Audits', description: 'Independent penetration testing', verified: true },
        { name: 'Financial Compliance Review', description: 'Annual regulatory examination', verified: true },
        { name: 'Smart Contract Audits', description: 'Code review by leading security firms', verified: true },
        { name: 'Proof of Reserves', description: 'Monthly third-party verification', verified: true }
      ]
    }
  ];

  const stats = [
    { label: 'Years in Operation', value: '7+', description: 'Trusted since 2017' },
    { label: 'Regulatory Licenses', value: '15+', description: 'Global compliance' },
    { label: 'Security Incidents', value: '0', description: 'Perfect track record' },
    { label: 'Insurance Coverage', value: '$100M', description: 'Maximum protection' }
  ];

  return (
    <section className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Trust & <span className="text-orange-400">Security</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Your security is our top priority. See the comprehensive measures we take to protect your investments.
          </motion.p>
        </div>

        {/* Trust Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16"
        >
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-orange-400 mb-2">
                {stat.value}
              </div>
              <div className="font-semibold mb-1">{stat.label}</div>
              <div className="text-sm text-muted-foreground">{stat.description}</div>
            </div>
          ))}
        </motion.div>

        {/* Trust Categories */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {trustMetrics.map((category, categoryIndex) => (
            <motion.div
              key={categoryIndex}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: categoryIndex * 0.1 }}
              className="glass-effect rounded-xl p-6"
            >
              {/* Category Header */}
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 gradient-gold rounded-lg flex items-center justify-center">
                  <Icon 
                    name={
                      categoryIndex === 0 ? 'Award' :
                      categoryIndex === 1 ? 'Shield' :
                      categoryIndex === 2 ? 'Umbrella' : 'FileCheck'
                    } 
                    size={20} 
                    color="black" 
                  />
                </div>
                <h3 className="text-xl font-semibold">{category.category}</h3>
              </div>

              {/* Category Items */}
              <div className="space-y-4">
                {category.items.map((item, itemIndex) => (
                  <div key={itemIndex} className="flex items-start space-x-3">
                    <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center mt-0.5">
                      <Icon name="Check" size={14} className="text-green-400" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="font-medium">{item.name}</span>
                        {item.verified && (
                          <Icon name="CheckCircle" size={16} className="text-green-400" />
                        )}
                        {item.amount && (
                          <span className="text-xs px-2 py-0.5 bg-orange-500/20 text-orange-400 rounded-full">
                            Verified
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12"
        >
          <div className="glass-effect rounded-xl p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">
              Ready to invest with <span className="text-orange-400">confidence?</span>
            </h3>
            <p className="text-muted-foreground mb-6">
              Join thousands of investors who trust KleverInvest with their cryptocurrency investments.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button
                className="gradient-gold text-black font-semibold px-8 py-3 hover:scale-105 transition-transform"
                onClick={() => navigate('/about-company-page')}
              >
                View Security Details
                <Icon name="ExternalLink" size={16} className="ml-2" />
              </Button>
              <Button
                variant="outline"
                className="border-orange-500 text-orange-400 hover:bg-orange-500/10 px-8 py-3"
                onClick={() => navigate('/signup')}
              >
                Start Investing
                <Icon name="ArrowRight" size={16} className="ml-2" />
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default TrustIndicators;
