import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const CoreBenefitsSection = () => {
  const [expandedCard, setExpandedCard] = useState(null);

  const benefits = [
    {
      icon: 'Shield',
      title: 'Institutional-Grade Security',
      description: 'Multi-signature wallets and cold storage protection',
      details: 'Our security infrastructure includes hardware security modules, multi-signature protocols, and 95% cold storage allocation. We maintain SOC 2 Type II compliance and conduct regular penetration testing.',
      stats: '99.99% uptime guarantee',
      certifications: ['SOC 2 Type II', 'ISO 27001', 'PCI DSS Level 1']
    },
    {
      icon: 'DollarSign',
      title: 'Transparent Fee Structure',
      description: 'Competitive rates with no hidden charges',
      details: 'We believe in complete transparency. Our fee structure is straightforward: 0.25% trading fees, no deposit fees, and minimal withdrawal charges. All fees are clearly displayed before transactions.',
      stats: '75% lower than industry average',
      certifications: ['Fair Trading Certified', 'Fee Transparency Pledge']
    },
    {
      icon: 'MessageCircle',
      title: '24/7 Customer Support',
      description: 'Live chat integration and dedicated support',
      details: 'Our expert support team is available around the clock via live chat, email, and phone. Average response time is under 2 minutes for urgent issues.',
      stats: '< 2 min response time',
      certifications: ['Customer Service Excellence', '5-Star Support Rating']
    },
    {
      icon: 'CheckCircle',
      title: 'Regulatory Compliance',
      description: 'Licensed and regulated by major financial authorities',
      details: 'We operate under strict regulatory oversight from multiple jurisdictions including FCA, CYSEC, and ASIC. Full compliance with AML/KYC requirements ensures maximum protection.',
      stats: 'Licensed in 15+ countries',
      certifications: ['FCA Licensed', 'CYSEC Regulated', 'ASIC Authorized']
    },
    {
      icon: 'BarChart3',
      title: 'Diversified Investment Portfolios',
      description: 'Risk management across multiple cryptocurrencies',
      details: 'Our portfolios span across 50+ cryptocurrencies with algorithmic rebalancing and risk management. Professional portfolio managers optimize allocations based on market conditions.',
      stats: '15.2% average annual returns',
      certifications: ['CFA Portfolio Management', 'Risk Management Certified']
    },
    {
      icon: 'Star',
      title: 'Proven Track Record',
      description: 'Verified user testimonials and performance history',
      details: 'Over 100,000 satisfied investors with a 98% satisfaction rate. Our platform has consistently outperformed market benchmarks over the past 5 years.',
      stats: '98% customer satisfaction',
      certifications: ['Trustpilot Excellence', 'Industry Awards 2023']
    }
  ];

  return (
    <section className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Six Core <span className="text-orange-400">Advantages</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Discover why thousands of investors trust KleverInvest with their cryptocurrency investments
          </motion.p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative group"
            >
              <div 
                className={`glass-effect rounded-xl p-6 cursor-pointer transition-all duration-300 ${
                  expandedCard === index ? 'ring-2 ring-orange-500' : 'hover:ring-1 hover:ring-orange-500/50'
                }`}
                onClick={() => setExpandedCard(expandedCard === index ? null : index)}
              >
                {/* Icon */}
                <div className="w-12 h-12 gradient-gold rounded-lg flex items-center justify-center mb-4">
                  <Icon name={benefit.icon} size={24} color="black" />
                </div>

                {/* Title & Description */}
                <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                <p className="text-muted-foreground mb-4">{benefit.description}</p>

                {/* Stats */}
                <div className="text-orange-400 font-semibold text-sm mb-4">
                  {benefit.stats}
                </div>

                {/* Expand/Collapse Indicator */}
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">
                    {expandedCard === index ? 'Less Details' : 'More Details'}
                  </span>
                  <Icon 
                    name={expandedCard === index ? 'ChevronUp' : 'ChevronDown'} 
                    size={16} 
                    className="text-orange-400" 
                  />
                </div>

                {/* Expanded Content */}
                {expandedCard === index && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="mt-4 pt-4 border-t border-border"
                  >
                    <p className="text-sm text-muted-foreground mb-4">
                      {benefit.details}
                    </p>
                    
                    <div className="space-y-2">
                      <h4 className="text-sm font-semibold text-orange-400">Certifications:</h4>
                      <div className="flex flex-wrap gap-2">
                        {benefit.certifications.map((cert, certIndex) => (
                          <span
                            key={certIndex}
                            className="text-xs px-2 py-1 bg-orange-500/10 text-orange-400 rounded-full"
                          >
                            {cert}
                          </span>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CoreBenefitsSection;