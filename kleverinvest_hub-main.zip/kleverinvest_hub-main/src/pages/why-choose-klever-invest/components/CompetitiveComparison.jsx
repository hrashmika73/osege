import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const CompetitiveComparison = () => {
  const [selectedMetric, setSelectedMetric] = useState('fees');

  const competitors = [
    {
      name: 'KleverInvest',
      logo: '₿',
      isUs: true,
      data: {
        fees: '0.25%',
        security: '5/5',
        cryptocurrencies: '50+',
        minInvestment: '$100',
        satisfaction: '98%',
        support: '24/7',
        licensing: '15+ countries'
      }
    },
    {
      name: 'Competitor A',
      logo: 'C',
      isUs: false,
      data: {
        fees: '1.49%',
        security: '4/5',
        cryptocurrencies: '30+',
        minInvestment: '$500',
        satisfaction: '85%',
        support: 'Business hours',
        licensing: '5 countries'
      }
    },
    {
      name: 'Competitor B',
      logo: 'B',
      isUs: false,
      data: {
        fees: '0.75%',
        security: '4/5',
        cryptocurrencies: '40+',
        minInvestment: '$250',
        satisfaction: '90%',
        support: '16/7',
        licensing: '10 countries'
      }
    },
    {
      name: 'Competitor C',
      logo: 'X',
      isUs: false,
      data: {
        fees: '2.00%',
        security: '3/5',
        cryptocurrencies: '25+',
        minInvestment: '$1000',
        satisfaction: '78%',
        support: 'Email only',
        licensing: '3 countries'
      }
    }
  ];

  const metrics = [
    { key: 'fees', label: 'Trading Fees', icon: 'DollarSign' },
    { key: 'security', label: 'Security Rating', icon: 'Shield' },
    { key: 'cryptocurrencies', label: 'Supported Coins', icon: 'Coins' },
    { key: 'minInvestment', label: 'Minimum Investment', icon: 'TrendingUp' },
    { key: 'satisfaction', label: 'Customer Satisfaction', icon: 'Heart' },
    { key: 'support', label: 'Customer Support', icon: 'MessageCircle' },
    { key: 'licensing', label: 'Global Licensing', icon: 'Globe' }
  ];

  const getBestValue = (metricKey) => {
    switch (metricKey) {
      case 'fees':
        return Math.min(...competitors.map(c => parseFloat(c.data[metricKey])));
      case 'security':
        return Math.max(...competitors.map(c => parseInt(c.data[metricKey])));
      case 'cryptocurrencies':
        return Math.max(...competitors.map(c => parseInt(c.data[metricKey])));
      case 'minInvestment':
        return Math.min(...competitors.map(c => parseInt(c.data[metricKey].replace('$', '').replace(',', ''))));
      case 'satisfaction':
        return Math.max(...competitors.map(c => parseInt(c.data[metricKey])));
      case 'licensing':
        return Math.max(...competitors.map(c => parseInt(c.data[metricKey])));
      default:
        return null;
    }
  };

  const isWinner = (competitor, metricKey) => {
    const value = competitor.data[metricKey];
    const bestValue = getBestValue(metricKey);
    
    switch (metricKey) {
      case 'fees':
        return parseFloat(value) === bestValue;
      case 'security':
        return parseInt(value) === bestValue;
      case 'cryptocurrencies':
        return parseInt(value) >= bestValue;
      case 'minInvestment':
        return parseInt(value.replace('$', '').replace(',', '')) === bestValue;
      case 'satisfaction':
        return parseInt(value) === bestValue;
      case 'support':
        return value === '24/7';
      case 'licensing':
        return parseInt(value) >= bestValue;
      default:
        return false;
    }
  };

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            How We <span className="text-orange-400">Compare</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            See why KleverInvest consistently outperforms the competition across key metrics
          </motion.p>
        </div>

        {/* Mobile Metric Selector */}
        <div className="md:hidden mb-8">
          <select
            value={selectedMetric}
            onChange={(e) => setSelectedMetric(e.target.value)}
            className="w-full p-3 bg-card border border-border rounded-lg text-foreground"
          >
            {metrics.map((metric) => (
              <option key={metric.key} value={metric.key}>
                {metric.label}
              </option>
            ))}
          </select>
        </div>

        {/* Desktop Comparison Table */}
        <div className="hidden md:block">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="glass-effect rounded-xl overflow-hidden"
          >
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left p-6 font-semibold">Platform</th>
                    {metrics.map((metric) => (
                      <th key={metric.key} className="text-center p-6 font-semibold">
                        <div className="flex flex-col items-center space-y-2">
                          <Icon name={metric.icon} size={20} className="text-orange-400" />
                          <span className="text-sm">{metric.label}</span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {competitors.map((competitor, index) => (
                    <motion.tr
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.6, delay: index * 0.1 }}
                      className={`border-b border-border last:border-b-0 ${
                        competitor.isUs ? 'bg-orange-500/5' : ''
                      }`}
                    >
                      <td className="p-6">
                        <div className="flex items-center space-x-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold ${
                            competitor.isUs ? 'gradient-gold text-black' : 'bg-muted text-muted-foreground'
                          }`}>
                            {competitor.logo}
                          </div>
                          <div>
                            <div className="font-semibold">{competitor.name}</div>
                            {competitor.isUs && (
                              <div className="text-xs text-orange-400 font-medium">That's us!</div>
                            )}
                          </div>
                        </div>
                      </td>
                      {metrics.map((metric) => (
                        <td key={metric.key} className="p-6 text-center">
                          <div className={`font-semibold ${
                            isWinner(competitor, metric.key) 
                              ? 'text-orange-400' :'text-muted-foreground'
                          }`}>
                            {competitor.data[metric.key]}
                            {isWinner(competitor, metric.key) && (
                              <Icon name="Crown" size={16} className="inline ml-1 text-orange-400" />
                            )}
                          </div>
                        </td>
                      ))}
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>

        {/* Mobile Comparison Cards */}
        <div className="md:hidden space-y-4">
          {competitors.map((competitor, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className={`glass-effect rounded-xl p-6 ${
                competitor.isUs ? 'ring-2 ring-orange-500' : ''
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold ${
                    competitor.isUs ? 'gradient-gold text-black' : 'bg-muted text-muted-foreground'
                  }`}>
                    {competitor.logo}
                  </div>
                  <div>
                    <div className="font-semibold">{competitor.name}</div>
                    {competitor.isUs && (
                      <div className="text-xs text-orange-400 font-medium">That's us!</div>
                    )}
                  </div>
                </div>
                <div className={`text-lg font-bold ${
                  isWinner(competitor, selectedMetric) 
                    ? 'text-orange-400' :'text-muted-foreground'
                }`}>
                  {competitor.data[selectedMetric]}
                  {isWinner(competitor, selectedMetric) && (
                    <Icon name="Crown" size={16} className="inline ml-1 text-orange-400" />
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CompetitiveComparison;