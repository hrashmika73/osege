import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../home-landing-page/components/Header';
import Footer from '../home-landing-page/components/Footer';
import HeroSection from './components/HeroSection';
import CoreBenefitsSection from './components/CoreBenefitsSection';
import CompetitiveComparison from './components/CompetitiveComparison';
import TrustIndicators from './components/TrustIndicators';
import ROICalculator from './components/ROICalculator';

const WhyChooseKleverInvest = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: isLoaded ? 1 : 0 }}
        transition={{ duration: 0.5 }}
        className="pt-16"
      >
        <HeroSection />
        <CoreBenefitsSection />
        <CompetitiveComparison />
        <TrustIndicators />
        <ROICalculator />
      </motion.main>

      <Footer />
    </div>
  );
};

export default WhyChooseKleverInvest;