import React from 'react';
import Icon from '../../../components/AppIcon';

const TransactionStats = ({ stats }) => {
  const statCards = [
    {
      title: 'Total Transactions',
      value: stats.totalTransactions.toLocaleString(),
      change: '+12.5%',
      changeType: 'positive',
      icon: 'Activity',
      color: 'bg-blue-500'
    },
    {
      title: 'Pending Approval',
      value: stats.pendingTransactions.toLocaleString(),
      change: stats.pendingTransactions > 0 ? 'Requires attention' : 'All clear',
      changeType: stats.pendingTransactions > 0 ? 'warning' : 'positive',
      icon: 'Clock',
      color: 'bg-warning'
    },
    {
      title: 'Total Volume (24h)',
      value: `$${stats.totalVolume.toLocaleString()}`,
      change: '+8.2%',
      changeType: 'positive',
      icon: 'DollarSign',
      color: 'bg-success'
    },
    {
      title: 'Failed Transactions',
      value: stats.failedTransactions.toLocaleString(),
      change: '-2.1%',
      changeType: 'positive',
      icon: 'AlertTriangle',
      color: 'bg-destructive'
    }
  ];

  const getChangeColor = (type) => {
    switch (type) {
      case 'positive':
        return 'text-success';
      case 'negative':
        return 'text-destructive';
      case 'warning':
        return 'text-warning';
      default:
        return 'text-muted-foreground';
    }
  };

  const getChangeIcon = (type) => {
    switch (type) {
      case 'positive':
        return 'TrendingUp';
      case 'negative':
        return 'TrendingDown';
      case 'warning':
        return 'AlertTriangle';
      default:
        return 'Minus';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {statCards.map((stat, index) => (
        <div key={index} className="bg-card border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className={`p-2 rounded-lg ${stat.color}/10`}>
              <Icon name={stat.icon} size={20} className={`${stat.color.replace('bg-', 'text-')}`} />
            </div>
            <div className={`flex items-center space-x-1 text-sm ${getChangeColor(stat.changeType)}`}>
              <Icon name={getChangeIcon(stat.changeType)} size={14} />
              <span>{stat.change}</span>
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-bold text-foreground mb-1">{stat.value}</h3>
            <p className="text-sm text-muted-foreground">{stat.title}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TransactionStats;