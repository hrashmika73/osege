import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const TransactionDetails = ({ transaction, isOpen, onClose, onApprove, onReject }) => {
  if (!isOpen || !transaction) return null;

  const formatAmount = (amount, currency) => {
    return `${parseFloat(amount).toLocaleString()} ${currency}`;
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleString();
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      pending: { bg: 'bg-warning/10', text: 'text-warning', icon: 'Clock' },
      completed: { bg: 'bg-success/10', text: 'text-success', icon: 'CheckCircle' },
      failed: { bg: 'bg-destructive/10', text: 'text-destructive', icon: 'XCircle' },
      cancelled: { bg: 'bg-muted', text: 'text-muted-foreground', icon: 'Ban' }
    };

    const config = statusConfig[status] || statusConfig.pending;

    return (
      <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-sm font-medium ${config.bg} ${config.text}`}>
        <Icon name={config.icon} size={14} />
        <span className="capitalize">{status}</span>
      </span>
    );
  };

  const getTransactionTypeIcon = (type) => {
    const typeIcons = {
      deposit: 'ArrowDownCircle',
      withdrawal: 'ArrowUpCircle',
      investment: 'TrendingUp',
      referral: 'Users',
      transfer: 'ArrowRightLeft'
    };
    return typeIcons[type] || 'Circle';
  };

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50" onClick={onClose} />
      
      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-card border rounded-lg shadow-elevation-3 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Icon name={getTransactionTypeIcon(transaction.type)} size={24} className="text-primary" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-foreground">Transaction Details</h2>
                <p className="text-sm text-muted-foreground">ID: {transaction.id}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {getStatusBadge(transaction.status)}
              <Button variant="ghost" size="sm" onClick={onClose} iconName="X" />
            </div>
          </div>

          {/* Content */}
          <div className="p-6 space-y-6">
            {/* User Information */}
            <div className="bg-muted/30 rounded-lg p-4">
              <h3 className="text-lg font-medium text-foreground mb-3">User Information</h3>
              <div className="flex items-center space-x-4 mb-4">
                <Image
                  src={transaction.user.avatar}
                  alt={transaction.user.name}
                  className="w-16 h-16 rounded-full"
                />
                <div>
                  <div className="font-medium text-foreground text-lg">{transaction.user.name}</div>
                  <div className="text-muted-foreground">{transaction.user.email}</div>
                  <div className="text-sm text-muted-foreground">User ID: {transaction.user.id}</div>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Account Status:</span>
                  <div className="font-medium text-foreground mt-1">{transaction.user.status}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">KYC Status:</span>
                  <div className="font-medium text-foreground mt-1">{transaction.user.kycStatus}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Member Since:</span>
                  <div className="font-medium text-foreground mt-1">{formatDate(transaction.user.joinedAt)}</div>
                </div>
              </div>
            </div>

            {/* Transaction Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-foreground">Transaction Details</h3>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm text-muted-foreground">Type:</span>
                    <div className="flex items-center space-x-2 mt-1">
                      <Icon name={getTransactionTypeIcon(transaction.type)} size={16} />
                      <span className="font-medium text-foreground capitalize">{transaction.type}</span>
                    </div>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Amount:</span>
                    <div className="font-semibold text-lg text-foreground mt-1">
                      {formatAmount(transaction.amount, transaction.cryptocurrency)}
                    </div>
                    {transaction.usdValue && (
                      <div className="text-sm text-muted-foreground">
                        ≈ ${parseFloat(transaction.usdValue).toLocaleString()}
                      </div>
                    )}
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Created:</span>
                    <div className="font-medium text-foreground mt-1">{formatDate(transaction.createdAt)}</div>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Last Updated:</span>
                    <div className="font-medium text-foreground mt-1">{formatDate(transaction.updatedAt)}</div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium text-foreground">Blockchain Details</h3>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm text-muted-foreground">Cryptocurrency:</span>
                    <div className="font-medium text-foreground mt-1">{transaction.cryptocurrency}</div>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Network:</span>
                    <div className="font-medium text-foreground mt-1">{transaction.network || 'N/A'}</div>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Confirmations:</span>
                    <div className="font-medium text-foreground mt-1">{transaction.confirmations || 'N/A'}</div>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Network Fee:</span>
                    <div className="font-medium text-foreground mt-1">{transaction.networkFee || 'N/A'}</div>
                  </div>
                  <div>
                    <span className="text-sm text-muted-foreground">Exchange Rate:</span>
                    <div className="font-medium text-foreground mt-1">{transaction.exchangeRate || 'N/A'}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Wallet Addresses */}
            {(transaction.walletAddress || transaction.txHash) && (
              <div className="bg-muted/30 rounded-lg p-4">
                <h3 className="text-lg font-medium text-foreground mb-3">Blockchain Information</h3>
                <div className="space-y-3">
                  {transaction.walletAddress && (
                    <div>
                      <span className="text-sm text-muted-foreground">Wallet Address:</span>
                      <div className="font-mono text-sm text-foreground mt-1 break-all bg-background p-2 rounded border">
                        {transaction.walletAddress}
                      </div>
                    </div>
                  )}
                  {transaction.txHash && (
                    <div>
                      <span className="text-sm text-muted-foreground">Transaction Hash:</span>
                      <div className="font-mono text-sm text-foreground mt-1 break-all bg-background p-2 rounded border">
                        {transaction.txHash}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Notes */}
            {transaction.note && (
              <div className="bg-muted/30 rounded-lg p-4">
                <h3 className="text-lg font-medium text-foreground mb-3">Notes</h3>
                <p className="text-foreground">{transaction.note}</p>
              </div>
            )}

            {/* Admin Actions */}
            {transaction.status === 'pending' && (
              <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
                <h3 className="text-lg font-medium text-foreground mb-3">Admin Actions Required</h3>
                <p className="text-muted-foreground mb-4">
                  This transaction is pending approval. Please review the details above and take appropriate action.
                </p>
                <div className="flex items-center space-x-3">
                  <Button
                    variant="destructive"
                    onClick={() => onReject(transaction.id)}
                    iconName="X"
                    iconPosition="left"
                  >
                    Reject Transaction
                  </Button>
                  <Button
                    variant="success"
                    onClick={() => onApprove(transaction.id)}
                    iconName="Check"
                    iconPosition="left"
                  >
                    Approve Transaction
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end space-x-3 p-6 border-t">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default TransactionDetails;