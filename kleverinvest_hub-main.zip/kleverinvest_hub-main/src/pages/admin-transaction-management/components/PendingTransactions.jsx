import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const PendingTransactions = ({ pendingTransactions, onApprove, onReject, onViewDetails }) => {
  const getTransactionTypeIcon = (type) => {
    const typeIcons = {
      deposit: 'ArrowDownCircle',
      withdrawal: 'ArrowUpCircle',
      investment: 'TrendingUp',
      referral: 'Users',
      transfer: 'ArrowRightLeft'
    };
    return typeIcons[type] || 'Circle';
  };

  const formatAmount = (amount, currency) => {
    return `${parseFloat(amount).toLocaleString()} ${currency}`;
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleString();
  };

  const getPriorityLevel = (transaction) => {
    const amount = parseFloat(transaction.amount);
    const hoursSinceCreated = (new Date() - new Date(transaction.createdAt)) / (1000 * 60 * 60);
    
    if (amount > 10000 || hoursSinceCreated > 24) return 'high';
    if (amount > 1000 || hoursSinceCreated > 12) return 'medium';
    return 'low';
  };

  const getPriorityBadge = (priority) => {
    const priorityConfig = {
      high: { bg: 'bg-destructive/10', text: 'text-destructive', label: 'High Priority' },
      medium: { bg: 'bg-warning/10', text: 'text-warning', label: 'Medium Priority' },
      low: { bg: 'bg-success/10', text: 'text-success', label: 'Low Priority' }
    };

    const config = priorityConfig[priority];
    return (
      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        {config.label}
      </span>
    );
  };

  if (pendingTransactions.length === 0) {
    return (
      <div className="bg-card border rounded-lg p-8 text-center">
        <Icon name="CheckCircle" size={48} className="text-success mx-auto mb-4" />
        <h3 className="text-lg font-medium text-foreground mb-2">All Caught Up!</h3>
        <p className="text-muted-foreground">No pending transactions require your attention.</p>
      </div>
    );
  }

  return (
    <div className="bg-card border rounded-lg overflow-hidden mb-6">
      <div className="bg-warning/10 border-b px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="AlertTriangle" size={20} className="text-warning" />
            <h3 className="text-lg font-semibold text-foreground">Pending Transactions</h3>
            <span className="bg-warning text-warning-foreground text-xs px-2 py-1 rounded-full">
              {pendingTransactions.length} Pending
            </span>
          </div>
          <p className="text-sm text-muted-foreground">Requires immediate attention</p>
        </div>
      </div>

      <div className="divide-y">
        {pendingTransactions.map((transaction) => {
          const priority = getPriorityLevel(transaction);
          
          return (
            <div key={transaction.id} className="p-6 hover:bg-muted/30 transition-colors">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-lg ${
                    priority === 'high' ? 'bg-destructive/10' : 
                    priority === 'medium' ? 'bg-warning/10' : 'bg-success/10'
                  }`}>
                    <Icon 
                      name={getTransactionTypeIcon(transaction.type)} 
                      size={20} 
                      className={
                        priority === 'high' ? 'text-destructive' : 
                        priority === 'medium' ? 'text-warning' : 'text-success'
                      } 
                    />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-mono text-sm text-primary">{transaction.id}</span>
                      {getPriorityBadge(priority)}
                    </div>
                    <div className="flex items-center space-x-3">
                      <Image
                        src={transaction.user.avatar}
                        alt={transaction.user.name}
                        className="w-8 h-8 rounded-full"
                      />
                      <div>
                        <div className="font-medium text-foreground">{transaction.user.name}</div>
                        <div className="text-sm text-muted-foreground">{transaction.user.email}</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-lg text-foreground">
                    {formatAmount(transaction.amount, transaction.cryptocurrency)}
                  </div>
                  {transaction.usdValue && (
                    <div className="text-sm text-muted-foreground">
                      ≈ ${parseFloat(transaction.usdValue).toLocaleString()}
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Type:</span>
                  <div className="font-medium text-foreground capitalize mt-1">{transaction.type}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Created:</span>
                  <div className="font-medium text-foreground mt-1">{formatDate(transaction.createdAt)}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Waiting Time:</span>
                  <div className="font-medium text-foreground mt-1">
                    {Math.round((new Date() - new Date(transaction.createdAt)) / (1000 * 60))} minutes
                  </div>
                </div>
              </div>

              {transaction.note && (
                <div className="mb-4 p-3 bg-muted/50 rounded-lg">
                  <span className="text-sm font-medium text-foreground">Note:</span>
                  <p className="text-sm text-muted-foreground mt-1">{transaction.note}</p>
                </div>
              )}

              <div className="flex items-center justify-between pt-4 border-t">
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onViewDetails(transaction)}
                    iconName="Eye"
                    iconPosition="left"
                  >
                    View Details
                  </Button>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => onReject(transaction.id)}
                    iconName="X"
                    iconPosition="left"
                  >
                    Reject
                  </Button>
                  <Button
                    variant="success"
                    size="sm"
                    onClick={() => onApprove(transaction.id)}
                    iconName="Check"
                    iconPosition="left"
                  >
                    Approve
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PendingTransactions;