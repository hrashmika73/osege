import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const BulkActions = ({ 
  selectedTransactions, 
  onBulkApprove, 
  onBulkReject, 
  onBulkExport, 
  onBulkStatusUpdate,
  onClearSelection 
}) => {
  const [bulkAction, setBulkAction] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const bulkActionOptions = [
    { value: '', label: 'Select Bulk Action' },
    { value: 'approve', label: 'Approve Selected' },
    { value: 'reject', label: 'Reject Selected' },
    { value: 'export', label: 'Export Selected' },
    { value: 'mark_completed', label: 'Mark as Completed' },
    { value: 'mark_failed', label: 'Mark as Failed' }
  ];

  const handleBulkAction = async () => {
    if (!bulkAction || selectedTransactions.length === 0) return;

    setIsProcessing(true);
    
    try {
      switch (bulkAction) {
        case 'approve':
          await onBulkApprove(selectedTransactions);
          break;
        case 'reject':
          await onBulkReject(selectedTransactions);
          break;
        case 'export':
          await onBulkExport(selectedTransactions);
          break;
        case 'mark_completed':
          await onBulkStatusUpdate(selectedTransactions, 'completed');
          break;
        case 'mark_failed': await onBulkStatusUpdate(selectedTransactions,'failed');
          break;
        default:
          break;
      }
      setBulkAction('');
    } catch (error) {
      console.error('Bulk action failed:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const getActionIcon = (action) => {
    const icons = {
      approve: 'Check',
      reject: 'X',
      export: 'Download',
      mark_completed: 'CheckCircle',
      mark_failed: 'XCircle'
    };
    return icons[action] || 'Settings';
  };

  const getActionVariant = (action) => {
    const variants = {
      approve: 'success',
      reject: 'destructive',
      export: 'outline',
      mark_completed: 'success',
      mark_failed: 'destructive'
    };
    return variants[action] || 'default';
  };

  if (selectedTransactions.length === 0) {
    return null;
  }

  return (
    <div className="bg-card border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Icon name="CheckSquare" size={20} className="text-primary" />
            <span className="font-medium text-foreground">
              {selectedTransactions.length} transaction{selectedTransactions.length !== 1 ? 's' : ''} selected
            </span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Select
              options={bulkActionOptions}
              value={bulkAction}
              onChange={setBulkAction}
              placeholder="Select action"
              className="w-48"
            />
            
            <Button
              onClick={handleBulkAction}
              disabled={!bulkAction || isProcessing}
              loading={isProcessing}
              variant={getActionVariant(bulkAction)}
              iconName={getActionIcon(bulkAction)}
              iconPosition="left"
            >
              {isProcessing ? 'Processing...' : 'Apply'}
            </Button>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearSelection}
            iconName="X"
            iconPosition="left"
          >
            Clear Selection
          </Button>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="flex items-center space-x-2 mt-4 pt-4 border-t">
        <span className="text-sm text-muted-foreground mr-2">Quick Actions:</span>
        
        <Button
          variant="success"
          size="sm"
          onClick={() => onBulkApprove(selectedTransactions)}
          disabled={isProcessing}
          iconName="Check"
          iconPosition="left"
        >
          Approve All
        </Button>
        
        <Button
          variant="destructive"
          size="sm"
          onClick={() => onBulkReject(selectedTransactions)}
          disabled={isProcessing}
          iconName="X"
          iconPosition="left"
        >
          Reject All
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          onClick={() => onBulkExport(selectedTransactions)}
          disabled={isProcessing}
          iconName="Download"
          iconPosition="left"
        >
          Export CSV
        </Button>
      </div>
    </div>
  );
};

export default BulkActions;