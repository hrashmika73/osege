import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const ManualTransaction = ({ isOpen, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    userId: '',
    userEmail: '',
    type: 'credit',
    amount: '',
    cryptocurrency: 'BTC',
    reason: '',
    note: '',
    sendNotification: true
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  const transactionTypes = [
    { value: 'credit', label: 'Credit (Add to Balance)' },
    { value: 'debit', label: 'Debit (Subtract from Balance)' }
  ];

  const cryptocurrencyOptions = [
    { value: 'BTC', label: 'Bitcoin (BTC)' },
    { value: 'ETH', label: 'Ethereum (ETH)' },
    { value: 'USDT', label: 'Tether (USDT)' },
    { value: 'BNB', label: 'Binance Coin (BNB)' },
    { value: 'ADA', label: 'Cardano (ADA)' }
  ];

  const reasonCodes = [
    { value: 'manual_adjustment', label: 'Manual Balance Adjustment' },
    { value: 'refund', label: 'Refund Processing' },
    { value: 'bonus', label: 'Bonus Credit' },
    { value: 'correction', label: 'Error Correction' },
    { value: 'penalty', label: 'Penalty Deduction' },
    { value: 'maintenance', label: 'System Maintenance' },
    { value: 'other', label: 'Other (Specify in Notes)' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.userEmail.trim()) {
      newErrors.userEmail = 'User email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.userEmail)) {
      newErrors.userEmail = 'Please enter a valid email address';
    }

    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      newErrors.amount = 'Please enter a valid amount greater than 0';
    }

    if (!formData.reason) {
      newErrors.reason = 'Please select a reason for this transaction';
    }

    if (formData.reason === 'other' && !formData.note.trim()) {
      newErrors.note = 'Please provide details when selecting "Other" as reason';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);
    
    try {
      await onSubmit({
        ...formData,
        amount: parseFloat(formData.amount),
        timestamp: new Date().toISOString()
      });
      
      // Reset form
      setFormData({
        userId: '',
        userEmail: '',
        type: 'credit',
        amount: '',
        cryptocurrency: 'BTC',
        reason: '',
        note: '',
        sendNotification: true
      });
      
      onClose();
    } catch (error) {
      console.error('Failed to create manual transaction:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      userId: '',
      userEmail: '',
      type: 'credit',
      amount: '',
      cryptocurrency: 'BTC',
      reason: '',
      note: '',
      sendNotification: true
    });
    setErrors({});
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50" onClick={onClose} />
      
      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-card border rounded-lg shadow-elevation-3 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Icon name="Plus" size={24} className="text-primary" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-foreground">Create Manual Transaction</h2>
                <p className="text-sm text-muted-foreground">Add or subtract balance from user account</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose} iconName="X" />
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* User Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground">User Information</h3>
              
              <Input
                label="User Email Address"
                type="email"
                placeholder="Enter user email address"
                value={formData.userEmail}
                onChange={(e) => handleInputChange('userEmail', e.target.value)}
                error={errors.userEmail}
                required
                description="The email address of the user whose balance will be modified"
              />
            </div>

            {/* Transaction Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground">Transaction Details</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Select
                  label="Transaction Type"
                  options={transactionTypes}
                  value={formData.type}
                  onChange={(value) => handleInputChange('type', value)}
                  required
                />
                
                <Select
                  label="Cryptocurrency"
                  options={cryptocurrencyOptions}
                  value={formData.cryptocurrency}
                  onChange={(value) => handleInputChange('cryptocurrency', value)}
                  required
                />
              </div>

              <Input
                label="Amount"
                type="number"
                step="0.00000001"
                min="0"
                placeholder="0.00000000"
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', e.target.value)}
                error={errors.amount}
                required
                description={`Amount to ${formData.type === 'credit' ? 'add to' : 'subtract from'} user's balance`}
              />

              <Select
                label="Reason Code"
                options={reasonCodes}
                value={formData.reason}
                onChange={(value) => handleInputChange('reason', value)}
                error={errors.reason}
                required
                description="Select the reason for this manual transaction"
              />

              <Input
                label="Additional Notes"
                type="text"
                placeholder="Enter additional details or explanation..."
                value={formData.note}
                onChange={(e) => handleInputChange('note', e.target.value)}
                error={errors.note}
                description="Optional notes for internal record keeping"
              />
            </div>

            {/* Notification Settings */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground">Notification Settings</h3>
              
              <Checkbox
                label="Send notification to user"
                description="User will receive an email notification about this balance change"
                checked={formData.sendNotification}
                onChange={(e) => handleInputChange('sendNotification', e.target.checked)}
              />
            </div>

            {/* Preview */}
            <div className="bg-muted/30 rounded-lg p-4">
              <h4 className="font-medium text-foreground mb-3">Transaction Preview</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">User:</span>
                  <div className="font-medium text-foreground mt-1">
                    {formData.userEmail || 'Not specified'}
                  </div>
                </div>
                <div>
                  <span className="text-muted-foreground">Action:</span>
                  <div className="font-medium text-foreground mt-1">
                    {formData.type === 'credit' ? 'Add to balance' : 'Subtract from balance'}
                  </div>
                </div>
                <div>
                  <span className="text-muted-foreground">Amount:</span>
                  <div className="font-medium text-foreground mt-1">
                    {formData.amount ? `${formData.amount} ${formData.cryptocurrency}` : 'Not specified'}
                  </div>
                </div>
                <div>
                  <span className="text-muted-foreground">Reason:</span>
                  <div className="font-medium text-foreground mt-1">
                    {reasonCodes.find(r => r.value === formData.reason)?.label || 'Not selected'}
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={resetForm}
                iconName="RotateCcw"
                iconPosition="left"
              >
                Reset Form
              </Button>
              
              <div className="flex items-center space-x-3">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={onClose}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  loading={isSubmitting}
                  iconName="Plus"
                  iconPosition="left"
                >
                  {isSubmitting ? 'Creating...' : 'Create Transaction'}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default ManualTransaction;