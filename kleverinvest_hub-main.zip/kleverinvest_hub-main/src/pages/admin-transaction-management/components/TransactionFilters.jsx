import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const TransactionFilters = ({ onFilterChange, onClearFilters, activeFilters }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const transactionTypes = [
    { value: 'all', label: 'All Types' },
    { value: 'deposit', label: 'Deposit' },
    { value: 'withdrawal', label: 'Withdrawal' },
    { value: 'investment', label: 'Investment' },
    { value: 'referral', label: 'Referral Bonus' },
    { value: 'transfer', label: 'Transfer' }
  ];

  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'pending', label: 'Pending' },
    { value: 'completed', label: 'Completed' },
    { value: 'failed', label: 'Failed' },
    { value: 'cancelled', label: 'Cancelled' }
  ];

  const cryptocurrencyOptions = [
    { value: 'all', label: 'All Cryptocurrencies' },
    { value: 'BTC', label: 'Bitcoin (BTC)' },
    { value: 'ETH', label: 'Ethereum (ETH)' },
    { value: 'USDT', label: 'Tether (USDT)' },
    { value: 'BNB', label: 'Binance Coin (BNB)' },
    { value: 'ADA', label: 'Cardano (ADA)' }
  ];

  const handleFilterChange = (key, value) => {
    onFilterChange({ ...activeFilters, [key]: value });
  };

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const hasActiveFilters = Object.values(activeFilters).some(value => 
    value && value !== 'all' && value !== ''
  );

  return (
    <div className="bg-card border rounded-lg p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon name="Filter" size={20} className="text-muted-foreground" />
          <h3 className="text-lg font-semibold text-foreground">Transaction Filters</h3>
          {hasActiveFilters && (
            <span className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
              Active
            </span>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {hasActiveFilters && (
            <Button
              variant="outline"
              size="sm"
              onClick={onClearFilters}
              iconName="X"
              iconPosition="left"
            >
              Clear All
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleExpanded}
            iconName={isExpanded ? "ChevronUp" : "ChevronDown"}
            iconPosition="right"
          >
            {isExpanded ? 'Less Filters' : 'More Filters'}
          </Button>
        </div>
      </div>

      {/* Basic Filters - Always Visible */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <Input
          type="search"
          placeholder="Search by Transaction ID..."
          value={activeFilters.search || ''}
          onChange={(e) => handleFilterChange('search', e.target.value)}
          className="w-full"
        />
        
        <Input
          type="search"
          placeholder="Search by User Email..."
          value={activeFilters.userEmail || ''}
          onChange={(e) => handleFilterChange('userEmail', e.target.value)}
          className="w-full"
        />

        <Select
          options={transactionTypes}
          value={activeFilters.type || 'all'}
          onChange={(value) => handleFilterChange('type', value)}
          placeholder="Select Type"
          className="w-full"
        />

        <Select
          options={statusOptions}
          value={activeFilters.status || 'all'}
          onChange={(value) => handleFilterChange('status', value)}
          placeholder="Select Status"
          className="w-full"
        />
      </div>

      {/* Advanced Filters - Expandable */}
      {isExpanded && (
        <div className="border-t pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Date Range</label>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="date"
                  value={activeFilters.dateFrom || ''}
                  onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                  placeholder="From Date"
                />
                <Input
                  type="date"
                  value={activeFilters.dateTo || ''}
                  onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                  placeholder="To Date"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Amount Range</label>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="number"
                  placeholder="Min Amount"
                  value={activeFilters.minAmount || ''}
                  onChange={(e) => handleFilterChange('minAmount', e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="Max Amount"
                  value={activeFilters.maxAmount || ''}
                  onChange={(e) => handleFilterChange('maxAmount', e.target.value)}
                />
              </div>
            </div>

            <Select
              label="Cryptocurrency"
              options={cryptocurrencyOptions}
              value={activeFilters.cryptocurrency || 'all'}
              onChange={(value) => handleFilterChange('cryptocurrency', value)}
              placeholder="Select Cryptocurrency"
              className="w-full"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default TransactionFilters;