import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const TransactionTable = ({ 
  transactions, 
  onSort, 
  sortConfig, 
  onApprove, 
  onReject, 
  onViewDetails,
  selectedTransactions,
  onSelectTransaction,
  onSelectAll 
}) => {
  const [expandedRow, setExpandedRow] = useState(null);

  const getStatusBadge = (status) => {
    const statusConfig = {
      pending: { bg: 'bg-warning/10', text: 'text-warning', icon: 'Clock' },
      completed: { bg: 'bg-success/10', text: 'text-success', icon: 'CheckCircle' },
      failed: { bg: 'bg-destructive/10', text: 'text-destructive', icon: 'XCircle' },
      cancelled: { bg: 'bg-muted', text: 'text-muted-foreground', icon: 'Ban' }
    };

    const config = statusConfig[status] || statusConfig.pending;

    return (
      <span className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        <Icon name={config.icon} size={12} />
        <span className="capitalize">{status}</span>
      </span>
    );
  };

  const getTransactionTypeIcon = (type) => {
    const typeIcons = {
      deposit: 'ArrowDownCircle',
      withdrawal: 'ArrowUpCircle',
      investment: 'TrendingUp',
      referral: 'Users',
      transfer: 'ArrowRightLeft'
    };
    return typeIcons[type] || 'Circle';
  };

  const formatAmount = (amount, currency) => {
    return `${parseFloat(amount).toLocaleString()} ${currency}`;
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleString();
  };

  const handleSort = (column) => {
    onSort(column);
  };

  const getSortIcon = (column) => {
    if (sortConfig.key !== column) return 'ArrowUpDown';
    return sortConfig.direction === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  const toggleRowExpansion = (transactionId) => {
    setExpandedRow(expandedRow === transactionId ? null : transactionId);
  };

  const isAllSelected = transactions.length > 0 && selectedTransactions.length === transactions.length;
  const isIndeterminate = selectedTransactions.length > 0 && selectedTransactions.length < transactions.length;

  return (
    <div className="bg-card border rounded-lg overflow-hidden">
      {/* Desktop Table */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50 border-b">
            <tr>
              <th className="p-4 text-left">
                <input
                  type="checkbox"
                  checked={isAllSelected}
                  ref={input => {
                    if (input) input.indeterminate = isIndeterminate;
                  }}
                  onChange={(e) => onSelectAll(e.target.checked)}
                  className="rounded border-border"
                />
              </th>
              {[
                { key: 'id', label: 'Transaction ID' },
                { key: 'user', label: 'User' },
                { key: 'type', label: 'Type' },
                { key: 'amount', label: 'Amount' },
                { key: 'status', label: 'Status' },
                { key: 'timestamp', label: 'Date' },
                { key: 'actions', label: 'Actions' }
              ].map((column) => (
                <th key={column.key} className="p-4 text-left">
                  {column.key !== 'actions' ? (
                    <button
                      onClick={() => handleSort(column.key)}
                      className="flex items-center space-x-1 text-sm font-medium text-foreground hover:text-primary"
                    >
                      <span>{column.label}</span>
                      <Icon name={getSortIcon(column.key)} size={14} />
                    </button>
                  ) : (
                    <span className="text-sm font-medium text-foreground">{column.label}</span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction) => (
              <React.Fragment key={transaction.id}>
                <tr className="border-b hover:bg-muted/30 transition-colors">
                  <td className="p-4">
                    <input
                      type="checkbox"
                      checked={selectedTransactions.includes(transaction.id)}
                      onChange={(e) => onSelectTransaction(transaction.id, e.target.checked)}
                      className="rounded border-border"
                    />
                  </td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-sm text-primary">{transaction.id}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleRowExpansion(transaction.id)}
                        iconName={expandedRow === transaction.id ? "ChevronUp" : "ChevronDown"}
                      />
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center space-x-3">
                      <Image
                        src={transaction.user.avatar}
                        alt={transaction.user.name}
                        className="w-8 h-8 rounded-full"
                      />
                      <div>
                        <div className="font-medium text-foreground">{transaction.user.name}</div>
                        <div className="text-sm text-muted-foreground">{transaction.user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <Icon name={getTransactionTypeIcon(transaction.type)} size={16} className="text-muted-foreground" />
                      <span className="capitalize text-foreground">{transaction.type}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="font-medium text-foreground">
                      {formatAmount(transaction.amount, transaction.cryptocurrency)}
                    </div>
                    {transaction.usdValue && (
                      <div className="text-sm text-muted-foreground">
                        ≈ ${parseFloat(transaction.usdValue).toLocaleString()}
                      </div>
                    )}
                  </td>
                  <td className="p-4">
                    {getStatusBadge(transaction.status)}
                  </td>
                  <td className="p-4">
                    <div className="text-sm text-foreground">{formatDate(transaction.timestamp)}</div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-2 flex-wrap min-w-[200px]">
                      {transaction.status === 'pending' && (
                        <>
                          <Button
                            variant="success"
                            size="sm"
                            onClick={() => onApprove(transaction.id)}
                            className="min-w-[80px] hover:scale-105 transition-transform"
                            title="Approve Transaction"
                          >
                            <Icon name="Check" size={14} className="mr-1" />
                            Approve
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => onReject(transaction.id)}
                            className="min-w-[80px] hover:scale-105 transition-transform"
                            title="Reject Transaction"
                          >
                            <Icon name="X" size={14} className="mr-1" />
                            Reject
                          </Button>
                        </>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onViewDetails(transaction)}
                        className="min-w-[80px] hover:scale-105 transition-transform"
                        title="View Details"
                      >
                        <Icon name="Eye" size={14} className="mr-1" />
                        Details
                      </Button>
                    </div>
                  </td>
                </tr>
                {expandedRow === transaction.id && (
                  <tr className="bg-muted/20">
                    <td colSpan="8" className="p-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="font-medium text-foreground">Blockchain Confirmations:</span>
                          <span className="ml-2 text-muted-foreground">{transaction.confirmations || 'N/A'}</span>
                        </div>
                        <div>
                          <span className="font-medium text-foreground">Network Fee:</span>
                          <span className="ml-2 text-muted-foreground">{transaction.networkFee || 'N/A'}</span>
                        </div>
                        <div>
                          <span className="font-medium text-foreground">Exchange Rate:</span>
                          <span className="ml-2 text-muted-foreground">{transaction.exchangeRate || 'N/A'}</span>
                        </div>
                        <div>
                          <span className="font-medium text-foreground">Wallet Address:</span>
                          <span className="ml-2 text-muted-foreground font-mono text-xs">{transaction.walletAddress || 'N/A'}</span>
                        </div>
                        <div>
                          <span className="font-medium text-foreground">Transaction Hash:</span>
                          <span className="ml-2 text-muted-foreground font-mono text-xs">{transaction.txHash || 'N/A'}</span>
                        </div>
                        <div>
                          <span className="font-medium text-foreground">Created:</span>
                          <span className="ml-2 text-muted-foreground">{formatDate(transaction.createdAt)}</span>
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="lg:hidden space-y-4 p-4">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="border rounded-lg p-4 bg-background">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={selectedTransactions.includes(transaction.id)}
                  onChange={(e) => onSelectTransaction(transaction.id, e.target.checked)}
                  className="rounded border-border"
                />
                <span className="font-mono text-sm text-primary">{transaction.id}</span>
              </div>
              {getStatusBadge(transaction.status)}
            </div>

            <div className="flex items-center space-x-3 mb-3">
              <Image
                src={transaction.user.avatar}
                alt={transaction.user.name}
                className="w-10 h-10 rounded-full"
              />
              <div className="flex-1">
                <div className="font-medium text-foreground">{transaction.user.name}</div>
                <div className="text-sm text-muted-foreground">{transaction.user.email}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
              <div>
                <span className="text-muted-foreground">Type:</span>
                <div className="flex items-center space-x-1 mt-1">
                  <Icon name={getTransactionTypeIcon(transaction.type)} size={14} />
                  <span className="capitalize text-foreground">{transaction.type}</span>
                </div>
              </div>
              <div>
                <span className="text-muted-foreground">Amount:</span>
                <div className="font-medium text-foreground mt-1">
                  {formatAmount(transaction.amount, transaction.cryptocurrency)}
                </div>
              </div>
              <div>
                <span className="text-muted-foreground">Date:</span>
                <div className="text-foreground mt-1">{formatDate(transaction.timestamp)}</div>
              </div>
              <div>
                <span className="text-muted-foreground">USD Value:</span>
                <div className="text-foreground mt-1">
                  ${parseFloat(transaction.usdValue || 0).toLocaleString()}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleRowExpansion(transaction.id)}
                iconName={expandedRow === transaction.id ? "ChevronUp" : "ChevronDown"}
                iconPosition="left"
              >
                {expandedRow === transaction.id ? 'Less Details' : 'More Details'}
              </Button>
              <div className="flex items-center space-x-2">
                {transaction.status === 'pending' && (
                  <>
                    <Button
                      variant="success"
                      size="sm"
                      onClick={() => onApprove(transaction.id)}
                      iconName="Check"
                    />
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => onReject(transaction.id)}
                      iconName="X"
                    />
                  </>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onViewDetails(transaction)}
                  iconName="Eye"
                />
              </div>
            </div>

            {expandedRow === transaction.id && (
              <div className="mt-4 pt-4 border-t space-y-2 text-sm">
                <div className="grid grid-cols-1 gap-2">
                  <div>
                    <span className="font-medium text-foreground">Confirmations:</span>
                    <span className="ml-2 text-muted-foreground">{transaction.confirmations || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="font-medium text-foreground">Network Fee:</span>
                    <span className="ml-2 text-muted-foreground">{transaction.networkFee || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="font-medium text-foreground">Wallet:</span>
                    <span className="ml-2 text-muted-foreground font-mono text-xs break-all">{transaction.walletAddress || 'N/A'}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {transactions.length === 0 && (
        <div className="text-center py-12">
          <Icon name="FileX" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No Transactions Found</h3>
          <p className="text-muted-foreground">Try adjusting your filters to see more results.</p>
        </div>
      )}
    </div>
  );
};

export default TransactionTable;
