import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import ChatWidget from '../../components/ui/ChatWidget';
import { defaultAvatars } from '../../utils/avatarHelper';

// Import components
import TransactionFilters from './components/TransactionFilters';
import TransactionTable from './components/TransactionTable';
import PendingTransactions from './components/PendingTransactions';
import BulkActions from './components/BulkActions';
import TransactionDetails from './components/TransactionDetails';
import ManualTransaction from './components/ManualTransaction';
import TransactionStats from './components/TransactionStats';

const AdminTransactionManagement = () => {
  const [transactions, setTransactions] = useState([]);
  const [filteredTransactions, setFilteredTransactions] = useState([]);
  const [pendingTransactions, setPendingTransactions] = useState([]);
  const [selectedTransactions, setSelectedTransactions] = useState([]);
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [isManualTransactionOpen, setIsManualTransactionOpen] = useState(false);
  const [sortConfig, setSortConfig] = useState({ key: 'timestamp', direction: 'desc' });
  const [filters, setFilters] = useState({
    search: '',
    userEmail: '',
    type: 'all',
    status: 'all',
    cryptocurrency: 'all',
    dateFrom: '',
    dateTo: '',
    minAmount: '',
    maxAmount: ''
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(20);
  const [stats, setStats] = useState({
    totalTransactions: 0,
    pendingTransactions: 0,
    totalVolume: 0,
    failedTransactions: 0
  });

  // Mock transaction data
  const mockTransactions = [
    {
      id: 'TXN-2025-001',
      user: {
        id: 'USR-001',
        name: 'John Smith',
        email: 'john.smith@email.com',
        avatar: defaultAvatars.user1,
        status: 'active',
        kycStatus: 'verified',
        joinedAt: '2024-01-15T10:30:00Z'
      },
      type: 'deposit',
      amount: '0.5',
      cryptocurrency: 'BTC',
      usdValue: '21500.00',
      status: 'pending',
      timestamp: '2025-01-29T08:15:00Z',
      createdAt: '2025-01-29T08:15:00Z',
      updatedAt: '2025-01-29T08:15:00Z',
      confirmations: 2,
      networkFee: '0.0001 BTC',
      exchangeRate: '43000.00',
      walletAddress: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
      txHash: '000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f',
      network: 'Bitcoin',
      note: 'Large deposit requiring manual verification'
    },
    {
      id: 'TXN-2025-002',
      user: {
        id: 'USR-002',
        name: 'Sarah Johnson',
        email: 'sarah.johnson@email.com',
        avatar: defaultAvatars.user2,
        status: 'active',
        kycStatus: 'verified',
        joinedAt: '2024-03-20T14:45:00Z'
      },
      type: 'withdrawal',
      amount: '2.5',
      cryptocurrency: 'ETH',
      usdValue: '8750.00',
      status: 'completed',
      timestamp: '2025-01-29T07:30:00Z',
      createdAt: '2025-01-29T07:30:00Z',
      updatedAt: '2025-01-29T07:45:00Z',
      confirmations: 12,
      networkFee: '0.002 ETH',
      exchangeRate: '3500.00',
      walletAddress: '0x742d35Cc6634C0532925a3b8D4C2c4e1b9c4b8e2',
      txHash: '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef',
      network: 'Ethereum'
    },
    {
      id: 'TXN-2025-003',
      user: {
        id: 'USR-003',
        name: 'Michael Chen',
        email: 'michael.chen@email.com',
        avatar: defaultAvatars.user3,
        status: 'active',
        kycStatus: 'pending',
        joinedAt: '2024-12-10T09:20:00Z'
      },
      type: 'investment',
      amount: '1000',
      cryptocurrency: 'USDT',
      usdValue: '1000.00',
      status: 'pending',
      timestamp: '2025-01-29T06:45:00Z',
      createdAt: '2025-01-29T06:45:00Z',
      updatedAt: '2025-01-29T06:45:00Z',
      confirmations: 0,
      networkFee: '1 USDT',
      exchangeRate: '1.00',
      walletAddress: 'TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE',
      network: 'Tron',
      note: 'Investment in Premium Plan - requires KYC verification'
    },
    {
      id: 'TXN-2025-004',
      user: {
        id: 'USR-004',
        name: 'Emily Rodriguez',
        email: 'emily.rodriguez@email.com',
        avatar: defaultAvatars.user4,
        status: 'active',
        kycStatus: 'verified',
        joinedAt: '2024-02-28T16:10:00Z'
      },
      type: 'referral',
      amount: '50',
      cryptocurrency: 'USDT',
      usdValue: '50.00',
      status: 'completed',
      timestamp: '2025-01-29T05:20:00Z',
      createdAt: '2025-01-29T05:20:00Z',
      updatedAt: '2025-01-29T05:25:00Z',
      confirmations: 6,
      networkFee: '0.5 USDT',
      exchangeRate: '1.00',
      walletAddress: 'TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE',
      network: 'Tron'
    },
    {
      id: 'TXN-2025-005',
      user: {
        id: 'USR-005',
        name: 'David Wilson',
        email: 'david.wilson@email.com',
        avatar: defaultAvatars.user5,
        status: 'active',
        kycStatus: 'verified',
        joinedAt: '2024-05-15T11:30:00Z'
      },
      type: 'transfer',
      amount: '0.1',
      cryptocurrency: 'BTC',
      usdValue: '4300.00',
      status: 'failed',
      timestamp: '2025-01-29T04:10:00Z',
      createdAt: '2025-01-29T04:10:00Z',
      updatedAt: '2025-01-29T04:15:00Z',
      confirmations: 0,
      networkFee: '0.0001 BTC',
      exchangeRate: '43000.00',
      walletAddress: '1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2',
      network: 'Bitcoin',
      note: 'Transaction failed due to insufficient network fee'
    }
  ];

  useEffect(() => {
    // Load from localStorage if available, otherwise use mock data
    const storedTransactions = localStorage.getItem('admin_transactions');
    const loadedTransactions = storedTransactions ? JSON.parse(storedTransactions) : mockTransactions;

    setTransactions(loadedTransactions);
    setFilteredTransactions(loadedTransactions);

    // Set pending transactions
    const pending = loadedTransactions.filter(tx => tx.status === 'pending');
    setPendingTransactions(pending);

    // Calculate stats
    setStats({
      totalTransactions: loadedTransactions.length,
      pendingTransactions: pending.length,
      totalVolume: loadedTransactions.reduce((sum, tx) => sum + parseFloat(tx.usdValue || 0), 0),
      failedTransactions: loadedTransactions.filter(tx => tx.status === 'failed').length
    });
  }, []);

  // Save transactions to localStorage whenever transactions change
  useEffect(() => {
    if (transactions.length > 0) {
      localStorage.setItem('admin_transactions', JSON.stringify(transactions));
    }
  }, [transactions]);

  // Filter transactions based on active filters
  useEffect(() => {
    let filtered = [...transactions];

    // Search filter
    if (filters.search) {
      filtered = filtered.filter(tx => 
        tx.id.toLowerCase().includes(filters.search.toLowerCase())
      );
    }

    // User email filter
    if (filters.userEmail) {
      filtered = filtered.filter(tx => 
        tx.user.email.toLowerCase().includes(filters.userEmail.toLowerCase())
      );
    }

    // Type filter
    if (filters.type && filters.type !== 'all') {
      filtered = filtered.filter(tx => tx.type === filters.type);
    }

    // Status filter
    if (filters.status && filters.status !== 'all') {
      filtered = filtered.filter(tx => tx.status === filters.status);
    }

    // Cryptocurrency filter
    if (filters.cryptocurrency && filters.cryptocurrency !== 'all') {
      filtered = filtered.filter(tx => tx.cryptocurrency === filters.cryptocurrency);
    }

    // Date range filter
    if (filters.dateFrom) {
      filtered = filtered.filter(tx => 
        new Date(tx.timestamp) >= new Date(filters.dateFrom)
      );
    }
    if (filters.dateTo) {
      filtered = filtered.filter(tx => 
        new Date(tx.timestamp) <= new Date(filters.dateTo + 'T23:59:59')
      );
    }

    // Amount range filter
    if (filters.minAmount) {
      filtered = filtered.filter(tx => 
        parseFloat(tx.amount) >= parseFloat(filters.minAmount)
      );
    }
    if (filters.maxAmount) {
      filtered = filtered.filter(tx => 
        parseFloat(tx.amount) <= parseFloat(filters.maxAmount)
      );
    }

    setFilteredTransactions(filtered);
    setCurrentPage(1);
  }, [filters, transactions]);

  // Sort transactions
  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });

    const sorted = [...filteredTransactions].sort((a, b) => {
      let aValue = a[key];
      let bValue = b[key];

      // Handle nested user properties
      if (key === 'user') {
        aValue = a.user.name;
        bValue = b.user.name;
      }

      // Handle numeric values
      if (key === 'amount') {
        aValue = parseFloat(aValue);
        bValue = parseFloat(bValue);
      }

      // Handle dates
      if (key === 'timestamp') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }

      if (aValue < bValue) return direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return direction === 'asc' ? 1 : -1;
      return 0;
    });

    setFilteredTransactions(sorted);
  };

  // Handle transaction selection
  const handleSelectTransaction = (transactionId, isSelected) => {
    if (isSelected) {
      setSelectedTransactions(prev => [...prev, transactionId]);
    } else {
      setSelectedTransactions(prev => prev.filter(id => id !== transactionId));
    }
  };

  const handleSelectAll = (isSelected) => {
    if (isSelected) {
      const currentPageTransactions = getCurrentPageTransactions();
      const currentPageIds = currentPageTransactions.map(tx => tx.id);
      setSelectedTransactions(prev => [...new Set([...prev, ...currentPageIds])]);
    } else {
      const currentPageTransactions = getCurrentPageTransactions();
      const currentPageIds = currentPageTransactions.map(tx => tx.id);
      setSelectedTransactions(prev => prev.filter(id => !currentPageIds.includes(id)));
    }
  };

  // Transaction actions
  const handleApprove = async (transactionId) => {
    try {
      // Find transaction details for confirmation
      const transaction = transactions.find(tx => tx.id === transactionId);

      if (!transaction) {
        alert('Transaction not found!');
        return;
      }

      const confirmMessage = `Approve Transaction ${transactionId}?\n\n` +
        `User: ${transaction.user.name}\n` +
        `Type: ${transaction.type.toUpperCase()}\n` +
        `Amount: ${transaction.amount} ${transaction.cryptocurrency}\n` +
        `USD Value: $${parseFloat(transaction.usdValue).toLocaleString()}\n\n` +
        `This action cannot be undone.`;

      if (!confirm(confirmMessage)) {
        return;
      }

      // Update transaction status
      setTransactions(prev => prev.map(tx =>
        tx.id === transactionId
          ? { ...tx, status: 'completed', updatedAt: new Date().toISOString() }
          : tx
      ));

      // Remove from pending
      setPendingTransactions(prev => prev.filter(tx => tx.id !== transactionId));

      // Update stats
      setStats(prev => ({
        ...prev,
        pendingTransactions: prev.pendingTransactions - 1
      }));

      // Show success message
      alert(`✅ Transaction ${transactionId} approved successfully!\n\nStatus: COMPLETED\nUser will be notified automatically.`);
      console.log(`Transaction ${transactionId} approved`);
    } catch (error) {
      console.error('Failed to approve transaction:', error);
      alert('❌ Failed to approve transaction. Please try again.');
    }
  };

  const handleReject = async (transactionId) => {
    try {
      // Find transaction details for confirmation
      const transaction = transactions.find(tx => tx.id === transactionId);

      if (!transaction) {
        alert('Transaction not found!');
        return;
      }

      const reason = prompt(`Reject Transaction ${transactionId}?\n\n` +
        `User: ${transaction.user.name}\n` +
        `Type: ${transaction.type.toUpperCase()}\n` +
        `Amount: ${transaction.amount} ${transaction.cryptocurrency}\n` +
        `USD Value: $${parseFloat(transaction.usdValue).toLocaleString()}\n\n` +
        `Please enter rejection reason (optional):`);

      if (reason === null) {
        return; // User cancelled
      }

      // Update transaction status
      setTransactions(prev => prev.map(tx =>
        tx.id === transactionId
          ? {
              ...tx,
              status: 'cancelled',
              updatedAt: new Date().toISOString(),
              rejectionReason: reason || 'No reason provided'
            }
          : tx
      ));

      // Remove from pending
      setPendingTransactions(prev => prev.filter(tx => tx.id !== transactionId));

      // Update stats
      setStats(prev => ({
        ...prev,
        pendingTransactions: prev.pendingTransactions - 1
      }));

      // Show success message
      alert(`❌ Transaction ${transactionId} rejected successfully!\n\nStatus: CANCELLED\nReason: ${reason || 'No reason provided'}\nUser will be notified automatically.`);
      console.log(`Transaction ${transactionId} rejected with reason: ${reason}`);
    } catch (error) {
      console.error('Failed to reject transaction:', error);
      alert('❌ Failed to reject transaction. Please try again.');
    }
  };

  const handleViewDetails = (transaction) => {
    setSelectedTransaction(transaction);
    setIsDetailsModalOpen(true);
  };

  // Bulk actions
  const handleBulkApprove = async (transactionIds) => {
    try {
      for (const id of transactionIds) {
        await handleApprove(id);
      }
      setSelectedTransactions([]);
    } catch (error) {
      console.error('Bulk approve failed:', error);
    }
  };

  const handleBulkReject = async (transactionIds) => {
    try {
      for (const id of transactionIds) {
        await handleReject(id);
      }
      setSelectedTransactions([]);
    } catch (error) {
      console.error('Bulk reject failed:', error);
    }
  };

  const handleBulkExport = async (transactionIds) => {
    try {
      const exportData = transactions.filter(tx => transactionIds.includes(tx.id));
      const csvContent = generateCSV(exportData);
      downloadCSV(csvContent, `transactions-${new Date().toISOString().split('T')[0]}.csv`);
      console.log('Transactions exported successfully');
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const handleBulkStatusUpdate = async (transactionIds, newStatus) => {
    try {
      setTransactions(prev => prev.map(tx => 
        transactionIds.includes(tx.id)
          ? { ...tx, status: newStatus, updatedAt: new Date().toISOString() }
          : tx
      ));
      setSelectedTransactions([]);
      console.log(`${transactionIds.length} transactions updated to ${newStatus}`);
    } catch (error) {
      console.error('Bulk status update failed:', error);
    }
  };

  // Manual transaction
  const handleManualTransaction = async (transactionData) => {
    try {
      const newTransaction = {
        id: `TXN-${new Date().getFullYear()}-${String(transactions.length + 1).padStart(3, '0')}`,
        user: {
          id: 'USR-MANUAL',
          name: 'Manual Entry',
          email: transactionData.userEmail,
          avatar: defaultAvatars.default,
          status: 'active',
          kycStatus: 'verified',
          joinedAt: new Date().toISOString()
        },
        type: transactionData.type === 'credit' ? 'deposit' : 'withdrawal',
        amount: transactionData.amount.toString(),
        cryptocurrency: transactionData.cryptocurrency,
        usdValue: (transactionData.amount * 43000).toString(), // Mock exchange rate
        status: 'completed',
        timestamp: transactionData.timestamp,
        createdAt: transactionData.timestamp,
        updatedAt: transactionData.timestamp,
        confirmations: 1,
        networkFee: '0',
        exchangeRate: '43000.00',
        walletAddress: 'Manual Transaction',
        network: 'Manual',
        note: `Manual ${transactionData.type} - Reason: ${transactionData.reason}${transactionData.note ? ` - ${transactionData.note}` : ''}`
      };

      setTransactions(prev => [newTransaction, ...prev]);
      setStats(prev => ({
        ...prev,
        totalTransactions: prev.totalTransactions + 1,
        totalVolume: prev.totalVolume + parseFloat(newTransaction.usdValue)
      }));

      console.log('Manual transaction created successfully');
    } catch (error) {
      console.error('Failed to create manual transaction:', error);
    }
  };

  // Utility functions
  const generateCSV = (data) => {
    const headers = ['ID', 'User', 'Email', 'Type', 'Amount', 'Cryptocurrency', 'USD Value', 'Status', 'Date'];
    const rows = data.map(tx => [
      tx.id,
      tx.user.name,
      tx.user.email,
      tx.type,
      tx.amount,
      tx.cryptocurrency,
      tx.usdValue,
      tx.status,
      new Date(tx.timestamp).toLocaleString()
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const downloadCSV = (content, filename) => {
    const blob = new Blob([content], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  // Pagination
  const getCurrentPageTransactions = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filteredTransactions.slice(startIndex, endIndex);
  };

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Navigation */}
      <AdminNavigation
        title="Transaction Management"
        breadcrumb={[
          { label: "Transactions", link: null },
          { label: "All Transactions", link: null }
        ]}
        actions={[
          {
            label: "Reset Data",
            icon: "RotateCcw",
            variant: "outline",
            onClick: () => {
              if (confirm('Reset all transaction data to original state?\n\nThis will clear all approve/reject actions and restore mock data.')) {
                localStorage.removeItem('admin_transactions');
                window.location.reload();
              }
            }
          },
          {
            label: "Export All",
            icon: "Download",
            variant: "outline",
            onClick: () => handleBulkExport(filteredTransactions.map(tx => tx.id))
          },
          {
            label: "Manual Transaction",
            icon: "Plus",
            variant: "default",
            onClick: () => setIsManualTransactionOpen(true)
          }
        ]}
      />

      <div className="flex">
        <main className="flex-1 p-6">
          <div className="mb-6">
            <p className="text-muted-foreground">
              Monitor and manage all platform cryptocurrency transactions
            </p>
          </div>

          {/* Transaction Stats */}
          <TransactionStats stats={stats} />

          {/* Pending Transactions */}
          <PendingTransactions
            pendingTransactions={pendingTransactions}
            onApprove={handleApprove}
            onReject={handleReject}
            onViewDetails={handleViewDetails}
          />

          {/* Filters */}
          <TransactionFilters
            onFilterChange={setFilters}
            onClearFilters={() => setFilters({
              search: '',
              userEmail: '',
              type: 'all',
              status: 'all',
              cryptocurrency: 'all',
              dateFrom: '',
              dateTo: '',
              minAmount: '',
              maxAmount: ''
            })}
            activeFilters={filters}
          />

          {/* Bulk Actions */}
          <BulkActions
            selectedTransactions={selectedTransactions}
            onBulkApprove={handleBulkApprove}
            onBulkReject={handleBulkReject}
            onBulkExport={handleBulkExport}
            onBulkStatusUpdate={handleBulkStatusUpdate}
            onClearSelection={() => setSelectedTransactions([])}
          />

          {/* Transaction Table */}
          <TransactionTable
            transactions={getCurrentPageTransactions()}
            onSort={handleSort}
            sortConfig={sortConfig}
            onApprove={handleApprove}
            onReject={handleReject}
            onViewDetails={handleViewDetails}
            selectedTransactions={selectedTransactions}
            onSelectTransaction={handleSelectTransaction}
            onSelectAll={handleSelectAll}
          />

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-6">
              <div className="text-sm text-muted-foreground">
                Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, filteredTransactions.length)} of {filteredTransactions.length} transactions
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  iconName="ChevronLeft"
                />
                <span className="text-sm text-foreground">
                  Page {currentPage} of {totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                  iconName="ChevronRight"
                />
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Modals */}
      <TransactionDetails
        transaction={selectedTransaction}
        isOpen={isDetailsModalOpen}
        onClose={() => {
          setIsDetailsModalOpen(false);
          setSelectedTransaction(null);
        }}
        onApprove={handleApprove}
        onReject={handleReject}
      />

      <ManualTransaction
        isOpen={isManualTransactionOpen}
        onClose={() => setIsManualTransactionOpen(false)}
        onSubmit={handleManualTransaction}
      />

      <ChatWidget />
    </div>
  );
};

export default AdminTransactionManagement;
