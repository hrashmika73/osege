import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const LoginSelection = () => {
  return (
    <>
      <Helmet>
        <title>Login - KleverInvest Hub</title>
        <meta name="description" content="Choose your login type for KleverInvest Hub" />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 flex items-center justify-center p-4">
        <div className="w-full max-w-4xl">
          
          {/* Header */}
          <div className="text-center mb-12">
            <Link to="/" className="inline-flex items-center space-x-3 mb-8">
              <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-2xl flex items-center justify-center">
                <Icon name="TrendingUp" size={32} className="text-white" />
              </div>
              <span className="text-3xl font-bold text-foreground">KleverInvest Hub</span>
            </Link>
            <h1 className="text-4xl font-bold text-foreground mb-4">Welcome Back</h1>
            <p className="text-xl text-muted-foreground">Choose your access level to continue</p>
          </div>

          {/* Login Options */}
          <div className="max-w-md mx-auto">

            {/* User Login */}
            <div className="bg-card border rounded-3xl p-8 text-center hover:shadow-lg transition-all duration-300 hover:border-primary/50">
              <div className="w-20 h-20 bg-gradient-to-r from-primary to-accent rounded-2xl mx-auto mb-6 flex items-center justify-center">
                <Icon name="User" size={32} className="text-white" />
              </div>

              <h2 className="text-2xl font-bold text-foreground mb-4">Investor Portal</h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                Access your investment dashboard, portfolio, trading tools, and manage your cryptocurrency investments.
              </p>

              <div className="space-y-3 mb-8">
                <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                  <Icon name="CheckCircle" size={16} className="text-success" />
                  <span>Investment Dashboard</span>
                </div>
                <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                  <Icon name="CheckCircle" size={16} className="text-success" />
                  <span>Trading Interface</span>
                </div>
                <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                  <Icon name="CheckCircle" size={16} className="text-success" />
                  <span>Portfolio Management</span>
                </div>
                <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                  <Icon name="CheckCircle" size={16} className="text-success" />
                  <span>Referral Program</span>
                </div>
              </div>

              <Link to="/user-login">
                <Button className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90" size="lg">
                  <Icon name="LogIn" size={18} className="mr-2" />
                  Access Investor Portal
                </Button>
              </Link>

              <div className="mt-4">
                <Link to="/register" className="text-sm text-primary hover:underline">
                  New investor? Create account
                </Link>
              </div>
            </div>
          </div>

          {/* Return to Home */}
          <div className="text-center mt-12">
            <Link 
              to="/" 
              className="inline-flex items-center space-x-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <Icon name="ArrowLeft" size={16} />
              <span>Return to Homepage</span>
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default LoginSelection;
