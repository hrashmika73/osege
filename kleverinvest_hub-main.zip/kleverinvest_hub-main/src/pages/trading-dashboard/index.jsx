import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import MarketOverview from './components/MarketOverview';
import ActivePositions from './components/ActivePositions';
import TradingHistory from './components/TradingHistory';
import MarketWatchlist from './components/MarketWatchlist';
import PerformanceMetrics from './components/PerformanceMetrics';
import TradingViewWidget from './components/TradingViewWidget';

const TradingDashboard = () => {
  const navigate = useNavigate();
  const { isUserAuthenticated } = useUserAuth();
  const [selectedTimeframe, setSelectedTimeframe] = useState('1D');
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Redirect to user login if not authenticated as user
  useEffect(() => {
    if (!isUserAuthenticated) {
      navigate('/user-login');
    }
  }, [isUserAuthenticated, navigate]);

  // Don't render if not authenticated
  if (!isUserAuthenticated) {
    return null;
  }

  // Simulate data loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setDashboardData({
        totalPortfolioValue: 138456.78,
        dayChange: 3245.67,
        dayChangePercent: 2.41,
        totalPnL: 12456.89,
        totalPnLPercent: 9.87,
        activePositions: 5,
        todaysTrades: 12
      });
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const timeframes = ['1H', '1D', '1W', '1M'];

  const quickAccessItems = [
    {
      label: 'BTC Trading',
      description: 'Live Bitcoin trading',
      icon: 'TrendingUp',
      color: 'bg-orange-500/10 text-orange-500',
      path: '/btc-live-trading-interface'
    },
    {
      label: 'Market Analysis',
      description: 'Technical analysis tools',
      icon: 'BarChart3',
      color: 'bg-primary/10 text-primary',
      onClick: () => {}
    },
    {
      label: 'Portfolio',
      description: 'Investment portfolio',
      icon: 'PieChart',
      color: 'bg-success/10 text-success',
      path: '/investment-portfolio-dashboard'
    },
    {
      label: 'Trade History',
      description: 'Past transactions',
      icon: 'History',
      color: 'bg-accent/10 text-accent',
      path: '/transaction-history'
    }
  ];

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const formatChange = (change, isPercent = false) => {
    const sign = change >= 0 ? '+' : '';
    return isPercent 
      ? `${sign}${change.toFixed(2)}%` 
      : `${sign}${formatCurrency(change)}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading trading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-foreground">Trading Dashboard</h1>
            <p className="text-sm sm:text-base text-muted-foreground">
              Monitor your trading activities and market performance
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Icon name="Settings" size={16} />
              <span className="hidden sm:inline ml-2">Settings</span>
            </Button>
            <Button size="sm" onClick={() => navigate('/btc-live-trading-interface')}>
              <Icon name="Plus" size={16} />
              <span className="hidden sm:inline ml-2">New Trade</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="p-4 sm:p-6 space-y-6">
        {/* Portfolio Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-card border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Portfolio Value</p>
                <p className="text-2xl font-bold text-foreground">
                  {formatCurrency(dashboardData.totalPortfolioValue)}
                </p>
                <p className={`text-sm font-medium flex items-center mt-1 ${
                  dashboardData.dayChange >= 0 ? 'text-success' : 'text-error'
                }`}>
                  <Icon 
                    name={dashboardData.dayChange >= 0 ? 'ArrowUp' : 'ArrowDown'} 
                    size={14} 
                    className="mr-1" 
                  />
                  {formatChange(dashboardData.dayChange)} ({formatChange(dashboardData.dayChangePercent, true)})
                </p>
              </div>
              <div className="bg-primary/10 p-3 rounded-lg">
                <Icon name="Wallet" size={24} className="text-primary" />
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total P&L</p>
                <p className="text-2xl font-bold text-foreground">
                  {formatCurrency(dashboardData.totalPnL)}
                </p>
                <p className={`text-sm font-medium mt-1 ${
                  dashboardData.totalPnLPercent >= 0 ? 'text-success' : 'text-error'
                }`}>
                  {formatChange(dashboardData.totalPnLPercent, true)}
                </p>
              </div>
              <div className="bg-success/10 p-3 rounded-lg">
                <Icon name="TrendingUp" size={24} className="text-success" />
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Positions</p>
                <p className="text-2xl font-bold text-foreground">
                  {dashboardData.activePositions}
                </p>
                <p className="text-sm text-muted-foreground mt-1">Open trades</p>
              </div>
              <div className="bg-accent/10 p-3 rounded-lg">
                <Icon name="Activity" size={24} className="text-accent" />
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Today's Trades</p>
                <p className="text-2xl font-bold text-foreground">
                  {dashboardData.todaysTrades}
                </p>
                <p className="text-sm text-muted-foreground mt-1">Completed</p>
              </div>
              <div className="bg-warning/10 p-3 rounded-lg">
                <Icon name="BarChart" size={24} className="text-warning" />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Access */}
        <div className="bg-card border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Quick Access</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickAccessItems.map((item, index) => (
              <div
                key={index}
                className="p-4 border rounded-lg hover:border-primary cursor-pointer transition-colors"
                onClick={() => item.path ? navigate(item.path) : item.onClick?.()}
              >
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-3 ${item.color}`}>
                  <Icon name={item.icon} size={20} />
                </div>
                <h4 className="font-medium text-foreground mb-1">{item.label}</h4>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Market Overview & TradingView */}
          <div className="lg:col-span-2 space-y-6">
            <MarketOverview />
            
            {/* TradingView Widget */}
            <div className="bg-card border rounded-lg">
              <div className="p-4 border-b">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-foreground">Market Analysis</h3>
                  <div className="flex items-center space-x-2">
                    {timeframes.map((timeframe) => (
                      <Button
                        key={timeframe}
                        variant={selectedTimeframe === timeframe ? "default" : "ghost"}
                        size="xs"
                        onClick={() => setSelectedTimeframe(timeframe)}
                      >
                        {timeframe}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="h-96">
                <TradingViewWidget timeframe={selectedTimeframe} />
              </div>
            </div>

            <ActivePositions />
          </div>

          {/* Right Column - Watchlist & Performance */}
          <div className="space-y-6">
            <MarketWatchlist />
            <PerformanceMetrics selectedTimeframe={selectedTimeframe} />
            <TradingHistory />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TradingDashboard;
