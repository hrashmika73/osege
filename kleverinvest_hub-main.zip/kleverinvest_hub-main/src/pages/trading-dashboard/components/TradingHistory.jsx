import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TradingHistory = () => {
  const [selectedFilter, setSelectedFilter] = useState('all');

  // Mock trading history data
  const tradingHistory = [
    {
      id: 1,
      symbol: 'BTC/USD',
      side: 'buy',
      size: 0.25,
      price: 44250.00,
      total: 11062.50,
      pnl: 382.63,
      status: 'completed',
      timestamp: new Date(Date.now() - 3600000)
    },
    {
      id: 2,
      symbol: 'ETH/USD',
      side: 'sell',
      size: 3.5,
      price: 2890.00,
      total: 10115.00,
      pnl: -125.50,
      status: 'completed',
      timestamp: new Date(Date.now() - 7200000)
    },
    {
      id: 3,
      symbol: 'BNB/USD',
      side: 'buy',
      size: 32.0,
      price: 305.50,
      total: 9776.00,
      pnl: 332.80,
      status: 'completed',
      timestamp: new Date(Date.now() - 10800000)
    },
    {
      id: 4,
      symbol: 'ADA/USD',
      side: 'sell',
      size: 2500.0,
      price: 0.485,
      total: 1212.50,
      pnl: 45.25,
      status: 'completed',
      timestamp: new Date(Date.now() - 14400000)
    },
    {
      id: 5,
      symbol: 'SOL/USD',
      side: 'buy',
      size: 15.0,
      price: 98.76,
      total: 1481.40,
      pnl: 89.12,
      status: 'pending',
      timestamp: new Date(Date.now() - 18000000)
    }
  ];

  const filters = [
    { key: 'all', label: 'All' },
    { key: 'completed', label: 'Completed' },
    { key: 'pending', label: 'Pending' },
    { key: 'buy', label: 'Buy' },
    { key: 'sell', label: 'Sell' }
  ];

  const filteredHistory = tradingHistory.filter(trade => {
    if (selectedFilter === 'all') return true;
    if (selectedFilter === 'completed' || selectedFilter === 'pending') {
      return trade.status === selectedFilter;
    }
    return trade.side === selectedFilter;
  });

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(price);
  };

  const formatCrypto = (amount, symbol) => {
    return `${amount.toFixed(4)} ${symbol.split('/')[0]}`;
  };

  const formatChange = (change) => {
    const sign = change >= 0 ? '+' : '';
    return `${sign}${formatPrice(change)}`;
  };

  const formatTime = (timestamp) => {
    return timestamp.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'text-success bg-success/20';
      case 'pending':
        return 'text-warning bg-warning/20';
      case 'failed':
        return 'text-error bg-error/20';
      default:
        return 'text-muted-foreground bg-muted';
    }
  };

  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Trading History</h3>
            <p className="text-sm text-muted-foreground">Recent trading activity</p>
          </div>
          <Button variant="ghost" size="sm">
            <Icon name="MoreHorizontal" size={16} />
          </Button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="p-4 border-b">
        <div className="flex flex-wrap gap-1 bg-muted rounded-lg p-1">
          {filters.map((filter) => (
            <Button
              key={filter.key}
              variant={selectedFilter === filter.key ? "default" : "ghost"}
              size="xs"
              className="flex-1 sm:flex-none"
              onClick={() => setSelectedFilter(filter.key)}
            >
              {filter.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="p-4 max-h-96 overflow-y-auto">
        {filteredHistory.length === 0 ? (
          <div className="text-center py-6">
            <Icon name="Activity" size={32} className="mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No trading history found</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredHistory.map((trade) => (
              <div key={trade.id} className="border rounded-lg p-3 hover:bg-muted/30">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-foreground">{trade.symbol}</span>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                      trade.side === 'buy' ?'bg-success/20 text-success' :'bg-error/20 text-error'
                    }`}>
                      {trade.side.toUpperCase()}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${getStatusColor(trade.status)}`}>
                      {trade.status.toUpperCase()}
                    </span>
                  </div>
                  <div className={`text-sm font-medium ${
                    trade.pnl >= 0 ? 'text-success' : 'text-error'
                  }`}>
                    {formatChange(trade.pnl)}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground text-xs">Size</div>
                    <div className="font-medium text-foreground">
                      {formatCrypto(trade.size, trade.symbol)}
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs">Price</div>
                    <div className="font-medium text-foreground">
                      {formatPrice(trade.price)}
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs">Total</div>
                    <div className="font-medium text-foreground">
                      {formatPrice(trade.total)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-2 pt-2 border-t">
                  <div className="text-xs text-muted-foreground">
                    {formatTime(trade.timestamp)}
                  </div>
                  <Button variant="ghost" size="xs">
                    <Icon name="ExternalLink" size={12} />
                    <span className="ml-1">Details</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Summary Footer */}
      <div className="p-4 border-t bg-muted/50">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="text-muted-foreground">Total Trades Today</div>
            <div className="font-semibold text-foreground">
              {tradingHistory.filter(t => t.status === 'completed').length}
            </div>
          </div>
          <div>
            <div className="text-muted-foreground">Today's P&L</div>
            <div className="font-semibold text-success">
              {formatChange(tradingHistory.reduce((sum, t) => sum + t.pnl, 0))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TradingHistory;