import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const MarketOverview = () => {
  const [marketData, setMarketData] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('trending');

  // Mock market data
  useEffect(() => {
    const generateMarketData = () => {
      const cryptos = [
        { symbol: 'BTC', name: 'Bitcoin', price: 45780.25, change: 2.82, volume: '28.5B', marketCap: '895.2B' },
        { symbol: 'ETH', name: 'Ethereum', price: 2845.67, change: -1.45, volume: '12.8B', marketCap: '342.1B' },
        { symbol: 'BNB', name: 'Binance Coin', price: 315.89, change: 4.23, volume: '2.1B', marketCap: '51.8B' },
        { symbol: 'ADA', name: 'Cardano', price: 0.485, change: -2.17, volume: '1.2B', marketCap: '16.9B' },
        { symbol: 'SOL', name: 'Solana', price: 98.76, change: 6.84, volume: '3.4B', marketCap: '43.2B' },
        { symbol: 'MATIC', name: 'Polygon', price: 0.872, change: 1.93, volume: '685M', marketCap: '8.1B' }
      ];

      setMarketData(cryptos);
    };

    generateMarketData();
    const interval = setInterval(generateMarketData, 5000);
    return () => clearInterval(interval);
  }, []);

  const categories = [
    { key: 'trending', label: 'Trending', icon: 'TrendingUp' },
    { key: 'gainers', label: 'Top Gainers', icon: 'ArrowUp' },
    { key: 'losers', label: 'Top Losers', icon: 'ArrowDown' },
    { key: 'volume', label: 'High Volume', icon: 'BarChart3' }
  ];

  const formatPrice = (price) => {
    if (price < 1) {
      return `$${price.toFixed(4)}`;
    }
    return `$${price.toLocaleString(undefined, { 
      minimumFractionDigits: 2, 
      maximumFractionDigits: 2 
    })}`;
  };

  const formatVolume = (volume) => volume;
  const formatMarketCap = (marketCap) => marketCap;

  const filteredData = () => {
    switch (selectedCategory) {
      case 'gainers':
        return [...marketData].sort((a, b) => b.change - a.change).slice(0, 6);
      case 'losers':
        return [...marketData].sort((a, b) => a.change - b.change).slice(0, 6);
      case 'volume':
        return [...marketData].sort((a, b) => parseFloat(b.volume) - parseFloat(a.volume)).slice(0, 6);
      default:
        return marketData;
    }
  };

  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 sm:p-6 border-b">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Market Overview</h3>
            <p className="text-sm text-muted-foreground">Live cryptocurrency market data</p>
          </div>
          
          {/* Category Selector */}
          <div className="flex items-center space-x-1 bg-muted rounded-lg p-1 overflow-x-auto">
            {categories.map((category) => (
              <Button
                key={category.key}
                variant={selectedCategory === category.key ? "default" : "ghost"}
                size="xs"
                className="whitespace-nowrap"
                onClick={() => setSelectedCategory(category.key)}
              >
                <Icon name={category.icon} size={14} />
                <span className="ml-1 hidden sm:inline">{category.label}</span>
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 sm:p-6">
        {/* Desktop Table View */}
        <div className="hidden lg:block">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left border-b">
                  <th className="pb-3 text-sm font-medium text-muted-foreground">Asset</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Price</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground text-right">24h Change</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Volume</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Market Cap</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredData().map((crypto) => (
                  <tr key={crypto.symbol} className="border-b hover:bg-muted/50">
                    <td className="py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-xs font-bold text-primary">{crypto.symbol[0]}</span>
                        </div>
                        <div>
                          <div className="font-medium text-foreground">{crypto.symbol}</div>
                          <div className="text-xs text-muted-foreground">{crypto.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 text-right font-mono">
                      <span className="font-medium text-foreground">{formatPrice(crypto.price)}</span>
                    </td>
                    <td className="py-4 text-right">
                      <span className={`font-medium flex items-center justify-end ${
                        crypto.change >= 0 ? 'text-success' : 'text-error'
                      }`}>
                        <Icon 
                          name={crypto.change >= 0 ? 'ArrowUp' : 'ArrowDown'} 
                          size={14} 
                          className="mr-1" 
                        />
                        {Math.abs(crypto.change).toFixed(2)}%
                      </span>
                    </td>
                    <td className="py-4 text-right font-mono">
                      <span className="text-muted-foreground">${formatVolume(crypto.volume)}</span>
                    </td>
                    <td className="py-4 text-right font-mono">
                      <span className="text-muted-foreground">${formatMarketCap(crypto.marketCap)}</span>
                    </td>
                    <td className="py-4 text-right">
                      <Button variant="ghost" size="xs">
                        <Icon name="Plus" size={14} />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Mobile Card View */}
        <div className="lg:hidden space-y-3">
          {filteredData().map((crypto) => (
            <div key={crypto.symbol} className="bg-muted/30 border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">{crypto.symbol[0]}</span>
                  </div>
                  <div>
                    <div className="font-medium text-foreground">{crypto.symbol}</div>
                    <div className="text-xs text-muted-foreground">{crypto.name}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-foreground">{formatPrice(crypto.price)}</div>
                  <div className={`text-xs font-medium flex items-center ${
                    crypto.change >= 0 ? 'text-success' : 'text-error'
                  }`}>
                    <Icon 
                      name={crypto.change >= 0 ? 'ArrowUp' : 'ArrowDown'} 
                      size={12} 
                      className="mr-1" 
                    />
                    {Math.abs(crypto.change).toFixed(2)}%
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <div className="text-muted-foreground">Volume</div>
                  <div className="font-medium text-foreground">${formatVolume(crypto.volume)}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Market Cap</div>
                  <div className="font-medium text-foreground">${formatMarketCap(crypto.marketCap)}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MarketOverview;