import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const MarketWatchlist = () => {
  const [watchlist, setWatchlist] = useState([]);
  const [alerts, setAlerts] = useState([]);

  // Mock watchlist data
  useEffect(() => {
    const generateWatchlist = () => {
      const items = [
        { symbol: 'BTC/USD', price: 45780.25, change: 2.82, alert: 46000, target: 48000 },
        { symbol: 'ETH/USD', price: 2845.67, change: -1.45, alert: 2800, target: 3000 },
        { symbol: 'BNB/USD', price: 315.89, change: 4.23, alert: 320, target: 350 },
        { symbol: 'ADA/USD', price: 0.485, change: -2.17, alert: 0.45, target: 0.55 },
        { symbol: 'SOL/USD', price: 98.76, change: 6.84, alert: 100, target: 120 }
      ];

      setWatchlist(items);
    };

    generateWatchlist();
    const interval = setInterval(generateWatchlist, 5000);
    return () => clearInterval(interval);
  }, []);

  const formatPrice = (price) => {
    if (price < 1) {
      return `$${price.toFixed(4)}`;
    }
    return `$${price.toLocaleString(undefined, { 
      minimumFractionDigits: 2, 
      maximumFractionDigits: 2 
    })}`;
  };

  const handleSetAlert = (symbol) => {
    alert(`Setting price alert for ${symbol}`);
  };

  const handleAddToWatchlist = () => {
    alert('Add new cryptocurrency to watchlist');
  };

  const handleRemoveFromWatchlist = (symbol) => {
    setWatchlist(prev => prev.filter(item => item.symbol !== symbol));
  };

  const isNearAlert = (price, alertPrice) => {
    return Math.abs(price - alertPrice) / alertPrice < 0.02; // Within 2%
  };

  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Market Watchlist</h3>
            <p className="text-sm text-muted-foreground">Track your favorite cryptocurrencies</p>
          </div>
          <Button variant="ghost" size="sm" onClick={handleAddToWatchlist}>
            <Icon name="Plus" size={16} />
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-3 max-h-96 overflow-y-auto">
        {watchlist.length === 0 ? (
          <div className="text-center py-6">
            <Icon name="Star" size={32} className="mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground mb-3">No items in watchlist</p>
            <Button variant="outline" size="sm" onClick={handleAddToWatchlist}>
              <Icon name="Plus" size={14} />
              <span className="ml-2">Add Cryptocurrency</span>
            </Button>
          </div>
        ) : (
          watchlist.map((item) => (
            <div key={item.symbol} className="border rounded-lg p-3 hover:bg-muted/30">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <span className="font-medium text-foreground">{item.symbol}</span>
                  {isNearAlert(item.price, item.alert) && (
                    <div className="w-2 h-2 bg-warning rounded-full animate-pulse" title="Near alert price" />
                  )}
                </div>
                <div className="flex items-center space-x-1">
                  <Button 
                    variant="ghost" 
                    size="xs"
                    onClick={() => handleSetAlert(item.symbol)}
                  >
                    <Icon name="Bell" size={12} />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="xs"
                    onClick={() => handleRemoveFromWatchlist(item.symbol)}
                  >
                    <Icon name="X" size={12} />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <div className="text-muted-foreground text-xs">Current Price</div>
                  <div className="font-medium text-foreground">{formatPrice(item.price)}</div>
                  <div className={`text-xs font-medium flex items-center ${
                    item.change >= 0 ? 'text-success' : 'text-error'
                  }`}>
                    <Icon 
                      name={item.change >= 0 ? 'ArrowUp' : 'ArrowDown'} 
                      size={10} 
                      className="mr-1" 
                    />
                    {Math.abs(item.change).toFixed(2)}%
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground text-xs">Price Alert</div>
                  <div className="font-medium text-foreground">{formatPrice(item.alert)}</div>
                  <div className="text-xs text-muted-foreground">
                    Target: {formatPrice(item.target)}
                  </div>
                </div>
              </div>

              {/* Progress bar to target */}
              <div className="mt-2">
                <div className="flex justify-between text-xs text-muted-foreground mb-1">
                  <span>Progress to Target</span>
                  <span>
                    {Math.min(100, Math.max(0, ((item.price - item.alert) / (item.target - item.alert)) * 100)).toFixed(0)}%
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-1.5">
                  <div 
                    className="bg-primary h-1.5 rounded-full transition-all duration-300"
                    style={{
                      width: `${Math.min(100, Math.max(0, ((item.price - item.alert) / (item.target - item.alert)) * 100))}%`
                    }}
                  />
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Quick Actions */}
      <div className="p-4 border-t bg-muted/50">
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" size="sm" className="w-full">
            <Icon name="TrendingUp" size={14} />
            <span className="ml-2">Add Alert</span>
          </Button>
          <Button variant="outline" size="sm" className="w-full">
            <Icon name="BarChart3" size={14} />
            <span className="ml-2">View Charts</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default MarketWatchlist;