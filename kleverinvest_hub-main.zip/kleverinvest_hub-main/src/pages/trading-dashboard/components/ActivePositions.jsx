import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ActivePositions = () => {
  // Mock active positions data
  const positions = [
    {
      id: 1,
      symbol: 'BTC/USD',
      side: 'long',
      size: 0.5,
      entryPrice: 44250.00,
      currentPrice: 45780.25,
      pnl: 765.13,
      pnlPercent: 3.46,
      margin: 2212.50,
      leverage: 5,
      timestamp: new Date(Date.now() - 3600000)
    },
    {
      id: 2,
      symbol: 'ETH/USD',
      side: 'short',
      size: 2.0,
      entryPrice: 2890.00,
      currentPrice: 2845.67,
      pnl: 88.66,
      pnlPercent: 1.53,
      margin: 1156.00,
      leverage: 2,
      timestamp: new Date(Date.now() - 7200000)
    },
    {
      id: 3,
      symbol: 'BNB/USD',
      side: 'long',
      size: 15.0,
      entryPrice: 305.50,
      currentPrice: 315.89,
      pnl: 155.85,
      pnlPercent: 3.40,
      margin: 918.00,
      leverage: 5,
      timestamp: new Date(Date.now() - 14400000)
    }
  ];

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(price);
  };

  const formatCrypto = (amount, symbol) => {
    return `${amount.toFixed(4)} ${symbol.split('/')[0]}`;
  };

  const formatChange = (change, isPercent = false) => {
    const sign = change >= 0 ? '+' : '';
    return isPercent 
      ? `${sign}${change.toFixed(2)}%` 
      : `${sign}${formatPrice(change)}`;
  };

  const formatTime = (timestamp) => {
    return timestamp.toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleClosePosition = (positionId) => {
    alert(`Closing position ${positionId}`);
  };

  const handleModifyPosition = (positionId) => {
    alert(`Modifying position ${positionId}`);
  };

  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 sm:p-6 border-b">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Active Positions</h3>
            <p className="text-sm text-muted-foreground">Your current open trades</p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Icon name="RefreshCw" size={16} />
            </Button>
            <Button variant="outline" size="sm">
              <Icon name="Settings" size={16} />
              <span className="hidden sm:inline ml-2">Manage</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="p-4 sm:p-6">
        {positions.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="TrendingUp" size={48} className="mx-auto text-muted-foreground mb-4" />
            <h4 className="text-lg font-medium text-foreground mb-2">No Active Positions</h4>
            <p className="text-muted-foreground mb-4">Start trading to see your positions here</p>
            <Button>
              <Icon name="Plus" size={16} />
              <span className="ml-2">New Trade</span>
            </Button>
          </div>
        ) : (
          <>
            {/* Desktop Table View */}
            <div className="hidden lg:block">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Symbol</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Side</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Size</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Entry Price</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Current Price</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">P&L</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {positions.map((position) => (
                      <tr key={position.id} className="border-b hover:bg-muted/50">
                        <td className="py-4">
                          <div className="flex items-center space-x-2">
                            <div className="font-medium text-foreground">{position.symbol}</div>
                            <span className="text-xs bg-muted px-2 py-1 rounded">
                              {position.leverage}x
                            </span>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {formatTime(position.timestamp)}
                          </div>
                        </td>
                        <td className="py-4">
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            position.side === 'long' ?'bg-success/20 text-success' :'bg-error/20 text-error'
                          }`}>
                            {position.side.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-4 text-right font-mono">
                          {formatCrypto(position.size, position.symbol)}
                        </td>
                        <td className="py-4 text-right font-mono">
                          {formatPrice(position.entryPrice)}
                        </td>
                        <td className="py-4 text-right font-mono">
                          {formatPrice(position.currentPrice)}
                        </td>
                        <td className="py-4 text-right">
                          <div className={`font-medium ${
                            position.pnl >= 0 ? 'text-success' : 'text-error'
                          }`}>
                            {formatChange(position.pnl)}
                          </div>
                          <div className={`text-xs ${
                            position.pnl >= 0 ? 'text-success' : 'text-error'
                          }`}>
                            {formatChange(position.pnlPercent, true)}
                          </div>
                        </td>
                        <td className="py-4 text-right">
                          <div className="flex items-center justify-end space-x-1">
                            <Button 
                              variant="ghost" 
                              size="xs"
                              onClick={() => handleModifyPosition(position.id)}
                            >
                              <Icon name="Edit2" size={14} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="xs"
                              onClick={() => handleClosePosition(position.id)}
                            >
                              <Icon name="X" size={14} />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Mobile Card View */}
            <div className="lg:hidden space-y-4">
              {positions.map((position) => (
                <div key={position.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-foreground">{position.symbol}</span>
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                        position.side === 'long' ?'bg-success/20 text-success' :'bg-error/20 text-error'
                      }`}>
                        {position.side.toUpperCase()}
                      </span>
                      <span className="text-xs bg-muted px-2 py-1 rounded">
                        {position.leverage}x
                      </span>
                    </div>
                    <div className={`text-right font-medium ${
                      position.pnl >= 0 ? 'text-success' : 'text-error'
                    }`}>
                      {formatChange(position.pnl)}
                      <div className="text-xs">
                        {formatChange(position.pnlPercent, true)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                    <div>
                      <div className="text-muted-foreground">Size</div>
                      <div className="font-medium text-foreground">
                        {formatCrypto(position.size, position.symbol)}
                      </div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Entry Price</div>
                      <div className="font-medium text-foreground">
                        {formatPrice(position.entryPrice)}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-xs text-muted-foreground">
                      Opened: {formatTime(position.timestamp)}
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="xs"
                        onClick={() => handleModifyPosition(position.id)}
                      >
                        <Icon name="Edit2" size={12} />
                        <span className="ml-1">Edit</span>
                      </Button>
                      <Button 
                        variant="outline" 
                        size="xs"
                        onClick={() => handleClosePosition(position.id)}
                      >
                        <Icon name="X" size={12} />
                        <span className="ml-1">Close</span>
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ActivePositions;