import React from 'react';
import { LineChart, Line, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis } from 'recharts';
import Icon from '../../../components/AppIcon';

const PerformanceMetrics = ({ selectedTimeframe }) => {
  // Mock performance data based on timeframe
  const getPerformanceData = (timeframe) => {
    const baseData = {
      '1H': [
        { time: '14:00', pnl: 120, trades: 2 },
        { time: '15:00', pnl: 245, trades: 3 },
        { time: '16:00', pnl: 180, trades: 1 },
        { time: '17:00', pnl: 320, trades: 4 },
        { time: '18:00', pnl: 280, trades: 2 }
      ],
      '1D': [
        { time: 'Mon', pnl: 450, trades: 8 },
        { time: 'Tue', pnl: 680, trades: 12 },
        { time: 'Wed', pnl: 520, trades: 6 },
        { time: 'Thu', pnl: 890, trades: 15 },
        { time: 'Fri', pnl: 1200, trades: 18 },
        { time: 'Sat', pnl: 760, trades: 9 },
        { time: 'Sun', pnl: 980, trades: 14 }
      ],
      '1W': [
        { time: 'W1', pnl: 2400, trades: 45 },
        { time: 'W2', pnl: 3200, trades: 67 },
        { time: 'W3', pnl: 1800, trades: 34 },
        { time: 'W4', pnl: 4100, trades: 78 }
      ],
      '1M': [
        { time: 'Jan', pnl: 5600, trades: 156 },
        { time: 'Feb', pnl: 7200, trades: 203 },
        { time: 'Mar', pnl: 4800, trades: 134 },
        { time: 'Apr', pnl: 8900, trades: 245 }
      ]
    };
    return baseData[timeframe] || baseData['1D'];
  };

  const performanceData = getPerformanceData(selectedTimeframe);

  // Calculate metrics
  const totalPnL = performanceData.reduce((sum, item) => sum + item.pnl, 0);
  const totalTrades = performanceData.reduce((sum, item) => sum + item.trades, 0);
  const avgPnLPerTrade = totalTrades > 0 ? totalPnL / totalTrades : 0;
  const winRate = 78.5; // Mock win rate
  const maxDrawdown = -245.67; // Mock max drawdown

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-popover border rounded-lg shadow-lg p-3">
          <p className="text-sm font-medium text-foreground mb-1">{label}</p>
          <p className="text-sm text-muted-foreground">
            P&L: <span className="font-semibold text-success">
              {formatCurrency(data.pnl)}
            </span>
          </p>
          <p className="text-sm text-muted-foreground">
            Trades: <span className="font-semibold text-foreground">
              {data.trades}
            </span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-card border rounded-lg">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Performance Metrics</h3>
            <p className="text-sm text-muted-foreground">Trading performance analysis</p>
          </div>
          <Icon name="TrendingUp" size={20} className="text-primary" />
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="text-xs text-muted-foreground mb-1">Total P&L</div>
            <div className="text-lg font-bold text-success">
              {formatCurrency(totalPnL)}
            </div>
            <div className="text-xs text-muted-foreground">
              {totalTrades} trades
            </div>
          </div>
          
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="text-xs text-muted-foreground mb-1">Avg P&L/Trade</div>
            <div className="text-lg font-bold text-foreground">
              {formatCurrency(avgPnLPerTrade)}
            </div>
            <div className="text-xs text-muted-foreground">
              Per trade
            </div>
          </div>

          <div className="bg-muted/30 rounded-lg p-3">
            <div className="text-xs text-muted-foreground mb-1">Win Rate</div>
            <div className="text-lg font-bold text-success">
              {winRate.toFixed(1)}%
            </div>
            <div className="text-xs text-muted-foreground">
              Success rate
            </div>
          </div>

          <div className="bg-muted/30 rounded-lg p-3">
            <div className="text-xs text-muted-foreground mb-1">Max Drawdown</div>
            <div className="text-lg font-bold text-error">
              {formatCurrency(maxDrawdown)}
            </div>
            <div className="text-xs text-muted-foreground">
              Worst loss
            </div>
          </div>
        </div>

        {/* P&L Chart */}
        <div>
          <div className="flex items-center space-x-2 mb-3">
            <Icon name="LineChart" size={16} className="text-primary" />
            <h4 className="font-medium text-foreground">P&L Trend</h4>
          </div>
          <div className="h-32 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="pnl"
                  stroke="hsl(var(--color-success))"
                  strokeWidth={2}
                  dot={{ r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Trading Activity Chart */}
        <div>
          <div className="flex items-center space-x-2 mb-3">
            <Icon name="BarChart3" size={16} className="text-accent" />
            <h4 className="font-medium text-foreground">Trading Activity</h4>
          </div>
          <div className="h-32 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={performanceData}>
                <XAxis 
                  dataKey="time" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'hsl(var(--color-muted-foreground))' }}
                />
                <YAxis hide />
                <Tooltip content={<CustomTooltip />} />
                <Bar
                  dataKey="trades"
                  fill="hsl(var(--color-accent))"
                  radius={[2, 2, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Performance Summary */}
        <div className="bg-muted/30 rounded-lg p-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Performance Rating</span>
            <div className="flex items-center space-x-2">
              <div className="flex space-x-1">
                {[1, 2, 3, 4].map((star) => (
                  <Icon 
                    key={star} 
                    name="Star" 
                    size={12} 
                    className="text-warning fill-current" 
                  />
                ))}
                <Icon name="Star" size={12} className="text-muted-foreground" />
              </div>
              <span className="font-medium text-foreground">4.2/5</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceMetrics;