import React from 'react';
import { MiniChart } from 'react-tradingview-embed';

const TradingViewWidget = ({ timeframe = '1D' }) => {
  const widgetOptions = {
    symbol: "BINANCE:BTCUSDT",
    width: "100%",
    height: "100%",
    interval: timeframe,
    timezone: "Etc/UTC",
    theme: "dark",
    style: "1",
    locale: "en",
    toolbar_bg: "#f1f3f6",
    enable_publishing: false,
    hide_top_toolbar: false,
    hide_legend: false,
    save_image: false,
    container_id: "mini-chart-widget",
    autosize: true
  };

  return (
    <div className="w-full h-full relative bg-card">
      <div className="absolute inset-0">
        <MiniChart widgetProps={widgetOptions} />
      </div>
    </div>
  );
};

export default TradingViewWidget;