import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminGatewayEdit = () => {
  const navigate = useNavigate();
  const { gatewayId } = useParams();
  const { isAdminAuthenticated } = useAdminAuth();
  const [gateway, setGateway] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadGateway();
  }, [isAdminAuthenticated, navigate, gatewayId]);

  const loadGateway = () => {
    setLoading(true);
    // Load gateway from localStorage or use mock data
    const savedGateways = JSON.parse(localStorage.getItem('admin_gateways_data') || '[]');
    const foundGateway = savedGateways.find(g => g.id === parseInt(gatewayId));
    
    if (foundGateway) {
      setGateway(foundGateway);
    } else {
      // Fallback to mock data if not found
      const mockGateway = {
        id: parseInt(gatewayId),
        name: 'PayPal',
        type: 'payment_processor',
        status: 'active',
        currency: ['USD', 'EUR', 'GBP'],
        minAmount: 10,
        maxAmount: 10000,
        processingFee: 2.9,
        feeType: 'percentage',
        apiKey: 'pp_live_***************',
        secretKey: '***************',
        webhookUrl: 'https://api.kleverinvest.com/webhooks/paypal',
        environment: 'production'
      };
      setGateway(mockGateway);
    }
    setLoading(false);
  };

  const handleSave = () => {
    setSaving(true);
    
    // Save gateway changes
    const savedGateways = JSON.parse(localStorage.getItem('admin_gateways_data') || '[]');
    const updatedGateways = savedGateways.map(g => 
      g.id === gateway.id ? gateway : g
    );
    
    localStorage.setItem('admin_gateways_data', JSON.stringify(updatedGateways));
    
    setTimeout(() => {
      setSaving(false);
      alert('Gateway settings saved successfully!');
      navigate('/admin-gateways');
    }, 1000);
  };

  const testConnection = () => {
    if (!gateway.apiKey || gateway.apiKey.includes('***')) {
      alert('Please enter valid API credentials before testing');
      return;
    }
    
    alert('Testing connection...');
    setTimeout(() => {
      alert('✅ Connection test successful!');
    }, 2000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <AdminNavigation title="Loading..." />
        <div className="p-6 flex items-center justify-center">
          <Icon name="Loader" size={24} className="animate-spin mr-2" />
          Loading gateway settings...
        </div>
      </div>
    );
  }

  if (!gateway) {
    return (
      <div className="min-h-screen bg-background">
        <AdminNavigation title="Gateway Not Found" />
        <div className="p-6 text-center">
          <p className="text-muted-foreground mb-4">Gateway not found</p>
          <Button onClick={() => navigate('/admin-gateways')}>
            Back to Gateways
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title={`Edit ${gateway.name}`}
        breadcrumb={[
          { label: "Gateway Management", link: "/admin-gateways" },
          { label: "Edit Gateway" }
        ]}
        actions={[
          {
            label: "Test Connection",
            icon: "Zap",
            variant: "outline",
            onClick: testConnection
          },
          {
            label: "Cancel",
            icon: "X",
            variant: "outline",
            onClick: () => navigate('/admin-gateways')
          },
          {
            label: saving ? "Saving..." : "Save Changes",
            icon: saving ? "Loader" : "Save",
            variant: "default",
            onClick: handleSave,
            disabled: saving
          }
        ]}
      />

      <div className="p-6">
        <div className="max-w-2xl mx-auto">
          <div className="bg-card border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">Gateway Configuration</h3>
            
            <div className="space-y-6">
              {/* Basic Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Gateway Name</label>
                  <input
                    type="text"
                    value={gateway.name}
                    onChange={(e) => setGateway({...gateway, name: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Type</label>
                  <select
                    value={gateway.type}
                    onChange={(e) => setGateway({...gateway, type: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="payment_processor">Payment Processor</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="cryptocurrency">Cryptocurrency</option>
                  </select>
                </div>
              </div>

              {/* Limits */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Minimum Amount</label>
                  <input
                    type="number"
                    value={gateway.minAmount}
                    onChange={(e) => setGateway({...gateway, minAmount: parseFloat(e.target.value)})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Maximum Amount</label>
                  <input
                    type="number"
                    value={gateway.maxAmount}
                    onChange={(e) => setGateway({...gateway, maxAmount: parseFloat(e.target.value)})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>

              {/* Processing Fee */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Processing Fee</label>
                  <input
                    type="number"
                    step="0.01"
                    value={gateway.processingFee}
                    onChange={(e) => setGateway({...gateway, processingFee: parseFloat(e.target.value)})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Fee Type</label>
                  <select
                    value={gateway.feeType}
                    onChange={(e) => setGateway({...gateway, feeType: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="percentage">Percentage</option>
                    <option value="fixed">Fixed Amount</option>
                  </select>
                </div>
              </div>

              {/* API Configuration */}
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">API Key</label>
                <input
                  type="password"
                  value={gateway.apiKey}
                  onChange={(e) => setGateway({...gateway, apiKey: e.target.value})}
                  placeholder="Enter API key"
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Secret Key</label>
                <input
                  type="password"
                  value={gateway.secretKey || ''}
                  onChange={(e) => setGateway({...gateway, secretKey: e.target.value})}
                  placeholder="Enter secret key"
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Webhook URL</label>
                <input
                  type="url"
                  value={gateway.webhookUrl}
                  onChange={(e) => setGateway({...gateway, webhookUrl: e.target.value})}
                  placeholder="https://api.kleverinvest.com/webhooks/gateway"
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              {/* Environment */}
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Environment</label>
                <select
                  value={gateway.environment}
                  onChange={(e) => setGateway({...gateway, environment: e.target.value})}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="sandbox">Sandbox (Test)</option>
                  <option value="production">Production (Live)</option>
                </select>
              </div>

              {/* Status */}
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-foreground">Gateway Status</label>
                  <p className="text-xs text-muted-foreground">Enable or disable this gateway</p>
                </div>
                <button
                  onClick={() => setGateway({...gateway, status: gateway.status === 'active' ? 'inactive' : 'active'})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    gateway.status === 'active' ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      gateway.status === 'active' ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminGatewayEdit;
