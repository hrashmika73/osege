import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

const PasswordRecovery = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState('email'); // 'email', 'code', 'reset'
  const [formData, setFormData] = useState({
    email: '',
    verificationCode: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateEmail = () => {
    const newErrors = {};
    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateCode = () => {
    const newErrors = {};
    if (!formData.verificationCode) {
      newErrors.verificationCode = 'Verification code is required';
    } else if (formData.verificationCode.length !== 6) {
      newErrors.verificationCode = 'Verification code must be 6 digits';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateNewPassword = () => {
    const newErrors = {};
    if (!formData.newPassword) {
      newErrors.newPassword = 'New password is required';
    } else if (formData.newPassword.length < 8) {
      newErrors.newPassword = 'Password must be at least 8 characters';
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData.newPassword !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSendCode = async (e) => {
    e.preventDefault();
    
    if (!validateEmail()) {
      return;
    }

    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      setStep('code');
    } catch (error) {
      setErrors({ general: 'Failed to send verification code. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyCode = async (e) => {
    e.preventDefault();
    
    if (!validateCode()) {
      return;
    }

    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      setStep('reset');
    } catch (error) {
      setErrors({ general: 'Invalid verification code. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    
    if (!validateNewPassword()) {
      return;
    }

    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      alert('Password reset successfully! You can now log in with your new password.');
      navigate('/login');
    } catch (error) {
      setErrors({ general: 'Failed to reset password. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const renderEmailStep = () => (
    <form onSubmit={handleSendCode} className="space-y-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-orange-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Mail" size={24} className="text-orange-400" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Reset Your Password</h2>
        <p className="text-slate-300">
          Enter your email address and we'll send you a verification code to reset your password.
        </p>
      </div>

      <div>
        <label htmlFor="email" className="block text-sm font-medium mb-2 text-white">
          Email Address
        </label>
        <Input
          id="email"
          name="email"
          type="email"
          value={formData.email}
          onChange={handleInputChange}
          placeholder="Enter your email address"
          className={`bg-white/10 border-white/20 text-white placeholder-slate-400 ${errors.email ? 'border-red-400' : ''}`}
          disabled={isLoading}
        />
        {errors.email && (
          <p className="text-red-400 text-sm mt-1">{errors.email}</p>
        )}
      </div>

      {errors.general && (
        <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
          <div className="flex items-center space-x-2">
            <Icon name="AlertTriangle" size={16} className="text-red-400" />
            <p className="text-red-400 text-sm">{errors.general}</p>
          </div>
        </div>
      )}

      <Button
        type="submit"
        className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold"
        size="lg"
        disabled={isLoading}
        loading={isLoading}
      >
        Send Verification Code
        <Icon name="ArrowRight" size={16} className="ml-2" />
      </Button>
    </form>
  );

  const renderCodeStep = () => (
    <form onSubmit={handleVerifyCode} className="space-y-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Shield" size={24} className="text-blue-400" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Verify Your Email</h2>
        <p className="text-slate-300">
          We've sent a 6-digit verification code to <span className="text-orange-400">{formData.email}</span>
        </p>
      </div>

      <div>
        <label htmlFor="verificationCode" className="block text-sm font-medium mb-2 text-white">
          Verification Code
        </label>
        <Input
          id="verificationCode"
          name="verificationCode"
          type="text"
          value={formData.verificationCode}
          onChange={handleInputChange}
          placeholder="Enter 6-digit code"
          maxLength="6"
          className={`bg-white/10 border-white/20 text-white placeholder-slate-400 text-center text-lg tracking-widest ${errors.verificationCode ? 'border-red-400' : ''}`}
          disabled={isLoading}
        />
        {errors.verificationCode && (
          <p className="text-red-400 text-sm mt-1">{errors.verificationCode}</p>
        )}
      </div>

      {errors.general && (
        <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
          <div className="flex items-center space-x-2">
            <Icon name="AlertTriangle" size={16} className="text-red-400" />
            <p className="text-red-400 text-sm">{errors.general}</p>
          </div>
        </div>
      )}

      <div className="space-y-3">
        <Button
          type="submit"
          className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold"
          size="lg"
          disabled={isLoading}
          loading={isLoading}
        >
          Verify Code
          <Icon name="ArrowRight" size={16} className="ml-2" />
        </Button>

        <Button
          type="button"
          variant="outline"
          className="w-full border-white/20 text-white hover:bg-white/10"
          onClick={() => setStep('email')}
          disabled={isLoading}
        >
          <Icon name="ArrowLeft" size={16} className="mr-2" />
          Back to Email
        </Button>
      </div>

      <div className="text-center">
        <p className="text-slate-400 text-sm">
          Didn't receive the code?{' '}
          <button
            type="button"
            onClick={handleSendCode}
            className="text-orange-400 hover:text-orange-300 font-medium"
            disabled={isLoading}
          >
            Resend code
          </button>
        </p>
      </div>
    </form>
  );

  const renderResetStep = () => (
    <form onSubmit={handleResetPassword} className="space-y-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Lock" size={24} className="text-green-400" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Create New Password</h2>
        <p className="text-slate-300">
          Your identity has been verified. Please create a new secure password.
        </p>
      </div>

      <div>
        <label htmlFor="newPassword" className="block text-sm font-medium mb-2 text-white">
          New Password
        </label>
        <div className="relative">
          <Input
            id="newPassword"
            name="newPassword"
            type={showPassword ? 'text' : 'password'}
            value={formData.newPassword}
            onChange={handleInputChange}
            placeholder="Create a strong password"
            className={`bg-white/10 border-white/20 text-white placeholder-slate-400 pr-12 ${errors.newPassword ? 'border-red-400' : ''}`}
            disabled={isLoading}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
          >
            <Icon name={showPassword ? 'EyeOff' : 'Eye'} size={16} />
          </button>
        </div>
        {errors.newPassword && (
          <p className="text-red-400 text-sm mt-1">{errors.newPassword}</p>
        )}
      </div>

      <div>
        <label htmlFor="confirmPassword" className="block text-sm font-medium mb-2 text-white">
          Confirm New Password
        </label>
        <div className="relative">
          <Input
            id="confirmPassword"
            name="confirmPassword"
            type={showConfirmPassword ? 'text' : 'password'}
            value={formData.confirmPassword}
            onChange={handleInputChange}
            placeholder="Confirm your new password"
            className={`bg-white/10 border-white/20 text-white placeholder-slate-400 pr-12 ${errors.confirmPassword ? 'border-red-400' : ''}`}
            disabled={isLoading}
          />
          <button
            type="button"
            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
          >
            <Icon name={showConfirmPassword ? 'EyeOff' : 'Eye'} size={16} />
          </button>
        </div>
        {errors.confirmPassword && (
          <p className="text-red-400 text-sm mt-1">{errors.confirmPassword}</p>
        )}
      </div>

      {errors.general && (
        <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
          <div className="flex items-center space-x-2">
            <Icon name="AlertTriangle" size={16} className="text-red-400" />
            <p className="text-red-400 text-sm">{errors.general}</p>
          </div>
        </div>
      )}

      <Button
        type="submit"
        className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold"
        size="lg"
        disabled={isLoading}
        loading={isLoading}
      >
        Reset Password
        <Icon name="CheckCircle" size={16} className="ml-2" />
      </Button>
    </form>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
              <Icon name="TrendingUp" size={24} color="white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">KleverInvest Hub</h1>
              <p className="text-sm text-orange-400 font-medium">Professional Trading Platform</p>
            </div>
          </div>
        </div>

        {/* Recovery Form */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 shadow-2xl">
          {step === 'email' && renderEmailStep()}
          {step === 'code' && renderCodeStep()}
          {step === 'reset' && renderResetStep()}

          {/* Back to Login */}
          <div className="mt-6 text-center">
            <p className="text-slate-400 text-sm">
              Remember your password?{' '}
              <Link to="/login" className="text-orange-400 hover:text-orange-300 font-medium">
                Back to login
              </Link>
            </p>
          </div>
        </div>

        {/* Security Features */}
        <div className="mt-8 text-center">
          <div className="flex items-center justify-center space-x-6 text-xs text-slate-400">
            <div className="flex items-center space-x-1">
              <Icon name="Shield" size={14} className="text-green-400" />
              <span>SSL Encrypted</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Lock" size={14} className="text-blue-400" />
              <span>Secure Recovery</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="CheckCircle" size={14} className="text-orange-400" />
              <span>GDPR Compliant</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PasswordRecovery;
