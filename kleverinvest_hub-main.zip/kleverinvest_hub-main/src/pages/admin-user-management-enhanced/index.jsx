import React, { useState } from 'react';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import AdminNavigation from '../../components/ui/AdminNavigation';

const AdminUserManagementEnhanced = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedUsers, setSelectedUsers] = useState([]);

  const users = [
    {
      id: 1,
      name: 'John Doe',
      email: 'john.doe@example.com',
      role: 'user',
      status: 'active',
      verified: true,
      balance: 15430.50,
      investments: 3,
      joinDate: '2023-06-15',
      lastLogin: '2024-01-15 09:30',
      country: 'United States',
      riskProfile: 'moderate'
    },
    {
      id: 2,
      name: 'Sarah Wilson',
      email: 'sarah.wilson@example.com',
      role: 'user',
      status: 'suspended',
      verified: false,
      balance: 8750.00,
      investments: 1,
      joinDate: '2023-08-22',
      lastLogin: '2024-01-10 14:45',
      country: 'Canada',
      riskProfile: 'conservative'
    },
    {
      id: 3,
      name: 'Mike Johnson',
      email: 'mike.johnson@example.com',
      role: 'premium',
      status: 'active',
      verified: true,
      balance: 45200.75,
      investments: 8,
      joinDate: '2023-03-10',
      lastLogin: '2024-01-15 11:20',
      country: 'United Kingdom',
      riskProfile: 'aggressive'
    }
  ];

  const stats = [
    { label: 'Total Users', value: '12,847', change: '+8.2%', color: 'blue' },
    { label: 'Active Users', value: '9,234', change: '+5.1%', color: 'green' },
    { label: 'Verified Users', value: '7,892', change: '+12.3%', color: 'purple' },
    { label: 'Suspended Users', value: '156', change: '-2.4%', color: 'red' }
  ];

  const handleUserSelect = (userId) => {
    setSelectedUsers(prev =>
      prev.includes(userId)
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const handleBulkAction = (action) => {
    alert(`${action} applied to ${selectedUsers.length} users`);
    setSelectedUsers([]);
  };

  const handleAddUser = () => {
    alert('Add user functionality coming soon...');
  };

  const handleExportUsers = () => {
    alert('Exporting user data...');
  };

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-card rounded-lg p-6 border">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center`}>
                <Icon name="Users" size={24} className="text-primary" />
              </div>
              <span className={`text-${stat.change.startsWith('+') ? 'success' : 'destructive'} text-sm font-medium`}>
                {stat.change}
              </span>
            </div>
            <h3 className="text-2xl font-bold text-foreground">{stat.value}</h3>
            <p className="text-muted-foreground text-sm">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="bg-card rounded-lg border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">User Activity Chart</h3>
        <div className="h-64 bg-muted rounded-lg flex items-center justify-center">
          <div className="text-center text-muted-foreground">
            <Icon name="BarChart3" size={48} className="mx-auto mb-2" />
            <p>User activity analytics chart would be displayed here</p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderUserList = () => (
    <div className="bg-card rounded-lg border">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">User Management</h3>
          <div className="flex items-center space-x-2">
            {selectedUsers.length > 0 && (
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">{selectedUsers.length} selected</span>
                <Button size="sm" variant="outline" onClick={() => handleBulkAction('Verify')}>
                  Verify
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleBulkAction('Suspend')}>
                  Suspend
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleBulkAction('Delete')}>
                  Delete
                </Button>
              </div>
            )}
            <Button size="sm" onClick={handleAddUser}>
              <Icon name="Plus" size={16} />
              <span className="ml-2">Add User</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted border-b border-border">
            <tr>
              <th className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedUsers(users.map(user => user.id));
                    } else {
                      setSelectedUsers([]);
                    }
                  }}
                  className="text-primary focus:ring-primary"
                />
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">User</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Balance</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Investments</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Last Login</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {users.map(user => (
              <tr key={user.id} className="hover:bg-muted/50">
                <td className="px-6 py-4">
                  <input
                    type="checkbox"
                    checked={selectedUsers.includes(user.id)}
                    onChange={() => handleUserSelect(user.id)}
                    className="text-primary focus:ring-primary"
                  />
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-medium">
                        {user.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-foreground">{user.name}</div>
                      <div className="text-sm text-muted-foreground">{user.email}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      user.status === 'active' ? 'bg-success/10 text-success' :
                      user.status === 'suspended' ? 'bg-destructive/10 text-destructive' :
                      'bg-warning/10 text-warning'
                    }`}>
                      {user.status}
                    </span>
                    {user.verified && (
                      <Icon name="CheckCircle" size={16} className="text-success" />
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-foreground">
                  ${user.balance.toLocaleString()}
                </td>
                <td className="px-6 py-4 text-sm text-foreground">
                  {user.investments}
                </td>
                <td className="px-6 py-4 text-sm text-muted-foreground">
                  {user.lastLogin}
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-2">
                    <Button size="sm" variant="outline">
                      <Icon name="Eye" size={16} />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Icon name="Edit" size={16} />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Icon name="MoreHorizontal" size={16} />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'BarChart3' },
    { id: 'users', label: 'User List', icon: 'Users' },
    { id: 'verification', label: 'Verification', icon: 'CheckCircle' },
    { id: 'analytics', label: 'Analytics', icon: 'TrendingUp' }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Navigation */}
      <AdminNavigation
        title="Enhanced User Management"
        breadcrumb={[
          { label: "Admin", link: null },
          { label: "Enhanced User Management", link: null }
        ]}
        actions={[
          {
            label: "Export Users",
            icon: "Download",
            variant: "outline",
            onClick: handleExportUsers
          },
          {
            label: "Add User",
            icon: "Plus",
            variant: "default",
            onClick: handleAddUser
          }
        ]}
      />

      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <p className="text-muted-foreground">Advanced user administration and analytics</p>
          </div>

          {/* Tab Navigation */}
          <div className="mb-8">
            <div className="border-b border-border">
              <nav className="-mb-px flex space-x-8">
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                      activeTab === tab.id
                        ? 'border-primary text-primary'
                        : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                    }`}
                  >
                    <Icon name={tab.icon} size={16} />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Tab Content */}
          {activeTab === 'overview' && renderOverview()}
          {activeTab === 'users' && renderUserList()}
          {activeTab === 'verification' && (
            <div className="bg-card rounded-lg border p-6">
              <div className="text-center py-8">
                <Icon name="CheckCircle" size={48} className="text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">User Verification</h3>
                <p className="text-muted-foreground">Verification management tools coming soon</p>
              </div>
            </div>
          )}
          {activeTab === 'analytics' && (
            <div className="bg-card rounded-lg border p-6">
              <div className="text-center py-8">
                <Icon name="TrendingUp" size={48} className="text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">User Analytics</h3>
                <p className="text-muted-foreground">Advanced analytics dashboard coming soon</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminUserManagementEnhanced;
