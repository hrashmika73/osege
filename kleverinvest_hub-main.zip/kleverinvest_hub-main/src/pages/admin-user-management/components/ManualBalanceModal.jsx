import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const ManualBalanceModal = ({ user, isOpen, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    type: '',
    amount: '',
    reason: '',
    notes: ''
  });

  const [errors, setErrors] = useState({});

  if (!isOpen || !user) return null;

  const transactionTypes = [
    { value: '', label: 'Select transaction type...' },
    { value: 'credit', label: 'Credit (Add Balance)' },
    { value: 'debit', label: 'Debit (Subtract Balance)' }
  ];

  const reasonOptions = [
    { value: '', label: 'Select reason...' },
    { value: 'admin-adjustment', label: 'Admin Adjustment' },
    { value: 'bonus', label: 'Bonus Credit' },
    { value: 'refund', label: 'Refund' },
    { value: 'penalty', label: 'Penalty' },
    { value: 'correction', label: 'Balance Correction' },
    { value: 'promotion', label: 'Promotional Credit' },
    { value: 'other', label: 'Other' }
  ];

  const validateForm = () => {
    const newErrors = {};

    if (!formData.type) {
      newErrors.type = 'Transaction type is required';
    }

    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      newErrors.amount = 'Valid amount is required';
    }

    if (!formData.reason) {
      newErrors.reason = 'Reason is required';
    }

    if (formData.type === 'debit' && parseFloat(formData.amount) > user.balance) {
      newErrors.amount = 'Debit amount cannot exceed current balance';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      const transactionData = {
        userId: user.id,
        type: formData.type,
        amount: parseFloat(formData.amount),
        reason: formData.reason,
        notes: formData.notes,
        timestamp: new Date().toISOString(),
        adminId: 'admin-001' // Mock admin ID
      };

      onSubmit(transactionData);
      handleClose();
    }
  };

  const handleClose = () => {
    setFormData({
      type: '',
      amount: '',
      reason: '',
      notes: ''
    });
    setErrors({});
    onClose();
  };

  const formatBalance = (balance) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(balance);
  };

  const calculateNewBalance = () => {
    if (!formData.amount || !formData.type) return user.balance;
    
    const amount = parseFloat(formData.amount);
    if (formData.type === 'credit') {
      return user.balance + amount;
    } else {
      return user.balance - amount;
    }
  };

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm" onClick={handleClose} />
      
      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-card border rounded-lg shadow-elevation-3 w-full max-w-md">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b">
            <div>
              <h2 className="text-lg font-semibold text-foreground">Manual Balance Adjustment</h2>
              <p className="text-sm text-muted-foreground">User: {user.username}</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              iconName="X"
            />
          </div>

          {/* Content */}
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {/* Current Balance Display */}
            <div className="bg-muted/30 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">Current Balance:</span>
                <span className="text-lg font-bold text-foreground">{formatBalance(user.balance)}</span>
              </div>
              
              {formData.amount && formData.type && (
                <div className="flex items-center justify-between mt-2 pt-2 border-t">
                  <span className="text-sm font-medium text-foreground">New Balance:</span>
                  <span className={`text-lg font-bold ${
                    calculateNewBalance() > user.balance ? 'text-success' : 
                    calculateNewBalance() < user.balance ? 'text-warning' : 'text-foreground'
                  }`}>
                    {formatBalance(calculateNewBalance())}
                  </span>
                </div>
              )}
            </div>

            {/* Transaction Type */}
            <Select
              label="Transaction Type"
              options={transactionTypes}
              value={formData.type}
              onChange={(value) => setFormData({ ...formData, type: value })}
              error={errors.type}
              required
            />

            {/* Amount */}
            <Input
              type="number"
              label="Amount ($)"
              placeholder="0.00"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              error={errors.amount}
              required
              min="0.01"
              step="0.01"
            />

            {/* Reason */}
            <Select
              label="Reason"
              options={reasonOptions}
              value={formData.reason}
              onChange={(value) => setFormData({ ...formData, reason: value })}
              error={errors.reason}
              required
            />

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Additional Notes
              </label>
              <textarea
                className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
                rows={3}
                placeholder="Optional notes about this transaction..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>

            {/* Warning for Debit */}
            {formData.type === 'debit' && (
              <div className="bg-warning/10 border border-warning/20 rounded-md p-3">
                <div className="flex items-center space-x-2">
                  <Icon name="AlertTriangle" size={16} className="text-warning" />
                  <span className="text-sm text-warning font-medium">
                    This will subtract money from the user's account
                  </span>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-end space-x-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                variant={formData.type === 'debit' ? 'destructive' : 'default'}
                iconName={formData.type === 'credit' ? 'Plus' : 'Minus'}
                iconPosition="left"
              >
                {formData.type === 'credit' ? 'Add Balance' : 'Subtract Balance'}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default ManualBalanceModal;