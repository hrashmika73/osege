import React, { useState } from 'react';

import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const UserFilters = ({ onFiltersChange, onReset }) => {
  const [filters, setFilters] = useState({
    search: '',
    verificationStatus: '',
    accountStatus: '',
    registrationDateFrom: '',
    registrationDateTo: '',
    balanceMin: '',
    balanceMax: ''
  });

  const verificationOptions = [
    { value: '', label: 'All Verification Status' },
    { value: 'verified', label: 'Verified' },
    { value: 'pending', label: 'Pending' },
    { value: 'rejected', label: 'Rejected' },
    { value: 'unverified', label: 'Unverified' }
  ];

  const statusOptions = [
    { value: '', label: 'All Account Status' },
    { value: 'active', label: 'Active' },
    { value: 'suspended', label: 'Suspended' },
    { value: 'inactive', label: 'Inactive' }
  ];

  const handleFilterChange = (field, value) => {
    const newFilters = { ...filters, [field]: value };
    setFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const handleReset = () => {
    const resetFilters = {
      search: '',
      verificationStatus: '',
      accountStatus: '',
      registrationDateFrom: '',
      registrationDateTo: '',
      balanceMin: '',
      balanceMax: ''
    };
    setFilters(resetFilters);
    onReset();
  };

  return (
    <div className="bg-card border rounded-lg p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">Filter Users</h3>
        <Button
          variant="outline"
          size="sm"
          onClick={handleReset}
          iconName="RotateCcw"
          iconPosition="left"
        >
          Reset Filters
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {/* Search Input */}
        <div className="lg:col-span-2">
          <Input
            type="search"
            label="Search Users"
            placeholder="Search by email or username..."
            value={filters.search}
            onChange={(e) => handleFilterChange('search', e.target.value)}
          />
        </div>

        {/* Verification Status */}
        <Select
          label="Verification Status"
          options={verificationOptions}
          value={filters.verificationStatus}
          onChange={(value) => handleFilterChange('verificationStatus', value)}
        />

        {/* Account Status */}
        <Select
          label="Account Status"
          options={statusOptions}
          value={filters.accountStatus}
          onChange={(value) => handleFilterChange('accountStatus', value)}
        />

        {/* Registration Date From */}
        <Input
          type="date"
          label="Registration From"
          value={filters.registrationDateFrom}
          onChange={(e) => handleFilterChange('registrationDateFrom', e.target.value)}
        />

        {/* Registration Date To */}
        <Input
          type="date"
          label="Registration To"
          value={filters.registrationDateTo}
          onChange={(e) => handleFilterChange('registrationDateTo', e.target.value)}
        />

        {/* Balance Min */}
        <Input
          type="number"
          label="Min Balance ($)"
          placeholder="0.00"
          value={filters.balanceMin}
          onChange={(e) => handleFilterChange('balanceMin', e.target.value)}
        />

        {/* Balance Max */}
        <Input
          type="number"
          label="Max Balance ($)"
          placeholder="10000.00"
          value={filters.balanceMax}
          onChange={(e) => handleFilterChange('balanceMax', e.target.value)}
        />
      </div>
    </div>
  );
};

export default UserFilters;