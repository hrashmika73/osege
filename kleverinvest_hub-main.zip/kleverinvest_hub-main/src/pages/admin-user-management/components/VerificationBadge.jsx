import React from 'react';
import Icon from '../../../components/AppIcon';

const VerificationBadge = ({ status }) => {
  const getVerificationConfig = (status) => {
    switch (status) {
      case 'verified':
        return {
          label: 'Verified',
          className: 'bg-success/10 text-success border-success/20',
          icon: 'ShieldCheck'
        };
      case 'pending':
        return {
          label: 'Pending',
          className: 'bg-warning/10 text-warning border-warning/20',
          icon: 'Clock'
        };
      case 'rejected':
        return {
          label: 'Rejected',
          className: 'bg-destructive/10 text-destructive border-destructive/20',
          icon: 'ShieldX'
        };
      case 'unverified':
        return {
          label: 'Unverified',
          className: 'bg-muted text-muted-foreground border-border',
          icon: 'Shield'
        };
      default:
        return {
          label: 'Unknown',
          className: 'bg-muted text-muted-foreground border-border',
          icon: 'HelpCircle'
        };
    }
  };

  const config = getVerificationConfig(status);

  return (
    <div className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium border ${config.className}`}>
      <Icon name={config.icon} size={12} />
      <span>{config.label}</span>
    </div>
  );
};

export default VerificationBadge;