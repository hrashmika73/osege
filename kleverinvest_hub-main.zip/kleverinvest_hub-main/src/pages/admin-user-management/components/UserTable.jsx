import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import UserStatusBadge from './UserStatusBadge';
import VerificationBadge from './VerificationBadge';

const UserTable = ({ users, selectedUsers, onUserSelect, onSelectAll, onUserAction, onSort, sortConfig }) => {
  const [hoveredRow, setHoveredRow] = useState(null);

  const handleSort = (field) => {
    onSort(field);
  };

  const getSortIcon = (field) => {
    if (sortConfig.field !== field) return 'ArrowUpDown';
    return sortConfig.direction === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatBalance = (balance) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(balance);
  };

  const formatLastActivity = (dateString) => {
    const now = new Date();
    const activityDate = new Date(dateString);
    const diffInHours = Math.floor((now - activityDate) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`;
    return formatDate(dateString);
  };

  return (
    <div className="bg-card border rounded-lg overflow-hidden">
      {/* Desktop Table */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50 border-b">
            <tr>
              <th className="p-4 text-left">
                <Checkbox
                  checked={selectedUsers.length === users.length && users.length > 0}
                  onChange={(e) => onSelectAll(e.target.checked)}
                />
              </th>
              {[
                { field: 'username', label: 'User' },
                { field: 'email', label: 'Email' },
                { field: 'registrationDate', label: 'Registered' },
                { field: 'verificationStatus', label: 'Verification' },
                { field: 'balance', label: 'Balance' },
                { field: 'lastActivity', label: 'Last Activity' },
                { field: 'status', label: 'Status' }
              ].map((column) => (
                <th key={column.field} className="p-4 text-left">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSort(column.field)}
                    className="font-semibold text-muted-foreground hover:text-foreground"
                    iconName={getSortIcon(column.field)}
                    iconPosition="right"
                  >
                    {column.label}
                  </Button>
                </th>
              ))}
              <th className="p-4 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr
                key={user.id}
                className={`border-b hover:bg-muted/30 transition-colors ${
                  selectedUsers.includes(user.id) ? 'bg-primary/5' : ''
                }`}
                onMouseEnter={() => setHoveredRow(user.id)}
                onMouseLeave={() => setHoveredRow(null)}
              >
                <td className="p-4">
                  <Checkbox
                    checked={selectedUsers.includes(user.id)}
                    onChange={(e) => onUserSelect(user.id, e.target.checked)}
                  />
                </td>
                <td className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <Icon name="User" size={20} className="text-primary" />
                    </div>
                    <div>
                      <div className="font-medium text-foreground">{user.username}</div>
                      <div className="text-sm text-muted-foreground">ID: {user.id}</div>
                    </div>
                  </div>
                </td>
                <td className="p-4">
                  <div className="text-foreground">{user.email}</div>
                </td>
                <td className="p-4">
                  <div className="text-muted-foreground">{formatDate(user.registrationDate)}</div>
                </td>
                <td className="p-4">
                  <VerificationBadge status={user.verificationStatus} />
                </td>
                <td className="p-4">
                  <div className="font-medium text-foreground">{formatBalance(user.balance)}</div>
                </td>
                <td className="p-4">
                  <div className="text-muted-foreground">{formatLastActivity(user.lastActivity)}</div>
                </td>
                <td className="p-4">
                  <UserStatusBadge status={user.status} />
                </td>
                <td className="p-4">
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onUserAction('view', user)}
                      iconName="Eye"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onUserAction('edit', user)}
                      iconName="Edit"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onUserAction('suspend', user)}
                      iconName={user.status === 'suspended' ? 'UserCheck' : 'UserX'}
                    />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="lg:hidden space-y-4 p-4">
        {users.map((user) => (
          <div key={user.id} className="bg-muted/30 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <Checkbox
                checked={selectedUsers.includes(user.id)}
                onChange={(e) => onUserSelect(user.id, e.target.checked)}
              />
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onUserAction('view', user)}
                  iconName="Eye"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onUserAction('edit', user)}
                  iconName="Edit"
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <Icon name="User" size={24} className="text-primary" />
              </div>
              <div className="flex-1">
                <div className="font-medium text-foreground">{user.username}</div>
                <div className="text-sm text-muted-foreground">{user.email}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="text-muted-foreground">Balance</div>
                <div className="font-medium text-foreground">{formatBalance(user.balance)}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Status</div>
                <UserStatusBadge status={user.status} />
              </div>
              <div>
                <div className="text-muted-foreground">Verification</div>
                <VerificationBadge status={user.verificationStatus} />
              </div>
              <div>
                <div className="text-muted-foreground">Last Activity</div>
                <div className="text-foreground">{formatLastActivity(user.lastActivity)}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UserTable;