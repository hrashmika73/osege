import React from 'react';
import Icon from '../../../components/AppIcon';

const UserStatusBadge = ({ status }) => {
  const getStatusConfig = (status) => {
    switch (status) {
      case 'active':
        return {
          label: 'Active',
          className: 'bg-success/10 text-success border-success/20',
          icon: 'CheckCircle'
        };
      case 'suspended':
        return {
          label: 'Suspended',
          className: 'bg-destructive/10 text-destructive border-destructive/20',
          icon: 'XCircle'
        };
      case 'inactive':
        return {
          label: 'Inactive',
          className: 'bg-muted text-muted-foreground border-border',
          icon: 'Clock'
        };
      default:
        return {
          label: 'Unknown',
          className: 'bg-muted text-muted-foreground border-border',
          icon: 'HelpCircle'
        };
    }
  };

  const config = getStatusConfig(status);

  return (
    <div className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium border ${config.className}`}>
      <Icon name={config.icon} size={12} />
      <span>{config.label}</span>
    </div>
  );
};

export default UserStatusBadge;