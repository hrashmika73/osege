import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

import VerificationBadge from './VerificationBadge';

const UserDetailModal = ({ user, isOpen, onClose, onSave }) => {
  const [activeTab, setActiveTab] = useState('profile');
  const [editMode, setEditMode] = useState(false);
  const [editedUser, setEditedUser] = useState(user || {});

  if (!isOpen || !user) return null;

  const tabs = [
    { id: 'profile', label: 'Profile', icon: 'User' },
    { id: 'wallet', label: 'Wallet', icon: 'Wallet' },
    { id: 'transactions', label: 'Transactions', icon: 'CreditCard' },
    { id: 'referrals', label: 'Referrals', icon: 'UserPlus' },
    { id: 'kyc', label: 'KYC Documents', icon: 'FileText' }
  ];

  const statusOptions = [
    { value: 'active', label: 'Active' },
    { value: 'suspended', label: 'Suspended' },
    { value: 'inactive', label: 'Inactive' }
  ];

  const verificationOptions = [
    { value: 'verified', label: 'Verified' },
    { value: 'pending', label: 'Pending' },
    { value: 'rejected', label: 'Rejected' },
    { value: 'unverified', label: 'Unverified' }
  ];

  const handleSave = () => {
    onSave(editedUser);
    setEditMode(false);
  };

  const handleCancel = () => {
    setEditedUser(user);
    setEditMode(false);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatBalance = (balance) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(balance);
  };

  const mockTransactions = [
    { id: 1, type: 'deposit', amount: 1000, date: '2025-01-25', status: 'completed' },
    { id: 2, type: 'withdrawal', amount: 250, date: '2025-01-20', status: 'pending' },
    { id: 3, type: 'investment', amount: 500, date: '2025-01-15', status: 'completed' }
  ];

  const mockReferrals = [
    { id: 1, username: 'john_doe', email: 'john@example.com', commission: 50, date: '2025-01-20' },
    { id: 2, username: 'jane_smith', email: 'jane@example.com', commission: 75, date: '2025-01-18' }
  ];

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm" onClick={onClose} />
      
      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-card border rounded-lg shadow-elevation-3 w-full max-w-4xl max-h-[90vh] overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <Icon name="User" size={24} className="text-primary" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-foreground">{user.username}</h2>
                <p className="text-muted-foreground">{user.email}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              {!editMode ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditMode(true)}
                  iconName="Edit"
                  iconPosition="left"
                >
                  Edit
                </Button>
              ) : (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="default"
                    size="sm"
                    onClick={handleSave}
                    iconName="Save"
                    iconPosition="left"
                  >
                    Save
                  </Button>
                </>
              )}
              
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                iconName="X"
              />
            </div>
          </div>

          {/* Tabs */}
          <div className="border-b">
            <div className="flex overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon name={tab.icon} size={16} />
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Content */}
          <div className="p-6 overflow-y-auto max-h-[60vh]">
            {activeTab === 'profile' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input
                    label="Username"
                    value={editMode ? editedUser.username : user.username}
                    onChange={(e) => setEditedUser({ ...editedUser, username: e.target.value })}
                    disabled={!editMode}
                  />
                  
                  <Input
                    label="Email"
                    type="email"
                    value={editMode ? editedUser.email : user.email}
                    onChange={(e) => setEditedUser({ ...editedUser, email: e.target.value })}
                    disabled={!editMode}
                  />
                  
                  <Select
                    label="Account Status"
                    options={statusOptions}
                    value={editMode ? editedUser.status : user.status}
                    onChange={(value) => setEditedUser({ ...editedUser, status: value })}
                    disabled={!editMode}
                  />
                  
                  <Select
                    label="Verification Status"
                    options={verificationOptions}
                    value={editMode ? editedUser.verificationStatus : user.verificationStatus}
                    onChange={(value) => setEditedUser({ ...editedUser, verificationStatus: value })}
                    disabled={!editMode}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm font-medium text-foreground">Registration Date</label>
                    <p className="text-muted-foreground mt-1">{formatDate(user.registrationDate)}</p>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-foreground">Last Activity</label>
                    <p className="text-muted-foreground mt-1">{formatDate(user.lastActivity)}</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'wallet' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-muted/30 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon name="DollarSign" size={20} className="text-success" />
                      <span className="font-medium text-foreground">Total Balance</span>
                    </div>
                    <p className="text-2xl font-bold text-foreground">{formatBalance(user.balance)}</p>
                  </div>
                  
                  <div className="bg-muted/30 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon name="TrendingUp" size={20} className="text-primary" />
                      <span className="font-medium text-foreground">Invested</span>
                    </div>
                    <p className="text-2xl font-bold text-foreground">{formatBalance(user.balance * 0.7)}</p>
                  </div>
                  
                  <div className="bg-muted/30 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon name="Wallet" size={20} className="text-accent" />
                      <span className="font-medium text-foreground">Available</span>
                    </div>
                    <p className="text-2xl font-bold text-foreground">{formatBalance(user.balance * 0.3)}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-foreground">Cryptocurrency Wallets</h4>
                  <div className="space-y-3">
                    {['Bitcoin (BTC)', 'Ethereum (ETH)', 'Tether (USDT)'].map((crypto, index) => (
                      <div key={crypto} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                        <span className="font-medium text-foreground">{crypto}</span>
                        <span className="text-muted-foreground">{(Math.random() * 10).toFixed(4)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'transactions' && (
              <div className="space-y-4">
                <h4 className="font-semibold text-foreground">Recent Transactions</h4>
                <div className="space-y-3">
                  {mockTransactions.map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          transaction.type === 'deposit' ? 'bg-success/10' :
                          transaction.type === 'withdrawal' ? 'bg-warning/10' : 'bg-primary/10'
                        }`}>
                          <Icon 
                            name={
                              transaction.type === 'deposit' ? 'ArrowDownLeft' :
                              transaction.type === 'withdrawal' ? 'ArrowUpRight' : 'TrendingUp'
                            } 
                            size={20} 
                            className={
                              transaction.type === 'deposit' ? 'text-success' :
                              transaction.type === 'withdrawal' ? 'text-warning' : 'text-primary'
                            }
                          />
                        </div>
                        <div>
                          <div className="font-medium text-foreground capitalize">{transaction.type}</div>
                          <div className="text-sm text-muted-foreground">{formatDate(transaction.date)}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-foreground">{formatBalance(transaction.amount)}</div>
                        <div className={`text-sm capitalize ${
                          transaction.status === 'completed' ? 'text-success' :
                          transaction.status === 'pending' ? 'text-warning' : 'text-destructive'
                        }`}>
                          {transaction.status}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'referrals' && (
              <div className="space-y-4">
                <h4 className="font-semibold text-foreground">Referred Users</h4>
                <div className="space-y-3">
                  {mockReferrals.map((referral) => (
                    <div key={referral.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <Icon name="User" size={20} className="text-primary" />
                        </div>
                        <div>
                          <div className="font-medium text-foreground">{referral.username}</div>
                          <div className="text-sm text-muted-foreground">{referral.email}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-success">{formatBalance(referral.commission)}</div>
                        <div className="text-sm text-muted-foreground">{formatDate(referral.date)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'kyc' && (
              <div className="space-y-4">
                <h4 className="font-semibold text-foreground">KYC Documents</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {['Identity Document', 'Proof of Address', 'Selfie Verification'].map((doc, index) => (
                    <div key={doc} className="p-4 bg-muted/30 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-foreground">{doc}</span>
                        <VerificationBadge status={index === 0 ? 'verified' : index === 1 ? 'pending' : 'rejected'} />
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Uploaded: {formatDate(user.registrationDate)}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-2"
                        iconName="Eye"
                        iconPosition="left"
                      >
                        View Document
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default UserDetailModal;