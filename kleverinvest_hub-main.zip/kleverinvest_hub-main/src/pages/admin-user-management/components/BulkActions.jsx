import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const BulkActions = ({ selectedUsers, onBulkAction, totalUsers }) => {
  const [selectedAction, setSelectedAction] = useState('');

  const bulkActionOptions = [
    { value: '', label: 'Select bulk action...' },
    { value: 'verify', label: 'Verify Email' },
    { value: 'suspend', label: 'Suspend Accounts' },
    { value: 'activate', label: 'Activate Accounts' },
    { value: 'export', label: 'Export Data' },
    { value: 'send-notification', label: 'Send Notification' }
  ];

  const handleExecuteAction = () => {
    if (selectedAction && selectedUsers.length > 0) {
      onBulkAction(selectedAction, selectedUsers);
      setSelectedAction('');
    }
  };

  return (
    <div className="bg-card border rounded-lg p-4 mb-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="text-sm text-muted-foreground">
            <span className="font-medium text-foreground">{selectedUsers.length}</span> of{' '}
            <span className="font-medium text-foreground">{totalUsers}</span> users selected
          </div>
          
          {selectedUsers.length > 0 && (
            <div className="flex items-center space-x-2">
              <Select
                options={bulkActionOptions}
                value={selectedAction}
                onChange={setSelectedAction}
                placeholder="Select action..."
                className="w-48"
              />
              
              <Button
                variant="default"
                size="sm"
                onClick={handleExecuteAction}
                disabled={!selectedAction}
                iconName="Play"
                iconPosition="left"
              >
                Execute
              </Button>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onBulkAction('export-all', [])}
            iconName="Download"
            iconPosition="left"
          >
            Export All
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => onBulkAction('refresh', [])}
            iconName="RefreshCw"
            iconPosition="left"
          >
            Refresh
          </Button>
        </div>
      </div>

      {selectedUsers.length > 0 && (
        <div className="mt-4 p-3 bg-primary/5 border border-primary/20 rounded-md">
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="Info" size={16} className="text-primary" />
            <span className="text-primary">
              {selectedUsers.length} user{selectedUsers.length > 1 ? 's' : ''} selected for bulk action
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default BulkActions;