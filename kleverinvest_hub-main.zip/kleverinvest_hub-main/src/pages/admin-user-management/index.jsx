import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import AdminNavigation from '../../components/ui/AdminNavigation';
import UserFilters from './components/UserFilters';
import UserTable from './components/UserTable';
import BulkActions from './components/BulkActions';
import UserDetailModal from './components/UserDetailModal';
import ManualBalanceModal from './components/ManualBalanceModal';
import BackendConnectionTest from '../../components/BackendConnectionTest';

const AdminUserManagement = () => {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [sortConfig, setSortConfig] = useState({ field: 'registrationDate', direction: 'desc' });
  const [selectedUser, setSelectedUser] = useState(null);
  const [isUserDetailModalOpen, setIsUserDetailModalOpen] = useState(false);
  const [isBalanceModalOpen, setIsBalanceModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [usersPerPage] = useState(10);
  const [showBackendTest, setShowBackendTest] = useState(false);

  // Load real user data and set up real-time updates
  useEffect(() => {
    const loadUsers = async () => {
      try {
        const userDataManager = await import('../../utils/userDataManager');
        const { getAllUsers, initializeAdminListeners } = userDataManager;
        const realUsers = getAllUsers();
        setUsers(realUsers);
        setFilteredUsers(realUsers);

        // Set up real-time listeners for new registrations
        const cleanup = initializeAdminListeners({
          onUserRegistered: (data) => {
            console.log('New user registered:', data.user);
            setUsers(prevUsers => {
              const updatedUsers = [...prevUsers, data.user];
              setFilteredUsers(updatedUsers);
              return updatedUsers;
            });

            // Show notification
            alert(`🎉 New user registered: ${data.user.fullName} (${data.user.email})`);
          },
          onUserUpdated: (data) => {
            console.log('User updated:', data.user);
            setUsers(prevUsers => {
              const updatedUsers = prevUsers.map(user =>
                user.id === data.user.id ? data.user : user
              );
              setFilteredUsers(updatedUsers);
              return updatedUsers;
            });
          }
        });

        return cleanup;
      } catch (error) {
        console.error('Error loading users:', error);
        // Set empty users on error
        setUsers([]);
        setFilteredUsers([]);
        return null;
      }
    };

    let cleanup;
    loadUsers().then(cleanupFn => {
      cleanup = cleanupFn;
    }).catch(error => {
      console.error('Failed to initialize user management:', error);
    });

    return () => {
      if (cleanup) cleanup();
    };
  }, []);

  // Filter users based on search criteria
  const handleFiltersChange = (filters) => {
    let filtered = [...users];

    if (filters.search) {
      filtered = filtered.filter(user =>
        user.username.toLowerCase().includes(filters.search.toLowerCase()) ||
        user.email.toLowerCase().includes(filters.search.toLowerCase())
      );
    }

    if (filters.verificationStatus) {
      filtered = filtered.filter(user => user.verificationStatus === filters.verificationStatus);
    }

    if (filters.accountStatus) {
      filtered = filtered.filter(user => user.status === filters.accountStatus);
    }

    if (filters.registrationDateFrom) {
      filtered = filtered.filter(user => 
        new Date(user.registrationDate) >= new Date(filters.registrationDateFrom)
      );
    }

    if (filters.registrationDateTo) {
      filtered = filtered.filter(user => 
        new Date(user.registrationDate) <= new Date(filters.registrationDateTo)
      );
    }

    if (filters.balanceMin) {
      filtered = filtered.filter(user => user.balance >= parseFloat(filters.balanceMin));
    }

    if (filters.balanceMax) {
      filtered = filtered.filter(user => user.balance <= parseFloat(filters.balanceMax));
    }

    setFilteredUsers(filtered);
    setCurrentPage(1);
  };

  // Reset filters
  const handleResetFilters = () => {
    setFilteredUsers(users);
    setCurrentPage(1);
  };

  // Sort users
  const handleSort = (field) => {
    const direction = sortConfig.field === field && sortConfig.direction === 'asc' ? 'desc' : 'asc';
    setSortConfig({ field, direction });

    const sorted = [...filteredUsers].sort((a, b) => {
      let aValue = a[field];
      let bValue = b[field];

      if (field === 'registrationDate' || field === 'lastActivity') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }

      if (field === 'balance') {
        aValue = parseFloat(aValue);
        bValue = parseFloat(bValue);
      }

      if (aValue < bValue) return direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return direction === 'asc' ? 1 : -1;
      return 0;
    });

    setFilteredUsers(sorted);
  };

  // Handle user selection
  const handleUserSelect = (userId, isSelected) => {
    if (isSelected) {
      setSelectedUsers([...selectedUsers, userId]);
    } else {
      setSelectedUsers(selectedUsers.filter(id => id !== userId));
    }
  };

  // Handle select all users
  const handleSelectAll = (isSelected) => {
    if (isSelected) {
      const currentPageUsers = getCurrentPageUsers().map(user => user.id);
      setSelectedUsers([...new Set([...selectedUsers, ...currentPageUsers])]);
    } else {
      const currentPageUsers = getCurrentPageUsers().map(user => user.id);
      setSelectedUsers(selectedUsers.filter(id => !currentPageUsers.includes(id)));
    }
  };

  // Handle bulk actions
  const handleBulkAction = (action, userIds) => {
    console.log(`Executing bulk action: ${action} for users:`, userIds);
    
    switch (action) {
      case 'verify':
        // Mock verification
        setUsers(users.map(user => 
          userIds.includes(user.id) 
            ? { ...user, verificationStatus: 'verified' }
            : user
        ));
        break;
      case 'suspend':
        setUsers(users.map(user => 
          userIds.includes(user.id) 
            ? { ...user, status: 'suspended' }
            : user
        ));
        break;
      case 'activate':
        setUsers(users.map(user => 
          userIds.includes(user.id) 
            ? { ...user, status: 'active' }
            : user
        ));
        break;
      case 'export':
        console.log('Exporting user data...');
        break;
      case 'export-all':
        console.log('Exporting all user data...');
        break;
      case 'refresh':
        window.location.reload();
        break;
      default:
        console.log('Unknown action:', action);
    }
    
    setSelectedUsers([]);
  };

  // Handle individual user actions
  const handleUserAction = (action, user) => {
    switch (action) {
      case 'view':
        setSelectedUser(user);
        setIsUserDetailModalOpen(true);
        break;
      case 'edit':
        setSelectedUser(user);
        setIsUserDetailModalOpen(true);
        break;
      case 'suspend':
        const newStatus = user.status === 'suspended' ? 'active' : 'suspended';
        setUsers(users.map(u => 
          u.id === user.id ? { ...u, status: newStatus } : u
        ));
        break;
      case 'balance':
        setSelectedUser(user);
        setIsBalanceModalOpen(true);
        break;
      default:
        console.log('Unknown action:', action);
    }
  };

  // Handle user detail save
  const handleUserDetailSave = (updatedUser) => {
    setUsers(users.map(user => 
      user.id === updatedUser.id ? updatedUser : user
    ));
    setFilteredUsers(filteredUsers.map(user => 
      user.id === updatedUser.id ? updatedUser : user
    ));
  };

  // Handle manual balance adjustment
  const handleBalanceAdjustment = (transactionData) => {
    const { userId, type, amount } = transactionData;
    
    setUsers(users.map(user => {
      if (user.id === userId) {
        const newBalance = type === 'credit' 
          ? user.balance + amount 
          : user.balance - amount;
        return { ...user, balance: Math.max(0, newBalance) };
      }
      return user;
    }));

    setFilteredUsers(filteredUsers.map(user => {
      if (user.id === userId) {
        const newBalance = type === 'credit' 
          ? user.balance + amount 
          : user.balance - amount;
        return { ...user, balance: Math.max(0, newBalance) };
      }
      return user;
    }));

    console.log('Balance adjustment logged:', transactionData);
  };

  // Pagination
  const getCurrentPageUsers = () => {
    const indexOfLastUser = currentPage * usersPerPage;
    const indexOfFirstUser = indexOfLastUser - usersPerPage;
    return filteredUsers.slice(indexOfFirstUser, indexOfLastUser);
  };

  const totalPages = Math.ceil(filteredUsers.length / usersPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    setSelectedUsers([]);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Navigation */}
      <AdminNavigation
        title="User Management"
        breadcrumb={[
          { label: "Users", link: null },
          { label: "All Users", link: null }
        ]}
        actions={[
          {
            label: "Test Backend",
            icon: "Server",
            variant: "outline",
            onClick: () => setShowBackendTest(true)
          },
          {
            label: "Add User",
            icon: "UserPlus",
            variant: "outline",
            onClick: () => {
              alert('Add user functionality coming soon...');
            }
          },
          {
            label: "Export All",
            icon: "Download",
            variant: "default",
            onClick: () => handleBulkAction('export-all', [])
          }
        ]}
      />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <p className="text-muted-foreground">
            Manage user accounts, verification status, and balances
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Icon name="Users" size={24} className="text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{users.length}</p>
                <p className="text-sm text-muted-foreground">Total Users</p>
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                <Icon name="UserCheck" size={24} className="text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {users.filter(u => u.status === 'active').length}
                </p>
                <p className="text-sm text-muted-foreground">Active Users</p>
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                <Icon name="ShieldCheck" size={24} className="text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {users.filter(u => u.verificationStatus === 'verified').length}
                </p>
                <p className="text-sm text-muted-foreground">Verified Users</p>
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                <Icon name="DollarSign" size={24} className="text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  ${users.reduce((sum, user) => sum + user.balance, 0).toLocaleString()}
                </p>
                <p className="text-sm text-muted-foreground">Total Balance</p>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <UserFilters 
          onFiltersChange={handleFiltersChange}
          onReset={handleResetFilters}
        />

        {/* Bulk Actions */}
        <BulkActions
          selectedUsers={selectedUsers}
          totalUsers={filteredUsers.length}
          onBulkAction={handleBulkAction}
        />

        {/* User Table */}
        <UserTable
          users={getCurrentPageUsers()}
          selectedUsers={selectedUsers}
          onUserSelect={handleUserSelect}
          onSelectAll={handleSelectAll}
          onUserAction={handleUserAction}
          onSort={handleSort}
          sortConfig={sortConfig}
        />

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-6">
            <div className="text-sm text-muted-foreground">
              Showing {((currentPage - 1) * usersPerPage) + 1} to{' '}
              {Math.min(currentPage * usersPerPage, filteredUsers.length)} of{' '}
              {filteredUsers.length} users
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                iconName="ChevronLeft"
              />
              
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={currentPage === page ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePageChange(page)}
                  className="w-10"
                >
                  {page}
                </Button>
              ))}
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                iconName="ChevronRight"
              />
            </div>
          </div>
        )}

        {/* Modals */}
        <UserDetailModal
          user={selectedUser}
          isOpen={isUserDetailModalOpen}
          onClose={() => {
            setIsUserDetailModalOpen(false);
            setSelectedUser(null);
          }}
          onSave={handleUserDetailSave}
        />

        <ManualBalanceModal
          user={selectedUser}
          isOpen={isBalanceModalOpen}
          onClose={() => {
            setIsBalanceModalOpen(false);
            setSelectedUser(null);
          }}
          onSubmit={handleBalanceAdjustment}
        />

        {/* Backend Connection Test Modal */}
        {showBackendTest && (
          <BackendConnectionTest onClose={() => setShowBackendTest(false)} />
        )}
      </div>
    </div>
  );
};

export default AdminUserManagement;
