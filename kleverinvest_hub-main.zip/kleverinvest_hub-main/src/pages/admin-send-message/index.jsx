import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminSendMessage = () => {
  const navigate = useNavigate();
  const { userId } = useParams();
  const { isAdminAuthenticated } = useAdminAuth();
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState({
    subject: '',
    content: '',
    priority: 'normal',
    type: 'general'
  });
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadUser();
  }, [isAdminAuthenticated, navigate, userId]);

  const loadUser = () => {
    // Load user data from localStorage
    const userData = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
    const foundUser = userData.find(u => u.id === parseInt(userId));
    
    if (foundUser) {
      setUser(foundUser);
    } else {
      // Mock user data
      setUser({
        id: parseInt(userId),
        fullName: 'Example User',
        email: 'user@example.com',
        username: 'user_example'
      });
    }
  };

  const handleSendMessage = () => {
    if (!message.subject.trim() || !message.content.trim()) {
      alert('Please fill in both subject and message content');
      return;
    }

    setSending(true);
    
    // Simulate sending message
    setTimeout(() => {
      // Save message to localStorage (simulate sent messages)
      const sentMessages = JSON.parse(localStorage.getItem('admin_sent_messages') || '[]');
      const newMessage = {
        id: Date.now(),
        userId: parseInt(userId),
        recipient: user,
        subject: message.subject,
        content: message.content,
        priority: message.priority,
        type: message.type,
        sentDate: new Date().toISOString(),
        sentBy: 'admin_001',
        status: 'sent'
      };
      
      sentMessages.push(newMessage);
      localStorage.setItem('admin_sent_messages', JSON.stringify(sentMessages));
      
      setSending(false);
      alert(`✅ Message sent successfully to ${user.fullName}!`);
      
      // Reset form
      setMessage({
        subject: '',
        content: '',
        priority: 'normal',
        type: 'general'
      });
      
      // Navigate back
      navigate(`/admin-user-details/${userId}`);
    }, 1500);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <AdminNavigation title="Loading..." />
        <div className="p-6 flex items-center justify-center">
          <Icon name="Loader" size={24} className="animate-spin mr-2" />
          Loading user information...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title={`Send Message to ${user.fullName}`}
        breadcrumb={[
          { label: "User Management", link: "/admin-active-users" },
          { label: "User Details", link: `/admin-user-details/${userId}` },
          { label: "Send Message" }
        ]}
        actions={[
          {
            label: "Cancel",
            icon: "X",
            variant: "outline",
            onClick: () => navigate(`/admin-user-details/${userId}`)
          },
          {
            label: sending ? "Sending..." : "Send Message",
            icon: sending ? "Loader" : "Send",
            variant: "default",
            onClick: handleSendMessage,
            disabled: sending
          }
        ]}
      />

      <div className="p-6">
        <div className="max-w-2xl mx-auto">
          {/* Recipient Info */}
          <div className="bg-card border rounded-lg p-6 mb-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Recipient</h3>
            <div className="flex items-center">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                <span className="text-lg font-medium text-primary">
                  {user.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}
                </span>
              </div>
              <div>
                <div className="text-sm font-medium text-foreground">{user.fullName}</div>
                <div className="text-sm text-muted-foreground">@{user.username}</div>
                <div className="text-xs text-muted-foreground">{user.email}</div>
              </div>
            </div>
          </div>

          {/* Message Form */}
          <div className="bg-card border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">Compose Message</h3>
            
            <div className="space-y-6">
              {/* Message Type and Priority */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Message Type
                  </label>
                  <select
                    value={message.type}
                    onChange={(e) => setMessage({...message, type: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="general">General</option>
                    <option value="account">Account Related</option>
                    <option value="kyc">KYC Verification</option>
                    <option value="transaction">Transaction</option>
                    <option value="support">Support</option>
                    <option value="promotional">Promotional</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Priority
                  </label>
                  <select
                    value={message.priority}
                    onChange={(e) => setMessage({...message, priority: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="low">Low</option>
                    <option value="normal">Normal</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              {/* Subject */}
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">
                  Subject *
                </label>
                <input
                  type="text"
                  value={message.subject}
                  onChange={(e) => setMessage({...message, subject: e.target.value})}
                  placeholder="Enter message subject"
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              {/* Message Content */}
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">
                  Message Content *
                </label>
                <textarea
                  value={message.content}
                  onChange={(e) => setMessage({...message, content: e.target.value})}
                  rows={8}
                  placeholder="Enter your message here..."
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  {message.content.length} characters
                </p>
              </div>

              {/* Quick Templates */}
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">
                  Quick Templates
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setMessage({
                      ...message,
                      subject: 'Account Verification Required',
                      content: 'Dear ' + user.fullName + ',\n\nWe need to verify your account information. Please log in to your account and complete the verification process.\n\nBest regards,\nKleverInvest Support Team'
                    })}
                  >
                    Verification Template
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setMessage({
                      ...message,
                      subject: 'Welcome to KleverInvest',
                      content: 'Dear ' + user.fullName + ',\n\nWelcome to KleverInvest! We are excited to have you as part of our investment community.\n\nIf you have any questions, please don\'t hesitate to contact our support team.\n\nBest regards,\nKleverInvest Team'
                    })}
                  >
                    Welcome Template
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setMessage({
                      ...message,
                      subject: 'Transaction Update',
                      content: 'Dear ' + user.fullName + ',\n\nWe wanted to provide you with an update regarding your recent transaction.\n\nPlease review the details in your account dashboard.\n\nBest regards,\nKleverInvest Support Team'
                    })}
                  >
                    Transaction Template
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setMessage({
                      ...message,
                      subject: 'Support Follow-up',
                      content: 'Dear ' + user.fullName + ',\n\nWe wanted to follow up on your recent support inquiry to ensure everything has been resolved to your satisfaction.\n\nIf you need any further assistance, please let us know.\n\nBest regards,\nKleverInvest Support Team'
                    })}
                  >
                    Support Template
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSendMessage;
