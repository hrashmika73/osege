import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminGoogleTools = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [settings, setSettings] = useState({
    // Google Analytics
    gaEnabled: false,
    gaMeasurementId: '',
    gaViewId: '',
    
    // Google Search Console
    gscEnabled: false,
    gscPropertyUrl: '',
    gscVerificationCode: '',
    
    // Google AdSense
    adsenseEnabled: false,
    adsensePublisherId: '',
    adsenseAutoAds: false,
    
    // Google Tag Manager
    gtmEnabled: false,
    gtmContainerId: '',
    
    // Google Maps
    mapsEnabled: false,
    mapsApiKey: '',
    
    // reCAPTCHA
    recaptchaEnabled: false,
    recaptchaSiteKey: '',
    recaptchaSecretKey: '',
    recaptchaVersion: 'v3'
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadGoogleSettings();
  }, [isAdminAuthenticated, navigate]);

  const loadGoogleSettings = () => {
    setLoading(true);
    // Load saved settings from localStorage
    const savedSettings = localStorage.getItem('admin_google_settings');
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
    setLoading(false);
  };

  const handleSaveSettings = () => {
    setSaving(true);
    // Save settings to localStorage
    localStorage.setItem('admin_google_settings', JSON.stringify(settings));
    
    setTimeout(() => {
      setSaving(false);
      alert('Google Tools settings saved successfully!');
    }, 1000);
  };

  const testIntegration = (tool) => {
    const testMessages = {
      analytics: 'Testing Google Analytics connection...',
      searchConsole: 'Testing Google Search Console connection...',
      adsense: 'Testing Google AdSense integration...',
      tagManager: 'Testing Google Tag Manager...',
      maps: 'Testing Google Maps API...',
      recaptcha: 'Testing reCAPTCHA integration...'
    };
    
    alert(testMessages[tool] || 'Testing integration...');
    setTimeout(() => {
      alert('Integration test completed successfully!');
    }, 1500);
  };

  const generateVerificationCode = () => {
    const code = `google-site-verification=${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
    setSettings({...settings, gscVerificationCode: code});
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Google Tools Integration"
        breadcrumb={[
          { label: "Controls", link: "/admin-controls" },
          { label: "Google Tools" }
        ]}
        actions={[
          {
            label: "Documentation",
            icon: "ExternalLink",
            variant: "outline",
            onClick: () => window.open('https://developers.google.com', '_blank')
          },
          {
            label: saving ? "Saving..." : "Save Settings",
            icon: saving ? "Loader" : "Save",
            variant: "default",
            onClick: handleSaveSettings,
            disabled: saving
          }
        ]}
      />

      <div className="p-6">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Icon name="Loader" size={24} className="animate-spin mr-2" />
            Loading Google Tools settings...
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Google Analytics */}
            <div className="bg-card border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground flex items-center">
                  <Icon name="BarChart" size={20} className="mr-2" />
                  Google Analytics
                </h3>
                <button
                  onClick={() => setSettings({...settings, gaEnabled: !settings.gaEnabled})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.gaEnabled ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.gaEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Measurement ID (GA4)
                  </label>
                  <input
                    type="text"
                    value={settings.gaMeasurementId}
                    onChange={(e) => setSettings({...settings, gaMeasurementId: e.target.value})}
                    placeholder="G-XXXXXXXXXX"
                    disabled={!settings.gaEnabled}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-muted disabled:text-muted-foreground"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    View ID (Universal Analytics)
                  </label>
                  <input
                    type="text"
                    value={settings.gaViewId}
                    onChange={(e) => setSettings({...settings, gaViewId: e.target.value})}
                    placeholder="123456789"
                    disabled={!settings.gaEnabled}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-muted disabled:text-muted-foreground"
                  />
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testIntegration('analytics')}
                  disabled={!settings.gaEnabled || !settings.gaMeasurementId}
                  className="w-full"
                >
                  <Icon name="Zap" size={16} className="mr-2" />
                  Test Integration
                </Button>
              </div>
            </div>

            {/* Google Search Console */}
            <div className="bg-card border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground flex items-center">
                  <Icon name="Search" size={20} className="mr-2" />
                  Google Search Console
                </h3>
                <button
                  onClick={() => setSettings({...settings, gscEnabled: !settings.gscEnabled})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.gscEnabled ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.gscEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Property URL
                  </label>
                  <input
                    type="url"
                    value={settings.gscPropertyUrl}
                    onChange={(e) => setSettings({...settings, gscPropertyUrl: e.target.value})}
                    placeholder="https://www.kleverinvest.com"
                    disabled={!settings.gscEnabled}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-muted disabled:text-muted-foreground"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Verification Code
                  </label>
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={settings.gscVerificationCode}
                      onChange={(e) => setSettings({...settings, gscVerificationCode: e.target.value})}
                      placeholder="google-site-verification=..."
                      disabled={!settings.gscEnabled}
                      className="flex-1 px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-muted disabled:text-muted-foreground"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={generateVerificationCode}
                      disabled={!settings.gscEnabled}
                    >
                      Generate
                    </Button>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testIntegration('searchConsole')}
                  disabled={!settings.gscEnabled || !settings.gscPropertyUrl}
                  className="w-full"
                >
                  <Icon name="Zap" size={16} className="mr-2" />
                  Test Integration
                </Button>
              </div>
            </div>

            {/* Google AdSense */}
            <div className="bg-card border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground flex items-center">
                  <Icon name="DollarSign" size={20} className="mr-2" />
                  Google AdSense
                </h3>
                <button
                  onClick={() => setSettings({...settings, adsenseEnabled: !settings.adsenseEnabled})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.adsenseEnabled ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.adsenseEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Publisher ID
                  </label>
                  <input
                    type="text"
                    value={settings.adsensePublisherId}
                    onChange={(e) => setSettings({...settings, adsensePublisherId: e.target.value})}
                    placeholder="ca-pub-XXXXXXXXXXXXXXXX"
                    disabled={!settings.adsenseEnabled}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-muted disabled:text-muted-foreground"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-foreground">Auto Ads</label>
                    <p className="text-xs text-muted-foreground">Automatically place ads on your site</p>
                  </div>
                  <button
                    onClick={() => setSettings({...settings, adsenseAutoAds: !settings.adsenseAutoAds})}
                    disabled={!settings.adsenseEnabled}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      settings.adsenseAutoAds && settings.adsenseEnabled ? 'bg-primary' : 'bg-gray-200'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings.adsenseAutoAds && settings.adsenseEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testIntegration('adsense')}
                  disabled={!settings.adsenseEnabled || !settings.adsensePublisherId}
                  className="w-full"
                >
                  <Icon name="Zap" size={16} className="mr-2" />
                  Test Integration
                </Button>
              </div>
            </div>

            {/* Google Tag Manager */}
            <div className="bg-card border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground flex items-center">
                  <Icon name="Tag" size={20} className="mr-2" />
                  Google Tag Manager
                </h3>
                <button
                  onClick={() => setSettings({...settings, gtmEnabled: !settings.gtmEnabled})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.gtmEnabled ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.gtmEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Container ID
                  </label>
                  <input
                    type="text"
                    value={settings.gtmContainerId}
                    onChange={(e) => setSettings({...settings, gtmContainerId: e.target.value})}
                    placeholder="GTM-XXXXXXX"
                    disabled={!settings.gtmEnabled}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-muted disabled:text-muted-foreground"
                  />
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testIntegration('tagManager')}
                  disabled={!settings.gtmEnabled || !settings.gtmContainerId}
                  className="w-full"
                >
                  <Icon name="Zap" size={16} className="mr-2" />
                  Test Integration
                </Button>
              </div>
            </div>

            {/* Google Maps */}
            <div className="bg-card border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground flex items-center">
                  <Icon name="MapPin" size={20} className="mr-2" />
                  Google Maps
                </h3>
                <button
                  onClick={() => setSettings({...settings, mapsEnabled: !settings.mapsEnabled})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.mapsEnabled ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.mapsEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    API Key
                  </label>
                  <input
                    type="text"
                    value={settings.mapsApiKey}
                    onChange={(e) => setSettings({...settings, mapsApiKey: e.target.value})}
                    placeholder="AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
                    disabled={!settings.mapsEnabled}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-muted disabled:text-muted-foreground"
                  />
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testIntegration('maps')}
                  disabled={!settings.mapsEnabled || !settings.mapsApiKey}
                  className="w-full"
                >
                  <Icon name="Zap" size={16} className="mr-2" />
                  Test Integration
                </Button>
              </div>
            </div>

            {/* Google reCAPTCHA */}
            <div className="bg-card border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground flex items-center">
                  <Icon name="Shield" size={20} className="mr-2" />
                  Google reCAPTCHA
                </h3>
                <button
                  onClick={() => setSettings({...settings, recaptchaEnabled: !settings.recaptchaEnabled})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.recaptchaEnabled ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.recaptchaEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Version
                  </label>
                  <select
                    value={settings.recaptchaVersion}
                    onChange={(e) => setSettings({...settings, recaptchaVersion: e.target.value})}
                    disabled={!settings.recaptchaEnabled}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-muted disabled:text-muted-foreground"
                  >
                    <option value="v2">reCAPTCHA v2</option>
                    <option value="v3">reCAPTCHA v3</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Site Key
                  </label>
                  <input
                    type="text"
                    value={settings.recaptchaSiteKey}
                    onChange={(e) => setSettings({...settings, recaptchaSiteKey: e.target.value})}
                    placeholder="6LcXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
                    disabled={!settings.recaptchaEnabled}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-muted disabled:text-muted-foreground"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">
                    Secret Key
                  </label>
                  <input
                    type="password"
                    value={settings.recaptchaSecretKey}
                    onChange={(e) => setSettings({...settings, recaptchaSecretKey: e.target.value})}
                    placeholder="6LcXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
                    disabled={!settings.recaptchaEnabled}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-muted disabled:text-muted-foreground"
                  />
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testIntegration('recaptcha')}
                  disabled={!settings.recaptchaEnabled || !settings.recaptchaSiteKey}
                  className="w-full"
                >
                  <Icon name="Zap" size={16} className="mr-2" />
                  Test Integration
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Integration Status */}
        <div className="mt-8 bg-card border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
            <Icon name="Activity" size={20} className="mr-2" />
            Integration Status
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              { name: 'Analytics', enabled: settings.gaEnabled, key: 'gaMeasurementId' },
              { name: 'Search Console', enabled: settings.gscEnabled, key: 'gscPropertyUrl' },
              { name: 'AdSense', enabled: settings.adsenseEnabled, key: 'adsensePublisherId' },
              { name: 'Tag Manager', enabled: settings.gtmEnabled, key: 'gtmContainerId' },
              { name: 'Maps', enabled: settings.mapsEnabled, key: 'mapsApiKey' },
              { name: 'reCAPTCHA', enabled: settings.recaptchaEnabled, key: 'recaptchaSiteKey' }
            ].map((tool, index) => (
              <div key={index} className="text-center p-4 border border-border rounded-lg">
                <div className={`w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center ${
                  tool.enabled && settings[tool.key] ? 'bg-green-100' : 'bg-gray-100'
                }`}>
                  <Icon 
                    name={tool.enabled && settings[tool.key] ? 'CheckCircle' : 'Circle'} 
                    size={16} 
                    className={tool.enabled && settings[tool.key] ? 'text-green-600' : 'text-gray-400'} 
                  />
                </div>
                <div className="text-sm font-medium text-foreground">{tool.name}</div>
                <div className={`text-xs ${
                  tool.enabled && settings[tool.key] ? 'text-green-600' : 'text-gray-400'
                }`}>
                  {tool.enabled && settings[tool.key] ? 'Active' : 'Inactive'}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminGoogleTools;
