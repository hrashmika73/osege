import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminThemeSettings = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [settings, setSettings] = useState({
    primaryColor: '#3b82f6',
    secondaryColor: '#10b981',
    accentColor: '#f59e0b',
    backgroundColor: '#ffffff',
    textColor: '#111827',
    borderRadius: '8',
    fontFamily: 'Inter',
    logoUrl: '',
    faviconUrl: '',
    darkMode: false,
    compactMode: false
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadThemeSettings();
  }, [isAdminAuthenticated, navigate]);

  const loadThemeSettings = () => {
    setLoading(true);
    // Load saved settings from localStorage
    const savedSettings = localStorage.getItem('admin_theme_settings');
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
    setLoading(false);
  };

  const handleSaveSettings = () => {
    setSaving(true);
    // Save settings to localStorage
    localStorage.setItem('admin_theme_settings', JSON.stringify(settings));
    
    // Apply theme to document
    applyTheme(settings);
    
    setTimeout(() => {
      setSaving(false);
      alert('Theme settings saved successfully!');
    }, 1000);
  };

  const applyTheme = (themeSettings) => {
    const root = document.documentElement;
    root.style.setProperty('--primary-color', themeSettings.primaryColor);
    root.style.setProperty('--secondary-color', themeSettings.secondaryColor);
    root.style.setProperty('--accent-color', themeSettings.accentColor);
    root.style.setProperty('--background-color', themeSettings.backgroundColor);
    root.style.setProperty('--text-color', themeSettings.textColor);
    root.style.setProperty('--border-radius', `${themeSettings.borderRadius}px`);
    
    if (themeSettings.darkMode) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  };

  const resetToDefaults = () => {
    if (window.confirm('Are you sure you want to reset all theme settings to defaults?')) {
      const defaultSettings = {
        primaryColor: '#3b82f6',
        secondaryColor: '#10b981',
        accentColor: '#f59e0b',
        backgroundColor: '#ffffff',
        textColor: '#111827',
        borderRadius: '8',
        fontFamily: 'Inter',
        logoUrl: '',
        faviconUrl: '',
        darkMode: false,
        compactMode: false
      };
      setSettings(defaultSettings);
      applyTheme(defaultSettings);
    }
  };

  const previewTheme = () => {
    applyTheme(settings);
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Theme Settings"
        breadcrumb={[
          { label: "Controls", link: "/admin-controls" },
          { label: "Theme Settings" }
        ]}
        actions={[
          {
            label: "Reset to Defaults",
            icon: "RotateCcw",
            variant: "outline",
            onClick: resetToDefaults
          },
          {
            label: "Preview",
            icon: "Eye",
            variant: "outline",
            onClick: previewTheme
          },
          {
            label: saving ? "Saving..." : "Save Settings",
            icon: saving ? "Loader" : "Save",
            variant: "default",
            onClick: handleSaveSettings,
            disabled: saving
          }
        ]}
      />

      <div className="p-6">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Icon name="Loader" size={24} className="animate-spin mr-2" />
            Loading theme settings...
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Color Settings */}
            <div className="bg-card border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
                <Icon name="Palette" size={20} className="mr-2" />
                Color Scheme
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Primary Color</label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="color"
                      value={settings.primaryColor}
                      onChange={(e) => setSettings({...settings, primaryColor: e.target.value})}
                      className="w-12 h-12 rounded border border-border cursor-pointer"
                    />
                    <input
                      type="text"
                      value={settings.primaryColor}
                      onChange={(e) => setSettings({...settings, primaryColor: e.target.value})}
                      className="flex-1 px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Secondary Color</label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="color"
                      value={settings.secondaryColor}
                      onChange={(e) => setSettings({...settings, secondaryColor: e.target.value})}
                      className="w-12 h-12 rounded border border-border cursor-pointer"
                    />
                    <input
                      type="text"
                      value={settings.secondaryColor}
                      onChange={(e) => setSettings({...settings, secondaryColor: e.target.value})}
                      className="flex-1 px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Accent Color</label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="color"
                      value={settings.accentColor}
                      onChange={(e) => setSettings({...settings, accentColor: e.target.value})}
                      className="w-12 h-12 rounded border border-border cursor-pointer"
                    />
                    <input
                      type="text"
                      value={settings.accentColor}
                      onChange={(e) => setSettings({...settings, accentColor: e.target.value})}
                      className="flex-1 px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Background Color</label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="color"
                      value={settings.backgroundColor}
                      onChange={(e) => setSettings({...settings, backgroundColor: e.target.value})}
                      className="w-12 h-12 rounded border border-border cursor-pointer"
                    />
                    <input
                      type="text"
                      value={settings.backgroundColor}
                      onChange={(e) => setSettings({...settings, backgroundColor: e.target.value})}
                      className="flex-1 px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Typography & Layout */}
            <div className="bg-card border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
                <Icon name="Type" size={20} className="mr-2" />
                Typography & Layout
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Font Family</label>
                  <select
                    value={settings.fontFamily}
                    onChange={(e) => setSettings({...settings, fontFamily: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="Inter">Inter</option>
                    <option value="Roboto">Roboto</option>
                    <option value="Open Sans">Open Sans</option>
                    <option value="Lato">Lato</option>
                    <option value="Poppins">Poppins</option>
                    <option value="Montserrat">Montserrat</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Border Radius (px)</label>
                  <input
                    type="range"
                    min="0"
                    max="20"
                    value={settings.borderRadius}
                    onChange={(e) => setSettings({...settings, borderRadius: e.target.value})}
                    className="w-full"
                  />
                  <div className="text-sm text-muted-foreground mt-1">{settings.borderRadius}px</div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-foreground">Dark Mode</label>
                    <button
                      onClick={() => setSettings({...settings, darkMode: !settings.darkMode})}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.darkMode ? 'bg-primary' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.darkMode ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-foreground">Compact Mode</label>
                    <button
                      onClick={() => setSettings({...settings, compactMode: !settings.compactMode})}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.compactMode ? 'bg-primary' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.compactMode ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Logo & Branding */}
            <div className="bg-card border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
                <Icon name="Image" size={20} className="mr-2" />
                Logo & Branding
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Logo URL</label>
                  <input
                    type="url"
                    value={settings.logoUrl}
                    onChange={(e) => setSettings({...settings, logoUrl: e.target.value})}
                    placeholder="https://example.com/logo.png"
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Favicon URL</label>
                  <input
                    type="url"
                    value={settings.faviconUrl}
                    onChange={(e) => setSettings({...settings, faviconUrl: e.target.value})}
                    placeholder="https://example.com/favicon.ico"
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                {settings.logoUrl && (
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">Logo Preview</label>
                    <div className="p-4 border border-border rounded-lg bg-muted/30">
                      <img
                        src={settings.logoUrl}
                        alt="Logo Preview"
                        className="max-h-16 max-w-full object-contain"
                        onError={(e) => {
                          e.target.style.display = 'none';
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Theme Preview */}
            <div className="bg-card border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
                <Icon name="Monitor" size={20} className="mr-2" />
                Theme Preview
              </h3>
              <div className="space-y-4">
                <div 
                  className="p-4 rounded-lg border"
                  style={{
                    backgroundColor: settings.backgroundColor,
                    color: settings.textColor,
                    borderRadius: `${settings.borderRadius}px`,
                    fontFamily: settings.fontFamily
                  }}
                >
                  <h4 className="font-semibold mb-2">Sample Card</h4>
                  <p className="text-sm mb-3">This is how your theme will look in the application.</p>
                  <div className="flex space-x-2">
                    <button
                      className="px-3 py-1 rounded text-white text-sm"
                      style={{
                        backgroundColor: settings.primaryColor,
                        borderRadius: `${settings.borderRadius}px`
                      }}
                    >
                      Primary
                    </button>
                    <button
                      className="px-3 py-1 rounded text-white text-sm"
                      style={{
                        backgroundColor: settings.secondaryColor,
                        borderRadius: `${settings.borderRadius}px`
                      }}
                    >
                      Secondary
                    </button>
                    <button
                      className="px-3 py-1 rounded text-white text-sm"
                      style={{
                        backgroundColor: settings.accentColor,
                        borderRadius: `${settings.borderRadius}px`
                      }}
                    >
                      Accent
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminThemeSettings;
