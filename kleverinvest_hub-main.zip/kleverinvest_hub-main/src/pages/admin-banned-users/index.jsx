import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminBannedUsers = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('banDate');

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadBannedUsers();
  }, [isAdminAuthenticated, navigate]);

  const loadBannedUsers = () => {
    setLoading(true);
    // Load banned users from localStorage or API
    setTimeout(() => {
      const storedUsers = JSON.parse(localStorage.getItem('admin_banned_users') || '[]');
      setUsers(storedUsers);
      setLoading(false);
    }, 500);
  };

  const handleUserAction = (userId, action) => {
    const user = users.find(u => u.id === userId);

    switch (action) {
      case 'view':
        // Navigate to ban details page
        navigate(`/admin-ban-details/${userId}`);
        break;
      case 'unban':
        if (window.confirm(`Are you sure you want to unban ${user.username}?`)) {
          // Remove user from banned list and update status
          const updatedUsers = users.filter(u => u.id !== userId);
          setUsers(updatedUsers);

          // Save to localStorage
          localStorage.setItem('admin_banned_users', JSON.stringify(updatedUsers));

          // Add user back to active users
          const activeUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
          const unbanndUser = { ...user, status: 'active', banReason: null, banDate: null };
          activeUsers.push(unbanndUser);
          localStorage.setItem('admin_users_data', JSON.stringify(activeUsers));

          alert(`User ${user.username} has been unbanned successfully`);
          loadBannedUsers();
        }
        break;
      case 'permanent':
        if (window.confirm(`Are you sure you want to permanently ban ${user.username}? This action cannot be undone.`)) {
          // Update ban status to permanent
          const updatedUsers = users.map(u =>
            u.id === userId
              ? { ...u, banType: 'permanent', banReason: `${u.banReason} - Made permanent` }
              : u
          );
          setUsers(updatedUsers);
          localStorage.setItem('admin_banned_users', JSON.stringify(updatedUsers));

          alert(`User ${user.username} has been permanently banned`);
          loadBannedUsers();
        }
        break;
      case 'appeal':
        // Navigate to appeal review page
        navigate(`/admin-ban-appeal/${userId}`);
        break;
      default:
        break;
    }
  };

  const filteredUsers = users.filter(user => {
    return user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
           user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
           user.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
           user.banReason.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const sortedUsers = [...filteredUsers].sort((a, b) => {
    switch (sortBy) {
      case 'banDate':
        return new Date(b.banDate) - new Date(a.banDate);
      case 'name':
        return a.fullName.localeCompare(b.fullName);
      case 'violations':
        return a.violationType.localeCompare(b.violationType);
      default:
        return 0;
    }
  });

  const getViolationBadge = (type) => {
    const typeClasses = {
      fraud: 'bg-red-100 text-red-800 border-red-200',
      policy: 'bg-orange-100 text-orange-800 border-orange-200',
      spam: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      other: 'bg-gray-100 text-gray-800 border-gray-200'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${typeClasses[type] || typeClasses.other}`}>
        {type.charAt(0).toUpperCase() + type.slice(1)}
      </span>
    );
  };

  const getAppealBadge = (status) => {
    const statusClasses = {
      pending: 'bg-blue-100 text-blue-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      none: 'bg-gray-100 text-gray-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusClasses[status] || statusClasses.none}`}>
        {status === 'none' ? 'No Appeal' : status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Banned Users"
        breadcrumb={[
          { label: "User Management", link: "/admin-user-management" },
          { label: "Banned Users" }
        ]}
        actions={[
          {
            label: "Export Ban Report",
            icon: "Download",
            variant: "outline",
            onClick: () => {
              const csvData = users.map(user => ({
                Username: user.username,
                Email: user.email,
                'Full Name': user.fullName,
                'Ban Reason': user.banReason,
                'Ban Date': formatDateTime(user.banDate),
                'Banned By': user.bannedBy,
                'Violation Type': user.violationType,
                'Appeal Status': user.appealStatus
              }));
              const csv = [
                Object.keys(csvData[0]).join(','),
                ...csvData.map(row => Object.values(row).join(','))
              ].join('\n');
              const blob = new Blob([csv], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `banned_users_${new Date().toISOString().split('T')[0]}.csv`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }
          },
          {
            label: "Refresh",
            icon: "RefreshCw",
            variant: "outline",
            onClick: loadBannedUsers
          }
        ]}
      />

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Banned</p>
                <p className="text-2xl font-bold text-foreground">{users.length}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Icon name="Ban" size={24} className="text-red-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Appeals</p>
                <p className="text-2xl font-bold text-foreground">
                  {users.filter(u => u.appealStatus === 'pending').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Icon name="Clock" size={24} className="text-blue-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Fraud Cases</p>
                <p className="text-2xl font-bold text-foreground">
                  {users.filter(u => u.violationType === 'fraud').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Icon name="AlertTriangle" size={24} className="text-yellow-600" />
              </div>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">This Month</p>
                <p className="text-2xl font-bold text-foreground">
                  {users.filter(u => new Date(u.banDate) > new Date('2024-01-01')).length}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Icon name="Calendar" size={24} className="text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-card border rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search banned users..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="banDate">Ban Date</option>
                <option value="name">Name</option>
                <option value="violations">Violation Type</option>
              </select>
            </div>
          </div>
        </div>

        {/* Banned Users Table */}
        <div className="bg-card border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Ban Reason
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Ban Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Violation Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Appeal Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Banned By
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {loading ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center">
                      <div className="flex items-center justify-center">
                        <Icon name="Loader" size={20} className="animate-spin mr-2" />
                        Loading banned users...
                      </div>
                    </td>
                  </tr>
                ) : sortedUsers.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="px-6 py-8 text-center text-muted-foreground">
                      No banned users found
                    </td>
                  </tr>
                ) : (
                  sortedUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-muted/30">
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3">
                            <Icon name="Ban" size={16} className="text-red-600" />
                          </div>
                          <div>
                            <div className="text-sm font-medium text-foreground">{user.fullName}</div>
                            <div className="text-sm text-muted-foreground">@{user.username}</div>
                            <div className="text-xs text-muted-foreground">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground max-w-xs">
                          {user.banReason}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">{formatDateTime(user.banDate)}</div>
                      </td>
                      <td className="px-6 py-4">
                        {getViolationBadge(user.violationType)}
                      </td>
                      <td className="px-6 py-4">
                        {getAppealBadge(user.appealStatus)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-foreground">{user.bannedBy}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUserAction(user.id, 'view')}
                            title="View Details"
                          >
                            <Icon name="Eye" size={16} />
                          </Button>
                          {user.appealStatus === 'pending' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleUserAction(user.id, 'appeal')}
                              title="Review Appeal"
                              className="text-blue-600 border-blue-200 hover:bg-blue-50"
                            >
                              <Icon name="Clock" size={16} />
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUserAction(user.id, 'unban')}
                            title="Unban User"
                            className="text-green-600 border-green-200 hover:bg-green-50"
                          >
                            <Icon name="UserCheck" size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUserAction(user.id, 'permanent')}
                            title="Permanent Ban"
                            className="text-red-600 border-red-200 hover:bg-red-50"
                          >
                            <Icon name="X" size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminBannedUsers;
