import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const LiveChatSettings = () => {
  const [settings, setSettings] = useState({
    enabled: true,
    apiKey: '',
    apiEndpoint: '',
    welcomeMessage: 'Hello! Welcome to KleverInvest. How can I help you today?',
    autoRespond: true,
    businessHours: {
      enabled: true,
      start: '09:00',
      end: '17:00',
      timezone: 'UTC'
    },
    offlineMessage: 'We are currently offline. Please leave a message and we will get back to you.',
    allowFileUploads: false,
    maxConcurrentChats: 50,
    responseTime: 30 // seconds
  });

  const [isSaving, setIsSaving] = useState(false);

  const handleChange = (field, value) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleBusinessHoursChange = (field, value) => {
    setSettings(prev => ({
      ...prev,
      businessHours: {
        ...prev.businessHours,
        [field]: value
      }
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      console.log('Live chat settings saved:', settings);
      // Here you would typically save to your backend
    } catch (error) {
      console.error('Failed to save settings:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const testConnection = async () => {
    if (!settings.apiKey || !settings.apiEndpoint) {
      alert('Please enter API key and endpoint first');
      return;
    }
    
    try {
      // Simulate API test
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Connection successful!');
    } catch (error) {
      alert('Connection failed. Please check your settings.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center">
            <Icon name="MessageCircle" size={20} className="mr-2 text-primary" />
            Live Chat Configuration
          </h3>
          <p className="text-sm text-muted-foreground mt-1">
            Configure live chat settings and API integration
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${settings.enabled ? 'bg-green-500' : 'bg-gray-400'}`} />
          <span className="text-sm text-muted-foreground">
            {settings.enabled ? 'Active' : 'Disabled'}
          </span>
        </div>
      </div>

      {/* Basic Settings */}
      <div className="bg-card border rounded-lg p-6">
        <h4 className="font-medium mb-4">Basic Settings</h4>
        <div className="space-y-4">
          <Checkbox
            checked={settings.enabled}
            onChange={(checked) => handleChange('enabled', checked)}
            label="Enable Live Chat"
            description="Allow visitors to chat with support agents"
          />

          <Input
            label="Welcome Message"
            value={settings.welcomeMessage}
            onChange={(e) => handleChange('welcomeMessage', e.target.value)}
            placeholder="Enter welcome message"
            className="w-full"
          />

          <Input
            label="Offline Message"
            value={settings.offlineMessage}
            onChange={(e) => handleChange('offlineMessage', e.target.value)}
            placeholder="Message shown when offline"
            className="w-full"
          />

          <Checkbox
            checked={settings.autoRespond}
            onChange={(checked) => handleChange('autoRespond', checked)}
            label="Auto-respond to common questions"
            description="Use AI to provide instant responses to frequently asked questions"
          />

          <Checkbox
            checked={settings.allowFileUploads}
            onChange={(checked) => handleChange('allowFileUploads', checked)}
            label="Allow file uploads"
            description="Let users upload files during chat sessions"
          />
        </div>
      </div>

      {/* API Configuration */}
      <div className="bg-card border rounded-lg p-6">
        <h4 className="font-medium mb-4 flex items-center">
          <Icon name="Settings" size={16} className="mr-2" />
          API Configuration
        </h4>
        <div className="space-y-4">
          <Input
            label="API Key"
            type="password"
            value={settings.apiKey}
            onChange={(e) => handleChange('apiKey', e.target.value)}
            placeholder="Enter your chat service API key"
            icon="Key"
          />

          <Input
            label="API Endpoint"
            value={settings.apiEndpoint}
            onChange={(e) => handleChange('apiEndpoint', e.target.value)}
            placeholder="https://api.chatservice.com/v1"
            icon="Link"
          />

          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Max Concurrent Chats"
              type="number"
              value={settings.maxConcurrentChats}
              onChange={(e) => handleChange('maxConcurrentChats', parseInt(e.target.value))}
              min="1"
              max="100"
            />
            <Input
              label="Response Time (seconds)"
              type="number"
              value={settings.responseTime}
              onChange={(e) => handleChange('responseTime', parseInt(e.target.value))}
              min="10"
              max="300"
            />
          </div>

          <Button
            variant="outline"
            onClick={testConnection}
            className="w-full sm:w-auto"
          >
            <Icon name="Zap" size={16} className="mr-2" />
            Test Connection
          </Button>
        </div>
      </div>

      {/* Business Hours */}
      <div className="bg-card border rounded-lg p-6">
        <h4 className="font-medium mb-4 flex items-center">
          <Icon name="Clock" size={16} className="mr-2" />
          Business Hours
        </h4>
        <div className="space-y-4">
          <Checkbox
            checked={settings.businessHours.enabled}
            onChange={(checked) => handleBusinessHoursChange('enabled', checked)}
            label="Enable business hours"
            description="Show online/offline status based on business hours"
          />

          {settings.businessHours.enabled && (
            <div className="grid grid-cols-3 gap-4 mt-4">
              <Input
                label="Start Time"
                type="time"
                value={settings.businessHours.start}
                onChange={(e) => handleBusinessHoursChange('start', e.target.value)}
              />
              <Input
                label="End Time"
                type="time"
                value={settings.businessHours.end}
                onChange={(e) => handleBusinessHoursChange('end', e.target.value)}
              />
              <Input
                label="Timezone"
                value={settings.businessHours.timezone}
                onChange={(e) => handleBusinessHoursChange('timezone', e.target.value)}
                placeholder="UTC, EST, PST..."
              />
            </div>
          )}
        </div>
      </div>

      {/* Popular Chat Services */}
      <div className="bg-card border rounded-lg p-6">
        <h4 className="font-medium mb-4">Popular Chat Services</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { name: 'Intercom', website: 'intercom.com', logo: '💬' },
            { name: 'Zendesk Chat', website: 'zendesk.com', logo: '🎧' },
            { name: 'Crisp', website: 'crisp.chat', logo: '💭' },
            { name: 'Tidio', website: 'tidio.com', logo: '🗨️' },
            { name: 'LiveChat', website: 'livechat.com', logo: '💻' },
            { name: 'Tawk.to', website: 'tawk.to', logo: '🔗' }
          ].map((service, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{service.logo}</span>
                <div>
                  <h5 className="font-medium text-sm">{service.name}</h5>
                  <p className="text-xs text-muted-foreground">{service.website}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-4">
          Configure your API settings above to integrate with any of these popular chat services.
        </p>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          disabled={isSaving}
          className="px-8"
        >
          {isSaving ? (
            <>
              <Icon name="Loader" size={16} className="mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Icon name="Save" size={16} className="mr-2" />
              Save Settings
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default LiveChatSettings;
