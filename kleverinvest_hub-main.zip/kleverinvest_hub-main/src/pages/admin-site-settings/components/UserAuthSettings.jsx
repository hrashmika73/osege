import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const UserAuthSettings = () => {
  const [settings, setSettings] = useState({
    // Email Verification Settings
    emailVerificationRequired: true,
    emailVerificationCodeLength: 6,
    emailVerificationExpiry: 15, // minutes
    emailResendCooldown: 60, // seconds
    maxEmailResendAttempts: 3,
    
    // OTP Settings
    otpRequired: true,
    otpMethod: 'app', // 'app', 'sms', 'email'
    otpCodeLength: 6,
    otpExpiry: 5, // minutes
    backupCodesEnabled: true,
    
    // Login Security
    maxLoginAttempts: 5,
    lockoutDuration: 15, // minutes
    sessionTimeout: 60, // minutes
    rememberMeEnabled: true,
    rememberMeDuration: 30, // days
    
    // Password Requirements
    minPasswordLength: 8,
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecialChars: true,
    passwordExpiry: 90, // days
    preventPasswordReuse: 5, // last N passwords
    
    // Device Management
    deviceTrackingEnabled: true,
    maxDevicesPerUser: 5,
    trustedDeviceExpiry: 30, // days
    
    // Notifications
    loginNotificationsEnabled: true,
    suspiciousActivityAlerts: true,
    passwordChangeNotifications: true
  });

  const [isSaving, setIsSaving] = useState(false);
  const [testMode, setTestMode] = useState(false);

  const handleChange = (field, value) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      console.log('User authentication settings saved:', settings);
      // Here you would typically save to your backend
    } catch (error) {
      console.error('Failed to save settings:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleTestUserFlow = () => {
    setTestMode(true);
    // Open user login in new tab with test mode
    window.open('/login?test=true', '_blank');
    setTimeout(() => setTestMode(false), 3000);
  };

  const resetToDefaults = () => {
    if (window.confirm('Reset all authentication settings to default values?')) {
      setSettings({
        emailVerificationRequired: true,
        emailVerificationCodeLength: 6,
        emailVerificationExpiry: 15,
        emailResendCooldown: 60,
        maxEmailResendAttempts: 3,
        otpRequired: true,
        otpMethod: 'app',
        otpCodeLength: 6,
        otpExpiry: 5,
        backupCodesEnabled: true,
        maxLoginAttempts: 5,
        lockoutDuration: 15,
        sessionTimeout: 60,
        rememberMeEnabled: true,
        rememberMeDuration: 30,
        minPasswordLength: 8,
        requireUppercase: true,
        requireLowercase: true,
        requireNumbers: true,
        requireSpecialChars: true,
        passwordExpiry: 90,
        preventPasswordReuse: 5,
        deviceTrackingEnabled: true,
        maxDevicesPerUser: 5,
        trustedDeviceExpiry: 30,
        loginNotificationsEnabled: true,
        suspiciousActivityAlerts: true,
        passwordChangeNotifications: true
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center">
            <Icon name="UserCheck" size={20} className="mr-2 text-primary" />
            User Authentication Settings
          </h3>
          <p className="text-sm text-muted-foreground mt-1">
            Configure user login security, verification, and authentication requirements
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleTestUserFlow}
            disabled={testMode}
          >
            {testMode ? (
              <>
                <Icon name="Loader" size={16} className="mr-2 animate-spin" />
                Testing...
              </>
            ) : (
              <>
                <Icon name="TestTube" size={16} className="mr-2" />
                Test User Flow
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Email Verification Settings */}
      <div className="bg-card border rounded-lg p-6">
        <h4 className="font-medium mb-4 flex items-center">
          <Icon name="Mail" size={16} className="mr-2" />
          Email Verification
        </h4>
        <div className="space-y-4">
          <Checkbox
            checked={settings.emailVerificationRequired}
            onChange={(checked) => handleChange('emailVerificationRequired', checked)}
            label="Require email verification for new logins"
            description="Users must verify their email address before accessing their account"
          />

          {settings.emailVerificationRequired && (
            <div className="grid grid-cols-2 gap-4 ml-6">
              <Input
                label="Code Length (digits)"
                type="number"
                value={settings.emailVerificationCodeLength}
                onChange={(e) => handleChange('emailVerificationCodeLength', parseInt(e.target.value))}
                min="4"
                max="8"
              />
              <Input
                label="Code Expiry (minutes)"
                type="number"
                value={settings.emailVerificationExpiry}
                onChange={(e) => handleChange('emailVerificationExpiry', parseInt(e.target.value))}
                min="5"
                max="60"
              />
              <Input
                label="Resend Cooldown (seconds)"
                type="number"
                value={settings.emailResendCooldown}
                onChange={(e) => handleChange('emailResendCooldown', parseInt(e.target.value))}
                min="30"
                max="300"
              />
              <Input
                label="Max Resend Attempts"
                type="number"
                value={settings.maxEmailResendAttempts}
                onChange={(e) => handleChange('maxEmailResendAttempts', parseInt(e.target.value))}
                min="1"
                max="10"
              />
            </div>
          )}
        </div>
      </div>

      {/* OTP Settings */}
      <div className="bg-card border rounded-lg p-6">
        <h4 className="font-medium mb-4 flex items-center">
          <Icon name="Smartphone" size={16} className="mr-2" />
          Two-Factor Authentication (OTP)
        </h4>
        <div className="space-y-4">
          <Checkbox
            checked={settings.otpRequired}
            onChange={(checked) => handleChange('otpRequired', checked)}
            label="Require OTP for user login"
            description="Add an extra layer of security with time-based one-time passwords"
          />

          {settings.otpRequired && (
            <div className="ml-6 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">OTP Method</label>
                <div className="flex space-x-4">
                  {[
                    { value: 'app', label: 'Authenticator App', icon: 'Smartphone' },
                    { value: 'sms', label: 'SMS', icon: 'MessageSquare' },
                    { value: 'email', label: 'Email', icon: 'Mail' }
                  ].map((method) => (
                    <label key={method.value} className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="otpMethod"
                        value={method.value}
                        checked={settings.otpMethod === method.value}
                        onChange={(e) => handleChange('otpMethod', e.target.value)}
                        className="text-primary focus:ring-primary"
                      />
                      <Icon name={method.icon} size={16} />
                      <span className="text-sm">{method.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="OTP Code Length"
                  type="number"
                  value={settings.otpCodeLength}
                  onChange={(e) => handleChange('otpCodeLength', parseInt(e.target.value))}
                  min="4"
                  max="8"
                />
                <Input
                  label="OTP Expiry (minutes)"
                  type="number"
                  value={settings.otpExpiry}
                  onChange={(e) => handleChange('otpExpiry', parseInt(e.target.value))}
                  min="1"
                  max="15"
                />
              </div>

              <Checkbox
                checked={settings.backupCodesEnabled}
                onChange={(checked) => handleChange('backupCodesEnabled', checked)}
                label="Enable backup codes"
                description="Allow users to generate backup codes for account recovery"
              />
            </div>
          )}
        </div>
      </div>

      {/* Login Security */}
      <div className="bg-card border rounded-lg p-6">
        <h4 className="font-medium mb-4 flex items-center">
          <Icon name="Shield" size={16} className="mr-2" />
          Login Security
        </h4>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Max Login Attempts"
              type="number"
              value={settings.maxLoginAttempts}
              onChange={(e) => handleChange('maxLoginAttempts', parseInt(e.target.value))}
              min="3"
              max="10"
            />
            <Input
              label="Lockout Duration (minutes)"
              type="number"
              value={settings.lockoutDuration}
              onChange={(e) => handleChange('lockoutDuration', parseInt(e.target.value))}
              min="5"
              max="60"
            />
            <Input
              label="Session Timeout (minutes)"
              type="number"
              value={settings.sessionTimeout}
              onChange={(e) => handleChange('sessionTimeout', parseInt(e.target.value))}
              min="15"
              max="480"
            />
            <Input
              label="Remember Me Duration (days)"
              type="number"
              value={settings.rememberMeDuration}
              onChange={(e) => handleChange('rememberMeDuration', parseInt(e.target.value))}
              min="1"
              max="90"
              disabled={!settings.rememberMeEnabled}
            />
          </div>

          <Checkbox
            checked={settings.rememberMeEnabled}
            onChange={(checked) => handleChange('rememberMeEnabled', checked)}
            label="Allow 'Remember Me' option"
            description="Users can choose to stay logged in for extended periods"
          />
        </div>
      </div>

      {/* Password Requirements */}
      <div className="bg-card border rounded-lg p-6">
        <h4 className="font-medium mb-4 flex items-center">
          <Icon name="Key" size={16} className="mr-2" />
          Password Requirements
        </h4>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Minimum Length"
              type="number"
              value={settings.minPasswordLength}
              onChange={(e) => handleChange('minPasswordLength', parseInt(e.target.value))}
              min="6"
              max="20"
            />
            <Input
              label="Password Expiry (days)"
              type="number"
              value={settings.passwordExpiry}
              onChange={(e) => handleChange('passwordExpiry', parseInt(e.target.value))}
              min="30"
              max="365"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Checkbox
                checked={settings.requireUppercase}
                onChange={(checked) => handleChange('requireUppercase', checked)}
                label="Require uppercase letters"
              />
              <Checkbox
                checked={settings.requireLowercase}
                onChange={(checked) => handleChange('requireLowercase', checked)}
                label="Require lowercase letters"
              />
            </div>
            <div className="space-y-2">
              <Checkbox
                checked={settings.requireNumbers}
                onChange={(checked) => handleChange('requireNumbers', checked)}
                label="Require numbers"
              />
              <Checkbox
                checked={settings.requireSpecialChars}
                onChange={(checked) => handleChange('requireSpecialChars', checked)}
                label="Require special characters"
              />
            </div>
          </div>

          <Input
            label="Prevent Password Reuse (last N passwords)"
            type="number"
            value={settings.preventPasswordReuse}
            onChange={(e) => handleChange('preventPasswordReuse', parseInt(e.target.value))}
            min="0"
            max="20"
          />
        </div>
      </div>

      {/* Notifications */}
      <div className="bg-card border rounded-lg p-6">
        <h4 className="font-medium mb-4 flex items-center">
          <Icon name="Bell" size={16} className="mr-2" />
          Security Notifications
        </h4>
        <div className="space-y-3">
          <Checkbox
            checked={settings.loginNotificationsEnabled}
            onChange={(checked) => handleChange('loginNotificationsEnabled', checked)}
            label="Send login notifications"
            description="Notify users via email when they log in from a new device"
          />
          <Checkbox
            checked={settings.suspiciousActivityAlerts}
            onChange={(checked) => handleChange('suspiciousActivityAlerts', checked)}
            label="Suspicious activity alerts"
            description="Alert users and admins about unusual login patterns"
          />
          <Checkbox
            checked={settings.passwordChangeNotifications}
            onChange={(checked) => handleChange('passwordChangeNotifications', checked)}
            label="Password change notifications"
            description="Notify users when their password is changed"
          />
        </div>
      </div>

      {/* Current Configuration Summary */}
      <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
        <h4 className="font-medium text-primary mb-3">Current Security Level</h4>
        <div className="grid grid-cols-3 gap-4 text-sm">
          <div>
            <span className="text-muted-foreground">Email Verification:</span>
            <span className={`ml-2 font-medium ${settings.emailVerificationRequired ? 'text-success' : 'text-warning'}`}>
              {settings.emailVerificationRequired ? 'Required' : 'Disabled'}
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Two-Factor Auth:</span>
            <span className={`ml-2 font-medium ${settings.otpRequired ? 'text-success' : 'text-warning'}`}>
              {settings.otpRequired ? 'Required' : 'Disabled'}
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Security Level:</span>
            <span className={`ml-2 font-medium ${
              settings.emailVerificationRequired && settings.otpRequired ? 'text-success' : 
              settings.emailVerificationRequired || settings.otpRequired ? 'text-warning' : 'text-error'
            }`}>
              {settings.emailVerificationRequired && settings.otpRequired ? 'High' : 
               settings.emailVerificationRequired || settings.otpRequired ? 'Medium' : 'Basic'}
            </span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={resetToDefaults}
        >
          <Icon name="RotateCcw" size={16} className="mr-2" />
          Reset to Defaults
        </Button>

        <Button
          onClick={handleSave}
          disabled={isSaving}
          className="px-8"
        >
          {isSaving ? (
            <>
              <Icon name="Loader" size={16} className="mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Icon name="Save" size={16} className="mr-2" />
              Save Settings
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default UserAuthSettings;
