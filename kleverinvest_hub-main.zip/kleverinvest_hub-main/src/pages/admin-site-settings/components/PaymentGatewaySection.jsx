import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const PaymentGatewaySection = ({ isExpanded, onToggle }) => {
  // Load settings from localStorage and update status
  const [gatewaySettings, setGatewaySettings] = useState(() => {
    const savedSettings = localStorage.getItem('payment_gateway_settings');
    if (savedSettings) {
      const parsed = JSON.parse(savedSettings);
      return {
        stripe: {
          enabled: parsed.stripe?.enabled || false,
          publishableKey: parsed.stripe?.publishableKey ? 'pk_****' + parsed.stripe.publishableKey.slice(-4) : '',
          secretKey: parsed.stripe?.secretKey ? '••••••••••••' + parsed.stripe.secretKey.slice(-4) : '',
          status: parsed.stripe?.enabled && parsed.stripe?.publishableKey ? 'connected' : 'not_configured'
        },
        paypal: {
          enabled: parsed.paypal?.enabled || false,
          email: parsed.paypal?.email || '',
          clientId: parsed.paypal?.clientId ? '••••••••••••' + parsed.paypal.clientId.slice(-4) : '',
          status: parsed.paypal?.enabled && parsed.paypal?.clientId ? 'connected' : 'not_configured'
        },
        bitcoin: {
          enabled: parsed.bitcoin?.enabled || false,
          address: parsed.bitcoin?.walletAddress ? parsed.bitcoin.walletAddress.slice(0, 10) + '...wlh' : '',
          confirmations: parsed.bitcoin?.confirmations || 3,
          status: parsed.bitcoin?.enabled && parsed.bitcoin?.walletAddress ? 'connected' : 'not_configured'
        },
        ethereum: {
          enabled: parsed.ethereum?.enabled || false,
          address: parsed.ethereum?.walletAddress ? parsed.ethereum.walletAddress.slice(0, 10) + '...' : '',
          network: parsed.ethereum?.network || 'mainnet',
          status: parsed.ethereum?.enabled && parsed.ethereum?.walletAddress ? 'connected' : 'not_configured'
        }
      };
    }
    return {
      stripe: { enabled: false, publishableKey: '', secretKey: '', status: 'not_configured' },
      paypal: { enabled: false, email: '', clientId: '', status: 'not_configured' },
      bitcoin: { enabled: false, address: '', confirmations: 3, status: 'not_configured' },
      ethereum: { enabled: false, address: '', network: 'mainnet', status: 'not_configured' }
    };
  });

  // Update settings when localStorage changes
  useEffect(() => {
    const handleStorageChange = () => {
      const savedSettings = localStorage.getItem('payment_gateway_settings');
      if (savedSettings) {
        const parsed = JSON.parse(savedSettings);
        setGatewaySettings({
          stripe: {
            enabled: parsed.stripe?.enabled || false,
            publishableKey: parsed.stripe?.publishableKey ? 'pk_****' + parsed.stripe.publishableKey.slice(-4) : '',
            secretKey: parsed.stripe?.secretKey ? '••••••••••••' + parsed.stripe.secretKey.slice(-4) : '',
            status: parsed.stripe?.enabled && parsed.stripe?.publishableKey ? 'connected' : 'not_configured'
          },
          paypal: {
            enabled: parsed.paypal?.enabled || false,
            email: parsed.paypal?.email || '',
            clientId: parsed.paypal?.clientId ? '••••••••••••' + parsed.paypal.clientId.slice(-4) : '',
            status: parsed.paypal?.enabled && parsed.paypal?.clientId ? 'connected' : 'not_configured'
          },
          bitcoin: {
            enabled: parsed.bitcoin?.enabled || false,
            address: parsed.bitcoin?.walletAddress ? parsed.bitcoin.walletAddress.slice(0, 10) + '...wlh' : '',
            confirmations: parsed.bitcoin?.confirmations || 3,
            status: parsed.bitcoin?.enabled && parsed.bitcoin?.walletAddress ? 'connected' : 'not_configured'
          },
          ethereum: {
            enabled: parsed.ethereum?.enabled || false,
            address: parsed.ethereum?.walletAddress ? parsed.ethereum.walletAddress.slice(0, 10) + '...' : '',
            network: parsed.ethereum?.network || 'mainnet',
            status: parsed.ethereum?.enabled && parsed.ethereum?.walletAddress ? 'connected' : 'not_configured'
          }
        });
      }
    };

    // Listen for storage changes
    window.addEventListener('storage', handleStorageChange);

    // Also listen for custom event from other tabs/components
    window.addEventListener('paymentSettingsChanged', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('paymentSettingsChanged', handleStorageChange);
    };
  }, []);

  const [showGatewayModal, setShowGatewayModal] = useState(false);

  const handleQuickSetup = (gateway) => {
    const configs = {
      stripe: {
        title: 'Stripe Setup',
        fields: ['Publishable Key', 'Secret Key', 'Webhook Secret'],
        docs: 'https://stripe.com/docs/keys'
      },
      paypal: {
        title: 'PayPal Setup',
        fields: ['Business Email', 'Client ID', 'Client Secret'],
        docs: 'https://developer.paypal.com'
      },
      bitcoin: {
        title: 'Bitcoin Setup',
        fields: ['Wallet Address', 'xPub Key', 'Confirmations'],
        docs: 'Bitcoin wallet configuration'
      },
      ethereum: {
        title: 'Ethereum Setup',
        fields: ['Wallet Address', 'Private Key', 'Gas Limit'],
        docs: 'Ethereum wallet configuration'
      }
    };

    const config = configs[gateway];
    const proceed = confirm(
      `${config.title} Quick Setup:\n\n` +
      `Required Fields:\n` +
      config.fields.map(field => `• ${field}`).join('\n') + 
      `\n\nDocumentation: ${config.docs}\n\n` +
      `Would you like to open the full gateway settings?`
    );

    if (proceed) {
      setShowGatewayModal(true);
    }
  };

  const handleToggleGateway = (gateway) => {
    setGatewaySettings(prev => ({
      ...prev,
      [gateway]: {
        ...prev[gateway],
        enabled: !prev[gateway].enabled
      }
    }));
  };

  const gateways = [
    {
      id: 'stripe',
      name: 'Stripe',
      icon: 'CreditCard',
      description: 'Credit/Debit Cards, ACH',
      color: 'bg-blue-500'
    },
    {
      id: 'paypal',
      name: 'PayPal',
      icon: 'Wallet',
      description: 'PayPal Payments',
      color: 'bg-blue-600'
    },
    {
      id: 'bitcoin',
      name: 'Bitcoin',
      icon: 'Bitcoin',
      description: 'Bitcoin Payments',
      color: 'bg-orange-500'
    },
    {
      id: 'ethereum',
      name: 'Ethereum',
      icon: 'Hexagon',
      description: 'Ethereum & ERC-20 Tokens',
      color: 'bg-indigo-500'
    }
  ];

  const getStatusBadge = (status) => {
    const configs = {
      connected: { color: 'bg-success/10 text-success border-success/20', text: 'Connected' },
      not_configured: { color: 'bg-warning/10 text-warning border-warning/20', text: 'Not Configured' },
      error: { color: 'bg-destructive/10 text-destructive border-destructive/20', text: 'Error' }
    };
    
    const config = configs[status] || configs.not_configured;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${config.color}`}>
        {config.text}
      </span>
    );
  };

  const PaymentGatewayModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-card rounded-lg p-6 max-w-lg w-full mx-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Payment Gateway Settings</h3>
          <Button variant="outline" size="sm" onClick={() => setShowGatewayModal(false)}>
            <Icon name="X" size={16} />
          </Button>
        </div>
        <p className="text-muted-foreground mb-4">
          For detailed payment gateway configuration, please use the main Payment Gateway Settings.
        </p>
        <div className="flex space-x-2">
          <Button 
            onClick={() => {
              setShowGatewayModal(false);
              // Navigate to main payment gateway settings
              window.location.href = '/admin-payment-gateway';
            }}
            className="flex-1"
          >
            <Icon name="Settings" size={16} className="mr-2" />
            Open Gateway Settings
          </Button>
          <Button 
            variant="outline" 
            onClick={() => setShowGatewayModal(false)}
          >
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-card rounded-lg border">
      <div 
        className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/20 transition-colors"
        onClick={onToggle}
      >
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="CreditCard" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="font-medium text-foreground">Payment Gateways</h3>
            <p className="text-sm text-muted-foreground">Configure payment processing</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-muted-foreground">
            {Object.values(gatewaySettings).filter(g => g.enabled).length} active
          </span>
          <Icon 
            name={isExpanded ? "ChevronUp" : "ChevronDown"} 
            size={20} 
            className="text-muted-foreground"
          />
        </div>
      </div>

      {isExpanded && (
        <div className="p-4 border-t border-border">
          <div className="space-y-4">
            {/* Quick Actions */}
            <div className="flex space-x-2 mb-6">
              <Button 
                onClick={() => setShowGatewayModal(true)}
                className="flex-1"
              >
                <Icon name="Settings" size={16} className="mr-2" />
                Configure Gateways
              </Button>
              <Button 
                variant="outline"
                onClick={() => window.location.href = '/admin-payment-gateway'}
              >
                <Icon name="ExternalLink" size={16} className="mr-2" />
                Gateway Dashboard
              </Button>
            </div>

            {/* Gateway List */}
            <div className="space-y-3">
              {gateways.map(gateway => (
                <div key={gateway.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${gateway.color}`}>
                      <Icon name={gateway.icon} size={16} className="text-white" />
                    </div>
                    <div>
                      <div className="font-medium text-foreground">{gateway.name}</div>
                      <div className="text-sm text-muted-foreground">{gateway.description}</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    {getStatusBadge(gatewaySettings[gateway.id].status)}
                    <label className="flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={gatewaySettings[gateway.id].enabled}
                        onChange={() => handleToggleGateway(gateway.id)}
                        className="sr-only"
                      />
                      <div className={`w-10 h-6 rounded-full transition-colors ${
                        gatewaySettings[gateway.id].enabled ? 'bg-primary' : 'bg-muted'
                      }`}>
                        <div className={`w-4 h-4 rounded-full bg-white transition-transform transform ${
                          gatewaySettings[gateway.id].enabled ? 'translate-x-5' : 'translate-x-1'
                        } mt-1`} />
                      </div>
                    </label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleQuickSetup(gateway.id)}
                    >
                      <Icon name="Settings" size={14} />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {/* Settings Summary */}
            <div className="bg-muted/20 rounded-lg p-4 mt-6">
              <h4 className="font-medium text-foreground mb-3">Configuration Status</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Active Gateways:</span>
                  <span className="font-medium">{Object.values(gatewaySettings).filter(g => g.enabled).length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Connected:</span>
                  <span className="font-medium text-success">
                    {Object.values(gatewaySettings).filter(g => g.status === 'connected').length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Need Setup:</span>
                  <span className="font-medium text-warning">
                    {Object.values(gatewaySettings).filter(g => g.status === 'not_configured').length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Errors:</span>
                  <span className="font-medium text-destructive">
                    {Object.values(gatewaySettings).filter(g => g.status === 'error').length}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Setup Help */}
            <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="Info" size={16} className="text-primary" />
                <span className="font-medium text-primary">Quick Setup Guide</span>
              </div>
              <div className="text-sm text-muted-foreground space-y-1">
                <div>• <strong>Stripe:</strong> Get keys from stripe.com/dashboard</div>
                <div>• <strong>PayPal:</strong> Create app at developer.paypal.com</div>
                <div>• <strong>Bitcoin:</strong> Use your wallet address and xPub key</div>
                <div>• <strong>Ethereum:</strong> Configure wallet address and network</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {showGatewayModal && <PaymentGatewayModal />}
    </div>
  );
};

export default PaymentGatewaySection;
