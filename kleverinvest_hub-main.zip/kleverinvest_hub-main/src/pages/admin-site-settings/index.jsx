import React, { useState, useEffect } from 'react';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import AdminNavigation from '../../components/ui/AdminNavigation';
import LiveChatSettings from './components/LiveChatSettings';
import UserAuthSettings from './components/UserAuthSettings';
import PaymentGatewaySection from './components/PaymentGatewaySection';

const AdminSiteSettings = () => {
  const [activeTab, setActiveTab] = useState('general');
  const [expandedSections, setExpandedSections] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState(null);
  const [notifications, setNotifications] = useState([]);

  // Load settings from localStorage
  const [settings, setSettings] = useState(() => {
    const savedSettings = localStorage.getItem('admin_site_settings');
    if (savedSettings) {
      return JSON.parse(savedSettings);
    }
    return {
      siteName: 'KleverInvest Hub',
      siteDescription: 'Professional Cryptocurrency Investment Platform',
      contactEmail: 'admin@kleverinvest.com',
      supportEmail: 'support@kleverinvest.com',
      maintenanceMode: false,
      registrationEnabled: true,
      emailVerificationRequired: true,
      twoFactorRequired: false,
      minimumDeposit: 100,
      maximumDeposit: 100000,
      withdrawalFee: 2.5,
      sessionTimeout: 30,
      maxLoginAttempts: 5,
      lockoutDuration: 15,
      notificationSettings: {
        pushEnabled: true,
        emailEnabled: true,
        smsEnabled: false,
        quietHours: { start: '22:00', end: '08:00' }
      }
    };
  });

  // Load last saved timestamp
  useEffect(() => {
    const lastSavedTime = localStorage.getItem('admin_site_settings_last_saved');
    if (lastSavedTime) {
      setLastSaved(new Date(lastSavedTime));
    }
  }, []);

  const tabs = [
    { id: 'general', label: 'General', icon: 'Settings' },
    { id: 'security', label: 'Security', icon: 'Shield' },
    { id: 'userauth', label: 'User Auth', icon: 'UserCheck' },
    { id: 'payments', label: 'Payments', icon: 'DollarSign' },
    { id: 'livechat', label: 'Live Chat', icon: 'MessageCircle' },
    { id: 'notifications', label: 'Notifications', icon: 'Bell' },
    { id: 'maintenance', label: 'Maintenance', icon: 'Tool' }
  ];

  const handleInputChange = (field, value) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simulate save delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Save to localStorage
      localStorage.setItem('admin_site_settings', JSON.stringify(settings));
      localStorage.setItem('admin_site_settings_last_saved', new Date().toISOString());
      setLastSaved(new Date());

      // Apply changes to frontend by updating a global settings event
      window.dispatchEvent(new CustomEvent('siteSettingsChanged', { detail: settings }));

      // Show success notification
      alert(`✅ Site Settings Saved Successfully!\n\n` +
        `Site Name: ${settings.siteName}\n` +
        `Contact Email: ${settings.contactEmail}\n` +
        `Maintenance Mode: ${settings.maintenanceMode ? 'ENABLED' : 'DISABLED'}\n\n` +
        `Changes have been applied to the frontend!`);
    } catch (error) {
      alert('❌ Failed to save settings. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  // Backup Database Function
  const handleBackupDatabase = async () => {
    if (!confirm('Create a complete system backup?\n\nThis will backup:\n• User data\n• Transaction records\n• System settings\n• Payment configurations\n\nProceed?')) {
      return;
    }

    try {
      // Simulate backup process
      const backupData = {
        timestamp: new Date().toISOString(),
        users: JSON.parse(localStorage.getItem('users') || '[]'),
        transactions: JSON.parse(localStorage.getItem('admin_transactions') || '[]'),
        settings: settings,
        paymentSettings: JSON.parse(localStorage.getItem('payment_gateway_settings') || '{}'),
        version: '1.0.0'
      };

      // Create downloadable backup file
      const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `kleverinvest_backup_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      alert('✅ Database backup created successfully!\n\nBackup file downloaded.\nRestore: Import this file in case of data recovery.');
    } catch (error) {
      alert('❌ Backup failed. Please try again.');
    }
  };

  // Clear Cache Function
  const handleClearCache = async () => {
    if (!confirm('Clear all system cache?\n\nThis will clear:\n• Browser cache\n• Local storage cache\n• Session data\n• Temporary files\n\nSystem will reload after clearing.')) {
      return;
    }

    try {
      // Clear various cache types
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map(name => caches.delete(name)));
      }

      // Clear some non-essential localStorage items
      const keysToKeep = ['admin_site_settings', 'payment_gateway_settings', 'admin_transactions'];
      const allKeys = Object.keys(localStorage);
      allKeys.forEach(key => {
        if (!keysToKeep.includes(key)) {
          localStorage.removeItem(key);
        }
      });

      alert('✅ System cache cleared successfully!\n\nCache cleared:\n• Browser cache\n• Temporary data\n• Session cache\n\nPage will reload...');
      
      // Reload page after cache clear
      setTimeout(() => window.location.reload(), 1000);
    } catch (error) {
      alert('❌ Failed to clear cache. Please try again.');
    }
  };

  // Push Notification Function
  const handlePushNotification = () => {
    const message = prompt('Push Notification to All Users\n\nEnter message (will appear in all user dashboards):');
    if (!message) return;

    const type = prompt('Notification Type:\n\n1. info (blue)\n2. success (green)\n3. warning (yellow)\n4. error (red)\n\nEnter type (default: info):') || 'info';

    const notification = {
      id: Date.now(),
      message: message,
      type: type,
      timestamp: new Date().toISOString(),
      from: 'System Administrator',
      persistent: true
    };

    // Save to localStorage for all users to see
    const existingNotifications = JSON.parse(localStorage.getItem('global_notifications') || '[]');
    existingNotifications.unshift(notification);
    localStorage.setItem('global_notifications', JSON.stringify(existingNotifications));

    // Dispatch event to notify all open tabs
    window.dispatchEvent(new CustomEvent('globalNotification', { detail: notification }));

    alert(`✅ Notification Pushed Successfully!\n\nMessage: "${message}"\nType: ${type.toUpperCase()}\nTimestamp: ${new Date().toLocaleString()}\n\nAll users will see this notification in their dashboards.`);
  };

  const renderGeneralSettings = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Site Name</label>
        <Input
          value={settings.siteName}
          onChange={(e) => handleInputChange('siteName', e.target.value)}
          placeholder="Enter site name"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Site Description</label>
        <textarea
          value={settings.siteDescription}
          onChange={(e) => handleInputChange('siteDescription', e.target.value)}
          rows="3"
          className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-background text-foreground"
          placeholder="Enter site description"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Contact Email</label>
          <Input
            type="email"
            value={settings.contactEmail}
            onChange={(e) => handleInputChange('contactEmail', e.target.value)}
            placeholder="contact@example.com"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Support Email</label>
          <Input
            type="email"
            value={settings.supportEmail}
            onChange={(e) => handleInputChange('supportEmail', e.target.value)}
            placeholder="support@example.com"
          />
        </div>
      </div>

      <div className="flex items-center space-x-3">
        <input
          type="checkbox"
          id="registrationEnabled"
          checked={settings.registrationEnabled}
          onChange={(e) => handleInputChange('registrationEnabled', e.target.checked)}
          className="text-primary focus:ring-primary"
        />
        <label htmlFor="registrationEnabled" className="text-sm font-medium text-foreground">
          Enable user registration
        </label>
      </div>

      <div className="flex items-center space-x-3">
        <input
          type="checkbox"
          id="emailVerificationRequired"
          checked={settings.emailVerificationRequired}
          onChange={(e) => handleInputChange('emailVerificationRequired', e.target.checked)}
          className="text-primary focus:ring-primary"
        />
        <label htmlFor="emailVerificationRequired" className="text-sm font-medium text-foreground">
          Require email verification for new users
        </label>
      </div>

      {lastSaved && (
        <div className="bg-success/10 border border-success/20 rounded-lg p-4">
          <p className="text-success text-sm">
            <Icon name="CheckCircle" size={16} className="inline mr-2" />
            Last saved: {lastSaved.toLocaleString()}
          </p>
        </div>
      )}
    </div>
  );

  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Session Timeout (minutes)</label>
          <Input
            type="number"
            value={settings.sessionTimeout}
            onChange={(e) => handleInputChange('sessionTimeout', parseInt(e.target.value))}
            min="5"
            max="120"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Max Login Attempts</label>
          <Input
            type="number"
            value={settings.maxLoginAttempts}
            onChange={(e) => handleInputChange('maxLoginAttempts', parseInt(e.target.value))}
            min="3"
            max="10"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Account Lockout Duration (minutes)</label>
        <Input
          type="number"
          value={settings.lockoutDuration}
          onChange={(e) => handleInputChange('lockoutDuration', parseInt(e.target.value))}
          min="5"
          max="60"
        />
      </div>

      <div className="flex items-center space-x-3">
        <input
          type="checkbox"
          id="twoFactorRequired"
          checked={settings.twoFactorRequired}
          onChange={(e) => handleInputChange('twoFactorRequired', e.target.checked)}
          className="text-primary focus:ring-primary"
        />
        <label htmlFor="twoFactorRequired" className="text-sm font-medium text-foreground">
          Require two-factor authentication for all users
        </label>
      </div>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <div className="bg-primary/10 border border-primary/20 rounded-lg p-6">
        <h4 className="font-medium text-primary mb-4 flex items-center">
          <Icon name="Megaphone" size={20} className="mr-2" />
          Push Notification to All Users
        </h4>
        <p className="text-sm text-muted-foreground mb-4">
          Send a notification message that will appear in all user dashboards immediately.
        </p>
        <Button onClick={handlePushNotification} className="w-full">
          <Icon name="Send" size={16} className="mr-2" />
          Push Notification to All Users
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="flex items-center space-x-3">
          <input
            type="checkbox"
            id="pushEnabled"
            checked={settings.notificationSettings?.pushEnabled}
            onChange={(e) => handleInputChange('notificationSettings', {
              ...settings.notificationSettings,
              pushEnabled: e.target.checked
            })}
            className="text-primary focus:ring-primary"
          />
          <label htmlFor="pushEnabled" className="text-sm font-medium text-foreground">
            Enable push notifications
          </label>
        </div>

        <div className="flex items-center space-x-3">
          <input
            type="checkbox"
            id="emailEnabled"
            checked={settings.notificationSettings?.emailEnabled}
            onChange={(e) => handleInputChange('notificationSettings', {
              ...settings.notificationSettings,
              emailEnabled: e.target.checked
            })}
            className="text-primary focus:ring-primary"
          />
          <label htmlFor="emailEnabled" className="text-sm font-medium text-foreground">
            Enable email notifications
          </label>
        </div>
      </div>
    </div>
  );

  const renderMaintenanceSettings = () => (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <input
          type="checkbox"
          id="maintenanceMode"
          checked={settings.maintenanceMode}
          onChange={(e) => handleInputChange('maintenanceMode', e.target.checked)}
          className="text-destructive focus:ring-destructive"
        />
        <label htmlFor="maintenanceMode" className="text-sm font-medium text-foreground">
          Enable maintenance mode
        </label>
      </div>

      {settings.maintenanceMode && (
        <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
          <p className="text-destructive text-sm">
            <Icon name="AlertTriangle" size={16} className="inline mr-2" />
            Maintenance mode is enabled. Only administrators can access the site.
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Button 
          className="p-4 h-auto hover:scale-105 transition-transform"
          onClick={handleBackupDatabase}
        >
          <div className="text-center">
            <Icon name="Database" size={24} className="mx-auto mb-2" />
            <div className="font-medium">Backup Database</div>
            <div className="text-xs opacity-75">Create system backup</div>
          </div>
        </Button>

        <Button 
          variant="outline" 
          className="p-4 h-auto hover:scale-105 transition-transform"
          onClick={handleClearCache}
        >
          <div className="text-center">
            <Icon name="RefreshCw" size={24} className="mx-auto mb-2" />
            <div className="font-medium">Clear Cache</div>
            <div className="text-xs text-muted-foreground">Clear system cache</div>
          </div>
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Navigation */}
      <AdminNavigation
        title="Site Settings"
        breadcrumb={[
          { label: "Admin", link: null },
          { label: "Site Settings", link: null }
        ]}
        actions={[
          {
            label: "System Logs",
            icon: "FileText",
            variant: "outline",
            onClick: () => window.location.href = '/admin-system-logs'
          },
          {
            label: "Save Settings",
            icon: "Save",
            variant: "default",
            onClick: handleSave,
            loading: isSaving
          }
        ]}
      />

      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-6">
            <p className="text-muted-foreground">
              Configure and manage platform settings
              {lastSaved && (
                <span className="ml-2 text-success">
                  • Last saved: {lastSaved.toLocaleString()}
                </span>
              )}
            </p>
          </div>

          {/* Settings Tabs */}
          <div className="bg-card border rounded-lg overflow-hidden">
            {/* Tab Navigation */}
            <div className="border-b border-border">
              <nav className="flex space-x-8 p-6">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 pb-2 border-b-2 transition-colors ${
                      activeTab === tab.id
                        ? 'border-primary text-primary'
                        : 'border-transparent text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    <Icon name={tab.icon} size={16} />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>

            {/* Tab Content */}
            <div className="p-6">
              <div className="max-w-4xl">
                {activeTab === 'general' && renderGeneralSettings()}
                {activeTab === 'security' && renderSecuritySettings()}
                {activeTab === 'userauth' && <UserAuthSettings />}
                {activeTab === 'payments' && (
                  <PaymentGatewaySection 
                    isExpanded={expandedSections.paymentGateways}
                    onToggle={() => toggleSection('paymentGateways')}
                  />
                )}
                {activeTab === 'livechat' && <LiveChatSettings />}
                {activeTab === 'notifications' && renderNotificationSettings()}
                {activeTab === 'maintenance' && renderMaintenanceSettings()}
              </div>
            </div>

            {/* Save Button Footer */}
            <div className="border-t border-border p-6 bg-muted/20">
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  Changes will be applied immediately after saving
                </div>
                <Button onClick={handleSave} disabled={isSaving}>
                  {isSaving ? (
                    <>
                      <Icon name="Loader2" size={16} className="animate-spin mr-2" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Icon name="Save" size={16} className="mr-2" />
                      Save All Settings
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSiteSettings;
