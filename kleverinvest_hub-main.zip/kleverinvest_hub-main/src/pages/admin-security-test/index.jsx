import React from 'react';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import AdminNavigation from '../../components/ui/AdminNavigation';
import AdminSecurityTest from '../../components/AdminSecurityTest';
import AdminSecurityMonitor from '../../components/AdminSecurityMonitor';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const AdminSecurityTestPage = () => {
  const { isAdminAuthenticated } = useAdminAuth();
  const navigate = useNavigate();

  // Redirect if not authenticated as admin
  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-secure-login');
    }
  }, [isAdminAuthenticated, navigate]);

  if (!isAdminAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Icon name="Shield" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h1 className="text-xl font-semibold text-foreground mb-2">Admin Access Required</h1>
          <p className="text-muted-foreground mb-4">Please log in with admin credentials to access security tests.</p>
          <Button onClick={() => navigate('/admin-secure-login')}>
            Admin Login
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation />
      <AdminSecurityMonitor />
      
      <div className="pl-4 pr-4 pt-4">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center space-x-3 mb-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Icon name="Shield" size={16} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Security Test Center</h1>
              <p className="text-muted-foreground">Validate and monitor admin security features</p>
            </div>
          </div>
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Icon name="Clock" size={14} />
              <span>{new Date().toLocaleString()}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Activity" size={14} />
              <span>Live Security Monitoring</span>
            </div>
          </div>
        </div>

        {/* Security Test Component */}
        <AdminSecurityTest />
        
        {/* Additional Security Information */}
        <div className="mt-8 bg-card border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Security Features Overview</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Icon name="Fingerprint" size={16} className="text-blue-500" />
                <h4 className="font-medium text-foreground">Biometric Authentication</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Hardware-based biometric authentication using WebAuthn for passwordless admin access.
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Icon name="Shield" size={16} className="text-green-500" />
                <h4 className="font-medium text-foreground">Device Fingerprinting</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Unique device identification and security level assessment for enhanced protection.
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Icon name="Clock" size={16} className="text-yellow-500" />
                <h4 className="font-medium text-foreground">Rate Limiting</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Progressive lockout system with IP tracking to prevent brute force attacks.
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Icon name="Key" size={16} className="text-purple-500" />
                <h4 className="font-medium text-foreground">JWT Sessions</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Secure JWT tokens with short expiration times and comprehensive session management.
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Icon name="Eye" size={16} className="text-red-500" />
                <h4 className="font-medium text-foreground">Security Monitoring</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Real-time security monitoring with alerts and automatic threat detection.
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Icon name="Lock" size={16} className="text-indigo-500" />
                <h4 className="font-medium text-foreground">Security Headers</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Content Security Policy and other security headers for comprehensive protection.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSecurityTestPage;
