import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const AboutPage = () => {
  const milestones = [
    {
      year: '2020',
      title: 'Company Founded',
      description: 'KleverInvest Hub was established with a vision to democratize investment opportunities.'
    },
    {
      year: '2021',
      title: 'First $10M AUM',
      description: 'Reached our first major milestone of $10 million in assets under management.'
    },
    {
      year: '2022',
      title: 'International Expansion',
      description: 'Expanded operations to serve clients across 15 countries worldwide.'
    },
    {
      year: '2023',
      title: 'AI-Powered Trading',
      description: 'Introduced advanced AI algorithms for optimized portfolio management.'
    },
    {
      year: '2024',
      title: '$100M AUM Achievement',
      description: 'Crossed the $100 million mark in assets under management.'
    }
  ];

  const teamMembers = [
    {
      name: 'Sarah Johnson',
      position: 'CEO & Founder',
      image: '/images/team/sarah.jpg',
      bio: 'Former Goldman Sachs VP with 15+ years in investment management.'
    },
    {
      name: 'Michael Chen',
      position: 'CTO',
      image: '/images/team/michael.jpg',
      bio: 'Ex-Google engineer specializing in fintech and blockchain technology.'
    },
    {
      name: 'David Rodriguez',
      position: 'Head of Trading',
      image: '/images/team/david.jpg',
      bio: 'Veteran trader with expertise in cryptocurrency and traditional markets.'
    },
    {
      name: 'Emily Wang',
      position: 'Head of Risk Management',
      image: '/images/team/emily.jpg',
      bio: 'Former JP Morgan risk analyst with deep expertise in portfolio optimization.'
    }
  ];

  const achievements = [
    {
      icon: 'Award',
      title: 'Industry Recognition',
      description: 'Winner of Best Fintech Innovation Award 2023'
    },
    {
      icon: 'Shield',
      title: 'Security First',
      description: 'Bank-grade security with multi-layer encryption'
    },
    {
      icon: 'Globe',
      title: 'Global Reach',
      description: 'Serving clients in 15+ countries worldwide'
    },
    {
      icon: 'TrendingUp',
      title: 'Proven Returns',
      description: 'Average annual returns of 18.5% over 4 years'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-white">
        <div className="max-w-7xl mx-auto px-6 py-20">
          <div className="text-center">
            <h1 className="text-5xl font-bold mb-6">About KleverInvest Hub</h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto mb-8">
              We're revolutionizing investment management through cutting-edge technology, 
              transparent practices, and unwavering commitment to our clients' financial success.
            </p>
            <div className="flex justify-center space-x-4">
              <Button variant="secondary" size="lg">
                <Icon name="Download" size={20} />
                Download Brochure
              </Button>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-primary">
                <Icon name="MessageCircle" size={20} />
                Contact Us
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Mission & Vision */}
      <div className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-6">Our Mission</h2>
              <p className="text-lg text-muted-foreground mb-8">
                To democratize access to sophisticated investment strategies and provide every investor 
                with the tools, insights, and opportunities traditionally available only to institutional clients.
              </p>
              <h2 className="text-3xl font-bold text-foreground mb-6">Our Vision</h2>
              <p className="text-lg text-muted-foreground">
                To become the world's most trusted and innovative investment platform, where technology 
                meets expertise to create exceptional financial outcomes for our global community.
              </p>
            </div>
            <div className="bg-card border rounded-lg p-8">
              <h3 className="text-2xl font-bold text-foreground mb-6">Key Statistics</h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">$100M+</div>
                  <div className="text-muted-foreground">Assets Under Management</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-success mb-2">12,000+</div>
                  <div className="text-muted-foreground">Active Investors</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-warning mb-2">18.5%</div>
                  <div className="text-muted-foreground">Average Annual Return</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-accent mb-2">15+</div>
                  <div className="text-muted-foreground">Countries Served</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Company Timeline */}
      <div className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">Our Journey</h2>
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-primary/20"></div>
            
            {milestones.map((milestone, index) => (
              <div key={index} className={`relative flex items-center ${index % 2 === 0 ? 'justify-start' : 'justify-end'} mb-12`}>
                <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                  <div className="bg-card border rounded-lg p-6 shadow-sm">
                    <div className="text-2xl font-bold text-primary mb-2">{milestone.year}</div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">{milestone.title}</h3>
                    <p className="text-muted-foreground">{milestone.description}</p>
                  </div>
                </div>
                {/* Timeline marker */}
                <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-primary rounded-full border-4 border-background"></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Leadership Team */}
      <div className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">Leadership Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-card border rounded-lg p-6 text-center hover:shadow-lg transition-shadow">
                <div className="w-24 h-24 bg-primary/10 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Icon name="User" size={40} className="text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-1">{member.name}</h3>
                <p className="text-primary font-medium mb-3">{member.position}</p>
                <p className="text-sm text-muted-foreground">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Achievements */}
      <div className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">Why Choose Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <div key={index} className="bg-card border rounded-lg p-6 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Icon name={achievement.icon} size={32} className="text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{achievement.title}</h3>
                <p className="text-muted-foreground">{achievement.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-20 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Your Investment Journey?</h2>
          <p className="text-xl text-white/90 mb-8">
            Join thousands of investors who trust KleverInvest Hub with their financial future.
          </p>
          <div className="flex justify-center space-x-4">
            <Link to="/user-login-portal">
              <Button variant="secondary" size="lg">
                <Icon name="LogIn" size={20} />
                Get Started Today
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-primary">
                <Icon name="Phone" size={20} />
                Talk to an Advisor
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
