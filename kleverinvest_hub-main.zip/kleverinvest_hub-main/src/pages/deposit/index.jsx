import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Header from '../../components/ui/Header';
import { bitcoinPaymentAPI, paypalAPI, stripeAPI } from '../../utils/paymentIntegration';

const DepositPage = () => {
  const navigate = useNavigate();
  const { user, isUserAuthenticated } = useUserAuth();
  const [activeMethod, setActiveMethod] = useState('bitcoin');

  // Redirect to user login if not authenticated as user
  useEffect(() => {
    if (!isUserAuthenticated) {
      navigate('/user-login');
    }
  }, [isUserAuthenticated, navigate]);

  // Don't render if not authenticated
  if (!isUserAuthenticated) {
    return null;
  }
  const [amount, setAmount] = useState('');
  const [processing, setProcessing] = useState(false);
  const [paymentData, setPaymentData] = useState(null);
  const [paymentStatus, setPaymentStatus] = useState(null);

  // Payment methods configuration
  const paymentMethods = [
    {
      id: 'bitcoin',
      name: 'Bitcoin',
      icon: 'Bitcoin',
      description: 'Instant deposits with Bitcoin',
      fees: '0% fee',
      processingTime: 'Instant confirmation',
      minAmount: 50,
      maxAmount: 100000,
      available: true
    },
    {
      id: 'paypal',
      name: 'PayPal',
      icon: 'CreditCard',
      description: 'Pay with your PayPal account',
      fees: '3.4% + $0.30',
      processingTime: 'Instant',
      minAmount: 10,
      maxAmount: 10000,
      available: false // Coming soon
    },
    {
      id: 'stripe',
      name: 'Credit Card',
      icon: 'CreditCard',
      description: 'Visa, Mastercard, American Express',
      fees: '2.9% + $0.30',
      processingTime: 'Instant',
      minAmount: 25,
      maxAmount: 25000,
      available: false // Coming soon
    },
    {
      id: 'bank',
      name: 'Bank Transfer',
      icon: 'Building2',
      description: 'Direct bank transfer',
      fees: '0% fee',
      processingTime: '1-3 business days',
      minAmount: 100,
      maxAmount: 50000,
      available: false // Manual process
    }
  ];

  const currentMethod = paymentMethods.find(m => m.id === activeMethod);

  // Handle deposit creation
  const handleCreateDeposit = async () => {
    if (!amount || amount < currentMethod.minAmount) {
      alert(`Minimum deposit amount is $${currentMethod.minAmount}`);
      return;
    }

    if (amount > currentMethod.maxAmount) {
      alert(`Maximum deposit amount is $${currentMethod.maxAmount.toLocaleString()}`);
      return;
    }

    setProcessing(true);

    try {
      let result;
      
      switch (activeMethod) {
        case 'bitcoin':
          result = await bitcoinPaymentAPI.createPayment(amount, 'USD');
          break;
        case 'paypal':
          result = await paypalAPI.createPayment(amount, 'USD');
          break;
        case 'stripe':
          result = await stripeAPI.createPaymentIntent(amount, 'USD');
          break;
        default:
          throw new Error('Unsupported payment method');
      }

      if (result.success) {
        setPaymentData(result.data);
        setPaymentStatus('created');
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      alert(`Error creating deposit: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  // Handle payment confirmation (for demo purposes)
  const handleConfirmPayment = async () => {
    setProcessing(true);
    
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setPaymentStatus('completed');
      
      alert(`Deposit successful!\n\nAmount: $${amount}\nMethod: ${currentMethod.name}\nTransaction ID: ${paymentData.paymentId}\n\nFunds will be added to your account shortly.`);
      
      // Reset form
      setAmount('');
      setPaymentData(null);
      setPaymentStatus(null);
      
    } catch (error) {
      alert(`Payment failed: ${error.message}`);
      setPaymentStatus('failed');
    } finally {
      setProcessing(false);
    }
  };

  // Copy address to clipboard
  const copyAddress = () => {
    if (paymentData?.address) {
      navigator.clipboard.writeText(paymentData.address);
      alert('Bitcoin address copied to clipboard!');
    }
  };

  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      navigate('/login');
    }
  }, [user, navigate]);

  if (!user) return null;

  const renderPaymentForm = () => {
    if (paymentStatus === 'created' && activeMethod === 'bitcoin') {
      return (
        <div className="bg-card border rounded-lg p-6">
          <div className="text-center mb-6">
            <Icon name="Bitcoin" size={48} className="text-orange-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">Send Bitcoin Payment</h3>
            <p className="text-muted-foreground">Send exactly {paymentData.btcAmount} BTC to the address below</p>
          </div>

          <div className="space-y-4">
            {/* QR Code */}
            <div className="text-center">
              <img
                src={paymentData.qrCode}
                alt="Bitcoin QR Code"
                className="mx-auto border rounded-lg"
              />
              <p className="text-xs text-muted-foreground mt-2">Scan with your Bitcoin wallet</p>
            </div>

            {/* Payment Details */}
            <div className="bg-muted/30 p-4 rounded-lg space-y-3">
              <div>
                <label className="text-sm font-medium text-foreground">Bitcoin Address</label>
                <div className="flex space-x-2 mt-1">
                  <div className="flex-1 p-2 bg-background border rounded text-sm font-mono break-all">
                    {paymentData.address}
                  </div>
                  <Button variant="outline" size="sm" onClick={copyAddress}>
                    <Icon name="Copy" size={16} />
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground">Amount (BTC)</label>
                  <div className="p-2 bg-background border rounded text-sm font-mono">
                    {paymentData.btcAmount}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Amount (USD)</label>
                  <div className="p-2 bg-background border rounded text-sm font-mono">
                    ${paymentData.amount.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>

            {/* Instructions */}
            <div className="bg-primary/10 p-4 rounded-lg">
              <h4 className="font-medium text-foreground mb-2">Payment Instructions</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Send exactly {paymentData.btcAmount} BTC to the address above</li>
                <li>• Payment will be confirmed after {paymentData.confirmationsRequired} confirmations</li>
                <li>• Do not send any other cryptocurrency to this address</li>
                <li>• This payment expires in 30 minutes</li>
              </ul>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3">
              <Button 
                onClick={handleConfirmPayment}
                disabled={processing}
                className="flex-1"
              >
                {processing ? 'Processing...' : 'I have sent the payment'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setPaymentData(null);
                  setPaymentStatus(null);
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="bg-card border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-6">Make a Deposit</h3>
        
        <div className="space-y-6">
          {/* Amount Input */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Deposit Amount (USD)
            </label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder={`Minimum $${currentMethod.minAmount}`}
              min={currentMethod.minAmount}
              max={currentMethod.maxAmount}
            />
            <div className="text-xs text-muted-foreground mt-1">
              Range: ${currentMethod.minAmount} - ${currentMethod.maxAmount.toLocaleString()}
            </div>
          </div>

          {/* Payment Methods */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Payment Method
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {paymentMethods.map(method => (
                <button
                  key={method.id}
                  onClick={() => setActiveMethod(method.id)}
                  disabled={!method.available}
                  className={`p-4 rounded-lg border text-left transition-colors ${
                    activeMethod === method.id
                      ? 'border-primary bg-primary/10'
                      : method.available
                      ? 'border-border hover:border-primary/50'
                      : 'border-border opacity-50 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-center space-x-3 mb-2">
                    <Icon name={method.icon} size={20} className={
                      method.id === 'bitcoin' ? 'text-orange-500' : 'text-muted-foreground'
                    } />
                    <div className="flex-1">
                      <div className="font-medium text-foreground">{method.name}</div>
                      {!method.available && (
                        <div className="text-xs text-warning">Coming Soon</div>
                      )}
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground mb-1">{method.description}</div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{method.fees}</span>
                    <span>{method.processingTime}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Method Details */}
          <div className="bg-muted/30 p-4 rounded-lg">
            <h4 className="font-medium text-foreground mb-2">{currentMethod.name} Details</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Processing Fee:</span>
                <span className="ml-2 font-medium">{currentMethod.fees}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Processing Time:</span>
                <span className="ml-2 font-medium">{currentMethod.processingTime}</span>
              </div>
            </div>
          </div>

          {/* Create Deposit Button */}
          <Button
            onClick={handleCreateDeposit}
            disabled={!amount || !currentMethod.available || processing}
            className="w-full"
          >
            {processing ? (
              <>
                <Icon name="Loader2" size={16} className="mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Icon name="ArrowDownCircle" size={16} className="mr-2" />
                Create Deposit Request
              </>
            )}
          </Button>
        </div>
      </div>
    );
  };

  return (
    <>
      <Helmet>
        <title>Make Deposit - KleverInvest Hub</title>
        <meta name="description" content="Deposit funds to your KleverInvest account" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />
        
        <div className="pt-16">
          <div className="container mx-auto px-4 py-8">
            
            {/* Header */}
            <div className="mb-8">
              <div className="flex items-center space-x-2 mb-4">
                <Button variant="outline" size="sm" onClick={() => navigate('/user-dashboard')}>
                  <Icon name="ArrowLeft" size={16} className="mr-2" />
                  Back to Dashboard
                </Button>
              </div>
              <h1 className="text-3xl font-bold text-foreground">Make a Deposit</h1>
              <p className="text-muted-foreground">Add funds to your investment account</p>
            </div>

            {/* Main Content */}
            <div className="max-w-2xl mx-auto">
              {renderPaymentForm()}

              {/* Security Notice */}
              <div className="mt-8 bg-card border rounded-lg p-6">
                <div className="flex items-start space-x-3">
                  <Icon name="Shield" size={20} className="text-success mt-0.5" />
                  <div>
                    <h4 className="font-medium text-foreground mb-2">Security & Privacy</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• All transactions are encrypted and secure</li>
                      <li>• We never store your payment information</li>
                      <li>��� Deposits are processed automatically</li>
                      <li>• 24/7 fraud monitoring and protection</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Support */}
              <div className="mt-6 text-center">
                <p className="text-sm text-muted-foreground">
                  Need help? Contact our{' '}
                  <button 
                    onClick={() => navigate('/support-chat-system')}
                    className="text-primary hover:underline"
                  >
                    support team
                  </button>
                  {' '}for assistance.
                </p>
              </div>
            </div>

          </div>
        </div>
      </div>
    </>
  );
};

export default DepositPage;
