import React from 'react';
import { Helmet } from 'react-helmet';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import { useUserAuth } from '../../contexts/UserAuthContext';

const UserDashboardTest = () => {
  const { user, isUserAuthenticated } = useUserAuth();

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Dashboard Test - KleverInvest</title>
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-4">User Dashboard Test</h1>
            <p className="text-muted-foreground">
              This is a test version of the dashboard without KYC restrictions
            </p>
          </div>

          <div className="bg-card border rounded-lg p-6 mb-6">
            <h2 className="text-lg font-semibold mb-4">Authentication Status</h2>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Icon 
                  name={isUserAuthenticated ? "CheckCircle" : "XCircle"} 
                  className={isUserAuthenticated ? "text-success" : "text-destructive"} 
                />
                <span>Authenticated: {isUserAuthenticated ? 'Yes' : 'No'}</span>
              </div>
              {user && (
                <div className="space-y-1 text-sm">
                  <div>Name: {user.name}</div>
                  <div>Email: {user.email}</div>
                  <div>Role: {user.role}</div>
                  <div>KYC Status: {user.kycStatus}</div>
                </div>
              )}
            </div>
          </div>

          {isUserAuthenticated ? (
            <div className="bg-success/10 border border-success/20 rounded-lg p-6">
              <div className="flex items-center space-x-2 mb-4">
                <Icon name="CheckCircle" className="text-success" />
                <h2 className="text-lg font-semibold text-success">Dashboard Access Available</h2>
              </div>
              <p className="text-muted-foreground mb-4">
                Your authentication is working correctly. You should be able to access the full dashboard.
              </p>
              <div className="flex space-x-3">
                <Button onClick={() => window.location.href = '/user-dashboard'}>
                  <Icon name="ExternalLink" size={16} className="mr-2" />
                  Go to Full Dashboard
                </Button>
                <Button variant="outline" onClick={() => window.location.href = '/user-profile-settings'}>
                  <Icon name="Settings" size={16} className="mr-2" />
                  Profile Settings
                </Button>
              </div>
            </div>
          ) : (
            <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-6">
              <div className="flex items-center space-x-2 mb-4">
                <Icon name="AlertTriangle" className="text-destructive" />
                <h2 className="text-lg font-semibold text-destructive">Authentication Required</h2>
              </div>
              <p className="text-muted-foreground mb-4">
                You need to log in to access the dashboard features.
              </p>
              <div className="flex space-x-3">
                <Button onClick={() => window.location.href = '/user-login'}>
                  <Icon name="LogIn" size={16} className="mr-2" />
                  Login
                </Button>
                <Button variant="outline" onClick={() => window.location.href = '/fix-403'}>
                  <Icon name="Wrench" size={16} className="mr-2" />
                  Fix Access Issues
                </Button>
              </div>
            </div>
          )}

          <div className="text-center mt-8">
            <div className="flex justify-center space-x-4">
              <Button variant="outline" onClick={() => window.location.href = '/auth-debug'}>
                <Icon name="Bug" size={16} className="mr-2" />
                Debug Authentication
              </Button>
              <Button variant="outline" onClick={() => window.location.href = '/'}>
                <Icon name="Home" size={16} className="mr-2" />
                Home
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboardTest;
