import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '../home-landing-page/components/Header';
import Footer from '../home-landing-page/components/Footer';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const TestimonialsPage = () => {
  const [activeFilter, setActiveFilter] = useState('all');

  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "Tech Entrepreneur",
      location: "San Francisco, CA",
      image: "/api/placeholder/80/80",
      rating: 5,
      category: "investment",
      text: "KleverInvest has completely transformed my approach to cryptocurrency investing. The platform's security measures and professional guidance have helped me achieve a 23% return in just 6 months.",
      investment: "$50,000",
      returns: "23%",
      duration: "6 months"
    },
    {
      id: 2,
      name: "Michael Chen",
      role: "Financial Advisor",
      location: "New York, NY",
      image: "/api/placeholder/80/80",
      rating: 5,
      category: "trading",
      text: "The trading dashboard is incredibly intuitive. Real-time analytics and automated tools have increased my trading efficiency by 40%. Best platform I've used in 15 years of trading.",
      investment: "$125,000",
      returns: "31%",
      duration: "1 year"
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      role: "Small Business Owner",
      location: "Austin, TX",
      image: "/api/placeholder/80/80",
      rating: 5,
      category: "security",
      text: "Security was my biggest concern when starting crypto investing. KleverInvest's bank-grade encryption and insurance coverage gave me the confidence to invest my retirement savings.",
      investment: "$75,000",
      returns: "18%",
      duration: "8 months"
    },
    {
      id: 4,
      name: "David Thompson",
      role: "Software Engineer",
      location: "Seattle, WA",
      image: "/api/placeholder/80/80",
      rating: 5,
      category: "support",
      text: "Customer support is outstanding. 24/7 availability and expert knowledge. They helped me navigate market volatility and protected my investments during uncertain times.",
      investment: "$35,000",
      returns: "27%",
      duration: "4 months"
    },
    {
      id: 5,
      name: "Jennifer Walsh",
      role: "Marketing Director",
      location: "Boston, MA",
      image: "/api/placeholder/80/80",
      rating: 5,
      category: "investment",
      text: "Started with just $1,000 to test the platform. The educational resources and guided investment plans made it easy for a beginner like me to grow my portfolio confidently.",
      investment: "$25,000",
      returns: "15%",
      duration: "3 months"
    },
    {
      id: 6,
      name: "Robert Kim",
      role: "Investment Banker",
      location: "Chicago, IL",
      image: "/api/placeholder/80/80",
      rating: 5,
      category: "trading",
      text: "Professional-grade tools with institutional-level security. The API integration and advanced analytics rival platforms costing 10x more. Exceptional value proposition.",
      investment: "$200,000",
      returns: "42%",
      duration: "2 years"
    }
  ];

  const filters = [
    { id: 'all', label: 'All Reviews', count: testimonials.length },
    { id: 'investment', label: 'Investment', count: testimonials.filter(t => t.category === 'investment').length },
    { id: 'trading', label: 'Trading', count: testimonials.filter(t => t.category === 'trading').length },
    { id: 'security', label: 'Security', count: testimonials.filter(t => t.category === 'security').length },
    { id: 'support', label: 'Support', count: testimonials.filter(t => t.category === 'support').length }
  ];

  const filteredTestimonials = activeFilter === 'all' 
    ? testimonials 
    : testimonials.filter(t => t.category === activeFilter);

  const stats = [
    { label: 'Happy Customers', value: '50,000+', icon: 'Users' },
    { label: 'Average Rating', value: '4.9/5', icon: 'Star' },
    { label: 'Success Rate', value: '96%', icon: 'TrendingUp' },
    { label: 'Countries Served', value: '50+', icon: 'Globe' }
  ];

  return (
    <>
      <Helmet>
        <title>Testimonials - KleverInvest Hub | Customer Success Stories</title>
        <meta 
          name="description" 
          content="Read real customer testimonials and success stories from KleverInvest Hub users. Discover how our platform has helped investors achieve their financial goals." 
        />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />
        
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-accent text-white py-20 pt-32">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Success Stories
              </h1>
              <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8">
                Discover how thousands of investors have achieved their financial goals with KleverInvest Hub's professional investment platform.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-card/30">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon name={stat.icon} size={24} className="text-primary" />
                  </div>
                  <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
                    {stat.value}
                  </h3>
                  <p className="text-muted-foreground">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Filter Tabs */}
        <section className="py-8 border-b border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap justify-center gap-4">
              {filters.map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setActiveFilter(filter.id)}
                  className={`px-6 py-3 rounded-full font-medium transition-all ${
                    activeFilter === filter.id
                      ? 'bg-primary text-white shadow-lg'
                      : 'bg-muted text-muted-foreground hover:bg-primary/10'
                  }`}
                >
                  {filter.label} ({filter.count})
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredTestimonials.map((testimonial, index) => (
                <motion.div
                  key={testimonial.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-card border rounded-xl p-6 hover:shadow-lg transition-shadow"
                >
                  {/* Rating Stars */}
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Icon key={i} name="Star" size={16} className="text-yellow-400 fill-current" />
                    ))}
                  </div>

                  {/* Testimonial Text */}
                  <blockquote className="text-foreground mb-6 leading-relaxed">
                    "{testimonial.text}"
                  </blockquote>

                  {/* Performance Metrics */}
                  <div className="grid grid-cols-3 gap-4 mb-6 p-4 bg-muted/50 rounded-lg">
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">Investment</p>
                      <p className="font-semibold text-foreground">{testimonial.investment}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">Returns</p>
                      <p className="font-semibold text-success">{testimonial.returns}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">Duration</p>
                      <p className="font-semibold text-foreground">{testimonial.duration}</p>
                    </div>
                  </div>

                  {/* Author Info */}
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mr-4">
                      <span className="text-white font-semibold">
                        {testimonial.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{testimonial.name}</h4>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.location}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-primary to-accent text-white">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Ready to Write Your Success Story?
              </h2>
              <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
                Join thousands of successful investors who have achieved their financial goals with KleverInvest Hub.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="gradient-gold text-black font-semibold px-8"
                  onClick={() => window.location.href = '/signup'}
                >
                  Start Investing Today
                  <Icon name="ArrowRight" size={20} className="ml-2" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-white text-white hover:bg-white/10"
                  onClick={() => window.location.href = '/contact'}
                >
                  Schedule Consultation
                  <Icon name="Calendar" size={20} className="ml-2" />
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default TestimonialsPage;
