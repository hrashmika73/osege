import React from 'react';
import AdminLoginInfo from '../../components/AdminLoginInfo';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const AdminLoginInfoPage = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <div className="bg-card border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="Shield" size={16} className="text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-foreground">KleverInvest Hub</h1>
                <p className="text-xs text-muted-foreground">Admin Access Center</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <Button
                onClick={() => window.location.href = '/'}
                variant="outline"
                size="sm"
              >
                <Icon name="Home" size={14} className="mr-2" />
                Home
              </Button>
              <Button
                onClick={() => window.location.href = '/admin-secure-login'}
                className="bg-red-600 hover:bg-red-700 text-white"
                size="sm"
              >
                <Icon name="LogIn" size={14} className="mr-2" />
                Admin Login
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="py-8">
        <AdminLoginInfo />
      </div>
      
      {/* Footer */}
      <div className="bg-muted/30 border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-center space-x-6 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Icon name="Shield" size={14} />
              <span>Secure Admin Access</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Lock" size={14} />
              <span>Enterprise Security</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Activity" size={14} />
              <span>Real-time Monitoring</span>
            </div>
          </div>
          <div className="text-center text-xs text-muted-foreground mt-2">
            © 2024 KleverInvest Hub - Administrative Portal
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminLoginInfoPage;
