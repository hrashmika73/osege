import React from 'react';
import { ArrowDownCircle, ArrowUpCircle, TrendingUp, DollarSign, Clock, CheckCircle, XCircle, ExternalLink, Copy } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from 'utils/cn';

const TransactionCard = ({ transaction, onClick }) => {
  const getTypeIcon = (type) => {
    switch (type) {
      case 'deposit':
        return <ArrowDownCircle className="h-5 w-5 text-green-600" />;
      case 'withdrawal':
        return <ArrowUpCircle className="h-5 w-5 text-red-600" />;
      case 'investment':
        return <TrendingUp className="h-5 w-5 text-blue-600" />;
      case 'earning':
        return <DollarSign className="h-5 w-5 text-purple-600" />;
      default:
        return <Clock className="h-5 w-5 text-gray-600" />;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getAmountColor = (type) => {
    switch (type) {
      case 'deposit': case'earning':
        return 'text-green-600';
      case 'withdrawal':
        return 'text-red-600';
      case 'investment':
        return 'text-blue-600';
      default:
        return 'text-gray-900';
    }
  };

  const getAmountPrefix = (type) => {
    switch (type) {
      case 'deposit': case'earning':
        return '+';
      case 'withdrawal':
        return '-';
      default:
        return '';
    }
  };

  const copyToClipboard = (text, e) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    // You could add a toast notification here
  };

  const openBlockchainExplorer = (hash, e) => {
    e.stopPropagation();
    // This would open the appropriate blockchain explorer
    window.open(`https://blockchain.info/tx/${hash}`, '_blank');
  };

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow cursor-pointer p-4"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          {getTypeIcon(transaction.type)}
          <div>
            <h3 className="font-medium text-gray-900 capitalize">
              {transaction.type}
            </h3>
            <p className="text-sm text-gray-600">
              {format(new Date(transaction.timestamp), 'MMM dd, yyyy HH:mm')}
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {getStatusIcon(transaction.status)}
          <span className={cn(
            "px-2 py-1 text-xs font-medium rounded-full capitalize",
            getStatusColor(transaction.status)
          )}>
            {transaction.status}
          </span>
        </div>
      </div>

      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="font-medium text-gray-900">
            {transaction.cryptocurrency}
          </span>
          <span className={cn(
            "text-lg font-semibold",
            getAmountColor(transaction.type)
          )}>
            {getAmountPrefix(transaction.type)}{transaction.amount}
          </span>
        </div>
        
        <div className="text-right">
          <p className="text-sm text-gray-600">USD Value</p>
          <p className="font-medium text-gray-900">
            ${transaction.usdValue?.toLocaleString()}
          </p>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">Transaction ID</span>
          <div className="flex items-center gap-1">
            <span className="font-mono text-gray-900">
              {transaction.id}
            </span>
            <button
              onClick={(e) => copyToClipboard(transaction.id, e)}
              className="p-1 hover:bg-gray-100 rounded transition-colors"
            >
              <Copy className="h-3 w-3 text-gray-400" />
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">Hash</span>
          <div className="flex items-center gap-1">
            <span className="font-mono text-gray-900">
              {transaction.hash?.slice(0, 10)}...{transaction.hash?.slice(-6)}
            </span>
            <button
              onClick={(e) => copyToClipboard(transaction.hash, e)}
              className="p-1 hover:bg-gray-100 rounded transition-colors"
            >
              <Copy className="h-3 w-3 text-gray-400" />
            </button>
            <button
              onClick={(e) => openBlockchainExplorer(transaction.hash, e)}
              className="p-1 hover:bg-gray-100 rounded transition-colors"
            >
              <ExternalLink className="h-3 w-3 text-gray-400" />
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">Network Fee</span>
          <span className="text-gray-900">
            {transaction.networkFee} {transaction.cryptocurrency}
          </span>
        </div>

        {transaction.status === 'pending' && (
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Confirmations</span>
            <span className="text-gray-900">
              {transaction.confirmations}/6
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default TransactionCard;