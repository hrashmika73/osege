import React from 'react';
import { X, Copy, ExternalLink, ArrowDownCircle, ArrowUpCircle, TrendingUp, DollarSign, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from 'utils/cn';

const TransactionDetailModal = ({ isOpen, onClose, transaction }) => {
  if (!isOpen || !transaction) return null;

  const getTypeIcon = (type) => {
    switch (type) {
      case 'deposit':
        return <ArrowDownCircle className="h-6 w-6 text-green-600" />;
      case 'withdrawal':
        return <ArrowUpCircle className="h-6 w-6 text-red-600" />;
      case 'investment':
        return <TrendingUp className="h-6 w-6 text-blue-600" />;
      case 'earning':
        return <DollarSign className="h-6 w-6 text-purple-600" />;
      default:
        return <Clock className="h-6 w-6 text-gray-600" />;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-600" />;
      case 'failed':
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return <AlertCircle className="h-5 w-5 text-gray-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'failed':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getAmountColor = (type) => {
    switch (type) {
      case 'deposit': case'earning':
        return 'text-green-600';
      case 'withdrawal':
        return 'text-red-600';
      case 'investment':
        return 'text-blue-600';
      default:
        return 'text-gray-900';
    }
  };

  const getAmountPrefix = (type) => {
    switch (type) {
      case 'deposit': case'earning':
        return '+';
      case 'withdrawal':
        return '-';
      default:
        return '';
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    // You could add a toast notification here
  };

  const openBlockchainExplorer = (hash) => {
    window.open(`https://blockchain.info/tx/${hash}`, '_blank');
  };

  const DetailRow = ({ label, value, copyable = false, linkable = false, onLinkClick }) => (
    <div className="flex justify-between items-start py-3 border-b border-gray-100 last:border-b-0">
      <span className="text-sm text-gray-600 font-medium">{label}</span>
      <div className="flex items-center gap-2 text-right">
        <span className="text-sm text-gray-900 font-mono break-all">
          {value}
        </span>
        {copyable && (
          <button
            onClick={() => copyToClipboard(value)}
            className="p-1 hover:bg-gray-100 rounded transition-colors"
            title="Copy to clipboard"
          >
            <Copy className="h-3 w-3 text-gray-400" />
          </button>
        )}
        {linkable && (
          <button
            onClick={onLinkClick}
            className="p-1 hover:bg-gray-100 rounded transition-colors"
            title="View on blockchain explorer"
          >
            <ExternalLink className="h-3 w-3 text-gray-400" />
          </button>
        )}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            {getTypeIcon(transaction.type)}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 capitalize">
                {transaction.type} Details
              </h2>
              <p className="text-sm text-gray-600">
                Transaction ID: {transaction.id}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-400" />
          </button>
        </div>

        {/* Status Banner */}
        <div className={cn(
          "p-4 border-b border-gray-200",
          transaction.status === 'completed' ? 'bg-green-50' :
          transaction.status === 'pending' ? 'bg-yellow-50' : 'bg-red-50'
        )}>
          <div className="flex items-center gap-2">
            {getStatusIcon(transaction.status)}
            <span className={cn(
              "px-3 py-1 text-sm font-medium rounded-full border capitalize",
              getStatusColor(transaction.status)
            )}>
              {transaction.status}
            </span>
            {transaction.status === 'pending' && (
              <span className="text-sm text-gray-600">
                {transaction.confirmations}/6 confirmations
              </span>
            )}
          </div>
        </div>

        {/* Main Content */}
        <div className="p-6 space-y-6">
          {/* Amount Section */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="text-center">
              <div className="text-sm text-gray-600 mb-1">Amount</div>
              <div className={cn(
                "text-3xl font-bold mb-2",
                getAmountColor(transaction.type)
              )}>
                {getAmountPrefix(transaction.type)}{transaction.amount} {transaction.cryptocurrency}
              </div>
              <div className="text-lg text-gray-900">
                ${transaction.usdValue?.toLocaleString()} USD
              </div>
              <div className="text-sm text-gray-600 mt-1">
                Rate: 1 {transaction.cryptocurrency} = ${transaction.exchangeRate?.toLocaleString()}
              </div>
            </div>
          </div>

          {/* Transaction Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Transaction Information</h3>
            
            <div className="bg-white border border-gray-200 rounded-lg divide-y divide-gray-100">
              <DetailRow
                label="Date & Time"
                value={format(new Date(transaction.timestamp), 'MMMM dd, yyyy at HH:mm:ss')}
              />
              
              <DetailRow
                label="Transaction Hash"
                value={transaction.hash}
                copyable={true}
                linkable={true}
                onLinkClick={() => openBlockchainExplorer(transaction.hash)}
              />
              
              <DetailRow
                label="From Address"
                value={transaction.from}
                copyable={true}
              />
              
              <DetailRow
                label="To Address"
                value={transaction.to}
                copyable={true}
              />
              
              <DetailRow
                label="Network Fee"
                value={`${transaction.networkFee} ${transaction.cryptocurrency}`}
              />
              
              {transaction.status === 'completed' && (
                <DetailRow
                  label="Confirmations"
                  value={`${transaction.confirmations}/6 Required`}
                />
              )}
            </div>
          </div>

          {/* Account Impact */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Account Impact</h3>
            
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-gray-600">Balance Change</div>
                  <div className={cn(
                    "text-lg font-semibold",
                    getAmountColor(transaction.type)
                  )}>
                    {getAmountPrefix(transaction.type)}{transaction.amount} {transaction.cryptocurrency}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">USD Impact</div>
                  <div className={cn(
                    "text-lg font-semibold",
                    getAmountColor(transaction.type)
                  )}>
                    {getAmountPrefix(transaction.type)}${transaction.usdValue?.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Information */}
          {transaction.status === 'pending' && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-yellow-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-yellow-800">Transaction Pending</h4>
                  <p className="text-sm text-yellow-700 mt-1">
                    Your transaction is currently being processed by the network. 
                    It typically takes 10-30 minutes to complete depending on network congestion.
                  </p>
                </div>
              </div>
            </div>
          )}

          {transaction.status === 'failed' && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <XCircle className="h-5 w-5 text-red-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-red-800">Transaction Failed</h4>
                  <p className="text-sm text-red-700 mt-1">
                    This transaction failed to complete. Common reasons include insufficient balance, 
                    network congestion, or invalid addresses. Contact support if you need assistance.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gray-50">
          <div className="text-sm text-gray-600">
            Need help? <a href="/support-chat-system" className="text-blue-600 hover:text-blue-700">Contact Support</a>
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={() => openBlockchainExplorer(transaction.hash)}
              className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <ExternalLink className="h-4 w-4" />
              View on Explorer
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransactionDetailModal;