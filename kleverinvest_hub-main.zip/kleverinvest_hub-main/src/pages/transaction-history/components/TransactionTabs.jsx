import React from 'react';
import { ArrowDownCircle, ArrowUpCircle, TrendingUp, DollarSign } from 'lucide-react';
import { cn } from 'utils/cn';
import Icon from '../../../components/AppIcon';


const TransactionTabs = ({ activeTab, onTabChange, counts }) => {
  const tabs = [
    {
      id: 'all',
      label: 'All Transactions',
      icon: null,
      count: counts?.all || 0
    },
    {
      id: 'deposits',
      label: 'Deposits',
      icon: ArrowDownCircle,
      count: counts?.deposits || 0,
      color: 'text-green-600'
    },
    {
      id: 'withdrawals',
      label: 'Withdrawals',
      icon: ArrowUpCircle,
      count: counts?.withdrawals || 0,
      color: 'text-red-600'
    },
    {
      id: 'investments',
      label: 'Investments',
      icon: TrendingUp,
      count: counts?.investments || 0,
      color: 'text-blue-600'
    },
    {
      id: 'earnings',
      label: 'Earnings',
      icon: DollarSign,
      count: counts?.earnings || 0,
      color: 'text-purple-600'
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm border mb-6">
      <div className="border-b border-gray-200">
        <nav className="flex overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={cn(
                  "flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-medium whitespace-nowrap transition-colors",
                  isActive
                    ? "border-blue-600 text-blue-600" :"border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300"
                )}
              >
                {Icon && (
                  <Icon className={cn("h-4 w-4", isActive ? "text-blue-600" : tab.color)} />
                )}
                <span>{tab.label}</span>
                {tab.count > 0 && (
                  <span className={cn(
                    "px-2 py-0.5 text-xs rounded-full",
                    isActive
                      ? "bg-blue-100 text-blue-600" :"bg-gray-100 text-gray-600"
                  )}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};

export default TransactionTabs;