import React, { useState } from 'react';
import { X, Download, Calendar, Filter, FileText, CheckCircle } from 'lucide-react';
import { format } from 'date-fns';


const ExportModal = ({ isOpen, onClose, transactions }) => {
  const [exportConfig, setExportConfig] = useState({
    format: 'csv',
    dateRange: 'all',
    customStartDate: '',
    customEndDate: '',
    includeFields: {
      transactionId: true,
      timestamp: true,
      type: true,
      cryptocurrency: true,
      amount: true,
      usdValue: true,
      status: true,
      hash: true,
      networkFee: true,
      addresses: false,
      confirmations: false
    },
    filterBy: {
      status: 'all',
      type: 'all',
      cryptocurrency: 'all'
    }
  });
  const [isExporting, setIsExporting] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);

  const handleConfigChange = (section, key, value) => {
    setExportConfig(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: value
      }
    }));
  };

  const handleDirectConfigChange = (key, value) => {
    setExportConfig(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const getFilteredTransactions = () => {
    return transactions.filter(transaction => {
      // Date filtering
      if (exportConfig.dateRange === 'custom') {
        const txDate = new Date(transaction.timestamp);
        const startDate = exportConfig.customStartDate ? new Date(exportConfig.customStartDate) : null;
        const endDate = exportConfig.customEndDate ? new Date(exportConfig.customEndDate) : null;
        
        if (startDate && txDate < startDate) return false;
        if (endDate && txDate > endDate) return false;
      }

      // Status filtering
      if (exportConfig.filterBy.status !== 'all' && transaction.status !== exportConfig.filterBy.status) {
        return false;
      }

      // Type filtering
      if (exportConfig.filterBy.type !== 'all' && transaction.type !== exportConfig.filterBy.type) {
        return false;
      }

      // Cryptocurrency filtering
      if (exportConfig.filterBy.cryptocurrency !== 'all' && transaction.cryptocurrency !== exportConfig.filterBy.cryptocurrency) {
        return false;
      }

      return true;
    });
  };

  const generateCSV = (data) => {
    const fields = exportConfig.includeFields;
    const headers = [];
    const fieldMap = {
      transactionId: 'Transaction ID',
      timestamp: 'Date & Time',
      type: 'Type',
      cryptocurrency: 'Cryptocurrency',
      amount: 'Amount',
      usdValue: 'USD Value',
      status: 'Status',
      hash: 'Transaction Hash',
      networkFee: 'Network Fee',
      addresses: 'From/To Addresses',
      confirmations: 'Confirmations'
    };

    // Build headers
    Object.keys(fields).forEach(field => {
      if (fields[field]) {
        headers.push(fieldMap[field]);
      }
    });

    // Build rows
    const rows = data.map(transaction => {
      const row = [];
      
      if (fields.transactionId) row.push(transaction.id);
      if (fields.timestamp) row.push(format(new Date(transaction.timestamp), 'yyyy-MM-dd HH:mm:ss'));
      if (fields.type) row.push(transaction.type);
      if (fields.cryptocurrency) row.push(transaction.cryptocurrency);
      if (fields.amount) row.push(transaction.amount);
      if (fields.usdValue) row.push(transaction.usdValue);
      if (fields.status) row.push(transaction.status);
      if (fields.hash) row.push(transaction.hash);
      if (fields.networkFee) row.push(transaction.networkFee);
      if (fields.addresses) row.push(`${transaction.from} -> ${transaction.to}`);
      if (fields.confirmations) row.push(transaction.confirmations);

      return row;
    });

    // Convert to CSV
    const csvContent = [headers, ...rows]
      .map(row => row.map(field => `"${field}"`).join(','))
      .join('\n');

    return csvContent;
  };

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      const filteredData = getFilteredTransactions();
      const csvContent = generateCSV(filteredData);
      
      // Create and download file
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', `transaction-history-${format(new Date(), 'yyyy-MM-dd')}.csv`);
      link.style.visibility = 'hidden';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Simulate processing time
      setTimeout(() => {
        setIsExporting(false);
        setExportComplete(true);
        
        // Auto close after 2 seconds
        setTimeout(() => {
          setExportComplete(false);
          onClose();
        }, 2000);
      }, 1500);
      
    } catch (error) {
      console.error('Export failed:', error);
      setIsExporting(false);
    }
  };

  const filteredCount = getFilteredTransactions().length;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <Download className="h-5 w-5 text-gray-600" />
            <h2 className="text-lg font-semibold text-gray-900">Export Transaction History</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-400" />
          </button>
        </div>

        {exportComplete ? (
          <div className="p-8 text-center">
            <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Export Complete!</h3>
            <p className="text-gray-600">Your transaction history has been downloaded successfully.</p>
          </div>
        ) : (
          <div className="p-6 space-y-6">
            {/* Export Format */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Export Format
              </label>
              <select
                value={exportConfig.format}
                onChange={(e) => handleDirectConfigChange('format', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="csv">CSV (Recommended for Excel/Sheets)</option>
                <option value="pdf">PDF (For printing/viewing)</option>
                <option value="json">JSON (For developers)</option>
              </select>
            </div>

            {/* Date Range */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="inline h-4 w-4 mr-1" />
                Date Range
              </label>
              <select
                value={exportConfig.dateRange}
                onChange={(e) => handleDirectConfigChange('dateRange', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent mb-3"
              >
                <option value="all">All Time</option>
                <option value="today">Today</option>
                <option value="week">This Week</option>
                <option value="month">This Month</option>
                <option value="quarter">This Quarter</option>
                <option value="year">This Year</option>
                <option value="custom">Custom Range</option>
              </select>

              {exportConfig.dateRange === 'custom' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">Start Date</label>
                    <input
                      type="date"
                      value={exportConfig.customStartDate}
                      onChange={(e) => handleDirectConfigChange('customStartDate', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">End Date</label>
                    <input
                      type="date"
                      value={exportConfig.customEndDate}
                      onChange={(e) => handleDirectConfigChange('customEndDate', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Filters */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Filter className="inline h-4 w-4 mr-1" />
                Additional Filters
              </label>
              <div className="grid grid-cols-3 gap-3">
                <select
                  value={exportConfig.filterBy.status}
                  onChange={(e) => handleConfigChange('filterBy', 'status', e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Statuses</option>
                  <option value="completed">Completed</option>
                  <option value="pending">Pending</option>
                  <option value="failed">Failed</option>
                </select>

                <select
                  value={exportConfig.filterBy.type}
                  onChange={(e) => handleConfigChange('filterBy', 'type', e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Types</option>
                  <option value="deposit">Deposits</option>
                  <option value="withdrawal">Withdrawals</option>
                  <option value="investment">Investments</option>
                  <option value="earning">Earnings</option>
                </select>

                <select
                  value={exportConfig.filterBy.cryptocurrency}
                  onChange={(e) => handleConfigChange('filterBy', 'cryptocurrency', e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Cryptos</option>
                  <option value="BTC">Bitcoin</option>
                  <option value="ETH">Ethereum</option>
                  <option value="USDT">Tether</option>
                </select>
              </div>
            </div>

            {/* Include Fields */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <FileText className="inline h-4 w-4 mr-1" />
                Include Fields
              </label>
              <div className="grid grid-cols-2 gap-3">
                {Object.keys(exportConfig.includeFields).map(field => (
                  <label key={field} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={exportConfig.includeFields[field]}
                      onChange={(e) => handleConfigChange('includeFields', field, e.target.checked)}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                    />
                    <span className="text-sm text-gray-700 capitalize">
                      {field.replace(/([A-Z])/g, ' $1').trim()}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Export Summary */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <FileText className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-900">Export Summary</span>
              </div>
              <div className="text-sm text-blue-700">
                <div>Format: {exportConfig.format.toUpperCase()}</div>
                <div>Transactions: {filteredCount}</div>
                <div>Fields: {Object.values(exportConfig.includeFields).filter(Boolean).length}</div>
              </div>
            </div>
          </div>
        )}

        {!exportComplete && (
          <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gray-50">
            <div className="text-sm text-gray-600">
              {filteredCount} transaction{filteredCount !== 1 ? 's' : ''} will be exported
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={onClose}
                disabled={isExporting}
                className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleExport}
                disabled={isExporting || filteredCount === 0}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isExporting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Exporting...
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4" />
                    Export Now
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExportModal;