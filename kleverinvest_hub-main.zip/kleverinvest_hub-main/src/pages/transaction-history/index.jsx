import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { Search, Filter, Download, Clock } from 'lucide-react';
import Header from 'components/ui/Header';
import TransactionTabs from './components/TransactionTabs';
import TransactionCard from './components/TransactionCard';
import TransactionTable from './components/TransactionTable';
import FilterModal from './components/FilterModal';
import TransactionDetailModal from './components/TransactionDetailModal';
import ExportModal from './components/ExportModal';
import { cn } from 'utils/cn';

const TransactionHistory = () => {
  const navigate = useNavigate();
  const { isUserAuthenticated } = useUserAuth();
  const [activeTab, setActiveTab] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [viewMode, setViewMode] = useState('cards'); // 'cards' or 'table'

  // Redirect to user login if not authenticated as user
  useEffect(() => {
    if (!isUserAuthenticated) {
      navigate('/user-login');
    }
  }, [isUserAuthenticated, navigate]);

  // Don't render if not authenticated
  if (!isUserAuthenticated) {
    return null;
  }
  const [filters, setFilters] = useState({
    dateRange: 'all',
    status: 'all',
    type: 'all',
    cryptocurrency: 'all',
    amountRange: { min: '', max: '' }
  });
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  // Mock transaction data
  const mockTransactions = [
    {
      id: 'TXN001',
      type: 'deposit',
      cryptocurrency: 'BTC',
      amount: 0.5,
      usdValue: 25000,
      status: 'completed',
      timestamp: '2025-01-29T10:30:00Z',
      hash: '0x1a2b3c4d5e6f7g8h9i0j',
      networkFee: 0.0001,
      confirmations: 6,
      exchangeRate: 50000,
      from: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
      to: '3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy'
    },
    {
      id: 'TXN002',
      type: 'withdrawal',
      cryptocurrency: 'ETH',
      amount: 2.5,
      usdValue: 8750,
      status: 'pending',
      timestamp: '2025-01-29T09:15:00Z',
      hash: '0x9i8h7g6f5e4d3c2b1a0j',
      networkFee: 0.005,
      confirmations: 2,
      exchangeRate: 3500,
      from: '0x742d35Cc6634C0532925a3b8D82e9f96c5a4d4F',
      to: '0x8ba1f109551bD432803012645Hac136c34d04'
    },
    {
      id: 'TXN003',
      type: 'investment',
      cryptocurrency: 'USDT',
      amount: 10000,
      usdValue: 10000,
      status: 'completed',
      timestamp: '2025-01-28T14:20:00Z',
      hash: '0xa0b1c2d3e4f5g6h7i8j9',
      networkFee: 1,
      confirmations: 12,
      exchangeRate: 1,
      from: 'TG2xPZjdxQ7ZV6R9F3K8M2L4P9',
      to: 'TLsV52sRDL3bDW4Ds4R5AW2'
    }
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setTransactions(mockTransactions);
      setLoading(false);
    }, 1000);
  }, []);

  const filteredTransactions = transactions.filter(transaction => {
    const matchesTab = activeTab === 'all' || transaction.type === activeTab;
    const matchesSearch = searchTerm === '' || 
      transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.cryptocurrency.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.hash.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilters = 
      (filters.status === 'all' || transaction.status === filters.status) &&
      (filters.type === 'all' || transaction.type === filters.type) &&
      (filters.cryptocurrency === 'all' || transaction.cryptocurrency === filters.cryptocurrency);

    return matchesTab && matchesSearch && matchesFilters;
  });

  const getTransactionCounts = () => {
    return {
      all: transactions.length,
      deposits: transactions.filter(t => t.type === 'deposit').length,
      withdrawals: transactions.filter(t => t.type === 'withdrawal').length,
      investments: transactions.filter(t => t.type === 'investment').length,
      earnings: transactions.filter(t => t.type === 'earning').length
    };
  };

  const handleTransactionClick = (transaction) => {
    setSelectedTransaction(transaction);
    setIsDetailModalOpen(true);
  };

  const handleExport = () => {
    setIsExportModalOpen(true);
  };

  const handleFilterApply = (newFilters) => {
    setFilters(newFilters);
    setIsFilterModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <main className="flex-1">
          <div className="p-4 lg:p-8">
            {/* Page Header */}
            <div className="mb-8">
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">
                Transaction History
              </h1>
              <p className="text-gray-600">
                Track and analyze all your financial activities across the platform
              </p>
            </div>

            {/* Search and Actions Bar */}
            <div className="bg-white rounded-lg shadow-sm border p-4 mb-6">
              <div className="flex flex-col lg:flex-row gap-4 lg:items-center lg:justify-between">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search by transaction ID, cryptocurrency, or hash..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                
                <div className="flex gap-2">
                  <button
                    onClick={() => setIsFilterModalOpen(true)}
                    className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <Filter className="h-4 w-4" />
                    <span className="hidden sm:inline">Filters</span>
                  </button>
                  
                  <button
                    onClick={handleExport}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Download className="h-4 w-4" />
                    <span className="hidden sm:inline">Export</span>
                  </button>
                  
                  {/* View Mode Toggle - Desktop Only */}
                  <div className="hidden lg:flex border border-gray-200 rounded-lg overflow-hidden">
                    <button
                      onClick={() => setViewMode('cards')}
                      className={cn(
                        "px-3 py-2 text-sm",
                        viewMode === 'cards' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
                      )}
                    >
                      Cards
                    </button>
                    <button
                      onClick={() => setViewMode('table')}
                      className={cn(
                        "px-3 py-2 text-sm border-l border-gray-200",
                        viewMode === 'table' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
                      )}
                    >
                      Table
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Transaction Tabs */}
            <TransactionTabs
              activeTab={activeTab}
              onTabChange={setActiveTab}
              counts={getTransactionCounts()}
            />

            {/* Loading State */}
            {loading ? (
              <div className="bg-white rounded-lg shadow-sm border p-8">
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  <span className="ml-3 text-gray-600">Loading transactions...</span>
                </div>
              </div>
            ) : (
              <>
                {/* Empty State */}
                {filteredTransactions.length === 0 ? (
                  <div className="bg-white rounded-lg shadow-sm border p-8 text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Clock className="h-8 w-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No transactions found</h3>
                    <p className="text-gray-600">
                      {searchTerm || Object.values(filters).some(f => f !== 'all' && f !== '' && (typeof f !== 'object' || (f.min !== '' || f.max !== '')))
                        ? 'Try adjusting your search criteria or filters' :'Your transactions will appear here once you start trading'
                      }
                    </p>
                  </div>
                ) : (
                  <>
                    {/* Desktop Table View */}
                    {viewMode === 'table' && (
                      <div className="hidden lg:block">
                        <TransactionTable
                          transactions={filteredTransactions}
                          onTransactionClick={handleTransactionClick}
                        />
                      </div>
                    )}

                    {/* Cards View - Mobile and Desktop */}
                    {(viewMode === 'cards' || window.innerWidth < 1024) && (
                      <div className="space-y-4">
                        {filteredTransactions.map((transaction) => (
                          <TransactionCard
                            key={transaction.id}
                            transaction={transaction}
                            onClick={() => handleTransactionClick(transaction)}
                          />
                        ))}
                      </div>
                    )}
                  </>
                )}
              </>
            )}
          </div>
        </main>
      </div>

      {/* Modals */}
      <FilterModal
        isOpen={isFilterModalOpen}
        onClose={() => setIsFilterModalOpen(false)}
        filters={filters}
        onApply={handleFilterApply}
      />

      <TransactionDetailModal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        transaction={selectedTransaction}
      />

      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        transactions={filteredTransactions}
      />
    </div>
  );
};

export default TransactionHistory;
