import React from 'react';
import { Helmet } from 'react-helmet';
import UserAuthDebug from '../../components/UserAuthDebug';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AuthDebugPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Authentication Debug - KleverInvest</title>
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-4">Authentication Debug</h1>
            <p className="text-muted-foreground">
              This page helps debug authentication and 403 Forbidden errors
            </p>
          </div>

          <UserAuthDebug />

          <div className="bg-card border rounded-lg p-6 mt-8">
            <h2 className="text-lg font-semibold mb-4">Common 403 Forbidden Solutions</h2>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Icon name="CheckCircle" className="text-success mt-1" size={16} />
                <div>
                  <h3 className="font-medium">Clear Browser Data</h3>
                  <p className="text-sm text-muted-foreground">Clear localStorage and cookies, then try logging in again</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Icon name="CheckCircle" className="text-success mt-1" size={16} />
                <div>
                  <h3 className="font-medium">Login with Test Account</h3>
                  <p className="text-sm text-muted-foreground">Use: user@kleverinvest.com / password123</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Icon name="CheckCircle" className="text-success mt-1" size={16} />
                <div>
                  <h3 className="font-medium">Check KYC Status</h3>
                  <p className="text-sm text-muted-foreground">Ensure your account has completed KYC verification</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Icon name="CheckCircle" className="text-success mt-1" size={16} />
                <div>
                  <h3 className="font-medium">Remove Admin Sessions</h3>
                  <p className="text-sm text-muted-foreground">Make sure no admin tokens are interfering with user login</p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-8">
            <div className="flex justify-center space-x-4">
              <Button variant="outline" onClick={() => window.location.href = '/'}>
                <Icon name="Home" size={16} className="mr-2" />
                Home
              </Button>
              <Button variant="outline" onClick={() => window.location.href = '/user-login'}>
                <Icon name="LogIn" size={16} className="mr-2" />
                User Login
              </Button>
              <Button variant="outline" onClick={() => window.location.href = '/register'}>
                <Icon name="UserPlus" size={16} className="mr-2" />
                Register
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthDebugPage;
