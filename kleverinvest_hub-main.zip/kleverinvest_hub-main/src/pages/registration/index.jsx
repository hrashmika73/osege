import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import { getSortedCountries } from '../../utils/countries';


const RegistrationPage = () => {
  const navigate = useNavigate();
  const { } = useUserAuth(); // Note: userAuth doesn't have register function yet
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    country: '',
    agreedToTerms: false,
    agreedToPrivacy: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [countries] = useState(getSortedCountries());

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Full name is required';
    }

    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    if (!formData.agreedToTerms) {
      newErrors.agreedToTerms = 'You must agree to the Terms of Service';
    }

    if (!formData.agreedToPrivacy) {
      newErrors.agreedToPrivacy = 'You must agree to the Privacy Policy';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    try {
      // Simulate registration API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Create user data
      const userData = {
        id: 'user_' + Date.now(),
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        country: formData.country,
        role: 'user',
        verified: false,
        kycStatus: 'pending',
        memberSince: new Date().toISOString().split('T')[0],
        balance: 0,
        wallet: null,
        referralCode: 'REF' + Date.now().toString().slice(-6)
      };

      // Store user session
      localStorage.setItem('userToken', 'temp_token_' + Date.now());
      localStorage.setItem('userData', JSON.stringify(userData));

      // Save user with actual password for login
      const userWithPassword = {
        ...userData,
        password: formData.password // Save the actual password
      };

      // Use centralized user management system
      const { addNewUser, createKYCRequest } = await import('../../utils/userDataManager');

      // Add user to admin system
      const adminUserData = addNewUser(userWithPassword);

      // Create KYC request
      const kycRequest = createKYCRequest(userWithPassword);

      // Trigger real-time sync events
      window.dispatchEvent(new CustomEvent('userRegistered', {
        detail: {
          user: adminUserData,
          timestamp: new Date().toISOString(),
          source: 'registration_page'
        }
      }));

      // Also trigger storage change event for immediate admin refresh
      window.dispatchEvent(new StorageEvent('storage', {
        key: 'admin_users_data',
        newValue: JSON.stringify([...JSON.parse(localStorage.getItem('admin_users_data') || '[]')]),
        oldValue: null,
        storageArea: localStorage
      }));

      // Ensure admin can see the new registration immediately
      localStorage.setItem('last_registration_timestamp', new Date().toISOString());
      localStorage.setItem('new_user_registered', 'true');

      // Verify the sync worked
      const currentUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
      const userExists = currentUsers.some(u => u.email === userData.email);

      if (userExists) {
        alert('Registration successful! Your account has been created. Please complete KYC verification to access your dashboard.');
      } else {
        alert('Registration completed. Please contact support if your account doesn\'t appear in the system.');
      }

      navigate('/kyc-verification');
    } catch (error) {
      setErrors({ general: 'Registration failed. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };



  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
              <Icon name="TrendingUp" size={24} color="white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">KleverInvest Hub</h1>
              <p className="text-sm text-orange-400 font-medium">Professional Trading Platform</p>
            </div>
          </div>
          <p className="text-slate-300">
            Create your investment account and start building wealth
          </p>
        </div>

        {/* Registration Form */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Full Name */}
            <div>
              <label htmlFor="name" className="block text-sm font-medium mb-2 text-white">
                Full Name
              </label>
              <Input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="Enter your full name"
                className={`bg-white/10 border-white/20 text-white placeholder-slate-400 ${errors.name ? 'border-red-400' : ''}`}
                disabled={isLoading}
              />
              {errors.name && (
                <p className="text-red-400 text-sm mt-1">{errors.name}</p>
              )}
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-2 text-white">
                Email Address
              </label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="Enter your email address"
                className={`bg-white/10 border-white/20 text-white placeholder-slate-400 ${errors.email ? 'border-red-400' : ''}`}
                disabled={isLoading}
              />
              {errors.email && (
                <p className="text-red-400 text-sm mt-1">{errors.email}</p>
              )}
            </div>

            {/* Phone */}
            <div>
              <label htmlFor="phone" className="block text-sm font-medium mb-2 text-white">
                Phone Number <span className="text-slate-400">(Optional)</span>
              </label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleInputChange}
                placeholder="+1 (555) 123-4567"
                className="bg-white/10 border-white/20 text-white placeholder-slate-400"
                disabled={isLoading}
              />
            </div>

            {/* Country Dropdown */}
            <div>
              <label htmlFor="country" className="block text-sm font-medium mb-2 text-white">
                Country <span className="text-slate-400">(Optional)</span>
              </label>
              <select
                id="country"
                name="country"
                value={formData.country}
                onChange={handleInputChange}
                className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                disabled={isLoading}
              >
                <option value="" className="bg-slate-800 text-white">Select your country</option>
                {countries.map((country, index) => {
                  if (country.code === 'separator') {
                    return (
                      <option key={index} disabled className="bg-slate-700 text-slate-400">
                        {country.name}
                      </option>
                    );
                  }
                  return (
                    <option key={country.code} value={country.code} className="bg-slate-800 text-white">
                      {country.name}
                    </option>
                  );
                })}
              </select>
            </div>

            {/* Password */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium mb-2 text-white">
                Password
              </label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="Create a strong password"
                  className={`bg-white/10 border-white/20 text-white placeholder-slate-400 pr-12 ${errors.password ? 'border-red-400' : ''}`}
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <Icon name={showPassword ? 'EyeOff' : 'Eye'} size={16} />
                </button>
              </div>
              {errors.password && (
                <p className="text-red-400 text-sm mt-1">{errors.password}</p>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium mb-2 text-white">
                Confirm Password
              </label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  placeholder="Confirm your password"
                  className={`bg-white/10 border-white/20 text-white placeholder-slate-400 pr-12 ${errors.confirmPassword ? 'border-red-400' : ''}`}
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <Icon name={showConfirmPassword ? 'EyeOff' : 'Eye'} size={16} />
                </button>
              </div>
              {errors.confirmPassword && (
                <p className="text-red-400 text-sm mt-1">{errors.confirmPassword}</p>
              )}
            </div>

            {/* Terms and Privacy */}
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  id="agreedToTerms"
                  name="agreedToTerms"
                  checked={formData.agreedToTerms}
                  onChange={handleInputChange}
                  className="mt-1 text-orange-600 focus:ring-orange-500"
                />
                <label htmlFor="agreedToTerms" className="text-sm text-slate-300">
                  I agree to the{' '}
                  <Link to="/terms" className="text-orange-400 hover:text-orange-300 underline">
                    Terms of Service
                  </Link>
                </label>
              </div>
              {errors.agreedToTerms && (
                <p className="text-red-400 text-sm">{errors.agreedToTerms}</p>
              )}

              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  id="agreedToPrivacy"
                  name="agreedToPrivacy"
                  checked={formData.agreedToPrivacy}
                  onChange={handleInputChange}
                  className="mt-1 text-orange-600 focus:ring-orange-500"
                />
                <label htmlFor="agreedToPrivacy" className="text-sm text-slate-300">
                  I agree to the{' '}
                  <Link to="/privacy" className="text-orange-400 hover:text-orange-300 underline">
                    Privacy Policy
                  </Link>
                </label>
              </div>
              {errors.agreedToPrivacy && (
                <p className="text-red-400 text-sm">{errors.agreedToPrivacy}</p>
              )}
            </div>

            {/* General Error */}
            {errors.general && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <Icon name="AlertTriangle" size={16} className="text-red-400" />
                  <p className="text-red-400 text-sm">{errors.general}</p>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold"
              size="lg"
              disabled={isLoading}
              loading={isLoading}
            >
              Create Account
              <Icon name="ArrowRight" size={16} className="ml-2" />
            </Button>
          </form>



          {/* Login Link */}
          <div className="mt-6 text-center">
            <p className="text-slate-400 text-sm">
              Already have an account?{' '}
              <Link to="/login" className="text-orange-400 hover:text-orange-300 font-medium">
                Sign in here
              </Link>
            </p>
          </div>
        </div>

        {/* Security Features */}
        <div className="mt-8 text-center">
          <div className="flex items-center justify-center space-x-6 text-xs text-slate-400">
            <div className="flex items-center space-x-1">
              <Icon name="Shield" size={14} className="text-green-400" />
              <span>SSL Encrypted</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Lock" size={14} className="text-blue-400" />
              <span>Secure Registration</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="CheckCircle" size={14} className="text-orange-400" />
              <span>GDPR Compliant</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegistrationPage;
