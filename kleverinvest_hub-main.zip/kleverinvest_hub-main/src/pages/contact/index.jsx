import React, { useState } from 'react';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
    investmentAmount: '',
    preferredContact: 'email'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setSubmitted(true);
  };

  const contactMethods = [
    {
      icon: 'Phone',
      title: 'Phone Support',
      description: 'Speak with our investment advisors',
      detail: '+1 (555) 123-4567',
      hours: 'Mon-Fri 9AM-6PM EST'
    },
    {
      icon: 'Mail',
      title: 'Email Support',
      description: 'Get detailed responses to your questions',
      detail: 'support@kleverinvest.com',
      hours: '24/7 Response within 4 hours'
    },
    {
      icon: 'MessageCircle',
      title: 'Live Chat',
      description: 'Instant support for urgent matters',
      detail: 'Available on platform',
      hours: '24/7 Available'
    },
    {
      icon: 'MapPin',
      title: 'Office Visit',
      description: 'Schedule an in-person consultation',
      detail: '123 Financial District, NYC',
      hours: 'By appointment only'
    }
  ];

  const offices = [
    {
      city: 'New York',
      address: '123 Financial District, New York, NY 10004',
      phone: '+1 (555) 123-4567',
      email: 'nyc@kleverinvest.com'
    },
    {
      city: 'London',
      address: '45 Canary Wharf, London E14 5AB, UK',
      phone: '+44 20 7123 4567',
      email: 'london@kleverinvest.com'
    },
    {
      city: 'Singapore',
      address: '1 Marina Bay, Singapore 018989',
      phone: '+65 6123 4567',
      email: 'singapore@kleverinvest.com'
    }
  ];

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="max-w-md mx-auto text-center p-8">
          <div className="w-16 h-16 bg-success/10 rounded-full mx-auto mb-6 flex items-center justify-center">
            <Icon name="CheckCircle" size={32} className="text-success" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-4">Message Sent Successfully!</h2>
          <p className="text-muted-foreground mb-6">
            Thank you for contacting us. One of our investment advisors will get back to you within 24 hours.
          </p>
          <Button onClick={() => setSubmitted(false)}>
            Send Another Message
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-white">
        <div className="max-w-7xl mx-auto px-6 py-20">
          <div className="text-center">
            <h1 className="text-5xl font-bold mb-6">Get in Touch</h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Have questions about our investment services? Our expert team is here to help you 
              make informed decisions about your financial future.
            </p>
          </div>
        </div>
      </div>

      {/* Contact Methods */}
      <div className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">How to Reach Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {contactMethods.map((method, index) => (
              <div key={index} className="bg-card border rounded-lg p-6 text-center hover:shadow-lg transition-shadow">
                <div className="w-16 h-16 bg-primary/10 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Icon name={method.icon} size={32} className="text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{method.title}</h3>
                <p className="text-muted-foreground mb-3">{method.description}</p>
                <p className="text-primary font-medium mb-1">{method.detail}</p>
                <p className="text-sm text-muted-foreground">{method.hours}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Contact Form and Info */}
      <div className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-card border rounded-lg p-8">
              <h2 className="text-2xl font-bold text-foreground mb-6">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="First Name"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    required
                  />
                  <Input
                    label="Last Name"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <Input
                  label="Email Address"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
                
                <Input
                  label="Phone Number"
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                />
                
                <Select
                  label="Subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select a subject</option>
                  <option value="general">General Inquiry</option>
                  <option value="investment">Investment Consultation</option>
                  <option value="account">Account Support</option>
                  <option value="technical">Technical Support</option>
                  <option value="partnership">Partnership Opportunities</option>
                </Select>
                
                <Select
                  label="Investment Amount Range"
                  name="investmentAmount"
                  value={formData.investmentAmount}
                  onChange={handleChange}
                >
                  <option value="">Select investment range</option>
                  <option value="under-10k">Under $10,000</option>
                  <option value="10k-50k">$10,000 - $50,000</option>
                  <option value="50k-100k">$50,000 - $100,000</option>
                  <option value="100k-500k">$100,000 - $500,000</option>
                  <option value="over-500k">Over $500,000</option>
                </Select>
                
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Message
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={5}
                    className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    placeholder="Tell us about your investment goals and any questions you have..."
                    required
                  />
                </div>
                
                <Select
                  label="Preferred Contact Method"
                  name="preferredContact"
                  value={formData.preferredContact}
                  onChange={handleChange}
                >
                  <option value="email">Email</option>
                  <option value="phone">Phone</option>
                  <option value="both">Both Email and Phone</option>
                </Select>
                
                <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Icon name="Loader" size={20} className="animate-spin" />
                      Sending Message...
                    </>
                  ) : (
                    <>
                      <Icon name="Send" size={20} />
                      Send Message
                    </>
                  )}
                </Button>
              </form>
            </div>

            {/* Contact Information */}
            <div className="space-y-8">
              <div className="bg-card border rounded-lg p-8">
                <h3 className="text-xl font-bold text-foreground mb-6">Our Global Offices</h3>
                <div className="space-y-6">
                  {offices.map((office, index) => (
                    <div key={index} className="border-b border-border last:border-b-0 pb-6 last:pb-0">
                      <h4 className="font-semibold text-foreground mb-2">{office.city}</h4>
                      <div className="space-y-2 text-sm text-muted-foreground">
                        <div className="flex items-start space-x-2">
                          <Icon name="MapPin" size={16} className="mt-0.5 flex-shrink-0" />
                          <span>{office.address}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Icon name="Phone" size={16} className="flex-shrink-0" />
                          <span>{office.phone}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Icon name="Mail" size={16} className="flex-shrink-0" />
                          <span>{office.email}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-card border rounded-lg p-8">
                <h3 className="text-xl font-bold text-foreground mb-4">Business Hours</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Monday - Friday</span>
                    <span className="text-foreground font-medium">9:00 AM - 6:00 PM EST</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Saturday</span>
                    <span className="text-foreground font-medium">10:00 AM - 2:00 PM EST</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Sunday</span>
                    <span className="text-foreground font-medium">Closed</span>
                  </div>
                  <div className="pt-3 border-t border-border">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Emergency Support</span>
                      <span className="text-success font-medium">24/7 Available</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="py-20 bg-background">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {[
              {
                question: "What is the minimum investment amount?",
                answer: "Our minimum investment amount is $1,000, making our platform accessible to a wide range of investors."
              },
              {
                question: "How are my investments protected?",
                answer: "We use bank-grade security, multi-layer encryption, and partner with regulated custodians to ensure maximum protection of your assets."
              },
              {
                question: "What are your fees?",
                answer: "Our transparent fee structure starts at 0.75% annually for portfolio management, with no hidden fees or commissions."
              },
              {
                question: "How quickly can I withdraw my funds?",
                answer: "Standard withdrawals are processed within 1-3 business days. Emergency withdrawals can be expedited for urgent needs."
              }
            ].map((faq, index) => (
              <div key={index} className="bg-card border rounded-lg p-6">
                <h3 className="font-semibold text-foreground mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
