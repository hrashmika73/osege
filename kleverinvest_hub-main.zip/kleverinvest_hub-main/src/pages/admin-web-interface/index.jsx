import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminWebInterface = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [settings, setSettings] = useState({
    layout: 'default',
    sidebar: 'left',
    headerStyle: 'fixed',
    footerStyle: 'static',
    animations: true,
    transitions: true,
    loadingSpinner: 'default',
    cardShadows: true,
    compactMode: false,
    showBreadcrumbs: true,
    showPageTitles: true,
    responsiveBreakpoints: {
      mobile: '768',
      tablet: '1024',
      desktop: '1280'
    },
    customCss: '',
    maintenanceMode: false,
    maintenanceMessage: 'We are currently performing maintenance. Please check back later.'
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadInterfaceSettings();
  }, [isAdminAuthenticated, navigate]);

  const loadInterfaceSettings = () => {
    const savedSettings = localStorage.getItem('admin_interface_settings');
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
  };

  const handleSaveSettings = () => {
    setSaving(true);
    localStorage.setItem('admin_interface_settings', JSON.stringify(settings));
    
    // Apply interface changes
    applyInterfaceChanges(settings);
    
    setTimeout(() => {
      setSaving(false);
      alert('Web Interface settings saved successfully!');
    }, 1000);
  };

  const applyInterfaceChanges = (interfaceSettings) => {
    const root = document.documentElement;
    
    // Apply responsive breakpoints
    root.style.setProperty('--mobile-breakpoint', `${interfaceSettings.responsiveBreakpoints.mobile}px`);
    root.style.setProperty('--tablet-breakpoint', `${interfaceSettings.responsiveBreakpoints.tablet}px`);
    root.style.setProperty('--desktop-breakpoint', `${interfaceSettings.responsiveBreakpoints.desktop}px`);
    
    // Apply layout classes
    document.body.className = '';
    if (interfaceSettings.compactMode) document.body.classList.add('compact-mode');
    if (interfaceSettings.animations) document.body.classList.add('animations-enabled');
    if (interfaceSettings.cardShadows) document.body.classList.add('shadows-enabled');
    
    // Apply custom CSS
    let customStyleElement = document.getElementById('custom-admin-styles');
    if (!customStyleElement) {
      customStyleElement = document.createElement('style');
      customStyleElement.id = 'custom-admin-styles';
      document.head.appendChild(customStyleElement);
    }
    customStyleElement.textContent = interfaceSettings.customCss;
    
    // Dispatch custom event for interface updates
    window.dispatchEvent(new CustomEvent('interfaceUpdated', { detail: interfaceSettings }));
  };

  const resetToDefaults = () => {
    if (window.confirm('Reset all web interface settings to defaults?')) {
      setSettings({
        layout: 'default',
        sidebar: 'left',
        headerStyle: 'fixed',
        footerStyle: 'static',
        animations: true,
        transitions: true,
        loadingSpinner: 'default',
        cardShadows: true,
        compactMode: false,
        showBreadcrumbs: true,
        showPageTitles: true,
        responsiveBreakpoints: {
          mobile: '768',
          tablet: '1024',
          desktop: '1280'
        },
        customCss: '',
        maintenanceMode: false,
        maintenanceMessage: 'We are currently performing maintenance. Please check back later.'
      });
    }
  };

  const previewChanges = () => {
    applyInterfaceChanges(settings);
    alert('Interface changes applied! Changes are now visible in the admin panel.');
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Web Interface Settings"
        breadcrumb={[
          { label: "Theme Settings", link: "/admin-theme-settings" },
          { label: "Web Interface" }
        ]}
        actions={[
          {
            label: "Reset to Defaults",
            icon: "RotateCcw",
            variant: "outline",
            onClick: resetToDefaults
          },
          {
            label: "Preview Changes",
            icon: "Eye",
            variant: "outline",
            onClick: previewChanges
          },
          {
            label: saving ? "Saving..." : "Save Settings",
            icon: saving ? "Loader" : "Save",
            variant: "default",
            onClick: handleSaveSettings,
            disabled: saving
          }
        ]}
      />

      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Layout Settings */}
          <div className="bg-card border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
              <Icon name="Layout" size={20} className="mr-2" />
              Layout Configuration
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Layout Style</label>
                <select
                  value={settings.layout}
                  onChange={(e) => setSettings({...settings, layout: e.target.value})}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="default">Default</option>
                  <option value="boxed">Boxed</option>
                  <option value="fluid">Fluid</option>
                  <option value="minimal">Minimal</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Sidebar Position</label>
                <select
                  value={settings.sidebar}
                  onChange={(e) => setSettings({...settings, sidebar: e.target.value})}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="left">Left</option>
                  <option value="right">Right</option>
                  <option value="hidden">Hidden</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Header Style</label>
                <select
                  value={settings.headerStyle}
                  onChange={(e) => setSettings({...settings, headerStyle: e.target.value})}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="fixed">Fixed</option>
                  <option value="static">Static</option>
                  <option value="sticky">Sticky</option>
                  <option value="hidden">Hidden</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Footer Style</label>
                <select
                  value={settings.footerStyle}
                  onChange={(e) => setSettings({...settings, footerStyle: e.target.value})}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="static">Static</option>
                  <option value="fixed">Fixed</option>
                  <option value="sticky">Sticky</option>
                  <option value="hidden">Hidden</option>
                </select>
              </div>
            </div>
          </div>

          {/* Visual Effects */}
          <div className="bg-card border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
              <Icon name="Sparkles" size={20} className="mr-2" />
              Visual Effects
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-foreground">Animations</label>
                  <p className="text-xs text-muted-foreground">Enable page transitions and animations</p>
                </div>
                <button
                  onClick={() => setSettings({...settings, animations: !settings.animations})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.animations ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.animations ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-foreground">Smooth Transitions</label>
                  <p className="text-xs text-muted-foreground">Enable CSS transitions</p>
                </div>
                <button
                  onClick={() => setSettings({...settings, transitions: !settings.transitions})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.transitions ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.transitions ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-foreground">Card Shadows</label>
                  <p className="text-xs text-muted-foreground">Add depth with shadows</p>
                </div>
                <button
                  onClick={() => setSettings({...settings, cardShadows: !settings.cardShadows})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.cardShadows ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.cardShadows ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-foreground">Compact Mode</label>
                  <p className="text-xs text-muted-foreground">Reduce spacing for more content</p>
                </div>
                <button
                  onClick={() => setSettings({...settings, compactMode: !settings.compactMode})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.compactMode ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.compactMode ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Loading Spinner</label>
                <select
                  value={settings.loadingSpinner}
                  onChange={(e) => setSettings({...settings, loadingSpinner: e.target.value})}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="default">Default</option>
                  <option value="dots">Dots</option>
                  <option value="pulse">Pulse</option>
                  <option value="bars">Bars</option>
                  <option value="spinner">Spinner</option>
                </select>
              </div>
            </div>
          </div>

          {/* Navigation Settings */}
          <div className="bg-card border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
              <Icon name="Navigation" size={20} className="mr-2" />
              Navigation Settings
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-foreground">Show Breadcrumbs</label>
                  <p className="text-xs text-muted-foreground">Display navigation breadcrumbs</p>
                </div>
                <button
                  onClick={() => setSettings({...settings, showBreadcrumbs: !settings.showBreadcrumbs})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.showBreadcrumbs ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.showBreadcrumbs ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-foreground">Show Page Titles</label>
                  <p className="text-xs text-muted-foreground">Display page titles in headers</p>
                </div>
                <button
                  onClick={() => setSettings({...settings, showPageTitles: !settings.showPageTitles})}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.showPageTitles ? 'bg-primary' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.showPageTitles ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>

          {/* Responsive Breakpoints */}
          <div className="bg-card border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
              <Icon name="Monitor" size={20} className="mr-2" />
              Responsive Breakpoints
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Mobile (px)</label>
                <input
                  type="number"
                  value={settings.responsiveBreakpoints.mobile}
                  onChange={(e) => setSettings({
                    ...settings,
                    responsiveBreakpoints: {
                      ...settings.responsiveBreakpoints,
                      mobile: e.target.value
                    }
                  })}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Tablet (px)</label>
                <input
                  type="number"
                  value={settings.responsiveBreakpoints.tablet}
                  onChange={(e) => setSettings({
                    ...settings,
                    responsiveBreakpoints: {
                      ...settings.responsiveBreakpoints,
                      tablet: e.target.value
                    }
                  })}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Desktop (px)</label>
                <input
                  type="number"
                  value={settings.responsiveBreakpoints.desktop}
                  onChange={(e) => setSettings({
                    ...settings,
                    responsiveBreakpoints: {
                      ...settings.responsiveBreakpoints,
                      desktop: e.target.value
                    }
                  })}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Maintenance Mode */}
        <div className="mt-8 bg-card border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
            <Icon name="AlertTriangle" size={20} className="mr-2" />
            Maintenance Mode
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-sm font-medium text-foreground">Maintenance Mode</label>
                <p className="text-xs text-muted-foreground">Enable to show maintenance page to users</p>
              </div>
              <button
                onClick={() => setSettings({...settings, maintenanceMode: !settings.maintenanceMode})}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  settings.maintenanceMode ? 'bg-red-500' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    settings.maintenanceMode ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-2">Maintenance Message</label>
              <textarea
                value={settings.maintenanceMessage}
                onChange={(e) => setSettings({...settings, maintenanceMessage: e.target.value})}
                rows={3}
                className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Enter maintenance message..."
              />
            </div>
          </div>
        </div>

        {/* Custom CSS */}
        <div className="mt-8 bg-card border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
            <Icon name="Code" size={20} className="mr-2" />
            Custom CSS
          </h3>
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Additional CSS Styles
            </label>
            <textarea
              value={settings.customCss}
              onChange={(e) => setSettings({...settings, customCss: e.target.value})}
              rows={8}
              className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-mono text-sm"
              placeholder="/* Add your custom CSS here */
.custom-button {
  background: linear-gradient(45deg, #3b82f6, #10b981);
  border: none;
  border-radius: 8px;
}

/* Custom animations */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}"
            />
            <p className="text-xs text-muted-foreground mt-2">
              Warning: Custom CSS can override existing styles. Test thoroughly before applying.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminWebInterface;
