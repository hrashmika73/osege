import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

const UserLogin = () => {
  const navigate = useNavigate();
  const { user, userLogin, isUserAuthenticated, loginAttempts, lockoutUntil } = useUserAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);

  // Redirect if already authenticated
  useEffect(() => {
    if (isUserAuthenticated) {
      navigate('/user-dashboard');
    }
  }, [isUserAuthenticated, navigate]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrors({});

    try {
      // Validate input
      if (!formData.email) {
        throw new Error('Email is required');
      }
      if (!formData.password) {
        throw new Error('Password is required');
      }

      // Check for lockout
      if (lockoutUntil && Date.now() < lockoutUntil) {
        const remainingTime = Math.ceil((lockoutUntil - Date.now()) / 1000 / 60);
        throw new Error(`Account locked. Try again in ${remainingTime} minutes.`);
      }

      // Attempt user login
      await userLogin({
        email: formData.email,
        password: formData.password
      });

      // Navigation handled by useEffect above
      
    } catch (error) {
      setErrors({ general: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>User Login - KleverInvest Hub</title>
        <meta name="description" content="Log in to your KleverInvest account" />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          
          {/* Header */}
          <div className="text-center mb-8">
            <Link to="/" className="inline-flex items-center space-x-2 mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-primary to-accent rounded-xl flex items-center justify-center">
                <Icon name="TrendingUp" size={24} className="text-white" />
              </div>
              <span className="text-xl font-bold text-foreground">KleverInvest Hub</span>
            </Link>
            <h1 className="text-2xl font-bold text-foreground mb-2">Welcome Back</h1>
            <p className="text-muted-foreground">Sign in to your investment account</p>
          </div>

          {/* Login Form */}
          <div className="bg-card border rounded-2xl p-8 shadow-lg">
            <form onSubmit={handleSubmit} className="space-y-6">
              
              <div>
                <label className="block text-sm font-medium mb-2 text-foreground">
                  Email Address
                </label>
                <Input
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="your.email@example.com"
                  className="w-full"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-foreground">
                  Password
                </label>
                <div className="relative">
                  <Input
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder="Enter your password"
                    className="w-full pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    <Icon name={showPassword ? "EyeOff" : "Eye"} size={16} />
                  </button>
                </div>
              </div>

              {/* Remember Me & Forgot Password */}
              <div className="flex items-center justify-between">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    name="rememberMe"
                    checked={formData.rememberMe}
                    onChange={handleInputChange}
                    className="rounded text-primary focus:ring-primary"
                  />
                  <span className="text-sm text-muted-foreground">Remember me</span>
                </label>
                <Link 
                  to="/forgot-password" 
                  className="text-sm text-primary hover:underline"
                >
                  Forgot password?
                </Link>
              </div>

              {/* Error Message */}
              {errors.general && (
                <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-3">
                  <div className="flex items-center space-x-2">
                    <Icon name="AlertCircle" size={16} className="text-destructive" />
                    <p className="text-destructive text-sm">{errors.general}</p>
                  </div>
                </div>
              )}

              {/* Login Button */}
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90"
                size="lg"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Icon name="Loader2" size={16} className="mr-2 animate-spin" />
                    Signing In...
                  </>
                ) : (
                  <>
                    <Icon name="LogIn" size={16} className="mr-2" />
                    Sign In
                  </>
                )}
              </Button>

              {/* Demo Credentials */}
              <div className="bg-muted/30 border rounded-lg p-3">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="Key" size={16} className="text-primary" />
                  <span className="text-primary text-sm font-medium">Demo Credentials</span>
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>Email: user@kleverinvest.com</div>
                  <div>Password: password123</div>
                  <div className="mt-2 text-warning">
                    Attempts remaining: {Math.max(0, 5 - loginAttempts)}
                  </div>
                </div>
              </div>
            </form>

            {/* Sign Up Link */}
            <div className="mt-6 text-center">
              <p className="text-sm text-muted-foreground">
                Don't have an account?{' '}
                <Link to="/register" className="text-primary hover:underline font-medium">
                  Sign up for free
                </Link>
              </p>
            </div>

            {/* Security Features */}
            <div className="mt-6 grid grid-cols-3 gap-2 text-xs text-muted-foreground">
              <div className="text-center">
                <Icon name="Shield" size={16} className="mx-auto mb-1 text-success" />
                <span>Encrypted</span>
              </div>
              <div className="text-center">
                <Icon name="Lock" size={16} className="mx-auto mb-1 text-primary" />
                <span>Secure</span>
              </div>
              <div className="text-center">
                <Icon name="CheckCircle" size={16} className="mx-auto mb-1 text-accent" />
                <span>Verified</span>
              </div>
            </div>
          </div>

          {/* Admin Login Link */}
          <div className="mt-6 text-center">
            <p className="text-xs text-muted-foreground mb-2">
              Administrative access?
            </p>
            <Link 
              to="/admin-secure-login" 
              className="inline-flex items-center space-x-1 text-xs text-warning hover:underline"
            >
              <Icon name="Shield" size={12} />
              <span>Admin Portal</span>
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserLogin;
