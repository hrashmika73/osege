import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../../contexts/AdminAuthContext';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const AdminContentManagement = () => {
  const navigate = useNavigate();
  const { admin, isAdminAuthenticated } = useAdminAuth();
  const [activeSection, setActiveSection] = useState('header');
  const [content, setContent] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  const contentSections = [
    { value: 'header', label: 'Header & Navigation' },
    { value: 'footer', label: 'Footer' },
    { value: 'hero', label: 'Hero Section' },
    { value: 'plans', label: 'Investment Plans' },
    { value: 'features', label: 'Features Section' },
    { value: 'about', label: 'About Page' },
    { value: 'contact', label: 'Contact Information' }
  ];

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }

    // Simulate loading content data
    setTimeout(() => {
      setContent({
        header: {
          logo_text: 'KleverInvest Hub',
          navigation_items: [
            { label: 'Features', url: '#features' },
            { label: 'Plans', url: '#plans' },
            { label: 'About', url: '/about' },
            { label: 'Contact', url: '/contact' }
          ]
        },
        hero: {
          title: 'Invest in the Future of Finance',
          subtitle: 'Build wealth with cryptocurrency investments backed by institutional-grade security',
          cta_text: 'Start Investing',
          background_image: '/images/hero-bg.jpg'
        },
        plans: [
          {
            id: 1,
            name: 'Bitcoin Starter',
            apy: 8.5,
            min_amount: 100,
            max_amount: 10000,
            duration: '30 days',
            features: ['Basic portfolio', 'Email support', 'Mobile app access'],
            popular: false
          },
          {
            id: 2,
            name: 'Ethereum Growth',
            apy: 12.5,
            min_amount: 1000,
            max_amount: 50000,
            duration: '90 days',
            features: ['Advanced portfolio', 'Priority support', 'API access', 'Analytics dashboard'],
            popular: true
          },
          {
            id: 3,
            name: 'DeFi Premium',
            apy: 18.2,
            min_amount: 5000,
            max_amount: 100000,
            duration: '180 days',
            features: ['Premium portfolio', 'Dedicated manager', 'Custom strategies', 'Institutional tools'],
            popular: false
          }
        ],
        features: [
          {
            icon: 'Shield',
            title: 'Bank-Grade Security',
            description: 'Multi-layer security with cold storage and insurance protection'
          },
          {
            icon: 'Zap',
            title: 'Instant Transactions',
            description: 'Lightning-fast deposits and withdrawals with minimal fees'
          },
          {
            icon: 'BarChart3',
            title: 'Advanced Analytics',
            description: 'Real-time portfolio tracking and performance insights'
          },
          {
            icon: 'Headphones',
            title: '24/7 Support',
            description: 'Round-the-clock customer support from crypto experts'
          }
        ],
        footer: {
          company_description: 'The future of cryptocurrency investing, built for everyone.',
          social_links: [
            { platform: 'Twitter', url: 'https://twitter.com/kleverinvest' },
            { platform: 'LinkedIn', url: 'https://linkedin.com/company/kleverinvest' },
            { platform: 'GitHub', url: 'https://github.com/kleverinvest' }
          ],
          links: {
            product: [
              { label: 'Features', url: '#features' },
              { label: 'Pricing', url: '#pricing' },
              { label: 'API', url: '/api' },
              { label: 'Security', url: '/security' }
            ],
            company: [
              { label: 'About', url: '/about' },
              { label: 'Blog', url: '/blog' },
              { label: 'Careers', url: '/careers' },
              { label: 'Contact', url: '/contact' }
            ],
            support: [
              { label: 'Help Center', url: '/help' },
              { label: 'Community', url: '/community' },
              { label: 'Status', url: '/status' },
              { label: 'Terms', url: '/terms' }
            ]
          }
        },
        about: {
          title: 'About KleverInvest',
          description: 'We are a leading cryptocurrency investment platform committed to making digital asset investing accessible to everyone.',
          mission: 'To democratize access to cryptocurrency investments through innovative technology and unparalleled security.',
          vision: 'To become the world\'s most trusted cryptocurrency investment platform.',
          values: [
            'Security First',
            'Transparency',
            'Innovation',
            'Customer Success'
          ]
        },
        contact: {
          email: 'support@kleverinvest.com',
          phone: '+1 (555) 123-4567',
          address: '123 Crypto Street, Digital City, DC 12345',
          business_hours: 'Monday - Friday: 9:00 AM - 6:00 PM EST',
          support_email: 'help@kleverinvest.com'
        }
      });
      setLoading(false);
    }, 1000);
  }, []);

  const handleSave = async () => {
    setSaving(true);
    
    // Simulate saving content
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setSaving(false);
    setMessage('Content saved successfully!');
    setTimeout(() => setMessage(''), 3000);
  };

  const handleInputChange = (section, field, value) => {
    setContent(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  const handleArrayAdd = (section, field) => {
    setContent(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: [...(prev[section][field] || []), '']
      }
    }));
  };

  const handleArrayRemove = (section, field, index) => {
    setContent(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: prev[section][field].filter((_, i) => i !== index)
      }
    }));
  };

  const renderHeaderEditor = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-white mb-4">Header & Navigation</h3>
      
      <Input
        label="Logo Text"
        value={content.header?.logo_text || ''}
        onChange={(e) => handleInputChange('header', 'logo_text', e.target.value)}
        className="bg-gray-700 border-gray-600 text-white"
      />

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">Navigation Items</label>
        {content.header?.navigation_items?.map((item, index) => (
          <div key={index} className="flex space-x-2 mb-2">
            <Input
              placeholder="Label"
              value={item.label}
              onChange={(e) => {
                const newItems = [...content.header.navigation_items];
                newItems[index].label = e.target.value;
                handleInputChange('header', 'navigation_items', newItems);
              }}
              className="bg-gray-700 border-gray-600 text-white"
            />
            <Input
              placeholder="URL"
              value={item.url}
              onChange={(e) => {
                const newItems = [...content.header.navigation_items];
                newItems[index].url = e.target.value;
                handleInputChange('header', 'navigation_items', newItems);
              }}
              className="bg-gray-700 border-gray-600 text-white"
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleArrayRemove('header', 'navigation_items', index)}
              className="border-red-600 text-red-400"
            >
              <Icon name="Trash" size={16} />
            </Button>
          </div>
        ))}
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleArrayAdd('header', 'navigation_items')}
          className="border-gray-600 text-gray-300"
        >
          <Icon name="Plus" size={16} />
          Add Navigation Item
        </Button>
      </div>
    </div>
  );

  const renderHeroEditor = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-white mb-4">Hero Section</h3>
      
      <Input
        label="Main Title"
        value={content.hero?.title || ''}
        onChange={(e) => handleInputChange('hero', 'title', e.target.value)}
        className="bg-gray-700 border-gray-600 text-white"
      />

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">Subtitle</label>
        <textarea
          value={content.hero?.subtitle || ''}
          onChange={(e) => handleInputChange('hero', 'subtitle', e.target.value)}
          rows={3}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-400"
        />
      </div>

      <Input
        label="Call-to-Action Text"
        value={content.hero?.cta_text || ''}
        onChange={(e) => handleInputChange('hero', 'cta_text', e.target.value)}
        className="bg-gray-700 border-gray-600 text-white"
      />

      <Input
        label="Background Image URL"
        value={content.hero?.background_image || ''}
        onChange={(e) => handleInputChange('hero', 'background_image', e.target.value)}
        className="bg-gray-700 border-gray-600 text-white"
      />
    </div>
  );

  const renderPlansEditor = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-white mb-4">Investment Plans</h3>
      
      {content.plans?.map((plan, index) => (
        <div key={plan.id} className="bg-gray-700/50 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-white">Plan {index + 1}</h4>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={plan.popular}
                onChange={(e) => {
                  const newPlans = [...content.plans];
                  newPlans[index].popular = e.target.checked;
                  handleInputChange('plans', '', newPlans);
                }}
                className="rounded border-gray-600 bg-gray-700"
              />
              <span className="text-sm text-gray-300">Popular Plan</span>
            </label>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Plan Name"
              value={plan.name}
              onChange={(e) => {
                const newPlans = [...content.plans];
                newPlans[index].name = e.target.value;
                setContent(prev => ({ ...prev, plans: newPlans }));
              }}
              className="bg-gray-700 border-gray-600 text-white"
            />
            
            <Input
              label="APY (%)"
              type="number"
              step="0.1"
              value={plan.apy}
              onChange={(e) => {
                const newPlans = [...content.plans];
                newPlans[index].apy = parseFloat(e.target.value);
                setContent(prev => ({ ...prev, plans: newPlans }));
              }}
              className="bg-gray-700 border-gray-600 text-white"
            />
            
            <Input
              label="Minimum Amount ($)"
              type="number"
              value={plan.min_amount}
              onChange={(e) => {
                const newPlans = [...content.plans];
                newPlans[index].min_amount = parseInt(e.target.value);
                setContent(prev => ({ ...prev, plans: newPlans }));
              }}
              className="bg-gray-700 border-gray-600 text-white"
            />
            
            <Input
              label="Maximum Amount ($)"
              type="number"
              value={plan.max_amount}
              onChange={(e) => {
                const newPlans = [...content.plans];
                newPlans[index].max_amount = parseInt(e.target.value);
                setContent(prev => ({ ...prev, plans: newPlans }));
              }}
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>
          
          <Input
            label="Duration"
            value={plan.duration}
            onChange={(e) => {
              const newPlans = [...content.plans];
              newPlans[index].duration = e.target.value;
              setContent(prev => ({ ...prev, plans: newPlans }));
            }}
            className="bg-gray-700 border-gray-600 text-white"
          />
        </div>
      ))}
    </div>
  );

  const renderFeaturesEditor = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-white mb-4">Features Section</h3>
      
      {content.features?.map((feature, index) => (
        <div key={index} className="bg-gray-700/50 rounded-lg p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              label="Icon Name"
              value={feature.icon}
              onChange={(e) => {
                const newFeatures = [...content.features];
                newFeatures[index].icon = e.target.value;
                setContent(prev => ({ ...prev, features: newFeatures }));
              }}
              className="bg-gray-700 border-gray-600 text-white"
            />
            
            <Input
              label="Title"
              value={feature.title}
              onChange={(e) => {
                const newFeatures = [...content.features];
                newFeatures[index].title = e.target.value;
                setContent(prev => ({ ...prev, features: newFeatures }));
              }}
              className="bg-gray-700 border-gray-600 text-white"
            />
            
            <div className="flex items-end">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const newFeatures = content.features.filter((_, i) => i !== index);
                  setContent(prev => ({ ...prev, features: newFeatures }));
                }}
                className="border-red-600 text-red-400"
              >
                <Icon name="Trash" size={16} />
              </Button>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Description</label>
            <textarea
              value={feature.description}
              onChange={(e) => {
                const newFeatures = [...content.features];
                newFeatures[index].description = e.target.value;
                setContent(prev => ({ ...prev, features: newFeatures }));
              }}
              rows={2}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-400"
            />
          </div>
        </div>
      ))}
      
      <Button
        variant="outline"
        onClick={() => {
          const newFeatures = [...(content.features || []), { icon: 'Star', title: '', description: '' }];
          setContent(prev => ({ ...prev, features: newFeatures }));
        }}
        className="border-gray-600 text-gray-300"
      >
        <Icon name="Plus" size={16} />
        Add Feature
      </Button>
    </div>
  );

  const renderContentEditor = () => {
    switch (activeSection) {
      case 'header':
        return renderHeaderEditor();
      case 'hero':
        return renderHeroEditor();
      case 'plans':
        return renderPlansEditor();
      case 'features':
        return renderFeaturesEditor();
      default:
        return <div className="text-gray-400">Select a section to edit</div>;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-300">Loading content editor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/admin-dashboard')}
              className="border-gray-600 text-gray-300"
            >
              <Icon name="ArrowLeft" size={16} />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-white">Content Management</h1>
              <p className="text-sm text-gray-400">Edit site content, plans, and images</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            {message && (
              <span className="text-green-400 text-sm">{message}</span>
            )}
            <Button
              onClick={handleSave}
              disabled={saving}
              className="bg-green-600 hover:bg-green-700"
            >
              {saving ? (
                <>
                  <Icon name="Loader" size={16} className="animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Icon name="Save" size={16} />
                  Save Changes
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-gray-800 border-r border-gray-700 min-h-screen">
          <div className="p-4">
            <h3 className="text-sm font-medium text-gray-400 uppercase tracking-wider mb-4">
              Content Sections
            </h3>
            <nav className="space-y-1">
              {contentSections.map((section) => (
                <button
                  key={section.value}
                  onClick={() => setActiveSection(section.value)}
                  className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeSection === section.value
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-300 hover:text-white hover:bg-gray-700'
                  }`}
                >
                  {section.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Content Editor */}
        <div className="flex-1 p-6">
          <div className="bg-gray-800 rounded-lg p-6">
            {renderContentEditor()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminContentManagement;
