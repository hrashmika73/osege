import React, { useState, useEffect } from 'react';
import Icon from '../../../../components/AppIcon';
import Button from '../../../../components/ui/Button';
import Input from '../../../../components/ui/Input';

const EditPlanModal = ({ plan, onClose, onSave }) => {
  const [editedPlan, setEditedPlan] = useState({
    name: '',
    roi: '',
    period: 'daily',
    minAmount: '',
    maxAmount: '',
    duration: '',
    status: 'active'
  });

  const [errors, setErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);

  // Initialize form with plan data
  useEffect(() => {
    if (plan) {
      setEditedPlan({
        name: plan.name,
        roi: plan.roi.toString(),
        period: plan.period,
        minAmount: plan.minAmount.toString(),
        maxAmount: plan.maxAmount.toString(),
        duration: plan.duration.toString(),
        status: plan.status
      });
    }
  }, [plan]);

  const handleInputChange = (field, value) => {
    setEditedPlan(prev => ({
      ...prev,
      [field]: value
    }));

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: null
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!editedPlan.name.trim()) {
      newErrors.name = 'Plan name is required';
    }

    if (!editedPlan.roi || parseFloat(editedPlan.roi) <= 0) {
      newErrors.roi = 'ROI must be greater than 0';
    } else if (parseFloat(editedPlan.roi) > 100) {
      newErrors.roi = 'ROI cannot exceed 100%';
    }

    if (!editedPlan.minAmount || parseFloat(editedPlan.minAmount) <= 0) {
      newErrors.minAmount = 'Minimum amount must be greater than 0';
    }

    if (!editedPlan.maxAmount || parseFloat(editedPlan.maxAmount) <= 0) {
      newErrors.maxAmount = 'Maximum amount must be greater than 0';
    } else if (parseFloat(editedPlan.maxAmount) <= parseFloat(editedPlan.minAmount)) {
      newErrors.maxAmount = 'Maximum amount must be greater than minimum amount';
    }

    if (!editedPlan.duration || parseInt(editedPlan.duration) <= 0) {
      newErrors.duration = 'Duration must be greater than 0 days';
    } else if (parseInt(editedPlan.duration) > 365) {
      newErrors.duration = 'Duration cannot exceed 365 days';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }

    setIsSaving(true);

    try {
      // Simulate save delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      const updatedPlan = {
        ...plan,
        name: editedPlan.name.trim(),
        roi: parseFloat(editedPlan.roi),
        period: editedPlan.period,
        minAmount: parseFloat(editedPlan.minAmount),
        maxAmount: parseFloat(editedPlan.maxAmount),
        duration: parseInt(editedPlan.duration),
        status: editedPlan.status
      };

      onSave(updatedPlan);
      onClose();
    } catch (error) {
      console.error('Error saving plan:', error);
      alert('Failed to save plan. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const calculateProjections = () => {
    const roi = parseFloat(editedPlan.roi) || 0;
    const minAmount = parseFloat(editedPlan.minAmount) || 0;
    const maxAmount = parseFloat(editedPlan.maxAmount) || 0;
    const duration = parseInt(editedPlan.duration) || 0;

    let periodsInDuration = 0;
    switch (editedPlan.period) {
      case 'daily':
        periodsInDuration = duration;
        break;
      case 'weekly':
        periodsInDuration = Math.floor(duration / 7);
        break;
      case 'monthly':
        periodsInDuration = Math.floor(duration / 30);
        break;
      default:
        periodsInDuration = 0;
    }

    const minReturn = minAmount * (roi / 100) * periodsInDuration;
    const maxReturn = maxAmount * (roi / 100) * periodsInDuration;

    return {
      minReturn: minReturn.toFixed(2),
      maxReturn: maxReturn.toFixed(2),
      periodsInDuration
    };
  };

  const projections = calculateProjections();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-lg shadow-lg max-w-2xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
              <Icon name="Edit" size={20} className="text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-foreground">Edit Investment Plan</h2>
              <p className="text-sm text-muted-foreground">Modify plan details and settings</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={onClose}>
            <Icon name="X" size={16} />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          <div className="space-y-6">
            {/* Basic Information */}
            <div>
              <h3 className="text-lg font-medium text-foreground mb-4">Basic Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Plan Name *
                  </label>
                  <Input
                    value={editedPlan.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="e.g., Premium Plan"
                    error={errors.name}
                  />
                  {errors.name && (
                    <p className="text-destructive text-xs mt-1">{errors.name}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Status
                  </label>
                  <select
                    value={editedPlan.status}
                    onChange={(e) => handleInputChange('status', e.target.value)}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-background text-foreground"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Returns & Duration */}
            <div>
              <h3 className="text-lg font-medium text-foreground mb-4">Returns & Duration</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    ROI Percentage *
                  </label>
                  <Input
                    type="number"
                    value={editedPlan.roi}
                    onChange={(e) => handleInputChange('roi', e.target.value)}
                    placeholder="e.g., 5"
                    step="0.1"
                    min="0"
                    max="100"
                    error={errors.roi}
                  />
                  {errors.roi && (
                    <p className="text-destructive text-xs mt-1">{errors.roi}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Period
                  </label>
                  <select
                    value={editedPlan.period}
                    onChange={(e) => handleInputChange('period', e.target.value)}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-background text-foreground"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Duration (Days) *
                  </label>
                  <Input
                    type="number"
                    value={editedPlan.duration}
                    onChange={(e) => handleInputChange('duration', e.target.value)}
                    placeholder="e.g., 30"
                    min="1"
                    max="365"
                    error={errors.duration}
                  />
                  {errors.duration && (
                    <p className="text-destructive text-xs mt-1">{errors.duration}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Investment Limits */}
            <div>
              <h3 className="text-lg font-medium text-foreground mb-4">Investment Limits</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Minimum Amount ($) *
                  </label>
                  <Input
                    type="number"
                    value={editedPlan.minAmount}
                    onChange={(e) => handleInputChange('minAmount', e.target.value)}
                    placeholder="e.g., 100"
                    min="1"
                    error={errors.minAmount}
                  />
                  {errors.minAmount && (
                    <p className="text-destructive text-xs mt-1">{errors.minAmount}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Maximum Amount ($) *
                  </label>
                  <Input
                    type="number"
                    value={editedPlan.maxAmount}
                    onChange={(e) => handleInputChange('maxAmount', e.target.value)}
                    placeholder="e.g., 10000"
                    min="1"
                    error={errors.maxAmount}
                  />
                  {errors.maxAmount && (
                    <p className="text-destructive text-xs mt-1">{errors.maxAmount}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Projections */}
            {editedPlan.roi && editedPlan.minAmount && editedPlan.maxAmount && editedPlan.duration && (
              <div className="bg-muted/20 rounded-lg p-4">
                <h4 className="font-medium text-foreground mb-3">Return Projections</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Min. Return:</span>
                    <div className="font-medium text-success">${projections.minReturn}</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Max. Return:</span>
                    <div className="font-medium text-success">${projections.maxReturn}</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Total Periods:</span>
                    <div className="font-medium text-foreground">{projections.periodsInDuration}</div>
                  </div>
                </div>
              </div>
            )}

            {/* Current Performance */}
            <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
              <h4 className="font-medium text-primary mb-3">Current Performance</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Total Investors:</span>
                  <div className="font-medium text-foreground">{plan?.totalInvestors || 0}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Total Invested:</span>
                  <div className="font-medium text-foreground">${(plan?.totalInvested || 0).toLocaleString()}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Plan ID:</span>
                  <div className="font-medium text-foreground">#{plan?.id}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border bg-muted/20">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              * Required fields. Changes will be applied immediately.
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={onClose} disabled={isSaving}>
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={isSaving}>
                {isSaving ? (
                  <>
                    <Icon name="Loader2" size={16} className="animate-spin mr-2" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Icon name="Save" size={16} className="mr-2" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditPlanModal;
