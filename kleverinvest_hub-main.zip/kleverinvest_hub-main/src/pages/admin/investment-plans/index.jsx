import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import AdminNavigation from '../../../components/ui/AdminNavigation';
import EditPlanModal from './components/EditPlanModal';

const AdminInvestmentPlans = () => {
  const navigate = useNavigate();
  const [plans, setPlans] = useState([
    {
      id: 1,
      name: 'Starter Plan',
      roi: 3,
      period: 'daily',
      minAmount: 100,
      maxAmount: 1000,
      duration: 30,
      status: 'active',
      totalInvestors: 234,
      totalInvested: 156800
    },
    {
      id: 2,
      name: 'Professional Plan',
      roi: 15,
      period: 'weekly',
      minAmount: 1000,
      maxAmount: 10000,
      duration: 60,
      status: 'active',
      totalInvestors: 89,
      totalInvested: 445600
    },
    {
      id: 3,
      name: 'Enterprise Plan',
      roi: 50,
      period: 'monthly',
      minAmount: 5000,
      maxAmount: 100000,
      duration: 90,
      status: 'active',
      totalInvestors: 23,
      totalInvested: 890000
    }
  ]);

  const [newPlan, setNewPlan] = useState({
    name: '',
    roi: '',
    period: 'daily',
    minAmount: '',
    maxAmount: '',
    duration: '',
    status: 'active'
  });

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);

  const handleCreatePlan = () => {
    if (!newPlan.name || !newPlan.roi || !newPlan.minAmount || !newPlan.maxAmount || !newPlan.duration) {
      alert('Please fill in all required fields');
      return;
    }

    const plan = {
      id: Date.now(),
      ...newPlan,
      roi: parseFloat(newPlan.roi),
      minAmount: parseFloat(newPlan.minAmount),
      maxAmount: parseFloat(newPlan.maxAmount),
      duration: parseInt(newPlan.duration),
      totalInvestors: 0,
      totalInvested: 0
    };

    setPlans([...plans, plan]);
    setNewPlan({
      name: '',
      roi: '',
      period: 'daily',
      minAmount: '',
      maxAmount: '',
      duration: '',
      status: 'active'
    });
    setShowCreateForm(false);
    alert(`Investment plan "${plan.name}" created successfully!`);
  };

  const handleToggleStatus = (id) => {
    setPlans(plans.map(plan => 
      plan.id === id 
        ? { ...plan, status: plan.status === 'active' ? 'inactive' : 'active' }
        : plan
    ));
  };

  const handleDeletePlan = (id, name) => {
    const proceed = confirm(`Are you sure you want to delete "${name}"?\n\nThis action cannot be undone.`);
    if (proceed) {
      setPlans(plans.filter(plan => plan.id !== id));
      alert(`Investment plan "${name}" deleted successfully!`);
    }
  };

  const handleEditPlan = (plan) => {
    setEditingPlan(plan);
    setShowEditModal(true);
  };

  const handleSaveEditedPlan = (updatedPlan) => {
    setPlans(plans.map(plan =>
      plan.id === updatedPlan.id ? updatedPlan : plan
    ));
    setEditingPlan(null);
    setShowEditModal(false);

    // Show detailed confirmation
    const details = `Investment Plan Updated Successfully!\n\n` +
      `Plan Name: ${updatedPlan.name}\n` +
      `ROI: ${updatedPlan.roi}% ${updatedPlan.period}\n` +
      `Investment Range: $${updatedPlan.minAmount} - $${updatedPlan.maxAmount.toLocaleString()}\n` +
      `Duration: ${updatedPlan.duration} days\n` +
      `Status: ${updatedPlan.status.toUpperCase()}\n\n` +
      `Changes have been applied and are now live for investors.`;

    alert(details);
  };

  const handleCloseEditModal = () => {
    setEditingPlan(null);
    setShowEditModal(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Investment Plan Management"
        breadcrumb={[
          { label: "Admin", link: null },
          { label: "Investment Plans", link: null }
        ]}
        actions={[
          {
            label: "Create Plan",
            icon: "Plus",
            variant: "default",
            onClick: () => setShowCreateForm(true)
          },
          {
            label: "Export Data",
            icon: "Download",
            variant: "outline",
            onClick: () => {
              const data = plans.map(p => ({
                name: p.name,
                roi: `${p.roi}%`,
                period: p.period,
                minAmount: p.minAmount,
                maxAmount: p.maxAmount,
                duration: `${p.duration} days`,
                status: p.status,
                investors: p.totalInvestors,
                invested: p.totalInvested
              }));
              const csv = [
                Object.keys(data[0]).join(','),
                ...data.map(row => Object.values(row).join(','))
              ].join('\\n');
              const blob = new Blob([csv], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const link = document.createElement('a');
              link.href = url;
              link.download = 'investment_plans.csv';
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              URL.revokeObjectURL(url);
              alert('Investment plans data exported successfully!');
            }
          }
        ]}
      />

      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-card rounded-lg p-6 border">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Icon name="TrendingUp" size={24} className="text-primary" />
                </div>
                <span className="text-primary text-sm font-medium">Active</span>
              </div>
              <h3 className="text-2xl font-bold text-foreground">{plans.filter(p => p.status === 'active').length}</h3>
              <p className="text-muted-foreground text-sm">Active Plans</p>
            </div>

            <div className="bg-card rounded-lg p-6 border">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                  <Icon name="Users" size={24} className="text-success" />
                </div>
                <span className="text-success text-sm font-medium">Total</span>
              </div>
              <h3 className="text-2xl font-bold text-foreground">{plans.reduce((sum, p) => sum + p.totalInvestors, 0)}</h3>
              <p className="text-muted-foreground text-sm">Total Investors</p>
            </div>

            <div className="bg-card rounded-lg p-6 border">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                  <Icon name="DollarSign" size={24} className="text-warning" />
                </div>
                <span className="text-warning text-sm font-medium">Volume</span>
              </div>
              <h3 className="text-2xl font-bold text-foreground">${(plans.reduce((sum, p) => sum + p.totalInvested, 0)).toLocaleString()}</h3>
              <p className="text-muted-foreground text-sm">Total Invested</p>
            </div>

            <div className="bg-card rounded-lg p-6 border">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <Icon name="Percent" size={24} className="text-accent" />
                </div>
                <span className="text-accent text-sm font-medium">Average</span>
              </div>
              <h3 className="text-2xl font-bold text-foreground">{(plans.reduce((sum, p) => sum + p.roi, 0) / plans.length).toFixed(1)}%</h3>
              <p className="text-muted-foreground text-sm">Average ROI</p>
            </div>
          </div>

          {/* Create Plan Form */}
          {showCreateForm && (
            <div className="bg-card border rounded-lg p-6 mb-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-foreground">Create New Investment Plan</h3>
                <Button variant="outline" size="sm" onClick={() => setShowCreateForm(false)}>
                  <Icon name="X" size={16} />
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Plan Name</label>
                  <Input
                    value={newPlan.name}
                    onChange={(e) => setNewPlan({...newPlan, name: e.target.value})}
                    placeholder="e.g., Premium Plan"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">ROI Percentage</label>
                  <Input
                    type="number"
                    value={newPlan.roi}
                    onChange={(e) => setNewPlan({...newPlan, roi: e.target.value})}
                    placeholder="e.g., 5"
                    step="0.1"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Period</label>
                  <select
                    value={newPlan.period}
                    onChange={(e) => setNewPlan({...newPlan, period: e.target.value})}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-background text-foreground"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Duration (Days)</label>
                  <Input
                    type="number"
                    value={newPlan.duration}
                    onChange={(e) => setNewPlan({...newPlan, duration: e.target.value})}
                    placeholder="e.g., 30"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Minimum Amount ($)</label>
                  <Input
                    type="number"
                    value={newPlan.minAmount}
                    onChange={(e) => setNewPlan({...newPlan, minAmount: e.target.value})}
                    placeholder="e.g., 100"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Maximum Amount ($)</label>
                  <Input
                    type="number"
                    value={newPlan.maxAmount}
                    onChange={(e) => setNewPlan({...newPlan, maxAmount: e.target.value})}
                    placeholder="e.g., 10000"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <Button variant="outline" onClick={() => setShowCreateForm(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreatePlan}>
                  <Icon name="Plus" size={16} className="mr-2" />
                  Create Plan
                </Button>
              </div>
            </div>
          )}

          {/* Investment Plans List */}
          <div className="bg-card border rounded-lg overflow-hidden">
            <div className="p-6 border-b border-border">
              <h3 className="text-lg font-semibold text-foreground">Investment Plans</h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted border-b border-border">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Plan Details</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">ROI & Period</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Investment Range</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Performance</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {plans.map(plan => (
                    <tr key={plan.id} className="hover:bg-muted/50">
                      <td className="px-6 py-4">
                        <div>
                          <div className="font-medium text-foreground">{plan.name}</div>
                          <div className="text-sm text-muted-foreground">{plan.duration} days duration</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div>
                          <div className="font-medium text-success">{plan.roi}%</div>
                          <div className="text-sm text-muted-foreground capitalize">{plan.period}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div>
                          <div className="font-medium text-foreground">${plan.minAmount} - ${plan.maxAmount.toLocaleString()}</div>
                          <div className="text-sm text-muted-foreground">Investment range</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div>
                          <div className="font-medium text-foreground">{plan.totalInvestors} investors</div>
                          <div className="text-sm text-success">${plan.totalInvested.toLocaleString()} invested</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          plan.status === 'active' 
                            ? 'bg-success/10 text-success' 
                            : 'bg-destructive/10 text-destructive'
                        }`}>
                          {plan.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleEditPlan(plan)}
                          >
                            <Icon name="Edit" size={16} />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleToggleStatus(plan.id)}
                          >
                            <Icon name={plan.status === 'active' ? 'Pause' : 'Play'} size={16} />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleDeletePlan(plan.id, plan.name)}
                          >
                            <Icon name="Trash2" size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>

      {/* Edit Plan Modal */}
      {showEditModal && editingPlan && (
        <EditPlanModal
          plan={editingPlan}
          onClose={handleCloseEditModal}
          onSave={handleSaveEditedPlan}
        />
      )}
    </div>
  );
};

export default AdminInvestmentPlans;
