import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../../contexts/AdminAuthContext';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const AdminUserManagement = () => {
  const navigate = useNavigate();
  const { admin, isAdminAuthenticated } = useAdminAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);

  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'active', label: 'Active' },
    { value: 'pending', label: 'Pending Verification' },
    { value: 'suspended', label: 'Suspended' },
    { value: 'banned', label: 'Banned' }
  ];

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }

    // Simulate loading users data
    setTimeout(() => {
      setUsers([
        {
          id: 1,
          name: 'Alex Johnson',
          email: 'alex.johnson@email.com',
          role: 'user',
          status: 'active',
          kycStatus: 'verified',
          registrationDate: '2024-01-15',
          lastLogin: '2024-01-20',
          balance: 25000,
          totalDeposits: 50000,
          totalWithdrawals: 25000
        },
        {
          id: 2,
          name: 'Sarah Wilson',
          email: 'sarah.wilson@email.com',
          role: 'user',
          status: 'active',
          kycStatus: 'pending',
          registrationDate: '2024-01-18',
          lastLogin: '2024-01-19',
          balance: 10000,
          totalDeposits: 15000,
          totalWithdrawals: 5000
        },
        {
          id: 3,
          name: 'Mike Chen',
          email: 'mike.chen@email.com',
          role: 'user',
          status: 'suspended',
          kycStatus: 'verified',
          registrationDate: '2024-01-10',
          lastLogin: '2024-01-17',
          balance: 0,
          totalDeposits: 100000,
          totalWithdrawals: 100000
        },
        {
          id: 4,
          name: 'Emma Davis',
          email: 'emma.davis@email.com',
          role: 'user',
          status: 'pending',
          kycStatus: 'rejected',
          registrationDate: '2024-01-19',
          lastLogin: 'Never',
          balance: 1000,
          totalDeposits: 1000,
          totalWithdrawals: 0
        }
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || user.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleUserAction = (action, userId) => {
    setUsers(prevUsers => prevUsers.map(user => {
      if (user.id === userId) {
        switch (action) {
          case 'activate':
            return { ...user, status: 'active' };
          case 'suspend':
            return { ...user, status: 'suspended' };
          case 'ban':
            return { ...user, status: 'banned' };
          case 'verify_kyc':
            return { ...user, kycStatus: 'verified' };
          case 'reject_kyc':
            return { ...user, kycStatus: 'rejected' };
          default:
            return user;
        }
      }
      return user;
    }));
  };

  const handleDeleteUser = async (userId) => {
    if (window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      try {
        // Use comprehensive deletion utility
        const { deleteUserCompletely } = await import('../../utils/userDeletion');
        const result = deleteUserCompletely(userId);

        if (result.success) {
          // Update local state
          const updatedUsers = users.filter(user => user.id !== userId);
          setUsers(updatedUsers);

          console.log(`✅ User ${userId} permanently deleted:`, result.deletionLog);
          alert(`✅ User has been permanently deleted from the system`);
        } else {
          console.error('❌ Deletion failed:', result.error);
          alert(`❌ Failed to delete user: ${result.message}`);
        }
      } catch (error) {
        console.error('❌ Error during deletion:', error);
        alert(`❌ Error during deletion: ${error.message}`);
      }
    }
  };

  const handleEditUser = (user) => {
    setEditingUser(user);
    setShowUserModal(true);
  };

  const handleBulkAction = (action) => {
    if (selectedUsers.length === 0) {
      alert('Please select users first');
      return;
    }

    setUsers(prevUsers => prevUsers.map(user => {
      if (selectedUsers.includes(user.id)) {
        switch (action) {
          case 'activate':
            return { ...user, status: 'active' };
          case 'suspend':
            return { ...user, status: 'suspended' };
          case 'verify_kyc':
            return { ...user, kycStatus: 'verified' };
          default:
            return user;
        }
      }
      return user;
    }));

    setSelectedUsers([]);
  };

  const getStatusBadge = (status) => {
    const styles = {
      active: 'bg-green-500/20 text-green-400 border-green-500/30',
      pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      suspended: 'bg-red-500/20 text-red-400 border-red-500/30',
      banned: 'bg-red-600/20 text-red-300 border-red-600/30'
    };
    
    return (
      <span className={`px-2 py-1 text-xs rounded-md border ${styles[status] || styles.pending}`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  const getKycBadge = (kycStatus) => {
    const styles = {
      verified: 'bg-green-500/20 text-green-400 border-green-500/30',
      pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      rejected: 'bg-red-500/20 text-red-400 border-red-500/30'
    };
    
    return (
      <span className={`px-2 py-1 text-xs rounded-md border ${styles[kycStatus] || styles.pending}`}>
        {kycStatus.charAt(0).toUpperCase() + kycStatus.slice(1)}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-300">Loading users...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/admin-dashboard')}
              className="border-gray-600 text-gray-300"
            >
              <Icon name="ArrowLeft" size={16} />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-white">User Management</h1>
              <p className="text-sm text-gray-400">Manage user accounts, KYC, and permissions</p>
            </div>
          </div>
          <Button
            onClick={() => {
              setEditingUser(null);
              setShowUserModal(true);
            }}
            className="bg-blue-600 hover:bg-blue-700 mt-4 sm:mt-0"
          >
            <Icon name="Plus" size={16} />
            Add New User
          </Button>
        </div>
      </div>

      <div className="p-6">
        {/* Filters and Search */}
        <div className="bg-gray-800 rounded-lg p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <Input
              placeholder="Search users by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              icon="Search"
              className="bg-gray-700 border-gray-600 text-white"
            />
            <Select
              options={statusOptions}
              value={statusFilter}
              onChange={(value) => setStatusFilter(value)}
              placeholder="Filter by status"
              className="bg-gray-700 border-gray-600 text-white"
            />
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleBulkAction('activate')}
                disabled={selectedUsers.length === 0}
                className="border-gray-600 text-gray-300"
              >
                Bulk Activate
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleBulkAction('suspend')}
                disabled={selectedUsers.length === 0}
                className="border-gray-600 text-gray-300"
              >
                Bulk Suspend
              </Button>
            </div>
          </div>
          <p className="text-sm text-gray-400">
            Total Users: {filteredUsers.length} | Selected: {selectedUsers.length}
          </p>
        </div>

        {/* Users Table */}
        <div className="bg-gray-800 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left">
                    <input
                      type="checkbox"
                      checked={selectedUsers.length === filteredUsers.length && filteredUsers.length > 0}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedUsers(filteredUsers.map(user => user.id));
                        } else {
                          setSelectedUsers([]);
                        }
                      }}
                      className="rounded border-gray-600 bg-gray-700"
                    />
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                    KYC
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Balance
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Last Login
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-gray-700/50">
                    <td className="px-6 py-4">
                      <input
                        type="checkbox"
                        checked={selectedUsers.includes(user.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedUsers([...selectedUsers, user.id]);
                          } else {
                            setSelectedUsers(selectedUsers.filter(id => id !== user.id));
                          }
                        }}
                        className="rounded border-gray-600 bg-gray-700"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <div className="text-sm font-medium text-white">{user.name}</div>
                        <div className="text-sm text-gray-400">{user.email}</div>
                        <div className="text-xs text-gray-500">ID: {user.id}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {getStatusBadge(user.status)}
                    </td>
                    <td className="px-6 py-4">
                      {getKycBadge(user.kycStatus)}
                    </td>
                    <td className="px-6 py-4 text-sm text-white">
                      ${user.balance.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-300">
                      {user.lastLogin}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditUser(user)}
                          className="border-gray-600 text-gray-300"
                        >
                          <Icon name="Edit" size={14} />
                        </Button>
                        <div className="relative group">
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-gray-600 text-gray-300"
                          >
                            <Icon name="MoreHorizontal" size={14} />
                          </Button>
                          <div className="absolute right-0 top-full mt-1 bg-gray-700 border border-gray-600 rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10">
                            <div className="py-1 w-40">
                              <button
                                onClick={() => handleUserAction('activate', user.id)}
                                className="block w-full text-left px-3 py-2 text-sm text-gray-300 hover:bg-gray-600"
                              >
                                Activate
                              </button>
                              <button
                                onClick={() => handleUserAction('suspend', user.id)}
                                className="block w-full text-left px-3 py-2 text-sm text-gray-300 hover:bg-gray-600"
                              >
                                Suspend
                              </button>
                              <button
                                onClick={() => handleUserAction('verify_kyc', user.id)}
                                className="block w-full text-left px-3 py-2 text-sm text-gray-300 hover:bg-gray-600"
                              >
                                Verify KYC
                              </button>
                              <button
                                onClick={() => handleDeleteUser(user.id)}
                                className="block w-full text-left px-3 py-2 text-sm text-red-400 hover:bg-gray-600"
                              >
                                Delete User
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminUserManagement;
