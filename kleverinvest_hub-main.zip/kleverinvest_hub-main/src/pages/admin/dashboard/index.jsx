import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../../contexts/AdminAuthContext';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import AnimatedBitcoin from '../../../components/ui/AnimatedBitcoin';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { admin, adminLogout, isAdminAuthenticated } = useAdminAuth();
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    totalDeposits: 0,
    totalWithdrawals: 0,
    pendingTransactions: 0,
    systemHealth: 'Good'
  });
  const [recentActivities, setRecentActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check session on mount
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }

    // Simulate loading admin dashboard data
    setTimeout(() => {
      setStats({
        totalUsers: 1247,
        activeUsers: 892,
        totalDeposits: 2450000,
        totalWithdrawals: 1850000,
        pendingTransactions: 23,
        systemHealth: 'Excellent'
      });

      setRecentActivities([
        {
          id: 1,
          type: 'user_registration',
          message: 'New user registered: john.doe@email.com',
          timestamp: new Date(Date.now() - 5 * 60000),
          severity: 'info'
        },
        {
          id: 2,
          type: 'large_deposit',
          message: 'Large deposit: $50,000 from user ID 1234',
          timestamp: new Date(Date.now() - 15 * 60000),
          severity: 'success'
        },
        {
          id: 3,
          type: 'kyc_pending',
          message: 'KYC verification pending for 12 users',
          timestamp: new Date(Date.now() - 30 * 60000),
          severity: 'warning'
        },
        {
          id: 4,
          type: 'system_update',
          message: 'System backup completed successfully',
          timestamp: new Date(Date.now() - 45 * 60000),
          severity: 'info'
        },
        {
          id: 5,
          type: 'security_alert',
          message: 'Failed login attempts detected from IP 192.168.1.100',
          timestamp: new Date(Date.now() - 60 * 60000),
          severity: 'error'
        }
      ]);

      setLoading(false);
    }, 1000);
  }, []);

  const handleLogout = () => {
    adminLogout();
    navigate('/admin-login');
  };

  const quickActions = [
    {
      title: 'User Management',
      description: 'Manage users, KYC, permissions',
      icon: 'Users',
      color: 'bg-blue-500',
      path: '/admin-user-management'
    },
    {
      title: 'Transaction Management',
      description: 'View deposits, withdrawals, transfers',
      icon: 'CreditCard',
      color: 'bg-green-500',
      path: '/admin-transaction-management'
    },
    {
      title: 'Enhanced User Management',
      description: 'Advanced user management features',
      icon: 'Edit',
      color: 'bg-purple-500',
      path: '/admin-user-management-enhanced'
    },
    {
      title: 'System Settings',
      description: 'Configure platform settings',
      icon: 'Settings',
      color: 'bg-orange-500',
      path: '/admin-site-settings'
    },
    {
      title: 'Analytics & Reports',
      description: 'View detailed analytics',
      icon: 'BarChart3',
      color: 'bg-indigo-500',
      path: '/admin-system-analytics'
    },
    {
      title: 'Security Logs',
      description: 'Monitor security events',
      icon: 'Shield',
      color: 'bg-red-500',
      path: '/admin-system-logs'
    }
  ];

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'success': return 'text-green-400';
      default: return 'text-blue-400';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'error': return 'AlertCircle';
      case 'warning': return 'AlertTriangle';
      case 'success': return 'CheckCircle';
      default: return 'Info';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-300">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 relative">
      {/* Floating Bitcoin Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-10 left-10">
          <AnimatedBitcoin size="sm" animation="float" speed="slow" showGlow />
        </div>
        <div className="absolute top-32 right-20">
          <AnimatedBitcoin size="xs" animation="bounce" speed="normal" />
        </div>
        <div className="absolute bottom-40 left-16">
          <AnimatedBitcoin size="sm" animation="pulse" speed="slow" showGlow />
        </div>
        <div className="absolute bottom-20 right-32">
          <AnimatedBitcoin size="xs" animation="float" speed="fast" />
        </div>
      </div>

      {/* Header */}
      <div className="bg-gray-800/90 backdrop-blur-sm border-b border-gray-700 px-6 py-4 relative z-10">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gradient-to-r from-red-600 to-red-800 rounded-xl flex items-center justify-center shadow-lg relative">
              <Icon name="Shield" size={32} className="text-white" />
              <div className="absolute -top-1 -right-1">
                <AnimatedBitcoin size="xs" animation="spin" speed="fast" />
              </div>
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-white">
                Welcome, {user?.username || 'Admin'}!
              </h1>
              <p className="text-sm text-gray-300 flex items-center">
                <AnimatedBitcoin size="xs" animation="pulse" speed="fast" className="mr-2" />
                Administrator Dashboard - {user?.adminLevel || 'Standard'} Level
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3 mt-4 sm:mt-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/admin/profile')}
              className="border-gray-600 text-gray-300 hover:text-white"
            >
              <Icon name="Settings" size={16} />
              <span className="hidden sm:inline ml-2">Settings</span>
            </Button>
            <Button
              variant="outline" 
              size="sm"
              onClick={handleLogout}
              className="border-red-600 text-red-400 hover:text-red-300 hover:border-red-500"
            >
              <Icon name="LogOut" size={16} />
              <span className="hidden sm:inline ml-2">Logout</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 relative z-10">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <Icon name="Users" size={24} className="text-blue-400" />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-400">Total Users</p>
                <p className="text-2xl font-bold text-white">{stats.totalUsers.toLocaleString()}</p>
              </div>
            </div>
          </div>

          <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                <Icon name="UserCheck" size={24} className="text-green-400" />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-400">Active Users</p>
                <p className="text-2xl font-bold text-white">{stats.activeUsers.toLocaleString()}</p>
              </div>
            </div>
          </div>

          <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <Icon name="TrendingUp" size={24} className="text-purple-400" />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-400">Total Deposits</p>
                <p className="text-2xl font-bold text-white">${stats.totalDeposits.toLocaleString()}</p>
              </div>
            </div>
          </div>

          <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                <Icon name="AlertCircle" size={24} className="text-orange-400" />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-400">Pending Transactions</p>
                <p className="text-2xl font-bold text-white">{stats.pendingTransactions}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {quickActions.map((action, index) => (
            <div
              key={index}
              onClick={() => navigate(action.path)}
              className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6 cursor-pointer hover:border-gray-600 transition-all duration-200 hover:scale-105"
            >
              <div className="flex items-center mb-4">
                <div className={`w-12 h-12 ${action.color}/20 rounded-lg flex items-center justify-center`}>
                  <Icon name={action.icon} size={24} className={`${action.color.replace('bg-', 'text-')}`} />
                </div>
                <div className="ml-4 flex-1">
                  <h3 className="font-semibold text-white">{action.title}</h3>
                  <p className="text-sm text-gray-400">{action.description}</p>
                </div>
                <Icon name="ArrowRight" size={20} className="text-gray-400" />
              </div>
            </div>
          ))}
        </div>

        {/* Recent Activity */}
        <div className="bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-white">Recent Activity</h3>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/admin-system-logs')}
              className="border-gray-600 text-gray-300"
            >
              View All Logs
            </Button>
          </div>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-3 p-3 bg-gray-700/50 rounded-lg">
                <Icon 
                  name={getSeverityIcon(activity.severity)} 
                  size={16} 
                  className={`${getSeverityColor(activity.severity)} mt-1 flex-shrink-0`} 
                />
                <div className="flex-1">
                  <p className="text-sm text-gray-300">{activity.message}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {activity.timestamp.toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
