import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

import Header from './components/Header';
import HeroSection from './components/HeroSection';
import StatsSection from './components/StatsSection';
import FeaturesSection from './components/FeaturesSection';
import InvestmentPlans from './components/InvestmentPlans';
import CTASection from './components/CTASection';
import Footer from './components/Footer';
import BTCPriceChart from '../../components/ui/BTCPriceChart';
import EarningsCalculator from '../../components/ui/EarningsCalculator';
import BitcoinAnimatedBackground from '../../components/ui/BitcoinAnimatedBackground';

const HomeLandingPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <BitcoinAnimatedBackground />
      <Header />
      <HeroSection />
      <StatsSection />
      <FeaturesSection />

      {/* BTC Price Chart Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Live Bitcoin Price
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Track Bitcoin prices in real-time and make informed investment decisions
            </p>
          </div>
          <BTCPriceChart />
        </div>
      </section>

      {/* Earnings Calculator Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Calculate Your Potential Earnings
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Use our advanced calculator to project your investment returns
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <EarningsCalculator />
          </div>
        </div>
      </section>

      <InvestmentPlans />
      <CTASection />
      <Footer />
    </div>
  );
};

export default HomeLandingPage;
