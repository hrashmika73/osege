import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const HeroSection = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [btcPrice, setBtcPrice] = useState(45234.67);

  // Auto-rotate hero slides
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % 3);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // Simulate real-time BTC price updates
  useEffect(() => {
    const priceTimer = setInterval(() => {
      setBtcPrice(prev => {
        const change = (Math.random() - 0.5) * 100;
        return Math.max(40000, prev + change);
      });
    }, 3000);
    return () => clearInterval(priceTimer);
  }, []);

  const heroSlides = [
    {
      title: 'Invest in the Future of Finance with Bitcoin',
      subtitle: 'Build wealth with cryptocurrency investments backed by institutional-grade security and Bitcoin expertise',
      cta: 'Start Bitcoin Investment',
      image: '₿'
    },
    {
      title: 'Maximize Your Bitcoin Returns',
      subtitle: 'Earn up to 18.2% APY with our professionally managed Bitcoin investment strategies',
      cta: 'View Bitcoin Plans',
      image: '₿'
    },
    {
      title: 'Trusted Bitcoin Investment Platform',
      subtitle: 'Join 150K+ investors who trust us with $2.4B+ in Bitcoin investments worldwide',
      cta: 'Join Bitcoin Revolution',
      image: '₿'
    }
  ];

  const handleGetStarted = () => {
    navigate('/admin-dashboard');
  };

  const handleWatchDemo = () => {
    // Demo functionality
    console.log('Watch demo clicked');
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background Effects */}
      <div className="absolute inset-0 gradient-dark opacity-50"></div>
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-orange-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-orange-500/5 to-yellow-500/5 rounded-full blur-3xl"></div>
      </div>

      {/* Bitcoin Price Ticker */}
      <div className="absolute top-20 right-4 md:right-8 z-20">
        <div className="glass-effect rounded-lg p-3 border border-orange-500/20">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xs font-bold">₿</span>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">BTC/USD</div>
              <div className="text-sm font-bold text-orange-400">
                ${btcPrice.toLocaleString()}
              </div>
            </div>
            <div className="text-xs text-green-400">+2.4%</div>
          </div>
        </div>
      </div>

      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-5xl mx-auto">
          {/* Large Bitcoin Symbol */}
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-24 h-24 md:w-32 md:h-32 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full mb-6 animate-bounce-slow">
              <span className="text-white text-4xl md:text-6xl font-bold">₿</span>
            </div>
          </div>

          <h1 className="text-4xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-orange-400 via-yellow-500 to-orange-600 bg-clip-text text-transparent">
              {heroSlides[currentSlide].title}
            </span>
          </h1>
          
          <p className="text-lg md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            {heroSlides[currentSlide].subtitle}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              size="lg" 
              onClick={handleGetStarted}
              className="gradient-gold text-black font-semibold px-8 py-4 hover:scale-105 transition-transform"
            >
              {heroSlides[currentSlide].cta}
              <Icon name="ArrowRight" size={20} className="ml-2" />
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              onClick={handleWatchDemo}
              className="px-8 py-4 border-orange-500/50 text-orange-400 hover:bg-orange-500/10"
            >
              Watch Bitcoin Demo
              <Icon name="Play" size={20} className="ml-2" />
            </Button>
          </div>

          {/* Bitcoin Investment Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
            <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
              <div className="text-2xl font-bold text-orange-400">₿2.4B+</div>
              <div className="text-xs text-muted-foreground">Bitcoin Managed</div>
            </div>
            <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
              <div className="text-2xl font-bold text-orange-400">150K+</div>
              <div className="text-xs text-muted-foreground">Bitcoin Investors</div>
            </div>
            <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
              <div className="text-2xl font-bold text-orange-400">18.2%</div>
              <div className="text-xs text-muted-foreground">Max Bitcoin APY</div>
            </div>
            <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
              <div className="text-2xl font-bold text-orange-400">50+</div>
              <div className="text-xs text-muted-foreground">Countries</div>
            </div>
          </div>

          {/* Slide Indicators */}
          <div className="flex justify-center space-x-2 mt-8">
            {heroSlides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentSlide 
                    ? 'bg-orange-400 w-8' :'bg-muted hover:bg-orange-400/50'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;