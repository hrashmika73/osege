import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const Header = () => {
  const navigate = useNavigate();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigationItems = [
    { label: 'Home', path: '/', isActive: true },
    { label: 'About', path: '/about-company-page' },
    { label: 'Why Choose', path: '/why-choose-klever-invest' },
    { label: 'Plans', path: '/investment-plans' },
    { label: 'How It Works', path: '/how-it-works' },
    { label: 'FAQ', path: '/faq' },
    { label: 'Testimonials', path: '/testimonials' }
  ];

  const handleGetStarted = () => {
    navigate('/signup');
  };

  const handleSignIn = () => {
    navigate('/login');
  };

  return (
    <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${
      isScrolled ? 'glass-effect backdrop-blur-md bg-background/80' : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo with BTC-themed design */}
        <Link to="/home-landing-page" className="flex items-center space-x-2">
          <div className="w-10 h-10 gradient-gold rounded-lg flex items-center justify-center relative">
            <Icon name="TrendingUp" size={20} color="black" />
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-orange-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xs font-bold">₿</span>
            </div>
          </div>
          <span className="font-bold text-xl bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
            KleverInvest Hub
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          {navigationItems.map((item, index) => (
            <Link
              key={index}
              to={item.path}
              className={`text-sm font-medium transition-colors duration-200 hover:text-orange-400 ${
                item.isActive ? 'text-orange-400' : 'text-muted-foreground'
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Desktop Actions */}
        <div className="hidden md:flex items-center space-x-4">
          <Button
            variant="ghost"
            onClick={handleSignIn}
            className="text-muted-foreground hover:text-foreground"
          >
            Sign In
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/admin-login')}
            className="text-xs text-muted-foreground hover:text-red-400"
          >
            Admin
          </Button>
          <Button
            onClick={handleGetStarted}
            className="gradient-gold text-black font-semibold hover:scale-105 transition-transform"
          >
            Sign Up
            <Icon name="ArrowRight" size={16} className="ml-2" />
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="sm"
          className="md:hidden"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={20} />
        </Button>
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <div className="md:hidden glass-effect border-t border-border">
          <nav className="container mx-auto px-4 py-4 space-y-2">
            {navigationItems.map((item, index) => (
              <Link
                key={index}
                to={item.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`block py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                  item.isActive 
                    ? 'bg-orange-500/10 text-orange-400' :'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
              >
                {item.label}
              </Link>
            ))}
            <div className="border-t border-border pt-4 space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={handleSignIn}
              >
                Sign In
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-red-400"
                onClick={() => navigate('/admin-login')}
              >
                <Icon name="Shield" size={16} className="mr-2" />
                Admin Login
              </Button>
              <Button
                onClick={handleGetStarted}
                className="w-full gradient-gold text-black font-semibold"
              >
                Sign Up
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
