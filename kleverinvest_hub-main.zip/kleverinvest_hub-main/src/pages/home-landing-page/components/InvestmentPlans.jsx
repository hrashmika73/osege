import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const InvestmentPlans = () => {
  const navigate = useNavigate();

  const investmentPlans = [
    {
      name: 'Bitcoin Starter',
      apy: '8.5%',
      minInvestment: '₿0.0022',
      minInvestmentUSD: '$100',
      duration: '30 days',
      features: [
        'Basic Bitcoin portfolio',
        'Email support',
        'Mobile app access',
        'Bitcoin price alerts'
      ],
      popular: false,
      bitcoinAmount: '₿0.01 - ₿1',
      color: 'from-blue-400 to-blue-600'
    },
    {
      name: 'Bitcoin Growth',
      apy: '12.5%',
      minInvestment: '₿0.022',
      minInvestmentUSD: '$1,000',
      duration: '90 days',
      features: [
        'Advanced Bitcoin portfolio',
        'Priority support',
        'API access',
        'Bitcoin analytics dashboard',
        'Lightning Network integration'
      ],
      popular: true,
      bitcoinAmount: '₿1 - ₿10',
      color: 'from-orange-400 to-yellow-500'
    },
    {
      name: 'Bitcoin Pro',
      apy: '18.2%',
      minInvestment: '₿0.22',
      minInvestmentUSD: '$10,000',
      duration: '180 days',
      features: [
        'Premium Bitcoin portfolio',
        'Dedicated Bitcoin advisor',
        'Custom Bitcoin strategies',
        'Institutional Bitcoin tools',
        'Hardware wallet integration',
        'White-glove onboarding'
      ],
      popular: false,
      bitcoinAmount: '₿10+',
      color: 'from-purple-400 to-purple-600'
    }
  ];

  const handleGetStarted = (plan) => {
    navigate('/admin-dashboard', { state: { selectedPlan: plan.name } });
  };

  return (
    <section id="plans" className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center animate-pulse">
              <span className="text-white text-xl font-bold">₿</span>
            </div>
            <h2 className="text-4xl font-bold">Bitcoin Investment Plans</h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Choose the perfect Bitcoin investment plan to start your cryptocurrency journey with professional management
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {investmentPlans.map((plan, index) => (
            <div key={index} className={`relative rounded-xl p-8 border-2 transition-all duration-300 hover:scale-105 ${
              plan.popular 
                ? 'border-orange-400 bg-gradient-to-b from-orange-500/5 to-yellow-500/5 shadow-2xl shadow-orange-500/20' 
                : 'border-border bg-card hover:border-orange-400/50 hover:bg-card/80'
            }`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="gradient-gold text-black px-6 py-2 rounded-full text-sm font-bold flex items-center space-x-2">
                    <span className="text-orange-600">₿</span>
                    <span>Most Popular</span>
                  </span>
                </div>
              )}

              {/* Plan Header */}
              <div className="text-center mb-8">
                <div className={`w-16 h-16 bg-gradient-to-r ${plan.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <span className="text-white text-2xl font-bold">₿</span>
                </div>
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="text-4xl font-bold text-primary mb-2">{plan.apy}</div>
                <div className="text-muted-foreground">Annual Percentage Yield</div>
              </div>

              {/* Investment Details */}
              <div className="space-y-3 mb-8 p-4 glass-effect rounded-lg border border-orange-500/10">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Minimum Investment</span>
                  <div className="text-right">
                    <div className="font-semibold text-orange-400">{plan.minInvestment}</div>
                    <div className="text-xs text-muted-foreground">{plan.minInvestmentUSD}</div>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Lock Period</span>
                  <span className="font-semibold">{plan.duration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Bitcoin Range</span>
                  <span className="font-semibold text-orange-400">{plan.bitcoinAmount}</span>
                </div>
              </div>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start">
                    <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
                      <Icon name="Check" size={12} color="white" />
                    </div>
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <Button 
                onClick={() => handleGetStarted(plan)}
                className={`w-full ${plan.popular ? 'gradient-gold text-black hover:scale-105' : 'border-orange-500/50 hover:bg-orange-500/10'}`}
                variant={plan.popular ? 'default' : 'outline'}
                size="lg"
              >
                <div className="flex items-center justify-center space-x-2">
                  <span className="text-orange-500">₿</span>
                  <span>Start Bitcoin Investment</span>
                </div>
              </Button>

              {/* Bitcoin bonus indicator */}
              {plan.popular && (
                <div className="mt-4 text-center">
                  <div className="inline-flex items-center space-x-2 text-xs text-orange-400 bg-orange-500/10 px-3 py-1 rounded-full">
                    <Icon name="Gift" size={12} />
                    <span>Free Bitcoin bonus included</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Bitcoin Calculator Teaser */}
        <div className="mt-16 text-center">
          <div className="glass-effect rounded-xl p-8 max-w-2xl mx-auto border border-orange-500/20">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Icon name="Calculator" size={24} className="text-orange-400" />
              <h3 className="text-xl font-bold">Bitcoin Investment Calculator</h3>
            </div>
            <p className="text-muted-foreground mb-6">
              See how much your Bitcoin investment could grow with our professional management
            </p>
            <Button 
              variant="outline" 
              className="border-orange-500/50 text-orange-400 hover:bg-orange-500/10"
              onClick={() => navigate('/btc-live-trading-interface')}
            >
              Try Bitcoin Calculator
              <Icon name="ArrowRight" size={16} className="ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InvestmentPlans;