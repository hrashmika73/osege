import React from 'react';
import Icon from '../../../components/AppIcon';

const FeaturesSection = () => {
  const features = [
    {
      icon: 'Shield',
      title: 'Bank-Grade Bitcoin Security',
      description: 'Multi-layer security with cold storage and insurance protection for your Bitcoin investments',
      bitcoinFeature: 'Hardware wallet integration & multi-sig protection'
    },
    {
      icon: 'Zap',
      title: 'Instant Bitcoin Transactions',
      description: 'Lightning-fast Bitcoin deposits and withdrawals with minimal network fees',
      bitcoinFeature: 'Lightning Network support for fast payments'
    },
    {
      icon: 'BarChart3',
      title: 'Advanced Bitcoin Analytics',
      description: 'Real-time Bitcoin portfolio tracking and performance insights with market analysis',
      bitcoinFeature: 'Bitcoin price alerts & technical indicators'
    },
    {
      icon: 'Headphones',
      title: '24/7 Bitcoin Expert Support',
      description: 'Round-the-clock customer support from Bitcoin and cryptocurrency experts',
      bitcoinFeature: 'Dedicated Bitcoin investment advisors'
    },
    {
      icon: 'Wallet',
      title: 'Secure Bitcoin Wallet',
      description: 'Industry-leading Bitcoin wallet with institutional-grade security features',
      bitcoinFeature: 'Non-custodial options available'
    },
    {
      icon: 'TrendingUp',
      title: 'Bitcoin Investment Strategies',
      description: 'Professional Bitcoin investment strategies designed to maximize your returns',
      bitcoinFeature: 'DCA automation & yield optimization'
    }
  ];

  return (
    <section id="features" className="py-20 bg-gradient-to-b from-background to-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xl font-bold">₿</span>
            </div>
            <h2 className="text-4xl font-bold">Why Choose KleverInvest for Bitcoin</h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Experience the future of Bitcoin investing with our cutting-edge platform designed specifically for cryptocurrency excellence
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="group">
              <div className="glass-effect rounded-xl p-6 hover:bg-card/50 transition-all duration-300 border border-orange-500/10 hover:border-orange-500/30 hover:scale-105">
                {/* Icon with Bitcoin accent */}
                <div className="relative mb-6">
                  <div className="w-14 h-14 gradient-gold rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Icon name={feature.icon} size={28} color="black" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">₿</span>
                  </div>
                </div>

                <h3 className="text-xl font-semibold mb-3 group-hover:text-orange-400 transition-colors">
                  {feature.title}
                </h3>
                
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  {feature.description}
                </p>

                {/* Bitcoin-specific feature highlight */}
                <div className="border-t border-orange-500/20 pt-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-orange-500 rounded-full flex items-center justify-center">
                      <Icon name="Check" size={10} color="white" />
                    </div>
                    <span className="text-sm text-orange-400 font-medium">
                      {feature.bitcoinFeature}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust indicators with Bitcoin theme */}
        <div className="mt-16 text-center">
          <div className="glass-effect rounded-xl p-8 max-w-4xl mx-auto border border-orange-500/20">
            <h3 className="text-2xl font-bold mb-6 flex items-center justify-center space-x-2">
              <Icon name="Award" size={24} className="text-orange-400" />
              <span>Bitcoin Investment Excellence</span>
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <Icon name="ShieldCheck" size={32} className="text-green-400 mx-auto mb-2" />
                <div className="text-sm font-semibold">SOC 2 Certified</div>
                <div className="text-xs text-muted-foreground">Bitcoin Security</div>
              </div>
              <div className="text-center">
                <Icon name="Award" size={32} className="text-blue-400 mx-auto mb-2" />
                <div className="text-sm font-semibold">Best Bitcoin Platform</div>
                <div className="text-xs text-muted-foreground">2024 Crypto Awards</div>
              </div>
              <div className="text-center">
                <Icon name="Users" size={32} className="text-purple-400 mx-auto mb-2" />
                <div className="text-sm font-semibold">150K+ Investors</div>
                <div className="text-xs text-muted-foreground">Trust Our Platform</div>
              </div>
              <div className="text-center">
                <Icon name="Globe" size={32} className="text-orange-400 mx-auto mb-2" />
                <div className="text-sm font-semibold">Global Presence</div>
                <div className="text-xs text-muted-foreground">50+ Countries</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;