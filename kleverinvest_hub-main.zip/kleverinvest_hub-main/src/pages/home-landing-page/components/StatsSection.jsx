import React from 'react';
import Icon from '../../../components/AppIcon';

const StatsSection = () => {
  const stats = [
    { 
      label: 'Total Bitcoin Value Locked', 
      value: '₿52,847', 
      usdValue: '$2.4B+',
      icon: 'Lock',
      color: 'text-orange-400'
    },
    { 
      label: 'Active Bitcoin Investors', 
      value: '150K+', 
      change: '+12.5% this month',
      icon: 'Users',
      color: 'text-blue-400'
    },
    { 
      label: 'Countries with Bitcoin Access', 
      value: '50+', 
      change: 'Expanding globally',
      icon: 'Globe',
      color: 'text-green-400'
    },
    { 
      label: 'Average Bitcoin APY', 
      value: '12.5%', 
      change: 'Up to 18.2% available',
      icon: 'TrendingUp',
      color: 'text-yellow-400'
    }
  ];

  return (
    <section className="py-20 border-t border-border bg-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
              <span className="text-white text-sm font-bold">₿</span>
            </div>
            <h2 className="text-2xl font-bold">Bitcoin Investment Platform Stats</h2>
          </div>
          <p className="text-muted-foreground">Trusted by investors worldwide for Bitcoin investments</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center group">
              <div className="glass-effect rounded-xl p-6 hover:bg-card/50 transition-all duration-300 border border-orange-500/10 hover:border-orange-500/30">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4 bg-gradient-to-r from-orange-400/20 to-yellow-500/20 ${stat.color} group-hover:scale-110 transition-transform`}>
                  <Icon name={stat.icon} size={24} />
                </div>
                <div className="space-y-2">
                  <div className="text-3xl font-bold text-primary">{stat.value}</div>
                  {stat.usdValue && (
                    <div className="text-lg font-semibold text-orange-400">{stat.usdValue}</div>
                  )}
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                  {stat.change && (
                    <div className="text-xs text-green-400">{stat.change}</div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bitcoin Price Movement Visualization */}
        <div className="mt-16 text-center">
          <div className="glass-effect rounded-xl p-6 max-w-4xl mx-auto border border-orange-500/20">
            <div className="flex items-center justify-center space-x-6 mb-4">
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs font-bold">₿</span>
                </div>
                <span className="font-semibold">Bitcoin Market Performance</span>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <div className="text-muted-foreground">24h Change</div>
                <div className="text-green-400 font-semibold">+2.4%</div>
              </div>
              <div>
                <div className="text-muted-foreground">7d Change</div>
                <div className="text-green-400 font-semibold">+8.7%</div>
              </div>
              <div>
                <div className="text-muted-foreground">Market Cap</div>
                <div className="text-orange-400 font-semibold">$847B</div>
              </div>
              <div>
                <div className="text-muted-foreground">Volume</div>
                <div className="text-blue-400 font-semibold">$23.4B</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StatsSection;