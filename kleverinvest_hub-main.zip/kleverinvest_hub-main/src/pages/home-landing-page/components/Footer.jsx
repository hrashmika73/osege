import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const Footer = () => {
  const footerSections = [
    {
      title: 'Product',
      links: [
        { label: 'Bitcoin Investment', href: '/' },
        { label: 'Trading Dashboard', href: '/trading-dashboard' },
        { label: 'Portfolio Management', href: '/investment-portfolio-dashboard' },
        { label: 'Market Analysis', href: '/market-analysis-center' },
        { label: 'Mobile App', href: '/signup' }
      ]
    },
    {
      title: 'Company',
      links: [
        { label: 'About Us', href: '/about' },
        { label: 'Why Choose Us', href: '/why-choose-klever-invest' },
        { label: 'How It Works', href: '/how-it-works' },
        { label: 'Careers', href: '/contact' },
        { label: 'Press Kit', href: '/contact' }
      ]
    },
    {
      title: 'Support',
      links: [
        { label: 'Help Center', href: '/faq' },
        { label: 'Contact Support', href: '/contact' },
        { label: 'Community', href: '/testimonials' },
        { label: 'System Status', href: '/admin-dashboard' },
        { label: 'API Documentation', href: '/contact' }
      ]
    },
    {
      title: 'Legal',
      links: [
        { label: 'Terms of Service', href: '/contact' },
        { label: 'Privacy Policy', href: '/contact' },
        { label: 'Cookie Policy', href: '/contact' },
        { label: 'Compliance', href: '/about' },
        { label: 'Risk Disclosure', href: '/about' }
      ]
    }
  ];

  const socialLinks = [
    { icon: 'Twitter', href: '#', label: 'Twitter' },
    { icon: 'Github', href: '#', label: 'GitHub' },
    { icon: 'Linkedin', href: '#', label: 'LinkedIn' },
    { icon: 'Youtube', href: '#', label: 'YouTube' }
  ];

  return (
    <footer className="border-t border-border bg-card/50">
      <div className="container mx-auto px-4 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8 mb-12">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <Link to="/home-landing-page" className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 gradient-gold rounded-lg flex items-center justify-center relative">
                <Icon name="TrendingUp" size={20} color="black" />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-orange-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs font-bold">₿</span>
                </div>
              </div>
              <span className="font-bold text-xl bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
                KleverInvest Hub
              </span>
            </Link>
            
            <p className="text-muted-foreground mb-6 max-w-md">
              The future of Bitcoin and cryptocurrency investing, built for everyone. Professional investment management with institutional-grade security.
            </p>

            {/* Bitcoin Price Widget */}
            <div className="glass-effect rounded-lg p-4 border border-orange-500/20 mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">₿</span>
                  </div>
                  <span className="font-semibold">Bitcoin</span>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-orange-400">$45,234.67</div>
                  <div className="text-xs text-green-400">+2.4%</div>
                </div>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 glass-effect rounded-lg flex items-center justify-center text-muted-foreground hover:text-orange-400 hover:bg-orange-500/10 transition-colors"
                >
                  <Icon name={social.icon} size={20} />
                </a>
              ))}
            </div>
          </div>

          {/* Footer Sections */}
          {footerSections.map((section, index) => (
            <div key={index}>
              <h3 className="font-semibold mb-4 text-foreground">{section.title}</h3>
              <ul className="space-y-3">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link
                      to={link.href}
                      className="text-muted-foreground hover:text-orange-400 transition-colors text-sm"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter Signup */}
        <div className="border-t border-border pt-8 mb-8">
          <div className="max-w-md">
            <h3 className="font-semibold mb-2 flex items-center space-x-2">
              <Icon name="Mail" size={20} className="text-orange-400" />
              <span>Bitcoin Market Updates</span>
            </h3>
            <p className="text-muted-foreground text-sm mb-4">
              Get the latest Bitcoin market insights and investment opportunities delivered to your inbox.
            </p>
            <div className="flex space-x-2">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-3 py-2 bg-background border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent"
              />
              <button className="px-4 py-2 gradient-gold text-black rounded-md text-sm font-semibold hover:scale-105 transition-transform">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-border pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-muted-foreground text-sm">
              © 2025 KleverInvest Hub. All rights reserved. Bitcoin investment platform.
            </div>
            
            <div className="flex items-center space-x-6 text-sm text-muted-foreground">
              <div className="flex items-center space-x-2">
                <Icon name="ShieldCheck" size={16} className="text-green-400" />
                <span>Secured by SSL</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="Award" size={16} className="text-yellow-400" />
                <span>SOC 2 Compliant</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-orange-400">₿</span>
                <span>Bitcoin Focused</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
