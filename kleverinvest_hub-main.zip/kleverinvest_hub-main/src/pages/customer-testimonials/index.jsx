import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../home-landing-page/components/Header';
import Footer from '../home-landing-page/components/Footer';
import HeroSection from './components/HeroSection';
import FeaturedTestimonials from './components/FeaturedTestimonials';
import VideoTestimonials from './components/VideoTestimonials';
import SuccessMetrics from './components/SuccessMetrics';
import CustomerSpotlight from './components/CustomerSpotlight';
import ReviewAggregation from './components/ReviewAggregation';

const CustomerTestimonials = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: isLoaded ? 1 : 0 }}
        transition={{ duration: 0.5 }}
        className="pt-16"
      >
        <HeroSection />
        <FeaturedTestimonials />
        <VideoTestimonials />
        <SuccessMetrics />
        <CustomerSpotlight />
        <ReviewAggregation />
      </motion.main>

      <Footer />
    </div>
  );
};

export default CustomerTestimonials;