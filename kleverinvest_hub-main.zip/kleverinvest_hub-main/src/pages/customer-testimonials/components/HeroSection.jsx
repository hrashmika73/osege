import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const HeroSection = () => {
  const trustIndicators = [
    { icon: 'Users', number: '50,000+', text: 'Happy Investors' },
    { icon: 'Star', number: '4.9/5', text: 'Average Rating' },
    { icon: 'TrendingUp', number: '$2.5M+', text: 'Profits Generated' }
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute top-24 left-16 w-32 h-32 gradient-gold rounded-full opacity-10 animate-pulse"></div>
        <div className="absolute bottom-32 right-20 w-24 h-24 bg-orange-500 rounded-full opacity-20 animate-bounce"></div>
        <motion.div
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
          animate={{ rotate: 360 }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
        >
          <div className="w-80 h-80 border border-orange-500/10 rounded-full"></div>
        </motion.div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Trust Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center space-x-2 glass-effect px-4 py-2 rounded-full mb-8"
          >
            <Icon name="Award" size={16} className="text-orange-400" />
            <span className="text-sm font-medium">Trusted by 50,000+ investors worldwide</span>
          </motion.div>

          {/* Main Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-4xl md:text-6xl font-bold mb-6"
          >
            What Our{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Customers Say
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="text-xl text-muted-foreground mb-12 max-w-3xl mx-auto"
          >
            Real stories from real investors who have achieved financial success with KleverInvest Hub. 
            Discover how our platform has transformed their investment journey.
          </motion.p>

          {/* Trust Indicators */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12"
          >
            {trustIndicators.map((indicator, index) => (
              <div key={index} className="glass-effect p-6 rounded-xl text-center">
                <div className="w-12 h-12 gradient-gold rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name={indicator.icon} size={20} color="black" />
                </div>
                <div className="text-2xl font-bold text-orange-400 mb-2">
                  {indicator.number}
                </div>
                <div className="text-sm text-muted-foreground">
                  {indicator.text}
                </div>
              </div>
            ))}
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.7 }}
            className="flex flex-col sm:flex-row justify-center gap-4"
          >
            <Button className="gradient-gold text-black font-semibold px-8 py-3 hover:scale-105 transition-transform">
              Join Our Community
              <Icon name="ArrowRight" size={16} className="ml-2" />
            </Button>
            <Button variant="outline" className="border-orange-500 text-orange-400 hover:bg-orange-500/10 px-8 py-3">
              Read More Stories
              <Icon name="BookOpen" size={16} className="ml-2" />
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;