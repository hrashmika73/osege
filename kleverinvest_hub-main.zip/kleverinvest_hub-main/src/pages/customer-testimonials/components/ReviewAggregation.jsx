import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReviewAggregation = () => {
  const [selectedPlatform, setSelectedPlatform] = useState('trustpilot');

  const reviewPlatforms = [
    {
      id: 'trustpilot',
      name: 'Trustpilot',
      icon: 'Star',
      rating: 4.8,
      totalReviews: 3247,
      recentReviews: [
        {
          rating: 5,
          author: 'Jennifer K.',
          date: '2 days ago',
          review: 'Exceptional platform with consistent returns. Customer support is outstanding.',
          verified: true
        },
        {
          rating: 5,
          author: 'Robert M.',
          date: '5 days ago',
          review: 'Best investment decision I\'ve made. The platform is user-friendly and profitable.',
          verified: true
        },
        {
          rating: 4,
          author: 'Lisa W.',
          date: '1 week ago',
          review: 'Great returns and security. Only wish they had more educational content.',
          verified: true
        }
      ]
    },
    {
      id: 'google',
      name: 'Google Reviews',
      icon: 'Search',
      rating: 4.9,
      totalReviews: 1892,
      recentReviews: [
        {
          rating: 5,
          author: 'Michael S.',
          date: '1 day ago',
          review: 'Transparent, secure, and highly profitable. Couldn\'t ask for more.',
          verified: true
        },
        {
          rating: 5,
          author: 'Sarah L.',
          date: '4 days ago',
          review: 'Amazing platform! The returns have exceeded all my expectations.',
          verified: true
        },
        {
          rating: 5,
          author: 'David P.',
          date: '6 days ago',
          review: 'Professional service with excellent customer support. Highly recommend.',
          verified: true
        }
      ]
    },
    {
      id: 'facebook',
      name: 'Facebook',
      icon: 'MessageSquare',
      rating: 4.7,
      totalReviews: 892,
      recentReviews: [
        {
          rating: 5,
          author: 'Maria G.',
          date: '3 days ago',
          review: 'Love this platform! Easy to use and great customer service.',
          verified: true
        },
        {
          rating: 4,
          author: 'John D.',
          date: '1 week ago',
          review: 'Solid platform with good returns. The mobile app could use some improvements.',
          verified: true
        },
        {
          rating: 5,
          author: 'Emma R.',
          date: '1 week ago',
          review: 'Fantastic experience overall. The educational resources are very helpful.',
          verified: true
        }
      ]
    }
  ];

  const currentPlatform = reviewPlatforms.find(p => p.id === selectedPlatform);

  const overallStats = {
    averageRating: 4.8,
    totalReviews: 6031,
    distribution: [
      { stars: 5, percentage: 78, count: 4704 },
      { stars: 4, percentage: 16, count: 965 },
      { stars: 3, percentage: 4, count: 241 },
      { stars: 2, percentage: 1, count: 60 },
      { stars: 1, percentage: 1, count: 61 }
    ]
  };

  const renderStars = (rating) => {
    return [...Array(5)].map((_, i) => (
      <Icon
        key={i}
        name="Star"
        size={16}
        className={i < rating ? "text-yellow-500 fill-current" : "text-gray-400"}
      />
    ));
  };

  return (
    <section className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Verified{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Reviews
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            See what customers are saying about us across multiple review platforms
          </motion.p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Overall Rating Summary */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="glass-effect p-8 rounded-xl mb-12"
          >
            <div className="grid md:grid-cols-2 gap-8 items-center">
              {/* Overall Score */}
              <div className="text-center md:text-left">
                <div className="text-6xl font-bold text-orange-400 mb-2">
                  {overallStats.averageRating}
                </div>
                <div className="flex items-center justify-center md:justify-start space-x-1 mb-2">
                  {renderStars(Math.round(overallStats.averageRating))}
                </div>
                <p className="text-muted-foreground">
                  Based on {overallStats.totalReviews.toLocaleString()} verified reviews
                </p>
              </div>

              {/* Rating Distribution */}
              <div className="space-y-2">
                {overallStats.distribution.map((dist) => (
                  <div key={dist.stars} className="flex items-center space-x-3">
                    <div className="flex items-center space-x-1">
                      <span className="text-sm w-2">{dist.stars}</span>
                      <Icon name="Star" size={14} className="text-yellow-500" />
                    </div>
                    <div className="flex-1 bg-border rounded-full h-2">
                      <div
                        className="h-2 gradient-gold rounded-full transition-all duration-1000"
                        style={{ width: `${dist.percentage}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-muted-foreground w-12">
                      {dist.percentage}%
                    </span>
                    <span className="text-xs text-muted-foreground w-16">
                      ({dist.count})
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Platform Selection */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {reviewPlatforms.map((platform) => (
              <Button
                key={platform.id}
                variant={selectedPlatform === platform.id ? "default" : "outline"}
                className={selectedPlatform === platform.id 
                  ? "gradient-gold text-black font-semibold" :"border-orange-500 text-orange-400 hover:bg-orange-500/10"
                }
                onClick={() => setSelectedPlatform(platform.id)}
              >
                <Icon name={platform.icon} size={16} className="mr-2" />
                {platform.name}
                <div className="ml-2 flex items-center space-x-1">
                  <Icon name="Star" size={12} className="text-yellow-500" />
                  <span className="text-xs">{platform.rating}</span>
                </div>
              </Button>
            ))}
          </div>

          {/* Platform Reviews */}
          <motion.div
            key={selectedPlatform}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="glass-effect rounded-xl overflow-hidden"
          >
            {/* Platform Header */}
            <div className="p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 gradient-gold rounded-full flex items-center justify-center">
                    <Icon name={currentPlatform?.icon} size={20} color="black" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{currentPlatform?.name}</h3>
                    <div className="flex items-center space-x-2">
                      <div className="flex items-center space-x-1">
                        {renderStars(Math.round(currentPlatform?.rating || 0))}
                      </div>
                      <span className="text-lg font-bold text-orange-400">
                        {currentPlatform?.rating}
                      </span>
                      <span className="text-muted-foreground">
                        ({currentPlatform?.totalReviews.toLocaleString()} reviews)
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Reviews */}
            <div className="p-6">
              <h4 className="text-lg font-semibold mb-6 text-orange-400">Recent Reviews</h4>
              <div className="space-y-6">
                {currentPlatform?.recentReviews?.map((review, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="glass-effect p-4 rounded-lg"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-start space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-orange-500/20 to-yellow-500/20 rounded-full flex items-center justify-center">
                          <Icon name="User" size={16} className="text-orange-400" />
                        </div>
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="font-medium">{review.author}</span>
                            {review.verified && (
                              <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                                <Icon name="Check" size={10} color="white" />
                              </div>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="flex items-center space-x-1">
                              {renderStars(review.rating)}
                            </div>
                            <span className="text-xs text-muted-foreground">{review.date}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">
                      "{review.review}"
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Call to Action */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="text-center mt-12 p-8 glass-effect rounded-xl"
          >
            <Icon name="MessageCircle" size={48} className="text-orange-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold mb-2">Join Our Satisfied Customers</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Don't just take our word for it. Join thousands of satisfied investors who have achieved success with KleverInvest Hub.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button className="gradient-gold text-black font-semibold px-8 py-3 hover:scale-105 transition-transform">
                Start Investing Today
                <Icon name="ArrowRight" size={16} className="ml-2" />
              </Button>
              <Button variant="outline" className="border-orange-500 text-orange-400 hover:bg-orange-500/10 px-8 py-3">
                Leave a Review
                <Icon name="Star" size={16} className="ml-2" />
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ReviewAggregation;