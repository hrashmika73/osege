import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const FeaturedTestimonials = () => {
  const [filter, setFilter] = useState('all');
  const [selectedTestimonial, setSelectedTestimonial] = useState(null);

  const filterOptions = [
    { id: 'all', label: 'All Stories', icon: 'Users' },
    { id: 'high-return', label: 'High Returns', icon: 'TrendingUp' },
    { id: 'long-term', label: 'Long-term', icon: 'Calendar' },
    { id: 'beginner', label: 'Beginners', icon: 'Sparkles' }
  ];

  const testimonials = [
    {
      id: 1,
      name: 'Sarah Chen',
      location: 'Singapore',
      photo: '/api/placeholder/80/80',
      investment: '$5,000',
      returns: '127%',
      duration: '8 months',
      category: 'high-return',
      verified: true,
      story: 'I started with KleverInvest as a complete beginner in cryptocurrency. The platform made it incredibly easy to understand and start investing.',
      fullStory: 'I was initially hesitant about cryptocurrency investments due to the complexity and risks involved. However, KleverInvest Hub\'s educational resources and step-by-step guidance gave me the confidence to start. Within just 8 months, I\'ve seen remarkable returns that have exceeded my expectations. The platform\'s transparency and real-time tracking features keep me informed every step of the way.',
      rating: 5,
      joinDate: 'March 2024'
    },
    {
      id: 2,
      name: 'Marcus Rodriguez',
      location: 'Miami, USA',
      photo: '/api/placeholder/80/80',
      investment: '$12,500',
      returns: '89%',
      duration: '1.2 years',
      category: 'long-term',
      verified: true,
      story: 'The consistent returns and professional support have made KleverInvest my go-to platform for cryptocurrency investments.',
      fullStory: 'After trying several investment platforms, I found KleverInvest Hub to be the most reliable and profitable. Their long-term investment strategies align perfectly with my financial goals. The customer support team is exceptional, always ready to help with any questions or concerns. I\'ve recommended this platform to my entire family.',
      rating: 5,
      joinDate: 'January 2023'
    },
    {
      id: 3,
      name: 'Emma Thompson',
      location: 'London, UK',
      photo: '/api/placeholder/80/80',
      investment: '$2,500',
      returns: '156%',
      duration: '6 months',
      category: 'beginner',
      verified: true,
      story: 'As someone new to investing, the educational resources and user-friendly interface made all the difference.',
      fullStory: 'I had zero experience with investments when I joined KleverInvest Hub. The educational materials, video tutorials, and responsive customer support helped me understand the market and make informed decisions. The results have been beyond my wildest dreams, and I\'m now planning to increase my investment significantly.',
      rating: 5,
      joinDate: 'June 2024'
    },
    {
      id: 4,
      name: 'David Park',
      location: 'Seoul, South Korea',
      photo: '/api/placeholder/80/80',
      investment: '$8,000',
      returns: '94%',
      duration: '10 months',
      category: 'high-return',
      verified: true,
      story: 'The advanced analytics and market insights have helped me make better investment decisions and maximize my returns.',
      fullStory: 'What sets KleverInvest Hub apart is their advanced analytics dashboard and market insights. As someone with a technical background, I appreciate the detailed data and performance metrics. The platform has consistently delivered solid returns while maintaining transparency about risks and market conditions.',
      rating: 5,
      joinDate: 'October 2023'
    },
    {
      id: 5,
      name: 'Lisa Johnson',
      location: 'Toronto, Canada',
      photo: '/api/placeholder/80/80',
      investment: '$15,000',
      returns: '112%',
      duration: '1.5 years',
      category: 'long-term',
      verified: true,
      story: 'KleverInvest has become an essential part of my retirement planning strategy with consistent, reliable returns.',
      fullStory: 'I was looking for a reliable platform to diversify my retirement portfolio when I discovered KleverInvest Hub. The platform\'s focus on long-term growth and risk management aligns perfectly with my investment philosophy. The steady returns have exceeded traditional investment vehicles, and I feel confident about my financial future.',
      rating: 5,
      joinDate: 'August 2022'
    },
    {
      id: 6,
      name: 'Ahmed Hassan',
      location: 'Dubai, UAE',
      photo: '/api/placeholder/80/80',
      investment: '$25,000',
      returns: '78%',
      duration: '2 years',
      category: 'long-term',
      verified: true,
      story: 'The platform\'s security measures and regulatory compliance give me peace of mind for my substantial investments.',
      fullStory: 'Security was my primary concern when choosing an investment platform. KleverInvest Hub\'s bank-grade security, insurance coverage, and regulatory compliance convinced me to invest significantly. The returns have been steady and reliable, and the customer service is exceptional for high-value accounts.',
      rating: 5,
      joinDate: 'December 2021'
    }
  ];

  const filteredTestimonials = filter === 'all' 
    ? testimonials 
    : testimonials.filter(t => t.category === filter);

  return (
    <section className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Success{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Stories
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Read authentic testimonials from our community of successful investors
          </motion.p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {filterOptions.map((option) => (
            <button
              key={option.id}
              onClick={() => setFilter(option.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all ${
                filter === option.id
                  ? 'gradient-gold text-black font-semibold' :'glass-effect text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon name={option.icon} size={16} />
              <span className="text-sm">{option.label}</span>
            </button>
          ))}
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTestimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="glass-effect p-6 rounded-xl hover:bg-card/80 transition-all duration-300 cursor-pointer group"
              onClick={() => setSelectedTestimonial(testimonial)}
            >
              {/* Customer Info */}
              <div className="flex items-start space-x-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-orange-500/20 to-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                  <Icon name="User" size={24} className="text-orange-400" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h3 className="font-bold">{testimonial.name}</h3>
                    {testimonial.verified && (
                      <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                        <Icon name="Check" size={12} color="white" />
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                </div>
              </div>

              {/* Investment Stats */}
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-orange-400">{testimonial.investment}</div>
                  <div className="text-xs text-muted-foreground">Invested</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-green-500">{testimonial.returns}</div>
                  <div className="text-xs text-muted-foreground">Returns</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold">{testimonial.duration}</div>
                  <div className="text-xs text-muted-foreground">Duration</div>
                </div>
              </div>

              {/* Rating */}
              <div className="flex items-center space-x-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Icon key={i} name="Star" size={16} className="text-yellow-500 fill-current" />
                ))}
              </div>

              {/* Story Preview */}
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                "{testimonial.story}"
              </p>

              {/* Read More */}
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  Member since {testimonial.joinDate}
                </span>
                <div className="flex items-center space-x-1 text-orange-400 group-hover:text-orange-300 transition-colors">
                  <span className="text-sm font-medium">Read Full Story</span>
                  <Icon name="ArrowRight" size={14} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Modal for Full Story */}
        {selectedTestimonial && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50"
            onClick={() => setSelectedTestimonial(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="glass-effect p-8 rounded-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setSelectedTestimonial(null)}
                className="absolute top-4 right-4 w-8 h-8 gradient-gold rounded-full flex items-center justify-center"
              >
                <Icon name="X" size={16} color="black" />
              </button>

              {/* Customer Header */}
              <div className="flex items-start space-x-4 mb-6">
                <div className="w-20 h-20 bg-gradient-to-br from-orange-500/20 to-yellow-500/20 rounded-full flex items-center justify-center">
                  <Icon name="User" size={32} className="text-orange-400" />
                </div>
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <h3 className="text-2xl font-bold">{selectedTestimonial.name}</h3>
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <Icon name="Check" size={14} color="white" />
                    </div>
                  </div>
                  <p className="text-muted-foreground">{selectedTestimonial.location}</p>
                  <div className="flex items-center space-x-1 mt-2">
                    {[...Array(selectedTestimonial.rating)].map((_, i) => (
                      <Icon key={i} name="Star" size={16} className="text-yellow-500 fill-current" />
                    ))}
                  </div>
                </div>
              </div>

              {/* Investment Stats */}
              <div className="grid grid-cols-3 gap-6 mb-6 p-4 glass-effect rounded-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-400">{selectedTestimonial.investment}</div>
                  <div className="text-sm text-muted-foreground">Investment</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-500">{selectedTestimonial.returns}</div>
                  <div className="text-sm text-muted-foreground">Total Returns</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{selectedTestimonial.duration}</div>
                  <div className="text-sm text-muted-foreground">Investment Period</div>
                </div>
              </div>

              {/* Full Story */}
              <div>
                <h4 className="text-lg font-semibold mb-4 text-orange-400">Full Story</h4>
                <p className="text-muted-foreground leading-relaxed">
                  "{selectedTestimonial.fullStory}"
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-border text-center">
                <p className="text-sm text-muted-foreground">
                  Member since {selectedTestimonial.joinDate}
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default FeaturedTestimonials;