import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const CustomerSpotlight = () => {
  const [activeSpotlight, setActiveSpotlight] = useState(0);

  const spotlights = [
    {
      name: 'Alexandra Rodriguez',
      title: 'Retired Teacher',
      location: 'Phoenix, Arizona',
      photo: '/api/placeholder/120/120',
      investment: '$22,500',
      returns: '156%',
      duration: '14 months',
      joinDate: 'September 2022',
      story: {
        background: 'Alexandra was looking for ways to grow her retirement savings after years of teaching. She was initially skeptical about cryptocurrency investments but was attracted to KleverInvest\'s educational approach.',
        journey: 'Starting with careful research and small investments, Alexandra gradually increased her portfolio as she gained confidence. She particularly appreciated the platform\'s educational resources and personal support.',
        results: 'Her disciplined approach and reinvestment strategy have yielded exceptional returns, allowing her to secure her retirement and even help her grandchildren with college funds.',
        advice: 'Start small, educate yourself, and don\'t let fear hold you back from financial opportunities. The platform makes it so much easier than I thought possible.'
      },
      achievements: [
        'Achieved 156% returns in 14 months',
        'Successfully diversified retirement portfolio',
        'Became platform ambassador in her community',
        'Helped 12 friends start their investment journey'
      ],
      investmentStrategy: 'Conservative growth with monthly reinvestment',
      favoriteFeatures: ['Educational content', 'Risk calculator', 'Personal support']
    },
    {
      name: 'Marcus Chen',
      title: 'Tech Entrepreneur',
      location: 'Seattle, Washington',
      photo: '/api/placeholder/120/120',
      investment: '$85,000',
      returns: '89%',
      duration: '18 months',
      joinDate: 'March 2022',
      story: {
        background: 'As a successful tech entrepreneur, Marcus was already familiar with digital currencies but needed a platform that could handle significant investments with institutional-level security.',
        journey: 'Marcus chose KleverInvest for its advanced analytics, security features, and transparent fee structure. He appreciated the platform\'s technical sophistication and professional approach.',
        results: 'His strategic approach to cryptocurrency investment has generated substantial returns while maintaining appropriate risk management for his high-value portfolio.',
        advice: 'Look for platforms that offer both sophistication and transparency. KleverInvest delivers on both fronts with excellent technology and clear communication.'
      },
      achievements: [
        'Generated $75,650 in profits',
        'Successfully scaled investment strategy',
        'Received VIP account status',
        'Participated in beta testing new features'
      ],
      investmentStrategy: 'Aggressive growth with technical analysis',
      favoriteFeatures: ['Advanced analytics', 'API access', 'Priority support']
    },
    {
      name: 'Fatima Al-Zahra',
      title: 'Medical Doctor',
      location: 'Dubai, UAE',
      photo: '/api/placeholder/120/120',
      investment: '$45,000',
      returns: '134%',
      duration: '11 months',
      joinDate: 'December 2022',
      story: {
        background: 'Dr. Al-Zahra needed a reliable investment platform that could accommodate her busy schedule while providing steady growth for her family savings.',
        journey: 'Attracted by the platform\'s reputation for security and compliance, Fatima started with a moderate investment and was impressed by the consistent returns and professional service.',
        results: 'Her investment success has exceeded expectations, providing financial security for her family and funding for her private practice expansion.',
        advice: 'Trust in platforms with proven track records and regulatory compliance. KleverInvest\'s transparency gave me the confidence to invest significantly.'
      },
      achievements: [
        'Achieved 134% returns in under a year',
        'Funded private practice expansion',
        'Diversified family investment portfolio',
        'Became regional success story'
      ],
      investmentStrategy: 'Balanced approach with automatic reinvestment',
      favoriteFeatures: ['Mobile app', 'Automated investing', 'Security features']
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSpotlight((prev) => (prev + 1) % spotlights.length);
    }, 10000); // Change every 10 seconds
    return () => clearInterval(interval);
  }, [spotlights.length]);

  const currentSpotlight = spotlights[activeSpotlight];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Customer{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Spotlight
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Deep dive into detailed success stories and investment strategies from our top performers
          </motion.p>
        </div>

        {/* Spotlight Navigation */}
        <div className="flex justify-center space-x-4 mb-12">
          {spotlights.map((spotlight, index) => (
            <button
              key={index}
              onClick={() => setActiveSpotlight(index)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all ${
                activeSpotlight === index
                  ? 'gradient-gold text-black font-semibold' :'glass-effect text-muted-foreground hover:text-foreground'
              }`}
            >
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500/20 to-yellow-500/20 rounded-full flex items-center justify-center">
                <Icon name="User" size={14} className={activeSpotlight === index ? "text-black" : "text-orange-400"} />
              </div>
              <span className="text-sm hidden sm:inline">{spotlight.name.split(' ')[0]}</span>
            </button>
          ))}
        </div>

        {/* Spotlight Content */}
        <motion.div
          key={activeSpotlight}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-6xl mx-auto"
        >
          <div className="glass-effect rounded-xl overflow-hidden">
            <div className="grid lg:grid-cols-3 gap-8 p-8">
              {/* Customer Profile */}
              <div className="text-center lg:text-left">
                <div className="w-32 h-32 bg-gradient-to-br from-orange-500/20 to-yellow-500/20 rounded-full flex items-center justify-center mx-auto lg:mx-0 mb-6">
                  <Icon name="User" size={48} className="text-orange-400" />
                </div>
                
                <h3 className="text-2xl font-bold mb-2">{currentSpotlight.name}</h3>
                <p className="text-orange-400 font-medium mb-1">{currentSpotlight.title}</p>
                <p className="text-sm text-muted-foreground mb-6">{currentSpotlight.location}</p>

                {/* Investment Stats */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-lg font-bold text-orange-400">{currentSpotlight.investment}</div>
                    <div className="text-xs text-muted-foreground">Invested</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-green-500">{currentSpotlight.returns}</div>
                    <div className="text-xs text-muted-foreground">Returns</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold">{currentSpotlight.duration}</div>
                    <div className="text-xs text-muted-foreground">Duration</div>
                  </div>
                </div>

                {/* Key Info */}
                <div className="space-y-3 text-sm">
                  <div className="flex items-center justify-between lg:justify-start lg:space-x-4">
                    <span className="text-muted-foreground">Member since:</span>
                    <span className="font-medium">{currentSpotlight.joinDate}</span>
                  </div>
                  <div className="flex items-center justify-between lg:justify-start lg:space-x-4">
                    <span className="text-muted-foreground">Strategy:</span>
                    <span className="font-medium">{currentSpotlight.investmentStrategy}</span>
                  </div>
                </div>
              </div>

              {/* Story Content */}
              <div className="lg:col-span-2 space-y-6">
                {/* Background */}
                <div>
                  <h4 className="text-lg font-semibold text-orange-400 mb-3">Background</h4>
                  <p className="text-muted-foreground leading-relaxed">
                    {currentSpotlight.story.background}
                  </p>
                </div>

                {/* Journey */}
                <div>
                  <h4 className="text-lg font-semibold text-orange-400 mb-3">Investment Journey</h4>
                  <p className="text-muted-foreground leading-relaxed">
                    {currentSpotlight.story.journey}
                  </p>
                </div>

                {/* Results */}
                <div>
                  <h4 className="text-lg font-semibold text-orange-400 mb-3">Results</h4>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    {currentSpotlight.story.results}
                  </p>
                </div>

                {/* Quote */}
                <div className="glass-effect p-4 rounded-lg border-l-4 border-orange-500">
                  <Icon name="Quote" size={20} className="text-orange-400 mb-2" />
                  <p className="italic text-muted-foreground">
                    "{currentSpotlight.story.advice}"
                  </p>
                  <p className="text-sm font-medium mt-2">- {currentSpotlight.name}</p>
                </div>
              </div>
            </div>

            {/* Achievements & Features */}
            <div className="border-t border-border p-8">
              <div className="grid md:grid-cols-2 gap-8">
                {/* Achievements */}
                <div>
                  <h4 className="text-lg font-semibold text-orange-400 mb-4">Key Achievements</h4>
                  <div className="space-y-2">
                    {currentSpotlight.achievements?.map((achievement, index) => (
                      <div key={index} className="flex items-start space-x-2">
                        <Icon name="Trophy" size={16} className="text-orange-400 mt-1 flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{achievement}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Favorite Features */}
                <div>
                  <h4 className="text-lg font-semibold text-orange-400 mb-4">Favorite Platform Features</h4>
                  <div className="space-y-2">
                    {currentSpotlight.favoriteFeatures?.map((feature, index) => (
                      <div key={index} className="flex items-start space-x-2">
                        <Icon name="Heart" size={16} className="text-red-500 mt-1 flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Progress Indicators */}
        <div className="flex justify-center space-x-2 mt-8">
          {spotlights.map((_, index) => (
            <div
              key={index}
              className={`h-2 rounded-full transition-all duration-300 ${
                activeSpotlight === index 
                  ? 'w-8 gradient-gold' :'w-2 bg-border'
              }`}
            ></div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CustomerSpotlight;