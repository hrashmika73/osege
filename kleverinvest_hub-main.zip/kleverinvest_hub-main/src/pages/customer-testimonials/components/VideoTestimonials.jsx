import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const VideoTestimonials = () => {
  const [playingVideo, setPlayingVideo] = useState(null);

  const videoTestimonials = [
    {
      id: 1,
      name: 'Robert Chen',
      title: 'Cryptocurrency Enthusiast',
      location: 'San Francisco, CA',
      thumbnail: '/api/placeholder/400/225',
      duration: '2:34',
      investment: '$18,500',
      returns: '142%',
      highlights: ['Platform Security', 'Investment Strategy', 'Customer Support'],
      description: 'Robert shares his journey from crypto skeptic to successful investor'
    },
    {
      id: 2,
      name: 'Maria Santos',
      title: 'Small Business Owner',
      location: 'Barcelona, Spain',
      thumbnail: '/api/placeholder/400/225',
      duration: '3:12',
      investment: '$7,250',
      returns: '189%',
      highlights: ['Beginner-Friendly', 'Educational Resources', 'Steady Growth'],
      description: 'How Maria built wealth for her business expansion through smart investing'
    },
    {
      id: 3,
      name: 'James Mitchell',
      title: 'Financial Advisor',
      location: 'Sydney, Australia',
      thumbnail: '/api/placeholder/400/225',
      duration: '4:18',
      investment: '$32,000',
      returns: '97%',
      highlights: ['Professional Analysis', 'Risk Management', 'Long-term Strategy'],
      description: 'A financial advisor\'s perspective on KleverInvest\'s investment approach'
    },
    {
      id: 4,
      name: 'Priya Patel',
      title: 'Software Engineer',
      location: 'Mumbai, India',
      thumbnail: '/api/placeholder/400/225',
      duration: '2:56',
      investment: '$4,800',
      returns: '203%',
      highlights: ['Technology Trust', 'Real-time Tracking', 'Mobile Experience'],
      description: 'Tech professional explains why she chose KleverInvest for her investments'
    }
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Video{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Testimonials
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Watch our customers share their investment journey and success stories
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {videoTestimonials.map((video, index) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="glass-effect rounded-xl overflow-hidden hover:bg-card/80 transition-all duration-300 group"
            >
              {/* Video Player Area */}
              <div className="relative">
                <div className="aspect-video bg-gradient-to-br from-orange-500/20 to-yellow-500/20 flex items-center justify-center cursor-pointer"
                     onClick={() => setPlayingVideo(video.id)}>
                  {playingVideo === video.id ? (
                    <div className="w-full h-full bg-black flex items-center justify-center">
                      <div className="text-center">
                        <Icon name="Play" size={64} className="text-white mb-4" />
                        <p className="text-white">Video Player</p>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="absolute inset-0 bg-gradient-to-br from-orange-500/20 to-yellow-500/20"></div>
                      <div className="relative z-10 w-16 h-16 gradient-gold rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Icon name="Play" size={24} color="black" />
                      </div>
                    </>
                  )}
                </div>
                
                {/* Duration Badge */}
                <div className="absolute bottom-3 right-3 bg-black/80 text-white text-sm px-2 py-1 rounded">
                  {video.duration}
                </div>

                {/* Success Indicator */}
                <div className="absolute top-3 left-3 glass-effect px-3 py-1 rounded-full">
                  <div className="flex items-center space-x-1">
                    <Icon name="TrendingUp" size={14} className="text-green-500" />
                    <span className="text-sm font-bold text-green-500">{video.returns}</span>
                  </div>
                </div>
              </div>

              {/* Video Info */}
              <div className="p-6">
                {/* Customer Info */}
                <div className="flex items-start space-x-4 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-500/20 to-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Icon name="User" size={20} className="text-orange-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{video.name}</h3>
                    <p className="text-sm text-orange-400">{video.title}</p>
                    <p className="text-xs text-muted-foreground">{video.location}</p>
                  </div>
                </div>

                {/* Investment Stats */}
                <div className="grid grid-cols-2 gap-4 mb-4 p-3 glass-effect rounded-lg">
                  <div className="text-center">
                    <div className="text-lg font-bold text-orange-400">{video.investment}</div>
                    <div className="text-xs text-muted-foreground">Investment</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-green-500">{video.returns}</div>
                    <div className="text-xs text-muted-foreground">Returns</div>
                  </div>
                </div>

                {/* Description */}
                <p className="text-sm text-muted-foreground mb-4">
                  {video.description}
                </p>

                {/* Key Highlights */}
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-orange-400 mb-2">Key Topics:</h4>
                  <div className="flex flex-wrap gap-2">
                    {video.highlights?.map((highlight, i) => (
                      <span key={i} className="text-xs px-2 py-1 glass-effect rounded-full">
                        {highlight}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Watch Button */}
                <button
                  onClick={() => setPlayingVideo(video.id)}
                  className="w-full gradient-gold text-black font-semibold py-3 rounded-lg hover:scale-105 transition-transform flex items-center justify-center space-x-2"
                >
                  <Icon name="Play" size={16} />
                  <span>Watch Testimonial</span>
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mt-16 p-8 glass-effect rounded-xl"
        >
          <Icon name="VideoIcon" size={48} className="text-orange-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold mb-2">Share Your Success Story</h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Have you achieved success with KleverInvest Hub? We'd love to feature your story and inspire other investors.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button className="gradient-gold text-black font-semibold px-6 py-3 rounded-lg hover:scale-105 transition-transform">
              Submit Your Story
              <Icon name="ArrowRight" size={16} className="ml-2 inline" />
            </button>
            <button className="border border-orange-500 text-orange-400 hover:bg-orange-500/10 px-6 py-3 rounded-lg transition-colors">
              Contact Us
              <Icon name="MessageCircle" size={16} className="ml-2 inline" />
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default VideoTestimonials;