import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const SuccessMetrics = () => {
  const [animatedValues, setAnimatedValues] = useState({
    totalInvestors: 0,
    averageReturns: 0,
    totalProfits: 0,
    satisfaction: 0
  });

  const targetValues = {
    totalInvestors: 52847,
    averageReturns: 124,
    totalProfits: 2.8,
    satisfaction: 4.9
  };

  const metrics = [
    {
      id: 'totalInvestors',
      icon: 'Users',
      label: 'Total Satisfied Investors',
      value: animatedValues.totalInvestors,
      target: targetValues.totalInvestors,
      suffix: '+',
      color: 'from-blue-500 to-cyan-500',
      description: 'Active investors earning profits'
    },
    {
      id: 'averageReturns',
      icon: 'TrendingUp',
      label: 'Average Customer Returns',
      value: animatedValues.averageReturns,
      target: targetValues.averageReturns,
      suffix: '%',
      color: 'from-green-500 to-emerald-500',
      description: 'Across all investment plans'
    },
    {
      id: 'totalProfits',
      icon: 'DollarSign',
      label: 'Combined Profits Generated',
      value: animatedValues.totalProfits,
      target: targetValues.totalProfits,
      prefix: '$',
      suffix: 'M+',
      color: 'from-orange-500 to-yellow-500',
      description: 'Total returns to customers'
    },
    {
      id: 'satisfaction',
      icon: 'Star',
      label: 'Platform Satisfaction Rating',
      value: animatedValues.satisfaction,
      target: targetValues.satisfaction,
      suffix: '/5',
      color: 'from-purple-500 to-pink-500',
      description: 'Based on verified reviews'
    }
  ];

  useEffect(() => {
    const duration = 2000; // 2 seconds
    const steps = 60;
    const stepDuration = duration / steps;

    const interval = setInterval(() => {
      setAnimatedValues(prev => {
        const newValues = {};
        let allComplete = true;

        Object.keys(targetValues).forEach(key => {
          const target = targetValues[key];
          const current = prev[key];
          const increment = target / steps;
          
          if (current < target) {
            newValues[key] = Math.min(current + increment, target);
            allComplete = false;
          } else {
            newValues[key] = target;
          }
        });

        if (allComplete) {
          clearInterval(interval);
        }

        return { ...prev, ...newValues };
      });
    }, stepDuration);

    return () => clearInterval(interval);
  }, []);

  const formatValue = (metric) => {
    let formattedValue;
    
    if (metric.id === 'totalInvestors') {
      formattedValue = Math.floor(metric.value).toLocaleString();
    } else if (metric.id === 'totalProfits') {
      formattedValue = metric.value.toFixed(1);
    } else if (metric.id === 'satisfaction') {
      formattedValue = metric.value.toFixed(1);
    } else {
      formattedValue = Math.floor(metric.value);
    }
    
    return `${metric.prefix || ''}${formattedValue}${metric.suffix || ''}`;
  };

  const testimonialHighlights = [
    {
      quote: "The returns exceeded my expectations completely!",
      author: "Sarah M.",
      category: "High Returns"
    },
    {
      quote: "Best investment platform I\'ve ever used.",
      author: "Michael R.",
      category: "Platform Quality"
    },
    {
      quote: "Customer support is phenomenal - 24/7 help.",
      author: "Emma T.",
      category: "Support"
    },
    {
      quote: "Transparent, secure, and highly profitable.",
      author: "David L.",
      category: "Trust"
    }
  ];

  return (
    <section className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Success{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              By Numbers
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Real metrics that demonstrate our commitment to customer success and satisfaction
          </motion.p>
        </div>

        {/* Main Metrics */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {metrics.map((metric, index) => (
            <motion.div
              key={metric.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="glass-effect p-6 rounded-xl text-center hover:bg-card/80 transition-all duration-300"
            >
              {/* Icon */}
              <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${metric.color} flex items-center justify-center`}>
                <Icon name={metric.icon} size={24} color="white" />
              </div>

              {/* Value */}
              <div className="text-3xl font-bold text-orange-400 mb-2">
                {formatValue(metric)}
              </div>

              {/* Label */}
              <h3 className="font-semibold mb-2">{metric.label}</h3>
              
              {/* Description */}
              <p className="text-sm text-muted-foreground">{metric.description}</p>
            </motion.div>
          ))}
        </div>

        {/* Customer Feedback Highlights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="glass-effect p-8 rounded-xl"
        >
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold mb-2">What Customers Say Most</h3>
            <p className="text-muted-foreground">Common themes from customer testimonials</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {testimonialHighlights.map((highlight, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="glass-effect p-4 rounded-lg"
              >
                <div className="flex items-start space-x-2 mb-3">
                  <Icon name="Quote" size={16} className="text-orange-400 mt-1 flex-shrink-0" />
                  <p className="text-sm italic">"{highlight.quote}"</p>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-orange-400">{highlight.author}</span>
                  <span className="text-xs px-2 py-1 glass-effect rounded-full">{highlight.category}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Trust Indicators */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="mt-16 text-center"
        >
          <div className="grid md:grid-cols-3 gap-8">
            <div className="glass-effect p-6 rounded-xl">
              <Icon name="Shield" size={32} className="text-green-500 mx-auto mb-3" />
              <h4 className="font-bold mb-2">Security Verified</h4>
              <p className="text-sm text-muted-foreground">
                Bank-grade security with insurance coverage
              </p>
            </div>
            <div className="glass-effect p-6 rounded-xl">
              <Icon name="Award" size={32} className="text-orange-400 mx-auto mb-3" />
              <h4 className="font-bold mb-2">Industry Recognition</h4>
              <p className="text-sm text-muted-foreground">
                Multiple awards for innovation and service
              </p>
            </div>
            <div className="glass-effect p-6 rounded-xl">
              <Icon name="Users" size={32} className="text-blue-500 mx-auto mb-3" />
              <h4 className="font-bold mb-2">Community Driven</h4>
              <p className="text-sm text-muted-foreground">
                Built based on customer feedback and needs
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SuccessMetrics;