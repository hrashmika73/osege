import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const PlanComparison = () => {
  const [selectedFeature, setSelectedFeature] = useState('overview');

  const plans = ['Starter Plan', 'Professional Plan', 'Elite Plan'];
  
  const features = {
    overview: {
      title: 'Plan Overview',
      icon: 'Info',
      data: {
        'Expected Returns': ['6-12%', '12-18%', '18-25%'],
        'Risk Level': ['Low', 'Moderate', 'Higher'],
        'Minimum Investment': ['$100', '$1,000', '$10,000'],
        'Management Fee': ['1.5%', '1.2%', '1.0%'],
        'Withdrawal Period': ['30 days', '14 days', '7 days']
      }
    },
    portfolio: {
      title: 'Portfolio Composition',
      icon: 'PieChart',
      data: {
        'Bitcoin (BTC)': ['60%', '40%', '30%'],
        'Ethereum (ETH)': ['25%', '30%', '25%'],
        'Alternative Coins': ['0%', '20%', '35%'],
        'DeFi Tokens': ['0%', '0%', '10%'],
        'Stablecoins': ['15%', '10%', '0%']
      }
    },
    support: {
      title: 'Support & Services',
      icon: 'MessageCircle',
      data: {
        'Customer Support': ['Email', 'Live Chat', 'VIP Support'],
        'Performance Reports': ['Monthly', 'Weekly', 'Daily'],
        'Account Manager': ['No', 'Yes', 'Personal'],
        'Strategy Sessions': ['No', 'Quarterly', 'Monthly'],
        'Market Analysis': ['Basic', 'Advanced', 'Custom']
      }
    },
    features: {
      title: 'Features & Benefits',
      icon: 'Star',
      data: {
        'Portfolio Rebalancing': ['Manual', 'AI-Powered', 'Custom Strategy'],
        'Early Access': ['No', 'No', 'Yes'],
        'Exclusive Opportunities': ['No', 'Limited', 'Full Access'],
        'Insurance Coverage': ['Basic', 'Enhanced', 'Premium'],
        'Tax Reporting': ['Basic', 'Detailed', 'Professional']
      }
    }
  };

  const getValueStyle = (value, rowIndex, colIndex) => {
    // Highlight best values
    const isHighlight = 
      (rowIndex === 0 && colIndex === 2) || // Highest returns
      (rowIndex === 1 && colIndex === 1) || // Moderate risk (often preferred)
      (rowIndex === 2 && colIndex === 0) || // Lowest minimum
      (rowIndex === 3 && colIndex === 2) || // Lowest fee
      (rowIndex === 4 && colIndex === 2);   // Fastest withdrawal

    return isHighlight ? 'text-orange-400 font-semibold' : 'text-foreground';
  };

  const categoryTabs = Object.keys(features);

  return (
    <section className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Detailed Plan <span className="text-orange-400">Comparison</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Compare all features side-by-side to make the best investment decision for your goals
          </motion.p>
        </div>

        {/* Feature Category Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-wrap justify-center gap-2 mb-12"
        >
          {categoryTabs.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedFeature(category)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full transition-all ${
                selectedFeature === category
                  ? 'gradient-gold text-black font-semibold' :'glass-effect text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon name={features[category].icon} size={16} />
              <span>{features[category].title}</span>
            </button>
          ))}
        </motion.div>

        {/* Comparison Table */}
        <motion.div
          key={selectedFeature}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="glass-effect rounded-xl overflow-hidden"
        >
          {/* Desktop Table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full">
              {/* Table Header */}
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left p-6 font-semibold">
                    {features[selectedFeature].title}
                  </th>
                  {plans.map((plan, index) => (
                    <th key={index} className="text-center p-6 font-semibold">
                      <div className="flex flex-col items-center space-y-2">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center font-bold ${
                          index === 1 ? 'gradient-gold text-black' : 'bg-muted text-muted-foreground'
                        }`}>
                          {index === 0 ? 'S' : index === 1 ? 'P' : 'E'}
                        </div>
                        <span className="text-sm">{plan}</span>
                        {index === 1 && (
                          <span className="text-xs text-orange-400 font-medium">Recommended</span>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>

              {/* Table Body */}
              <tbody>
                {Object.entries(features[selectedFeature].data).map(([feature, values], rowIndex) => (
                  <tr key={feature} className="border-b border-border last:border-b-0">
                    <td className="p-6 font-medium">{feature}</td>
                    {values.map((value, colIndex) => (
                      <td key={colIndex} className="p-6 text-center">
                        <span className={getValueStyle(value, rowIndex, colIndex)}>
                          {value}
                        </span>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden p-6 space-y-6">
            {plans.map((plan, planIndex) => (
              <div key={planIndex} className="bg-card rounded-lg p-4">
                <div className="flex items-center space-x-3 mb-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold ${
                    planIndex === 1 ? 'gradient-gold text-black' : 'bg-muted text-muted-foreground'
                  }`}>
                    {planIndex === 0 ? 'S' : planIndex === 1 ? 'P' : 'E'}
                  </div>
                  <div>
                    <div className="font-semibold">{plan}</div>
                    {planIndex === 1 && (
                      <div className="text-xs text-orange-400 font-medium">Recommended</div>
                    )}
                  </div>
                </div>
                <div className="space-y-3">
                  {Object.entries(features[selectedFeature].data).map(([feature, values], rowIndex) => (
                    <div key={feature} className="flex justify-between">
                      <span className="text-sm text-muted-foreground">{feature}:</span>
                      <span className={`text-sm font-medium ${getValueStyle(values[planIndex], rowIndex, planIndex)}`}>
                        {values[planIndex]}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-12"
        >
          <div className="glass-effect rounded-xl p-6 max-w-2xl mx-auto">
            <div className="flex items-start space-x-3">
              <Icon name="Info" size={20} className="text-orange-400 mt-0.5" />
              <div className="text-sm text-muted-foreground text-left">
                <strong className="text-foreground">Note:</strong> All plans include basic security features, 
                regulatory compliance, and access to our mobile app. Upgrade or downgrade your plan at any time. 
                Performance data based on historical results and current market analysis.
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default PlanComparison;