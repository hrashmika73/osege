import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useUserAuth } from '../../../contexts/UserAuthContext';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PlanCards = ({ selectedPlan, setSelectedPlan }) => {
  const [showModal, setShowModal] = useState(false);
  const [modalPlan, setModalPlan] = useState(null);
  const navigate = useNavigate();
  const { isUserAuthenticated, user } = useUserAuth();

  const handleInvestNow = (plan) => {
    if (isUserAuthenticated) {
      // User is logged in, check KYC status
      if (user?.kycStatus === 'verified') {
        // Redirect to investment form or user dashboard with selected plan
        setSelectedPlan(plan.id);
        navigate('/user-dashboard?tab=investments&plan=' + plan.id);
      } else {
        // Redirect to KYC verification
        navigate('/kyc-verification');
      }
    } else {
      // User not logged in, redirect to signup
      setSelectedPlan(plan.id);
      navigate('/signup');
    }
  };

  const plans = [
    {
      id: 'starter',
      name: 'Starter Plan',
      risk: 'Low Risk',
      riskLevel: 1,
      returns: '6-12%',
      minAmount: 100,
      recommended: false,
      features: [
        'Diversified cryptocurrency portfolio',
        'Professional risk management',
        'Monthly performance reports',
        'Email support',
        'Basic market analysis'
      ],
      allocation: {
        'Bitcoin (BTC)': 60,
        'Ethereum (ETH)': 25,
        'Stablecoins': 15
      },
      withdrawalPeriod: '30 days',
      managementFee: '1.5%',
      description: 'Perfect for beginners looking to enter the cryptocurrency market with minimal risk exposure.',
      historicalPerformance: [
        { year: '2023', return: 8.4 },
        { year: '2022', return: 7.2 },
        { year: '2021', return: 11.8 }
      ]
    },
    {
      id: 'professional',
      name: 'Professional Plan',
      risk: 'Moderate Risk',
      riskLevel: 2,
      returns: '12-18%',
      minAmount: 1000,
      recommended: true,
      features: [
        'Advanced portfolio optimization',
        'AI-powered rebalancing',
        'Weekly performance reports',
        'Priority support & live chat',
        'Advanced market insights',
        'Dedicated account manager',
        'Quarterly strategy calls'
      ],
      allocation: {
        'Bitcoin (BTC)': 40,
        'Ethereum (ETH)': 30,
        'Alt Coins': 20,
        'Stablecoins': 10
      },
      withdrawalPeriod: '14 days',
      managementFee: '1.2%',
      description: 'Ideal for experienced investors seeking balanced growth with professional management.',
      historicalPerformance: [
        { year: '2023', return: 15.2 },
        { year: '2022', return: 13.8 },
        { year: '2021', return: 17.4 }
      ]
    },
    {
      id: 'elite',
      name: 'Elite Plan',
      risk: 'Higher Risk',
      riskLevel: 3,
      returns: '18-25%',
      minAmount: 10000,
      recommended: false,
      features: [
        'Aggressive growth strategies',
        'Access to exclusive opportunities',
        'Daily performance monitoring',
        'VIP support & priority service',
        'Custom investment strategies',
        'Personal portfolio manager',
        'Monthly strategy sessions',
        'Early access to new features'
      ],
      allocation: {
        'Bitcoin (BTC)': 30,
        'Ethereum (ETH)': 25,
        'Alt Coins': 35,
        'DeFi Tokens': 10
      },
      withdrawalPeriod: '7 days',
      managementFee: '1.0%',
      description: 'For high-net-worth individuals seeking maximum returns with higher risk tolerance.',
      historicalPerformance: [
        { year: '2023', return: 22.1 },
        { year: '2022', return: 19.5 },
        { year: '2021', return: 24.7 }
      ]
    }
  ];

  const getRiskColor = (level) => {
    switch (level) {
      case 1: return 'text-green-400 bg-green-500/20';
      case 2: return 'text-yellow-400 bg-yellow-500/20';
      case 3: return 'text-red-400 bg-red-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  const handlePlanDetails = (plan) => {
    setModalPlan(plan);
    setShowModal(true);
  };

  const PlanModal = ({ plan, onClose }) => {
    if (!plan) return null;

    return (
      <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="glass-effect rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        >
          {/* Modal Header */}
          <div className="p-6 border-b border-border">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">{plan.name}</h2>
                <div className="flex items-center space-x-3 mt-2">
                  <span className={`px-3 py-1 rounded-full text-sm ${getRiskColor(plan.riskLevel)}`}>
                    {plan.risk}
                  </span>
                  <span className="text-orange-400 font-semibold">
                    {plan.returns} Annual Returns
                  </span>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-muted hover:bg-border flex items-center justify-center transition-colors"
              >
                <Icon name="X" size={20} />
              </button>
            </div>
          </div>

          {/* Modal Content */}
          <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column */}
            <div className="space-y-6">
              {/* Description */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Plan Overview</h3>
                <p className="text-muted-foreground">{plan.description}</p>
              </div>

              {/* Key Details */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Key Details</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Minimum Investment:</span>
                    <span className="font-medium">${plan.minAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Management Fee:</span>
                    <span className="font-medium">{plan.managementFee} annually</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Withdrawal Period:</span>
                    <span className="font-medium">{plan.withdrawalPeriod}</span>
                  </div>
                </div>
              </div>

              {/* Features */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Plan Features</h3>
                <div className="space-y-2">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-start space-x-2">
                      <Icon name="Check" size={16} className="text-green-400 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              {/* Asset Allocation */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Asset Allocation</h3>
                <div className="space-y-3">
                  {Object.entries(plan.allocation).map(([asset, percentage]) => (
                    <div key={asset} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{asset}</span>
                        <span className="font-medium">{percentage}%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="gradient-gold h-2 rounded-full transition-all duration-500"
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Historical Performance */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Historical Performance</h3>
                <div className="space-y-2">
                  {plan.historicalPerformance.map((performance, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-card rounded-lg">
                      <span className="font-medium">{performance.year}</span>
                      <span className="text-green-400 font-semibold">
                        +{performance.return}%
                      </span>
                    </div>
                  ))}
                </div>
                <div className="text-xs text-muted-foreground mt-2">
                  * Past performance does not guarantee future results
                </div>
              </div>

              {/* Action Button */}
              <Button className="w-full gradient-gold text-black font-semibold py-3">
                Select This Plan
                <Icon name="ArrowRight" size={16} className="ml-2" />
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    );
  };

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Choose Your <span className="text-orange-400">Investment Plan</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Select the perfect investment strategy that matches your risk tolerance and financial goals
          </motion.p>
        </div>

        {/* Plan Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className={`relative glass-effect rounded-xl p-8 ${
                plan.recommended ? 'ring-2 ring-orange-500' : ''
              } ${selectedPlan === plan.id ? 'ring-2 ring-orange-500' : ''}`}
            >
              {/* Recommended Badge */}
              {plan.recommended && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <div className="gradient-gold text-black px-4 py-1 rounded-full text-sm font-semibold">
                    Most Popular
                  </div>
                </div>
              )}

              {/* Plan Header */}
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className={`inline-block px-3 py-1 rounded-full text-sm ${getRiskColor(plan.riskLevel)}`}>
                  {plan.risk}
                </div>
              </div>

              {/* Returns */}
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-orange-400 mb-2">
                  {plan.returns}
                </div>
                <div className="text-sm text-muted-foreground">Expected Annual Returns</div>
              </div>

              {/* Minimum Investment */}
              <div className="text-center mb-8">
                <div className="text-2xl font-bold mb-1">
                  ${plan.minAmount.toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground">Minimum Investment</div>
              </div>

              {/* Key Features (Top 3) */}
              <div className="space-y-3 mb-8">
                {plan.features.slice(0, 3).map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-start space-x-3">
                    <Icon name="Check" size={16} className="text-green-400 mt-0.5" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
                {plan.features.length > 3 && (
                  <div className="text-sm text-orange-400 font-medium">
                    +{plan.features.length - 3} more features
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Button
                  className={`w-full ${
                    plan.recommended
                      ? 'gradient-gold text-black font-semibold hover:scale-105' :'bg-card hover:bg-muted text-foreground'
                  } transition-transform`}
                  onClick={() => handleInvestNow(plan)}
                >
                  Choose Plan
                  <Icon name="ArrowRight" size={16} className="ml-2" />
                </Button>
                <Button
                  variant="outline"
                  className="w-full border-orange-500/50 text-orange-400 hover:bg-orange-500/10"
                  onClick={() => handlePlanDetails(plan)}
                >
                  View Details
                  <Icon name="Eye" size={16} className="ml-2" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Real-time Availability */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12"
        >
          <div className="inline-flex items-center space-x-2 glass-effect px-6 py-3 rounded-full">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-sm text-muted-foreground">
              All plans available • No waiting list • Instant activation
            </span>
          </div>
        </motion.div>
      </div>

      {/* Plan Details Modal */}
      {showModal && (
        <PlanModal 
          plan={modalPlan} 
          onClose={() => {
            setShowModal(false);
            setModalPlan(null);
          }} 
        />
      )}
    </section>
  );
};

export default PlanCards;
