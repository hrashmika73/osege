import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useUserAuth } from '../../../contexts/UserAuthContext';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SpecialPromotions = () => {
  const navigate = useNavigate();
  const { isUserAuthenticated, user } = useUserAuth();

  const handleGetStarted = () => {
    if (isUserAuthenticated) {
      // User is logged in, check KYC status
      if (user?.kycStatus === 'verified') {
        // Redirect to user dashboard
        navigate('/user-dashboard?tab=investments');
      } else {
        // Redirect to KYC verification
        navigate('/kyc-verification');
      }
    } else {
      // User not logged in, redirect to signup
      navigate('/signup');
    }
  };
  const [timeLeft, setTimeLeft] = useState({
    days: 7,
    hours: 12,
    minutes: 30,
    seconds: 45
  });

  // Countdown timer simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        let { days, hours, minutes, seconds } = prev;
        
        if (seconds > 0) {
          seconds--;
        } else {
          seconds = 59;
          if (minutes > 0) {
            minutes--;
          } else {
            minutes = 59;
            if (hours > 0) {
              hours--;
            } else {
              hours = 23;
              if (days > 0) {
                days--;
              }
            }
          }
        }
        
        return { days, hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const promotions = [
    {
      id: 'early-bird',
      title: 'Early Investor Bonus',
      description: 'Get an extra 2% annual return on your first investment',
      bonus: '+2% APY',
      icon: 'Zap',
      color: 'from-yellow-400 to-orange-500',
      textColor: 'text-yellow-400',
      bgColor: 'bg-yellow-500/10',
      terms: 'Minimum $1,000 investment. Valid for first 30 days.',
      limited: true,
      spots: 247
    },
    {
      id: 'referral',
      title: 'Referral Program',
      description: 'Earn 10% commission on every successful referral',
      bonus: '10% Commission',
      icon: 'Users',
      color: 'from-blue-400 to-cyan-500',
      textColor: 'text-cyan-400',
      bgColor: 'bg-cyan-500/10',
      terms: 'Commission paid monthly. No limit on referrals.',
      limited: false
    },
    {
      id: 'compound',
      title: 'Compound Boost',
      description: 'Double compound frequency for Elite Plan members',
      bonus: 'Daily Compounding',
      icon: 'TrendingUp',  
      color: 'from-green-400 to-emerald-500',
      textColor: 'text-green-400',
      bgColor: 'bg-green-500/10',
      terms: 'Elite Plan only. Automatic enrollment.',
      limited: false
    }
  ];

  const incentives = [
    {
      title: 'No Setup Fees',
      description: 'Zero account setup or activation fees',
      icon: 'DollarSign',
      value: 'Save $99'
    },
    {
      title: 'Priority Support',
      description: 'Jump the queue with premium support access',
      icon: 'MessageCircle',
      value: '< 1min response'
    },
    {
      title: 'Portfolio Insurance',
      description: 'Additional insurance coverage for first year',
      icon: 'Shield',
      value: 'Extra $50K'
    },
    {
      title: 'Mobile App Access',
      description: 'Exclusive early access to our mobile application',
      icon: 'Smartphone',
      value: 'Beta Access'
    }
  ];

  return (
    <section className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Limited Time <span className="text-orange-400">Promotions</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Take advantage of exclusive offers designed to maximize your investment returns
          </motion.p>
        </div>

        {/* Countdown Timer */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block glass-effect rounded-xl p-6">
            <h3 className="text-lg font-semibold mb-4 text-orange-400">
              ⚡ Flash Sale Ends In
            </h3>
            <div className="flex justify-center space-x-6">
              {Object.entries(timeLeft).map(([unit, value]) => (
                <div key={unit} className="text-center">
                  <div className="w-16 h-16 gradient-gold rounded-lg flex items-center justify-center mb-2">
                    <span className="text-2xl font-bold text-black">
                      {value.toString().padStart(2, '0')}
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground capitalize">{unit}</div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Special Promotions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {promotions.map((promo, index) => (
            <motion.div
              key={promo.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className={`relative glass-effect rounded-xl p-6 ${promo.bgColor} ${
                promo.limited ? 'ring-2 ring-orange-500' : ''
              }`}
            >
              {/* Limited Badge */}
              {promo.limited && (
                <div className="absolute -top-3 -right-3">
                  <div className="gradient-gold text-black px-3 py-1 rounded-full text-xs font-bold">
                    LIMITED
                  </div>
                </div>
              )}

              {/* Icon */}
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 bg-gradient-to-r ${promo.color}`}>
                <Icon name={promo.icon} size={24} color="white" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-semibold mb-2">{promo.title}</h3>
              <p className="text-muted-foreground mb-4">{promo.description}</p>

              {/* Bonus Display */}
              <div className={`text-2xl font-bold mb-4 ${promo.textColor}`}>
                {promo.bonus}
              </div>

              {/* Limited Spots */}
              {promo.limited && (
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Spots Remaining:</span>
                    <span className="font-medium">{promo.spots}</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="gradient-gold h-2 rounded-full"
                      style={{ width: `${(promo.spots / 500) * 100}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {/* Terms */}
              <div className="text-xs text-muted-foreground mb-4">
                {promo.terms}
              </div>

              {/* Action Button */}
              <Button
                className={`w-full ${
                  promo.limited
                    ? 'gradient-gold text-black font-semibold hover:scale-105' :'bg-card hover:bg-muted text-foreground'
                } transition-transform`}
                onClick={handleGetStarted}
              >
                {promo.limited ? 'Claim Now' : 'Learn More'}
                <Icon name="ArrowRight" size={16} className="ml-2" />
              </Button>
            </motion.div>
          ))}
        </div>

        {/* Additional Incentives */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="glass-effect rounded-xl p-8"
        >
          <h3 className="text-2xl font-bold text-center mb-8">
            <span className="text-orange-400">Exclusive</span> Early Investor Benefits
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {incentives.map((incentive, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 gradient-gold rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name={incentive.icon} size={24} color="black" />
                </div>
                <h4 className="font-semibold mb-2">{incentive.title}</h4>
                <p className="text-sm text-muted-foreground mb-2">{incentive.description}</p>
                <div className="text-orange-400 font-bold">{incentive.value}</div>
              </div>
            ))}
          </div>

          {/* CTA Section */}
          <div className="text-center mt-12 pt-8 border-t border-border">
            <h4 className="text-xl font-bold mb-4">
              Ready to Start Your Investment Journey?
            </h4>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Join thousands of successful investors who've already secured their financial future with KleverInvest. Don't miss out on these exclusive launch offers.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button
                className="gradient-gold text-black font-semibold px-8 py-3 hover:scale-105 transition-transform"
                onClick={handleGetStarted}
              >
                Get Started Now
                <Icon name="Rocket" size={16} className="ml-2" />
              </Button>
              <Button
                variant="outline"
                className="border-orange-500 text-orange-400 hover:bg-orange-500/10 px-8 py-3"
                onClick={() => navigate('/contact')}
              >
                Schedule Consultation
                <Icon name="Calendar" size={16} className="ml-2" />
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Risk Disclaimer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-center mt-12"
        >
          <div className="max-w-4xl mx-auto p-6 bg-card/30 rounded-xl">
            <div className="flex items-start space-x-3">
              <Icon name="AlertTriangle" size={20} className="text-yellow-400 mt-0.5" />
              <div className="text-sm text-muted-foreground text-left">
                <strong className="text-foreground">Important:</strong> 
                All promotional offers are subject to terms and conditions. Cryptocurrency investments 
                carry inherent risks and past performance does not guarantee future results. 
                Promotional rates and bonuses may be modified or discontinued at any time. 
                Please read our full terms of service and risk disclosure before investing.
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SpecialPromotions;
