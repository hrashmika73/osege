import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const PlansHero = () => {
  const highlights = [
    { icon: 'TrendingUp', text: 'Up to 25% Annual Returns' },
    { icon: 'Shield', text: 'Institutional Security' },
    { icon: 'Users', text: '100,000+ Investors' }
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-1/4 w-20 h-20 gradient-gold rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 right-1/4 w-16 h-16 bg-orange-500 rounded-full opacity-30 animate-bounce"></div>
        <motion.div
          className="absolute top-1/3 right-10"
          animate={{ y: [-20, 20, -20] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        >
          <div className="w-32 h-32 border border-orange-500/30 rounded-full"></div>
        </motion.div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-4xl md:text-6xl font-bold mb-6"
          >
            Investment{' '}
            <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
              Plans
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto"
          >
            Choose from our structured cryptocurrency investment packages designed for different 
            risk tolerances and investment goals. Professional portfolio management meets proven returns.
          </motion.p>

          {/* Key Highlights */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="flex flex-wrap justify-center gap-6 mb-12"
          >
            {highlights.map((item, index) => (
              <div
                key={index}
                className="flex items-center space-x-3 glass-effect px-6 py-3 rounded-full"
              >
                <div className="w-10 h-10 gradient-gold rounded-full flex items-center justify-center">
                  <Icon name={item.icon} size={18} color="black" />
                </div>
                <span className="font-medium">{item.text}</span>
              </div>
            ))}
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto"
          >
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-400 mb-2">15.2%</div>
              <div className="text-sm text-muted-foreground">Average Annual Return</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-400 mb-2">$100</div>
              <div className="text-sm text-muted-foreground">Minimum Investment</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-400 mb-2">7</div>
              <div className="text-sm text-muted-foreground">Years Experience</div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default PlansHero;