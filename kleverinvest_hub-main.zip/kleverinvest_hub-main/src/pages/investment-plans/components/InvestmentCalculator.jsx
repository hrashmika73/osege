import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useUserAuth } from '../../../contexts/UserAuthContext';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const InvestmentCalculator = () => {
  const [selectedPlan, setSelectedPlan] = useState('professional');
  const [investmentAmount, setInvestmentAmount] = useState(5000);
  const [investmentPeriod, setInvestmentPeriod] = useState(24);
  const [compoundingFrequency, setCompoundingFrequency] = useState('monthly');
  const [results, setResults] = useState({});
  const navigate = useNavigate();
  const { isUserAuthenticated, user } = useUserAuth();

  const handleStartInvesting = () => {
    if (isUserAuthenticated) {
      // User is logged in, check KYC status
      if (user?.kycStatus === 'verified') {
        // Redirect to user dashboard with calculated plan
        navigate('/user-dashboard?tab=investments&plan=' + selectedPlan + '&amount=' + investmentAmount);
      } else {
        // Redirect to KYC verification
        navigate('/kyc-verification');
      }
    } else {
      // User not logged in, redirect to signup
      navigate('/signup');
    }
  };

  const planData = {
    starter: {
      name: 'Starter Plan',
      minRate: 0.06,
      maxRate: 0.12,
      avgRate: 0.09,
      riskLevel: 'Low',
      color: 'text-green-400'
    },
    professional: {
      name: 'Professional Plan',
      minRate: 0.12,
      maxRate: 0.18,
      avgRate: 0.15,
      riskLevel: 'Moderate',
      color: 'text-yellow-400'
    },
    elite: {
      name: 'Elite Plan',
      minRate: 0.18,
      maxRate: 0.25,
      avgRate: 0.215,
      riskLevel: 'Higher',
      color: 'text-red-400'
    }
  };

  const compoundingOptions = {
    monthly: { label: 'Monthly', frequency: 12 },
    quarterly: { label: 'Quarterly', frequency: 4 },
    annually: { label: 'Annually', frequency: 1 }
  };

  useEffect(() => {
    calculateProjections();
  }, [selectedPlan, investmentAmount, investmentPeriod, compoundingFrequency]);

  const calculateProjections = () => {
    const plan = planData[selectedPlan];
    const frequency = compoundingOptions[compoundingFrequency].frequency;
    const periods = (investmentPeriod / 12) * frequency;

    const scenarios = ['conservative', 'expected', 'optimistic'];
    const rates = [plan.minRate, plan.avgRate, plan.maxRate];

    const projections = scenarios.map((scenario, index) => {
      const annualRate = rates[index];
      const periodRate = annualRate / frequency;
      const futureValue = investmentAmount * Math.pow(1 + periodRate, periods);
      const totalReturn = futureValue - investmentAmount;
      const roi = (totalReturn / investmentAmount) * 100;

      return {
        scenario,
        futureValue,
        totalReturn,
        roi,
        monthlyReturn: totalReturn / investmentPeriod
      };
    });

    setResults({ projections });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const quickAmounts = [1000, 5000, 10000, 25000, 50000];
  const quickPeriods = [6, 12, 24, 36, 60];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Investment <span className="text-orange-400">Calculator</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Calculate your potential returns with compound interest visualization across different scenarios
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Calculator Inputs */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="glass-effect rounded-xl p-8"
          >
            <h3 className="text-xl font-semibold mb-6">Investment Parameters</h3>

            {/* Plan Selection */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-3">Select Investment Plan</label>
              <div className="grid grid-cols-1 gap-3">
                {Object.entries(planData).map(([key, plan]) => (
                  <button
                    key={key}
                    onClick={() => setSelectedPlan(key)}
                    className={`p-4 rounded-lg border transition-all ${
                      selectedPlan === key
                        ? 'border-orange-500 bg-orange-500/10' :'border-border bg-card hover:bg-muted'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="text-left">
                        <div className="font-medium">{plan.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {(plan.minRate * 100).toFixed(0)}% - {(plan.maxRate * 100).toFixed(0)}% returns
                        </div>
                      </div>
                      <div className={`text-sm px-2 py-1 rounded-full ${
                        plan.riskLevel === 'Low' ? 'bg-green-500/20 text-green-400' :
                        plan.riskLevel === 'Moderate'? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {plan.riskLevel}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Investment Amount */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-3">Investment Amount</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                  $
                </div>
                <Input
                  type="number"
                  value={investmentAmount}
                  onChange={(e) => setInvestmentAmount(Number(e.target.value))}
                  className="pl-8"
                  min="100"
                  max="1000000"
                />
              </div>
              <div className="flex flex-wrap gap-2 mt-3">
                {quickAmounts.map((amount) => (
                  <button
                    key={amount}
                    onClick={() => setInvestmentAmount(amount)}
                    className={`px-3 py-1 rounded-full text-sm transition-colors ${
                      investmentAmount === amount
                        ? 'bg-orange-500 text-black' :'bg-muted text-muted-foreground hover:bg-orange-500/20'
                    }`}
                  >
                    ${amount.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>

            {/* Investment Period */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-3">
                Investment Period ({investmentPeriod} months)
              </label>
              <input
                type="range"
                min="6"
                max="60"
                value={investmentPeriod}
                onChange={(e) => setInvestmentPeriod(Number(e.target.value))}
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #F0B90B 0%, #F0B90B ${((investmentPeriod - 6) / 54) * 100}%, #1E2329 ${((investmentPeriod - 6) / 54) * 100}%, #1E2329 100%)`
                }}
              />
              <div className="flex flex-wrap gap-2 mt-3">
                {quickPeriods.map((period) => (
                  <button
                    key={period}
                    onClick={() => setInvestmentPeriod(period)}
                    className={`px-3 py-1 rounded-full text-sm transition-colors ${
                      investmentPeriod === period
                        ? 'bg-orange-500 text-black' :'bg-muted text-muted-foreground hover:bg-orange-500/20'
                    }`}
                  >
                    {period}m
                  </button>
                ))}
              </div>
            </div>

            {/* Compounding Frequency */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-3">Compounding Frequency</label>
              <div className="grid grid-cols-3 gap-2">
                {Object.entries(compoundingOptions).map(([key, option]) => (
                  <button
                    key={key}
                    onClick={() => setCompoundingFrequency(key)}
                    className={`p-3 rounded-lg border text-sm transition-all ${
                      compoundingFrequency === key
                        ? 'border-orange-500 bg-orange-500/10' :'border-border bg-card hover:bg-muted'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Summary */}
            <div className="bg-card rounded-lg p-4">
              <h4 className="font-medium mb-3">Calculation Summary</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Plan:</span>
                  <span>{planData[selectedPlan].name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Investment:</span>
                  <span>{formatCurrency(investmentAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Period:</span>
                  <span>{investmentPeriod} months</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Compounding:</span>
                  <span>{compoundingOptions[compoundingFrequency].label}</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Results Display */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-6"
          >
            <h3 className="text-xl font-semibold">Projected Returns</h3>

            {results.projections?.map((projection, index) => {
              const scenarioData = {
                conservative: { label: 'Conservative', color: 'text-green-400', bgColor: 'bg-green-500/10' },
                expected: { label: 'Expected', color: 'text-orange-400', bgColor: 'bg-orange-500/10' },
                optimistic: { label: 'Optimistic', color: 'text-red-400', bgColor: 'bg-red-500/10' }
              };

              const scenario = scenarioData[projection.scenario];

              return (
                <div key={index} className={`glass-effect rounded-xl p-6 ${scenario.bgColor}`}>
                  <div className="flex items-center justify-between mb-4">
                    <h4 className={`text-lg font-semibold ${scenario.color}`}>
                      {scenario.label} Scenario
                    </h4>
                    <div className="text-right">
                      <div className={`text-2xl font-bold ${scenario.color}`}>
                        +{projection.roi.toFixed(1)}%
                      </div>
                      <div className="text-sm text-muted-foreground">Total ROI</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="text-center p-3 bg-card rounded-lg">
                      <div className="text-lg font-bold text-foreground">
                        {formatCurrency(projection.futureValue)}
                      </div>
                      <div className="text-xs text-muted-foreground">Final Value</div>
                    </div>
                    <div className="text-center p-3 bg-card rounded-lg">
                      <div className={`text-lg font-bold ${scenario.color}`}>
                        {formatCurrency(projection.totalReturn)}
                      </div>
                      <div className="text-xs text-muted-foreground">Total Profit</div>
                    </div>
                  </div>

                  <div className="text-center">
                    <div className="text-sm text-muted-foreground">
                      ~{formatCurrency(projection.monthlyReturn)} per month
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Action Button */}
            <Button
              className="w-full gradient-gold text-black font-semibold py-4"
              onClick={handleStartInvesting}
            >
              Get Started with {planData[selectedPlan].name}
              <Icon name="ArrowRight" size={16} className="ml-2" />
            </Button>

            {/* Disclaimer */}
            <div className="p-4 bg-card/50 rounded-lg">
              <div className="flex items-start space-x-2">
                <Icon name="AlertTriangle" size={16} className="text-yellow-400 mt-0.5" />
                <div className="text-xs text-muted-foreground">
                  <strong>Disclaimer:</strong> These projections are estimates based on historical performance 
                  and should not be considered guaranteed returns. Cryptocurrency investments carry risks 
                  and actual results may vary significantly.
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default InvestmentCalculator;
