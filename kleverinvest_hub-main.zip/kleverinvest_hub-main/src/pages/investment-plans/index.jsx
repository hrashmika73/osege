import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../home-landing-page/components/Header';
import Footer from '../home-landing-page/components/Footer';
import PlansHero from './components/PlansHero';
import PlanCards from './components/PlanCards';
import PlanComparison from './components/PlanComparison';
import InvestmentCalculator from './components/InvestmentCalculator';
import SpecialPromotions from './components/SpecialPromotions';

const InvestmentPlans = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: isLoaded ? 1 : 0 }}
        transition={{ duration: 0.5 }}
        className="pt-16"
      >
        <PlansHero />
        <PlanCards selectedPlan={selectedPlan} setSelectedPlan={setSelectedPlan} />
        <PlanComparison />
        <InvestmentCalculator />
        <SpecialPromotions />
      </motion.main>

      <Footer />
    </div>
  );
};

export default InvestmentPlans;