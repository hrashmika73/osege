import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '../home-landing-page/components/Header';
import Footer from '../home-landing-page/components/Footer';
import FAQSection from '../how-it-works/components/FAQSection';

const FAQPage = () => {
  return (
    <>
      <Helmet>
        <title>FAQ - KleverInvest Hub | Frequently Asked Questions</title>
        <meta 
          name="description" 
          content="Find answers to frequently asked questions about KleverInvest Hub. Learn about our investment process, security measures, and platform features." 
        />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        {/* Hero Section */}
        <div className="bg-gradient-to-r from-primary to-accent text-white py-20 pt-32">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Get answers to common questions about KleverInvest Hub, our investment process, security measures, and platform features.
            </p>
          </div>
        </div>

        {/* FAQ Content */}
        <FAQSection />

        <Footer />
      </div>
    </>
  );
};

export default FAQPage;
