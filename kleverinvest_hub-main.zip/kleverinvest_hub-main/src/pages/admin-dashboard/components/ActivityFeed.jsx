import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ActivityFeed = ({ activities, title = "Recent Activity" }) => {
  const getActivityIcon = (type) => {
    switch (type) {
      case 'user_registration':
        return 'UserPlus';
      case 'transaction':
        return 'CreditCard';
      case 'withdrawal':
        return 'ArrowUpRight';
      case 'deposit':
        return 'ArrowDownLeft';
      case 'system_alert':
        return 'AlertTriangle';
      case 'support_ticket':
        return 'MessageCircle';
      default:
        return 'Activity';
    }
  };

  const getActivityColor = (type, priority) => {
    if (priority === 'high') return 'bg-error/10 text-error border-error/20';
    if (priority === 'medium') return 'bg-warning/10 text-warning border-warning/20';
    
    switch (type) {
      case 'user_registration':
        return 'bg-success/10 text-success border-success/20';
      case 'transaction': case'deposit':
        return 'bg-primary/10 text-primary border-primary/20';
      case 'withdrawal':
        return 'bg-warning/10 text-warning border-warning/20';
      case 'system_alert':
        return 'bg-error/10 text-error border-error/20';
      default:
        return 'bg-muted text-muted-foreground border-border';
    }
  };

  const formatTime = (timestamp) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInMinutes = Math.floor((now - time) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">{title}</h3>
        <Button variant="ghost" size="sm">
          <Icon name="MoreHorizontal" size={16} />
        </Button>
      </div>
      <div className="space-y-4 max-h-96 overflow-y-auto">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors duration-200">
            <div className={`p-2 rounded-lg border ${getActivityColor(activity.type, activity.priority)}`}>
              <Icon name={getActivityIcon(activity.type)} size={16} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-foreground truncate">{activity.title}</p>
                <span className="text-xs text-muted-foreground">{formatTime(activity.timestamp)}</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">{activity.description}</p>
              {activity.amount && (
                <p className="text-sm font-medium text-primary mt-1">{activity.amount}</p>
              )}
              {activity.actionRequired && (
                <div className="flex items-center space-x-2 mt-2">
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                  {activity.canApprove && (
                    <Button variant="default" size="sm">
                      Approve
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ActivityFeed;