import React from 'react';
import Icon from '../../../components/AppIcon';

const SystemStatus = ({ services, title = "System Status" }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'operational':
        return 'text-success';
      case 'degraded':
        return 'text-warning';
      case 'down':
        return 'text-error';
      default:
        return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'operational':
        return 'CheckCircle';
      case 'degraded':
        return 'AlertTriangle';
      case 'down':
        return 'XCircle';
      default:
        return 'Clock';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'operational':
        return 'Operational';
      case 'degraded':
        return 'Degraded';
      case 'down':
        return 'Down';
      default:
        return 'Unknown';
    }
  };

  const overallStatus = services.every(s => s.status === 'operational') 
    ? 'operational' 
    : services.some(s => s.status === 'down') 
    ? 'down' :'degraded';

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">{title}</h3>
        <div className={`flex items-center space-x-2 ${getStatusColor(overallStatus)}`}>
          <Icon name={getStatusIcon(overallStatus)} size={16} />
          <span className="text-sm font-medium">{getStatusText(overallStatus)}</span>
        </div>
      </div>
      <div className="space-y-3">
        {services.map((service) => (
          <div key={service.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
            <div className="flex items-center space-x-3">
              <Icon name={service.icon} size={18} className="text-muted-foreground" />
              <div>
                <p className="font-medium text-sm text-foreground">{service.name}</p>
                {service.description && (
                  <p className="text-xs text-muted-foreground">{service.description}</p>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {service.responseTime && (
                <span className="text-xs text-muted-foreground">{service.responseTime}ms</span>
              )}
              <div className={`flex items-center space-x-1 ${getStatusColor(service.status)}`}>
                <Icon name={getStatusIcon(service.status)} size={14} />
                <span className="text-xs font-medium">{getStatusText(service.status)}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 pt-4 border-t">
        <p className="text-xs text-muted-foreground">
          Last updated: {new Date().toLocaleString()}
        </p>
      </div>
    </div>
  );
};

export default SystemStatus;