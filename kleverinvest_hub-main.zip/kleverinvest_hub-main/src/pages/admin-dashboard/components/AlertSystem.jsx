import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AlertSystem = ({ alerts, title = "System Alerts" }) => {
  const [dismissedAlerts, setDismissedAlerts] = useState(new Set());

  const getAlertIcon = (severity) => {
    switch (severity) {
      case 'critical':
        return 'AlertTriangle';
      case 'warning':
        return 'AlertCircle';
      case 'info':
        return 'Info';
      default:
        return 'Bell';
    }
  };

  const getAlertColor = (severity) => {
    switch (severity) {
      case 'critical':
        return 'bg-error/10 text-error border-error/20';
      case 'warning':
        return 'bg-warning/10 text-warning border-warning/20';
      case 'info':
        return 'bg-primary/10 text-primary border-primary/20';
      default:
        return 'bg-muted text-muted-foreground border-border';
    }
  };

  const dismissAlert = (alertId) => {
    setDismissedAlerts(prev => new Set([...prev, alertId]));
  };

  const visibleAlerts = alerts.filter(alert => !dismissedAlerts.has(alert.id));

  if (visibleAlerts.length === 0) {
    return (
      <div className="bg-card border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">{title}</h3>
          <div className="flex items-center space-x-2 text-success">
            <Icon name="CheckCircle" size={16} />
            <span className="text-sm font-medium">All Clear</span>
          </div>
        </div>
        <div className="text-center py-8">
          <Icon name="Shield" size={48} className="mx-auto text-success mb-4" />
          <p className="text-muted-foreground">No active alerts. System running smoothly.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">{title}</h3>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-muted-foreground">{visibleAlerts.length} active</span>
          <Button variant="ghost" size="sm">
            <Icon name="Settings" size={16} />
          </Button>
        </div>
      </div>
      <div className="space-y-3 max-h-80 overflow-y-auto">
        {visibleAlerts.map((alert) => (
          <div key={alert.id} className={`p-4 rounded-lg border ${getAlertColor(alert.severity)}`}>
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                <Icon name={getAlertIcon(alert.severity)} size={20} />
                <div className="flex-1">
                  <h4 className="font-medium text-sm mb-1">{alert.title}</h4>
                  <p className="text-sm opacity-90 mb-2">{alert.message}</p>
                  <div className="flex items-center space-x-4 text-xs opacity-75">
                    <span>{new Date(alert.timestamp).toLocaleString()}</span>
                    {alert.source && <span>Source: {alert.source}</span>}
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-1">
                {alert.actionUrl && (
                  <Button variant="ghost" size="sm">
                    <Icon name="ExternalLink" size={14} />
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={() => dismissAlert(alert.id)}>
                  <Icon name="X" size={14} />
                </Button>
              </div>
            </div>
            {alert.details && (
              <div className="mt-3 pt-3 border-t border-current/20">
                <p className="text-xs opacity-75">{alert.details}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AlertSystem;