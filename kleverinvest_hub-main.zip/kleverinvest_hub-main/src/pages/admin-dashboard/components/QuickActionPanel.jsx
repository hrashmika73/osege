import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActionPanel = ({ title, actions }) => {
  return (
    <div className="bg-card border rounded-lg p-6">
      <h3 className="text-lg font-semibold text-foreground mb-4">{title}</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {actions.map((action, index) => (
          <Button
            key={index}
            variant="outline"
            className="flex items-center justify-start space-x-3 p-4 h-auto hover:bg-muted/50 transition-colors duration-200"
            onClick={action.onClick}
          >
            <div className={`p-2 rounded-lg ${action.color || 'bg-primary/10 text-primary'}`}>
              <Icon name={action.icon} size={20} />
            </div>
            <div className="text-left">
              <div className="font-medium text-sm">{action.label}</div>
              {action.description && (
                <div className="text-xs text-muted-foreground">{action.description}</div>
              )}
            </div>
          </Button>
        ))}
      </div>
    </div>
  );
};

export default QuickActionPanel;