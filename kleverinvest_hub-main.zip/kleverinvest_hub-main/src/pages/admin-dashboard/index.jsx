import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import AdminNavigation from '../../components/ui/AdminNavigation';
import BackendConnectionTest from '../../components/BackendConnectionTest';
import TestRegistrationFlow from '../../components/TestRegistrationFlow';
import NetworkErrorTest from '../../components/NetworkErrorTest';
import KYCTestComponent from '../../components/KYCTestComponent';
import AdminSecurityMonitor from '../../components/AdminSecurityMonitor';
import AdminDataRefresh from '../../components/AdminDataRefresh';
import SystemStatusMonitor from '../../components/SystemStatusMonitor';
import { simpleReloadTest } from '../../utils/simpleReloadTest';
import { adminUserAPI } from '../../services/adminApiService';
import BackendConnectionDisplay from '../../components/BackendConnectionDisplay';

// Error Boundary Component for AdminDashboard
class AdminDashboardErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('AdminDashboard Error:', error, errorInfo);
    this.setState({
      error: error,
      errorInfo: errorInfo
    });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <div className="max-w-md w-full text-center">
            <div className="bg-card border rounded-lg p-8">
              <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="AlertTriangle" size={32} className="text-destructive" />
              </div>
              <h1 className="text-2xl font-bold text-foreground mb-4">
                Dashboard Error
              </h1>
              <p className="text-muted-foreground mb-6">
                There was an error loading the admin dashboard. This has been logged for review.
              </p>
              <div className="space-y-3">
                <Button
                  onClick={() => window.location.reload()}
                  className="w-full"
                >
                  <Icon name="RefreshCw" size={16} className="mr-2" />
                  Reload Dashboard
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.location.href = '/admin-login'}
                  className="w-full"
                >
                  <Icon name="LogIn" size={16} className="mr-2" />
                  Back to Login
                </Button>
              </div>
              {this.state.error && (
                <details className="mt-4 text-left">
                  <summary className="text-sm text-muted-foreground cursor-pointer">
                    Error Details
                  </summary>
                  <pre className="text-xs bg-muted p-2 rounded mt-2 overflow-auto">
                    {this.state.error.toString()}
                  </pre>
                </details>
              )}
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Safe wrapper for AdminSecurityMonitor
const SafeAdminSecurityMonitor = () => {
  try {
    return <AdminSecurityMonitor />;
  } catch (monitorError) {
    console.warn('AdminSecurityMonitor error:', monitorError);
    return null;
  }
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  // Safe admin auth with fallbacks
  let adminAuth;
  try {
    adminAuth = useAdminAuth();
  } catch (authError) {
    console.error('Admin auth hook error:', authError);
    adminAuth = {
      admin: null,
      isAdminAuthenticated: false,
      adminLogout: () => {},
      loading: false
    };
  }

  const { admin, isAdminAuthenticated, adminLogout, loading } = adminAuth;

  // Safe navigation wrapper
  const safeNavigate = (path) => {
    try {
      if (navigate && typeof navigate === 'function') {
        navigate(path);
      } else {
        window.location.href = path;
      }
    } catch (error) {
      console.warn('Navigation error:', error);
      window.location.href = path;
    }
  };
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showBackendTest, setShowBackendTest] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [userStats, setUserStats] = useState({
    total: 0,
    active: 0,
    newToday: 0,
    totalBalance: 0
  });

  // Note: Authentication is now handled by ProtectedAdminRoute wrapper
  // No need for individual auth checks in components

  // Check for reload test results
  useEffect(() => {
    simpleReloadTest.checkAfterReload();
  }, []);

  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  // Load real-time user statistics using adminUserAPI
  useEffect(() => {
    const loadUserStats = async () => {
      try {
        // Use the new adminUserAPI for real user statistics
        const response = await adminUserAPI.getUserStats();

        if (!response?.success) {
          console.warn('Failed to load user stats from API, using fallback');
          setUserStats({
            total: 0,
            active: 0,
            newToday: 0,
            totalBalance: 0,
            verified: 0,
            newThisWeek: 0
          });
          return () => {}; // Return empty cleanup function
        }

        // Use the real stats data from the response
        const stats = response.data;
        const safeStats = {
          total: Number(stats?.total) || 0,
          active: Number(stats?.active) || 0,
          newToday: Number(stats?.newToday) || 0,
          totalBalance: Number(stats?.totalBalance) || 0,
          verified: Number(stats?.verified) || 0,
          newThisWeek: Number(stats?.newThisWeek) || 0
        };

        setUserStats(safeStats);

        // Set up periodic refresh to update stats every 30 seconds
        const refreshInterval = setInterval(async () => {
          try {
            const refreshResponse = await adminUserAPI.getUserStats();
            if (refreshResponse?.success) {
              const refreshStats = refreshResponse.data;
              const refreshSafeStats = {
                total: Number(refreshStats?.total) || 0,
                active: Number(refreshStats?.active) || 0,
                newToday: Number(refreshStats?.newToday) || 0,
                totalBalance: Number(refreshStats?.totalBalance) || 0,
                verified: Number(refreshStats?.verified) || 0,
                newThisWeek: Number(refreshStats?.newThisWeek) || 0
              };
              setUserStats(refreshSafeStats);
            }
          } catch (refreshError) {
            console.warn('Error refreshing stats:', refreshError);
          }
        }, 30000); // Refresh every 30 seconds

        return () => clearInterval(refreshInterval);
      } catch (error) {
        console.warn('Error loading user statistics, using fallback data:', error);
        // Set fallback stats with safe defaults
        setUserStats({
          total: 0,
          active: 0,
          newToday: 0,
          totalBalance: 0,
          verified: 0,
          newThisWeek: 0
        });
        return () => {}; // Return empty cleanup function
      }
    };

    let cleanup;
    loadUserStats().then(cleanupFn => {
      cleanup = cleanupFn;
    }).catch(error => {
      console.warn('Failed to load user stats:', error);
      setUserStats({
        total: 0,
        active: 0,
        newToday: 0,
        totalBalance: 0,
        verified: 0,
        newThisWeek: 0
      });
    });

    return () => {
      if (cleanup && typeof cleanup === 'function') {
        try {
          cleanup();
        } catch (error) {
          console.warn('Error during cleanup:', error);
        }
      }
    };
  }, []);

  // Quick actions data - comprehensive admin navigation
  const quickActionsData = [
    {
      category: "User Management",
      actions: [
        {
          label: "Active Users",
          description: "Manage active users",
          icon: "Users",
          color: "bg-green-100 text-green-800 border-green-200",
          onClick: () => safeNavigate('/admin-active-users')
        },
        {
          label: "Banned Users",
          description: "Manage banned users",
          icon: "Ban",
          color: "bg-red-100 text-red-800 border-red-200",
          onClick: () => safeNavigate('/admin-banned-users')
        },
        {
          label: "Pending KYC",
          description: "KYC verification",
          icon: "Clock",
          color: "bg-yellow-100 text-yellow-800 border-yellow-200",
          onClick: () => safeNavigate('/admin-pending-kyc')
        },
        {
          label: "KYC Log",
          description: "KYC activity log",
          icon: "FileText",
          color: "bg-blue-100 text-blue-800 border-blue-200",
          onClick: () => safeNavigate('/admin-kyc-log')
        }
      ]
    },
    {
      category: "Gateway Management",
      actions: [
        {
          label: "Gateways",
          description: "Payment gateways",
          icon: "CreditCard",
          color: "bg-purple-100 text-purple-800 border-purple-200",
          onClick: () => safeNavigate('/admin-gateways')
        },
        {
          label: "Pending Deposits",
          description: "Review deposits",
          icon: "Clock",
          color: "bg-yellow-100 text-yellow-800 border-yellow-200",
          onClick: () => safeNavigate('/admin-pending-deposits')
        },
        {
          label: "Accepted Deposits",
          description: "Approved deposits",
          icon: "CheckCircle",
          color: "bg-green-100 text-green-800 border-green-200",
          onClick: () => safeNavigate('/admin-accepted-deposits')
        },
        {
          label: "Rejected Deposits",
          description: "Rejected deposits",
          icon: "XCircle",
          color: "bg-red-100 text-red-800 border-red-200",
          onClick: () => safeNavigate('/admin-rejected-deposits')
        },
        {
          label: "Deposit Log",
          description: "Deposit activity",
          icon: "FileText",
          color: "bg-blue-100 text-blue-800 border-blue-200",
          onClick: () => safeNavigate('/admin-deposit-log')
        }
      ]
    },
    {
      category: "Payment Management",
      actions: [
        {
          label: "Pending Withdraws",
          description: "Review withdrawals",
          icon: "ArrowDown",
          color: "bg-orange-100 text-orange-800 border-orange-200",
          onClick: () => safeNavigate('/admin-pending-withdraws')
        },
        {
          label: "Withdraw Log",
          description: "Withdrawal activity",
          icon: "FileText",
          color: "bg-blue-100 text-blue-800 border-blue-200",
          onClick: () => safeNavigate('/admin-withdraw-log')
        }
      ]
    },
    {
      category: "Controls",
      actions: [
        {
          label: "Theme Settings",
          description: "Customize appearance",
          icon: "Palette",
          color: "bg-purple-100 text-purple-800 border-purple-200",
          onClick: () => safeNavigate('/admin-theme-settings')
        },
        {
          label: "Email Settings",
          description: "Configure emails",
          icon: "Mail",
          color: "bg-blue-100 text-blue-800 border-blue-200",
          onClick: () => safeNavigate('/admin-email-settings')
        },
        {
          label: "Language Manager",
          description: "Manage languages",
          icon: "Globe",
          color: "bg-green-100 text-green-800 border-green-200",
          onClick: () => safeNavigate('/admin-language-manager')
        },
        {
          label: "Google Tools",
          description: "Google integrations",
          icon: "Zap",
          color: "bg-yellow-100 text-yellow-800 border-yellow-200",
          onClick: () => safeNavigate('/admin-google-tools')
        }
      ]
    },
    {
      category: "System & Analytics",
      actions: [
        {
          label: "System Analytics",
          description: "Platform insights",
          icon: "BarChart",
          color: "bg-green-500/10 text-green-500 border-green-200",
          onClick: () => safeNavigate('/admin-system-analytics')
        },
        {
          label: "System Logs",
          description: "Activity monitoring",
          icon: "FileText",
          color: "bg-warning/10 text-warning border-warning/20",
          onClick: () => safeNavigate('/admin-system-logs')
        },
        {
          label: "Transaction Management",
          description: "Transaction oversight",
          icon: "CheckCircle",
          color: "bg-blue-500/10 text-blue-500 border-blue-200",
          onClick: () => safeNavigate('/admin-transaction-management')
        },
        {
          label: "Site Settings",
          description: "Platform configuration",
          icon: "Settings",
          color: "bg-purple-500/10 text-purple-500 border-purple-200",
          onClick: () => safeNavigate('/admin-site-settings')
        },
        {
          label: "Security Test",
          description: "Security validation",
          icon: "Shield",
          color: "bg-red-500/10 text-red-500 border-red-200",
          onClick: () => safeNavigate('/admin-security-test')
        },
        {
          label: "Backend Test",
          description: "API integration test",
          icon: "Database",
          color: "bg-indigo-500/10 text-indigo-500 border-indigo-200",
          onClick: () => safeNavigate('/backend-integration-test')
        }
      ]
    }
  ];

  const FeatureCard = ({ title, description, icon, onClick, route, stats }) => (
    <div className="bg-card border rounded-lg p-6 hover:shadow-lg transition-shadow cursor-pointer" onClick={onClick || (() => safeNavigate(route))}>
      <div className="flex items-center justify-between mb-4">
        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name={icon} size={24} className="text-primary" />
        </div>
        <Icon name="ArrowRight" size={16} className="text-muted-foreground" />
      </div>
      <h3 className="font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground mb-4">{description}</p>
      {stats && (
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">{stats.label}</span>
          <span className="font-medium text-primary">{stats.value}</span>
        </div>
      )}
    </div>
  );

  // Safety check before rendering
  if (!userStats || typeof userStats !== 'object') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Icon name="Loader2" size={48} className="animate-spin text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Safe AdminSecurityMonitor rendering */}
      <SafeAdminSecurityMonitor />
      {/* Professional Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 ${sidebarCollapsed ? 'w-16' : 'w-80'} bg-card border-r border-border transition-all duration-300 ease-in-out overflow-hidden`}>
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          {!sidebarCollapsed && (
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Icon name="Shield" size={16} className="text-white" />
              </div>
              <div>
                <h2 className="text-sm font-semibold text-foreground">Admin Portal</h2>
                <p className="text-xs text-muted-foreground">KleverInvest Hub</p>
              </div>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="ml-auto"
          >
            <Icon name={sidebarCollapsed ? "ChevronRight" : "ChevronLeft"} size={16} />
          </Button>
        </div>

        {/* Quick Actions in Sidebar */}
        <div className="p-4 overflow-y-auto h-[calc(100vh-80px)]">
          {!sidebarCollapsed && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                  Quick Actions
                </h3>
              </div>

              {quickActionsData.map((category, categoryIndex) => (
                <div key={categoryIndex} className="space-y-2">
                  <h4 className="text-xs font-medium text-muted-foreground mb-2">
                    {category.category}
                  </h4>
                  <div className="space-y-1">
                    {category.actions.map((action, actionIndex) => (
                      <Button
                        key={actionIndex}
                        variant="ghost"
                        className={`w-full justify-start p-3 h-auto hover:bg-muted/50 transition-colors duration-200 border ${action.color}`}
                        onClick={action.onClick}
                      >
                        <div className="flex items-center space-x-3 w-full">
                          <div className={`p-1.5 rounded-md ${action.color.split(' ')[0]} ${action.color.split(' ')[1]}`}>
                            <Icon name={action.icon} size={14} />
                          </div>
                          <div className="text-left flex-1 min-w-0">
                            <div className="font-medium text-xs truncate">{action.label}</div>
                            <div className="text-xs text-muted-foreground truncate">{action.description}</div>
                          </div>
                        </div>
                      </Button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {sidebarCollapsed && (
            <div className="space-y-2">
              {quickActionsData.flatMap(category => category.actions).map((action, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  size="sm"
                  className="w-full justify-center p-2"
                  onClick={action.onClick}
                  title={action.label}
                >
                  <Icon name={action.icon} size={16} />
                </Button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className={`flex-1 ${sidebarCollapsed ? 'ml-16' : 'ml-80'} transition-all duration-300 ease-in-out`}>
        {/* Admin Navigation */}
        <AdminNavigation
          title="Investment Admin Dashboard"
          showBackButton={false}
          actions={[
            {
              label: "Test Backend",
              icon: "Server",
              variant: "outline",
              onClick: () => setShowBackendTest(true)
            },
            {
              label: "Export Report",
              icon: "Download",
              variant: "outline",
              onClick: () => {
                alert('Export functionality will be available soon');
              }
            }
          ]}
        />

        <div className="p-6">
          {/* System Status Monitor */}
          <SystemStatusMonitor />

          {/* Welcome Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Welcome back, Admin</h1>
                <p className="text-muted-foreground">
                  {currentTime.toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <AdminDataRefresh onRefresh={(newStats) => setUserStats(newStats)} />
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">
                    {currentTime.toLocaleTimeString('en-US', { 
                      hour: '2-digit', 
                      minute: '2-digit'
                    })}
                  </p>
                  <p className="text-xs text-muted-foreground">Local Time</p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content - Coming Soon Sections */}
          <div className="space-y-8">
            
            {/* Platform Status */}
            <div className="bg-card border rounded-lg p-6">
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name="CheckCircle" size={24} className="text-success" />
                </div>
                <h2 className="text-xl font-semibold text-foreground mb-2">Platform Ready</h2>
                <p className="text-muted-foreground mb-4">
                  Your KleverInvest admin platform is ready for configuration
                </p>
                <div className="inline-flex items-center px-4 py-2 rounded-full bg-success/10 text-success text-sm font-medium">
                  <Icon name="Zap" size={16} className="mr-2" />
                  System Operational
                </div>
              </div>
            </div>

            {/* Feature Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <FeatureCard
                title="User Analytics"
                description="Track user registration, activity, and engagement metrics"
                icon="Users"
                route="/admin-user-management-enhanced"
                stats={{ label: "Active Users", value: "9,234" }}
              />
              <FeatureCard
                title="Financial Reports"
                description="Monitor transactions, revenue, and financial performance"
                icon="DollarSign"
                route="/admin-payment-gateway"
                stats={{ label: "Today's Revenue", value: "$847,590" }}
              />
              <FeatureCard
                title="System Monitoring"
                description="Real-time system health and performance tracking"
                icon="Activity"
                route="/admin-system-analytics"
                stats={{ label: "System Health", value: "98.5%" }}
              />
              <FeatureCard
                title="Investment Tools"
                description="Portfolio management and investment tracking tools"
                icon="TrendingUp"
                route="/admin-transaction-management"
                stats={{ label: "Active Investments", value: "1,247" }}
              />
              <FeatureCard
                title="Risk Management"
                description="Risk assessment and compliance monitoring"
                icon="Shield"
                route="/admin-system-logs"
                stats={{ label: "Risk Score", value: "Low" }}
              />
              <FeatureCard
                title="Support Dashboard"
                description="Customer support and ticketing system"
                icon="MessageCircle"
                route="/support-chat-system"
                stats={{ label: "Open Tickets", value: "12" }}
              />
            </div>

            {/* Registration Flow Test */}
            <div className="mb-8">
              <TestRegistrationFlow />
            </div>

            {/* Network Error Test */}
            <div className="mb-8">
              <NetworkErrorTest />
            </div>

            {/* KYC Test */}
            <div className="mb-8">
              <KYCTestComponent />
            </div>

            {/* Live System Status */}
            <div className="bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 rounded-lg p-6">
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <Icon name="Zap" size={20} className="text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-foreground mb-2">Live System Status</h3>
                  <p className="text-muted-foreground mb-4">
                    Real-time platform monitoring and quick actions for immediate administrative tasks.
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                    <div className="bg-white/50 rounded-lg p-3 text-center">
                      <div className="text-lg font-bold text-success">99.9%</div>
                      <div className="text-xs text-muted-foreground">Uptime</div>
                    </div>
                    <div className="bg-white/50 rounded-lg p-3 text-center">
                      <div className="text-lg font-bold text-primary">142ms</div>
                      <div className="text-xs text-muted-foreground">Response</div>
                    </div>
                    <div className="bg-white/50 rounded-lg p-3 text-center">
                      <div className="text-lg font-bold text-accent">1,247</div>
                      <div className="text-xs text-muted-foreground">Online</div>
                    </div>
                    <div className="bg-white/50 rounded-lg p-3 text-center">
                      <div className="text-lg font-bold text-warning">3</div>
                      <div className="text-xs text-muted-foreground">Alerts</div>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      onClick={() => setShowBackendTest(true)}
                      className="bg-primary hover:bg-primary/90"
                    >
                      <Icon name="Server" size={16} className="mr-2" />
                      System Health
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => safeNavigate('/admin-system-logs')}
                    >
                      <Icon name="FileText" size={16} className="mr-2" />
                      View Logs
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        const data = JSON.stringify({ timestamp: new Date().toISOString(), users: 12847, transactions: 1247, revenue: 847590 }, null, 2);
                        const blob = new Blob([data], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = `admin_report_${new Date().toISOString().split('T')[0]}.json`;
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        URL.revokeObjectURL(url);
                      }}
                    >
                      <Icon name="Download" size={16} className="mr-2" />
                      Export Report
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Live Platform Statistics */}
            <div className="bg-card border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground">Live Platform Statistics</h3>
                <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                  <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                  <span>Live Data</span>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  {
                    label: "Total Users",
                    value: (userStats.total || 0).toLocaleString(),
                    change: `+${userStats.newToday || 0} today`,
                    icon: "Users",
                    color: "text-primary"
                  },
                  {
                    label: "Active Users",
                    value: (userStats.active || 0).toLocaleString(),
                    change: `${userStats.total > 0 ? Math.round(((userStats.active || 0) / userStats.total) * 100) : 0}% active`,
                    icon: "UserCheck",
                    color: "text-accent"
                  },
                  {
                    label: "New This Week",
                    value: (userStats.newThisWeek || 0).toLocaleString(),
                    change: `${userStats.newToday || 0} today`,
                    icon: "UserPlus",
                    color: "text-success"
                  },
                  {
                    label: "Total Balance",
                    value: `$${(userStats.totalBalance || 0).toLocaleString()}`,
                    change: `${userStats.verified || 0} verified`,
                    icon: "DollarSign",
                    color: "text-warning"
                  }
                ].map((stat, index) => (
                  <div key={index} className="text-center p-4 bg-gradient-to-br from-muted/30 to-muted/10 rounded-lg border hover:shadow-md transition-shadow cursor-pointer" onClick={() => {
                    try {
                      const routes = ['/admin-user-management-enhanced', '/admin-transaction-management', '/admin-payment-gateway', '/admin-system-analytics'];
                      safeNavigate(routes[index]);
                    } catch (error) {
                      console.warn('Navigation error:', error);
                    }
                  }}>
                    <div className={`w-8 h-8 bg-muted/50 rounded-full flex items-center justify-center mx-auto mb-2`}>
                      <Icon name={stat.icon} size={16} className={stat.color} />
                    </div>
                    <div className="text-xl font-bold text-foreground">{stat.value}</div>
                    <div className="text-xs text-muted-foreground mb-1">{stat.label}</div>
                    <div className={`text-xs font-medium ${(stat.change || '').startsWith('+') ? 'text-success' : 'text-destructive'}`}>
                      {stat.change}
                    </div>
                  </div>
                ))}
              </div>
              <div className="text-center mt-4">
                <p className="text-sm text-muted-foreground">
                  Click any metric to view detailed analytics • Data updates every 30 seconds
                </p>
              </div>
            </div>
          </div>

          {/* Backend Connection Display */}
          <div className="lg:col-span-1">
            <BackendConnectionDisplay />
          </div>

          {/* Simple Reload Test */}
          <div className="lg:col-span-1">
            <div className="bg-card border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Icon name="RefreshCw" size={16} className="text-blue-500" />
                  <h3 className="font-semibold text-foreground">Reload Test</h3>
                </div>
                <Button
                  onClick={simpleReloadTest.testReload}
                  size="sm"
                  variant="outline"
                >
                  <Icon name="RefreshCw" size={14} className="mr-2" />
                  Test Reload
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                Test that admin session persists across page reloads
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Backend Connection Test Modal */}
      {showBackendTest && (
        <BackendConnectionTest onClose={() => setShowBackendTest(false)} />
      )}
    </div>
  );
};

// Enhanced wrapped component with additional safety
const WrappedAdminDashboard = () => {
  try {
    return (
      <AdminDashboardErrorBoundary>
        <AdminDashboard />
      </AdminDashboardErrorBoundary>
    );
  } catch (wrapperError) {
    console.error('Critical AdminDashboard wrapper error:', wrapperError);
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="AlertTriangle" size={32} className="text-red-500" />
          </div>
          <h1 className="text-xl font-semibold text-foreground mb-2">Dashboard Error</h1>
          <p className="text-muted-foreground mb-4">
            The admin dashboard encountered a critical error. Please refresh the page or contact support.
          </p>
          <div className="space-y-2">
            <button
              onClick={() => window.location.reload()}
              className="w-full bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90 transition-colors"
            >
              Refresh Page
            </button>
            <button
              onClick={() => window.location.href = '/admin-secure-login'}
              className="w-full bg-secondary text-secondary-foreground px-4 py-2 rounded-md hover:bg-secondary/90 transition-colors"
            >
              Return to Login
            </button>
          </div>
        </div>
      </div>
    );
  }
};

export default WrappedAdminDashboard;
