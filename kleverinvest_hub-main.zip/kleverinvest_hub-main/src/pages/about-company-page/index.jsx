import React, { useState } from 'react';


import Header from '../home-landing-page/components/Header';
import Footer from '../home-landing-page/components/Footer';
import CompanyStory from './components/CompanyStory';
import LeadershipTeam from './components/LeadershipTeam';
import CompanyTimeline from './components/CompanyTimeline';
import MissionVision from './components/MissionVision';
import SecurityCompliance from './components/SecurityCompliance';
import OfficeLocations from './components/OfficeLocations';
import AwardsRecognition from './components/AwardsRecognition';

const AboutCompanyPage = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      {/* Hero Section */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 gradient-dark opacity-30"></div>
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-72 h-72 bg-orange-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative z-10 container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full mb-6">
                <span className="text-white text-3xl font-bold">₿</span>
              </div>
            </div>

            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              About <span className="bg-gradient-to-r from-orange-400 to-yellow-500 bg-clip-text text-transparent">
                KleverInvest Hub
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Leading the future of Bitcoin and cryptocurrency investing with institutional-grade security, 
              professional management, and unparalleled expertise since 2019.
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
              <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
                <div className="text-2xl font-bold text-orange-400">5+</div>
                <div className="text-xs text-muted-foreground">Years Experience</div>
              </div>
              <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
                <div className="text-2xl font-bold text-orange-400">₿2.4B+</div>
                <div className="text-xs text-muted-foreground">Assets Managed</div>
              </div>
              <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
                <div className="text-2xl font-bold text-orange-400">150K+</div>
                <div className="text-xs text-muted-foreground">Trusted Investors</div>
              </div>
              <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
                <div className="text-2xl font-bold text-orange-400">50+</div>
                <div className="text-xs text-muted-foreground">Global Presence</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <CompanyStory />
      <LeadershipTeam />
      <CompanyTimeline />
      <MissionVision />
      <SecurityCompliance />
      <OfficeLocations />
      <AwardsRecognition />
      
      <Footer />
    </div>
  );
};

export default AboutCompanyPage;