import React from 'react';
import Icon from '../../../components/AppIcon';

const CompanyStory = () => {
  return (
    <section className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Story Content */}
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xl font-bold">₿</span>
                </div>
                <h2 className="text-3xl font-bold">Our Bitcoin Journey</h2>
              </div>

              <div className="space-y-6 text-muted-foreground">
                <p className="text-lg leading-relaxed">
                  Founded in 2019 by a team of cryptocurrency pioneers and financial experts, 
                  KleverInvest Hub was born from a simple vision: to democratize access to 
                  professional Bitcoin investment management for investors worldwide.
                </p>

                <p className="leading-relaxed">
                  Our founders recognized that while Bitcoin represented the future of finance, 
                  most investors lacked the expertise and infrastructure to safely and profitably 
                  navigate the cryptocurrency markets. We set out to bridge this gap by building 
                  a platform that combines institutional-grade security with user-friendly design.
                </p>

                <p className="leading-relaxed">
                  Today, we manage over ₿52,847 in Bitcoin investments for more than 150,000 
                  investors across 50+ countries. Our success is built on three core principles: 
                  security, transparency, and innovation in cryptocurrency investment management.
                </p>
              </div>

              <div className="mt-8 grid grid-cols-2 gap-6">
                <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
                  <div className="flex items-center space-x-2 mb-2">
                    <Icon name="Shield" size={20} className="text-green-400" />
                    <span className="font-semibold">Security First</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Industry-leading security protocols protect your Bitcoin investments
                  </p>
                </div>
                <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
                  <div className="flex items-center space-x-2 mb-2">
                    <Icon name="Users" size={20} className="text-blue-400" />
                    <span className="font-semibold">Global Community</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Serving Bitcoin investors in over 50 countries worldwide
                  </p>
                </div>
              </div>
            </div>

            {/* Visual Content */}
            <div className="relative">
              <div className="glass-effect rounded-2xl p-8 border border-orange-500/20">
                {/* Bitcoin Visual */}
                <div className="text-center mb-8">
                  <div className="inline-flex items-center justify-center w-32 h-32 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full mb-6 animate-pulse">
                    <span className="text-white text-6xl font-bold">₿</span>
                  </div>
                  <h3 className="text-xl font-bold mb-2">Bitcoin Innovation Leader</h3>
                  <p className="text-muted-foreground">
                    Pioneering the future of cryptocurrency investment
                  </p>
                </div>

                {/* Key Metrics */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-orange-500/10 rounded-lg">
                    <div className="text-2xl font-bold text-orange-400">99.9%</div>
                    <div className="text-xs text-muted-foreground">Uptime Record</div>
                  </div>
                  <div className="text-center p-4 bg-green-500/10 rounded-lg">
                    <div className="text-2xl font-bold text-green-400">24/7</div>
                    <div className="text-xs text-muted-foreground">Bitcoin Support</div>
                  </div>
                  <div className="text-center p-4 bg-blue-500/10 rounded-lg">
                    <div className="text-2xl font-bold text-blue-400">SOC 2</div>
                    <div className="text-xs text-muted-foreground">Certified Security</div>
                  </div>
                  <div className="text-center p-4 bg-purple-500/10 rounded-lg">
                    <div className="text-2xl font-bold text-purple-400">ISO 27001</div>
                    <div className="text-xs text-muted-foreground">Compliance</div>
                  </div>
                </div>
              </div>

              {/* Floating Elements */}
              <div className="absolute -top-4 -right-4 w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center animate-bounce">
                <Icon name="TrendingUp" size={24} color="white" />
              </div>
              <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center">
                <Icon name="Award" size={16} color="white" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CompanyStory;