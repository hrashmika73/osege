import React from 'react';
import Icon from '../../../components/AppIcon';

const AwardsRecognition = () => {
  const awards = [
    {
      year: '2024',
      title: 'Best Bitcoin Investment Platform',
      organization: 'Crypto Excellence Awards',
      description: 'Recognized for outstanding Bitcoin investment management and user experience',
      category: 'Platform Excellence',
      icon: 'Award',
      color: 'text-yellow-400'
    },
    {
      year: '2024',
      title: 'Top 10 Fintech Innovators',
      organization: 'Financial Technology Magazine',
      description: 'Selected among the most innovative fintech companies revolutionizing Bitcoin investment',
      category: 'Innovation',
      icon: 'Zap',
      color: 'text-blue-400'
    },
    {
      year: '2023',
      title: 'Best Bitcoin Security Implementation',
      organization: 'Cybersecurity Excellence Awards',
      description: 'Outstanding achievement in Bitcoin custody security and multi-signature implementation',
      category: 'Security',
      icon: 'Shield',
      color: 'text-green-400'
    },
    {
      year: '2023',
      title: 'Customer Choice Award',
      organization: 'Bitcoin Investment Review',
      description: 'Highest customer satisfaction rating among Bitcoin investment platforms',
      category: 'Customer Service',
      icon: 'Heart',
      color: 'text-red-400'
    },
    {
      year: '2022',
      title: 'Fastest Growing Bitcoin Platform',
      organization: 'Cryptocurrency Business Awards',
      description: 'Recognized for rapid growth in Bitcoin investment services and global expansion',
      category: 'Growth',
      icon: 'TrendingUp',
      color: 'text-purple-400'
    },
    {
      year: '2022',
      title: 'Best Mobile Bitcoin App',
      organization: 'Mobile Finance Awards',
      description: 'Excellence in mobile Bitcoin investment application design and functionality',
      category: 'Mobile Technology',
      icon: 'Smartphone',
      color: 'text-orange-400'
    }
  ];

  const mediaFeatures = [
    {
      outlet: 'Forbes',
      title: 'The Future of Bitcoin Investment Management',
      date: 'March 2024',
      quote: 'KleverInvest Hub is revolutionizing how individuals access professional Bitcoin investment strategies.',
      logo: '📰'
    },
    {
      outlet: 'TechCrunch',
      title: 'Bitcoin Platform Reaches $2.4B in Assets',
      date: 'January 2024',
      quote: 'A testament to growing institutional and retail confidence in professionally managed Bitcoin investments.',
      logo: '💻'
    },
    {
      outlet: 'CoinDesk',
      title: 'Security-First Approach to Bitcoin Custody',
      date: 'December 2023',
      quote: 'Setting new standards for Bitcoin security with innovative multi-signature and cold storage solutions.',
      logo: '₿'
    },
    {
      outlet: 'Wall Street Journal',
      title: 'Democratizing Bitcoin Investment Access',
      date: 'October 2023',
      quote: 'Making institutional-grade Bitcoin investment strategies accessible to individual investors worldwide.',
      logo: '📊'
    }
  ];

  const certifications = [
    {
      name: 'ISO 27001 Certified',
      description: 'Information Security Management',
      year: '2023',
      icon: 'ShieldCheck'
    },
    {
      name: 'SOC 2 Type II Compliant',
      description: 'Security & Availability Controls',
      year: '2022',
      icon: 'Lock'
    },
    {
      name: 'PCI DSS Certified',
      description: 'Payment Card Industry Security',
      year: '2022',
      icon: 'CreditCard'
    },
    {
      name: 'GDPR Compliant',
      description: 'European Data Protection',
      year: '2021',
      icon: 'FileText'
    }
  ];

  return (
    <section className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
              <Icon name="Trophy" size={24} color="white" />
            </div>
            <h2 className="text-4xl font-bold">Awards & Recognition</h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Industry recognition for our excellence in Bitcoin investment management, security, and innovation
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Awards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {awards.map((award, index) => (
              <div key={index} className="glass-effect rounded-xl p-6 border border-yellow-500/20 hover:border-yellow-500/40 transition-all hover:scale-105">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-yellow-400/20 to-orange-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon name={award.icon} size={32} className={award.color} />
                  </div>
                  
                  <div className="mb-4">
                    <div className="text-sm text-yellow-400 font-semibold mb-1">{award.year}</div>
                    <h3 className="text-lg font-bold mb-2">{award.title}</h3>
                    <p className="text-sm text-blue-400 font-medium mb-3">{award.organization}</p>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4">{award.description}</p>

                  <div className="border-t border-border pt-3">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-orange-500/20 text-orange-400">
                      {award.category}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Media Coverage */}
          <div className="mb-16">
            <div className="text-center mb-12">
              <h3 className="text-2xl font-bold mb-4 flex items-center justify-center space-x-2">
                <Icon name="Newspaper" size={24} className="text-blue-400" />
                <span>Media Coverage</span>
              </h3>
              <p className="text-muted-foreground">
                Featured in leading financial and technology publications for our Bitcoin innovation
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {mediaFeatures.map((feature, index) => (
                <div key={index} className="glass-effect rounded-lg p-6 border border-blue-500/20">
                  <div className="flex items-start space-x-4">
                    <div className="text-3xl">{feature.logo}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-bold text-blue-400">{feature.outlet}</h4>
                        <span className="text-xs text-muted-foreground">{feature.date}</span>
                      </div>
                      <h5 className="font-semibold mb-3">{feature.title}</h5>
                      <blockquote className="text-sm text-muted-foreground italic border-l-2 border-orange-400 pl-3">
                        "{feature.quote}"
                      </blockquote>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Industry Certifications */}
          <div className="mb-16">
            <div className="text-center mb-12">
              <h3 className="text-2xl font-bold mb-4 flex items-center justify-center space-x-2">
                <Icon name="Badge" size={24} className="text-green-400" />
                <span>Industry Certifications</span>
              </h3>
              <p className="text-muted-foreground">
                Maintaining the highest standards in Bitcoin investment security and compliance
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {certifications.map((cert, index) => (
                <div key={index} className="glass-effect rounded-lg p-6 text-center border border-green-500/20">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-400/20 to-blue-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Icon name={cert.icon} size={24} className="text-green-400" />
                  </div>
                  <h4 className="font-bold mb-2">{cert.name}</h4>
                  <p className="text-sm text-muted-foreground mb-2">{cert.description}</p>
                  <div className="text-xs text-green-400 font-semibold">Since {cert.year}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Recognition Summary */}
          <div className="text-center">
            <div className="glass-effect rounded-xl p-8 max-w-4xl mx-auto border border-orange-500/20">
              <div className="flex items-center justify-center space-x-3 mb-6">
                <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-2xl font-bold">₿</span>
                </div>
                <h3 className="text-2xl font-bold">Industry Leadership in Bitcoin Investment</h3>
              </div>
              
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Our commitment to excellence in Bitcoin investment management has earned recognition 
                from industry leaders, media outlets, and most importantly, our 150,000+ satisfied investors.
              </p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div>
                  <div className="text-3xl font-bold text-yellow-400 mb-2">15+</div>
                  <div className="text-sm text-muted-foreground">Industry Awards</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-400 mb-2">50+</div>
                  <div className="text-sm text-muted-foreground">Media Features</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-400 mb-2">10+</div>
                  <div className="text-sm text-muted-foreground">Certifications</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-orange-400 mb-2">₿2.4B+</div>
                  <div className="text-sm text-muted-foreground">Assets Recognized</div>
                </div>
              </div>

              <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-sm opacity-70">
                <div className="flex items-center space-x-2">
                  <Icon name="Trophy" size={16} className="text-yellow-400" />
                  <span>Award Winning</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="Newspaper" size={16} className="text-blue-400" />
                  <span>Media Featured</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="ShieldCheck" size={16} className="text-green-400" />
                  <span>Industry Certified</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-orange-400">₿</span>
                  <span>Bitcoin Specialized</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AwardsRecognition;