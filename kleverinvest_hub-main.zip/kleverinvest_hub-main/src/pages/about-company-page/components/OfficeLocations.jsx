import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const OfficeLocations = () => {
  const [selectedOffice, setSelectedOffice] = useState('headquarters');

  const offices = [
    {
      id: 'headquarters',
      type: 'Headquarters',
      city: 'San Francisco',
      country: 'USA',
      address: '425 Market Street, Suite 2200, San Francisco, CA 94105',
      team: '85 employees',
      specialization: 'Bitcoin Research & Development',
      departments: ['Engineering', 'Product', 'Bitcoin Research', 'Security'],
      coordinates: { lat: 37.7749, lng: -122.4194 },
      timezone: 'PST (UTC-8)',
      contact: {
        phone: '+1 (415) 555-0123',
        email: 'sf@kleverinvest.com'
      },
      bitcoinFocus: 'Core Bitcoin platform development and security infrastructure'
    },
    {
      id: 'london',
      type: 'European Hub',
      city: 'London',
      country: 'United Kingdom',
      address: '1 Canary Wharf, Level 42, London E14 5AB',
      team: '45 employees',
      specialization: 'European Bitcoin Markets',
      departments: ['Compliance', 'Business Development', 'Customer Success'],
      coordinates: { lat: 51.5074, lng: -0.1278 },
      timezone: 'GMT (UTC+0)',
      contact: {
        phone: '+44 20 7946 0958',
        email: 'london@kleverinvest.com'
      },
      bitcoinFocus: 'European Bitcoin regulatory compliance and market expansion'
    },
    {
      id: 'singapore',
      type: 'Asia-Pacific Hub',
      city: 'Singapore',
      country: 'Singapore',
      address: '8 Marina Bay Financial Centre, Tower 1, Level 28',
      team: '32 employees',
      specialization: 'Asian Bitcoin Markets',
      departments: ['Trading', 'Regional Operations', 'Partnerships'],
      coordinates: { lat: 1.3521, lng: 103.8198 },
      timezone: 'SGT (UTC+8)',
      contact: {
        phone: '+65 6789 1234',
        email: 'singapore@kleverinvest.com'
      },
      bitcoinFocus: 'Bitcoin trading operations and Asian market development'
    },
    {
      id: 'toronto',
      type: 'North American Operations',
      city: 'Toronto',
      country: 'Canada',
      address: '100 King Street West, Suite 5600, Toronto, ON M5X 1C9',
      team: '28 employees',
      specialization: 'Bitcoin Customer Support',
      departments: ['Customer Support', 'Marketing', 'Legal'],
      coordinates: { lat: 43.6532, lng: -79.3832 },
      timezone: 'EST (UTC-5)',
      contact: {
        phone: '+1 (416) 555-0199',
        email: 'toronto@kleverinvest.com'
      },
      bitcoinFocus: '24/7 Bitcoin investment support and customer success'
    }
  ];

  const selectedOfficeData = offices.find(office => office.id === selectedOffice);

  const globalStats = [
    { label: 'Global Offices', value: '4', icon: 'Building' },
    { label: 'Countries', value: '4', icon: 'Globe' },
    { label: 'Team Members', value: '190+', icon: 'Users' },
    { label: 'Time Zones', value: '4', icon: 'Clock' }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-400 to-green-500 rounded-full flex items-center justify-center">
              <Icon name="MapPin" size={24} color="white" />
            </div>
            <h2 className="text-4xl font-bold">Global Presence</h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our Bitcoin investment expertise spans across four continents, providing 24/7 support to investors worldwide
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Global Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
            {globalStats.map((stat, index) => (
              <div key={index} className="glass-effect rounded-lg p-6 text-center border border-blue-500/20">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-400/20 to-green-500/20 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Icon name={stat.icon} size={24} className="text-blue-400" />
                </div>
                <div className="text-2xl font-bold text-blue-400 mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Office Selection */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {offices.map((office) => (
              <Button
                key={office.id}
                onClick={() => setSelectedOffice(office.id)}
                variant={selectedOffice === office.id ? 'default' : 'outline'}
                className={`${
                  selectedOffice === office.id 
                    ? 'gradient-gold text-black' :'border-blue-500/50 text-blue-400 hover:bg-blue-500/10'
                }`}
              >
                <Icon name="MapPin" size={16} className="mr-2" />
                {office.city}
              </Button>
            ))}
          </div>

          {/* Selected Office Details */}
          {selectedOfficeData && (
            <div className="glass-effect rounded-xl p-8 border border-blue-500/20 mb-12">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Office Info */}
                <div>
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-400 to-green-500 rounded-full flex items-center justify-center">
                      <Icon name="Building" size={24} color="white" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold">{selectedOfficeData.city} Office</h3>
                      <p className="text-blue-400 font-semibold">{selectedOfficeData.type}</p>
                    </div>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div className="flex items-start space-x-3">
                      <Icon name="MapPin" size={16} className="text-muted-foreground mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold">Address</p>
                        <p className="text-sm text-muted-foreground">{selectedOfficeData.address}</p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Icon name="Users" size={16} className="text-muted-foreground mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold">Team Size</p>
                        <p className="text-sm text-muted-foreground">{selectedOfficeData.team}</p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Icon name="Clock" size={16} className="text-muted-foreground mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold">Timezone</p>
                        <p className="text-sm text-muted-foreground">{selectedOfficeData.timezone}</p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <span className="text-orange-400 mt-1">₿</span>
                      <div>
                        <p className="font-semibold">Bitcoin Focus</p>
                        <p className="text-sm text-muted-foreground">{selectedOfficeData.bitcoinFocus}</p>
                      </div>
                    </div>
                  </div>

                  {/* Contact Info */}
                  <div className="border-t border-border pt-4">
                    <h4 className="font-semibold mb-3">Contact Information</h4>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Icon name="Phone" size={14} className="text-green-400" />
                        <span className="text-sm">{selectedOfficeData.contact.phone}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Icon name="Mail" size={14} className="text-blue-400" />
                        <span className="text-sm">{selectedOfficeData.contact.email}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Departments & Specialization */}
                <div>
                  <div className="mb-6">
                    <h4 className="font-semibold mb-3 flex items-center space-x-2">
                      <Icon name="Target" size={16} className="text-orange-400" />
                      <span>Specialization</span>
                    </h4>
                    <div className="glass-effect rounded-lg p-4 border border-orange-500/20">
                      <p className="text-orange-400 font-semibold">{selectedOfficeData.specialization}</p>
                    </div>
                  </div>

                  <div className="mb-6">
                    <h4 className="font-semibold mb-3 flex items-center space-x-2">
                      <Icon name="Briefcase" size={16} className="text-blue-400" />
                      <span>Departments</span>
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      {selectedOfficeData.departments.map((dept, index) => (
                        <div key={index} className="glass-effect rounded-lg p-3 text-center border border-blue-500/20">
                          <span className="text-sm text-blue-400 font-medium">{dept}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Office Image Placeholder */}
                  <div className="glass-effect rounded-lg p-8 text-center border border-green-500/20">
                    <div className="w-24 h-24 bg-gradient-to-r from-blue-400 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon name="Building" size={32} color="white" />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Modern office space in the heart of {selectedOfficeData.city}'s financial district
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Global Coverage */}
          <div className="text-center">
            <div className="glass-effect rounded-xl p-8 max-w-4xl mx-auto border border-green-500/20">
              <h3 className="text-2xl font-bold mb-6 flex items-center justify-center space-x-2">
                <Icon name="Globe" size={24} className="text-green-400" />
                <span>24/7 Bitcoin Investment Support</span>
              </h3>
              
              <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
                With offices across four time zones, our Bitcoin investment experts provide round-the-clock 
                support to investors worldwide, ensuring your cryptocurrency investments are always monitored 
                and managed professionally.
              </p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-blue-400">Americas</div>
                  <div className="text-sm text-muted-foreground">San Francisco, Toronto</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-green-400">Europe</div>
                  <div className="text-sm text-muted-foreground">London Hub</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-orange-400">Asia-Pacific</div>
                  <div className="text-sm text-muted-foreground">Singapore Operations</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-purple-400">Global</div>
                  <div className="text-sm text-muted-foreground">50+ Countries Served</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default OfficeLocations;