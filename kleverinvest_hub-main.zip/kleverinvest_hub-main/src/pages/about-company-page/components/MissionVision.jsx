import React from 'react';
import Icon from '../../../components/AppIcon';

const MissionVision = () => {
  const values = [
    {
      icon: 'Shield',
      title: 'Security First',
      description: 'Every Bitcoin transaction and investment is protected by institutional-grade security protocols',
      color: 'text-blue-400'
    },
    {
      icon: 'Users',
      title: 'Investor-Centric',
      description: 'Our platform prioritizes investor success with transparent Bitcoin investment strategies',
      color: 'text-green-400'
    },
    {
      icon: 'Zap',
      title: 'Innovation',
      description: 'Continuously advancing Bitcoin investment technology and user experience',
      color: 'text-yellow-400'
    },
    {
      icon: 'Globe',
      title: 'Global Access',
      description: 'Making Bitcoin investment opportunities accessible to investors worldwide',
      color: 'text-purple-400'
    },
    {
      icon: 'TrendingUp',
      title: 'Performance',
      description: 'Delivering consistent returns through professional Bitcoin portfolio management',
      color: 'text-orange-400'
    },
    {
      icon: 'Heart',
      title: 'Trust',
      description: 'Building lasting relationships through transparency and Bitcoin investment excellence',
      color: 'text-pink-400'
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Mission & Vision */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
            {/* Mission */}
            <div className="glass-effect rounded-xl p-8 border border-orange-500/20">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center">
                  <Icon name="Target" size={24} color="white" />
                </div>
                <h3 className="text-2xl font-bold">Our Mission</h3>
              </div>
              
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                To democratize access to professional Bitcoin investment management, empowering individuals 
                and institutions worldwide to participate in the digital asset revolution with confidence, 
                security, and expert guidance.
              </p>

              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center mt-1">
                    <span className="text-white text-xs font-bold">₿</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-orange-400">Bitcoin Accessibility</h4>
                    <p className="text-sm text-muted-foreground">Making Bitcoin investment simple and secure for everyone</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <Icon name="Shield" size={14} color="white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-green-400">Professional Management</h4>
                    <p className="text-sm text-muted-foreground">Institutional-grade Bitcoin investment strategies</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center mt-1">
                    <Icon name="Globe" size={14} color="white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-blue-400">Global Impact</h4>
                    <p className="text-sm text-muted-foreground">Expanding Bitcoin investment opportunities worldwide</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Vision */}
            <div className="glass-effect rounded-xl p-8 border border-orange-500/20">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full flex items-center justify-center">
                  <Icon name="Eye" size={24} color="white" />
                </div>
                <h3 className="text-2xl font-bold">Our Vision</h3>
              </div>
              
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                To become the world's most trusted Bitcoin investment platform, leading the transformation 
                of global finance through innovative cryptocurrency solutions that create wealth and 
                financial freedom for millions of investors.
              </p>

              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center mt-1">
                    <Icon name="Crown" size={14} color="white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-purple-400">Market Leadership</h4>
                    <p className="text-sm text-muted-foreground">Leading Bitcoin investment innovation globally</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center mt-1">
                    <Icon name="Zap" size={14} color="white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-yellow-400">Technology Innovation</h4>
                    <p className="text-sm text-muted-foreground">Pioneering next-generation Bitcoin investment tools</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center mt-1">
                    <Icon name="TrendingUp" size={14} color="white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-orange-400">Financial Transformation</h4>
                    <p className="text-sm text-muted-foreground">Reshaping how the world invests in Bitcoin</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Company Values */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xl font-bold">₿</span>
              </div>
              <h2 className="text-4xl font-bold">Our Values</h2>
            </div>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              The principles that guide our Bitcoin investment platform and drive our commitment to investor success
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="group">
                <div className="glass-effect rounded-xl p-6 hover:bg-card/50 transition-all duration-300 border border-orange-500/10 hover:border-orange-500/30 hover:scale-105 h-full">
                  <div className="text-center mb-4">
                    <div className={`w-14 h-14 rounded-lg flex items-center justify-center mx-auto mb-4 bg-gradient-to-r from-orange-400/20 to-yellow-500/20 group-hover:scale-110 transition-transform`}>
                      <Icon name={value.icon} size={28} className={value.color} />
                    </div>
                    <h3 className="text-xl font-semibold mb-3 group-hover:text-orange-400 transition-colors">
                      {value.title}
                    </h3>
                  </div>
                  
                  <p className="text-muted-foreground text-center leading-relaxed">
                    {value.description}
                  </p>

                  {/* Bitcoin accent */}
                  <div className="flex justify-center mt-4">
                    <div className="w-8 h-8 bg-orange-500/20 rounded-full flex items-center justify-center">
                      <span className="text-orange-400 text-xs font-bold">₿</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Impact Statement */}
          <div className="mt-16 text-center">
            <div className="glass-effect rounded-xl p-8 max-w-4xl mx-auto border border-orange-500/20">
              <div className="flex items-center justify-center space-x-3 mb-6">
                <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-2xl font-bold">₿</span>
                </div>
                <h3 className="text-2xl font-bold">Our Bitcoin Impact</h3>
              </div>
              
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Together, we're building the future of finance through Bitcoin investment excellence, 
                one investor at a time, creating lasting wealth and financial freedom.
              </p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div>
                  <div className="text-3xl font-bold text-orange-400 mb-2">₿52.8K+</div>
                  <div className="text-sm text-muted-foreground">Bitcoin Under Management</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-400 mb-2">150K+</div>
                  <div className="text-sm text-muted-foreground">Lives Impacted</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-400 mb-2">50+</div>
                  <div className="text-sm text-muted-foreground">Countries Served</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-purple-400 mb-2">$2.4B+</div>
                  <div className="text-sm text-muted-foreground">Wealth Created</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MissionVision;