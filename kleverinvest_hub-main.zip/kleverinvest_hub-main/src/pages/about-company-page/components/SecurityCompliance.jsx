import React from 'react';
import Icon from '../../../components/AppIcon';

const SecurityCompliance = () => {
  const securityFeatures = [
    {
      icon: 'Shield',
      title: 'Multi-Signature Bitcoin Wallets',
      description: 'Advanced multi-signature technology protects Bitcoin investments with distributed key management',
      details: ['Hardware security modules', 'Offline cold storage', 'Distributed key architecture']
    },
    {
      icon: 'Lock',
      title: 'Institutional Grade Custody',
      description: 'Bank-level Bitcoin custody solutions with insurance coverage and regulatory compliance',
      details: ['$100M+ insurance coverage', 'Regulated custody partners', 'Segregated Bitcoin storage']
    },
    {
      icon: 'Eye',
      title: '24/7 Security Monitoring',
      description: 'Round-the-clock monitoring of Bitcoin transactions and platform security',
      details: ['Real-time threat detection', 'Automated security responses', 'Security incident management']
    },
    {
      icon: 'Users',
      title: 'Identity Verification',
      description: 'Comprehensive KYC/AML procedures for Bitcoin investment platform access',
      details: ['Multi-factor authentication', 'Biometric verification', 'Document verification']
    }
  ];

  const certifications = [
    {
      logo: '🛡️',
      name: 'SOC 2 Type II',
      description: 'Security, availability, and confidentiality controls',
      validUntil: '2025',
      category: 'Security'
    },
    {
      logo: '🏛️',
      name: 'ISO 27001',
      description: 'Information security management systems',
      validUntil: '2025',
      category: 'Compliance'
    },
    {
      logo: '⚖️',
      name: 'GDPR Compliant',
      description: 'European Union data protection regulation',
      validUntil: 'Ongoing',
      category: 'Privacy'
    },
    {
      logo: '🔒',
      name: 'PCI DSS',
      description: 'Payment card industry data security standard',
      validUntil: '2025',
      category: 'Payments'
    },
    {
      logo: '🏦',
      name: 'FINCEN Registered',
      description: 'US Financial Crimes Enforcement Network',
      validUntil: 'Active',
      category: 'Regulatory'
    },
    {
      logo: '🌍',
      name: 'EU MiCA Ready',
      description: 'Markets in Crypto-Assets regulation compliance',
      validUntil: '2024',
      category: 'European'
    }
  ];

  const auditPartners = [
    {
      name: 'Deloitte',
      type: 'Financial Audit',
      focus: 'Bitcoin custody and accounting practices'
    },
    {
      name: 'Ernst & Young',
      type: 'Security Audit',
      focus: 'Cybersecurity and Bitcoin wallet security'
    },
    {
      name: 'KPMG',
      type: 'Compliance Audit',
      focus: 'Regulatory compliance and risk management'
    }
  ];

  return (
    <section className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
              <Icon name="ShieldCheck" size={24} color="white" />
            </div>
            <h2 className="text-4xl font-bold">Security & Compliance</h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Industry-leading security protocols and regulatory compliance ensure your Bitcoin investments are protected at the highest standards
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Security Features */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {securityFeatures.map((feature, index) => (
              <div key={index} className="glass-effect rounded-xl p-6 border border-green-500/20 hover:border-green-500/40 transition-all">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-400/20 to-blue-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon name={feature.icon} size={24} className="text-green-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                    <p className="text-muted-foreground mb-4">{feature.description}</p>
                    <ul className="space-y-2">
                      {feature.details.map((detail, detailIndex) => (
                        <li key={detailIndex} className="flex items-center space-x-2">
                          <Icon name="Check" size={14} className="text-green-400 flex-shrink-0" />
                          <span className="text-sm text-muted-foreground">{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Bitcoin Security Stats */}
          <div className="glass-effect rounded-xl p-8 mb-16 border border-orange-500/20">
            <div className="text-center mb-8">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-2xl font-bold">₿</span>
                </div>
                <h3 className="text-2xl font-bold">Bitcoin Security Excellence</h3>
              </div>
              <p className="text-muted-foreground">Our track record in Bitcoin investment protection</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400 mb-2">100%</div>
                <div className="text-sm text-muted-foreground">Bitcoin Security Record</div>
                <div className="text-xs text-green-300 mt-1">No security breaches</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400 mb-2">₿52.8K+</div>
                <div className="text-sm text-muted-foreground">Bitcoin Protected</div>
                <div className="text-xs text-blue-300 mt-1">Under secure custody</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-400 mb-2">$100M+</div>
                <div className="text-sm text-muted-foreground">Insurance Coverage</div>
                <div className="text-xs text-orange-300 mt-1">Bitcoin custody insurance</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-400 mb-2">99.99%</div>
                <div className="text-sm text-muted-foreground">Platform Uptime</div>
                <div className="text-xs text-purple-300 mt-1">Reliable Bitcoin access</div>
              </div>
            </div>
          </div>

          {/* Certifications Grid */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-center mb-8 flex items-center justify-center space-x-2">
              <Icon name="Award" size={24} className="text-yellow-400" />
              <span>Certifications & Compliance</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {certifications.map((cert, index) => (
                <div key={index} className="glass-effect rounded-lg p-6 border border-blue-500/20 hover:border-blue-500/40 transition-all">
                  <div className="text-center">
                    <div className="text-4xl mb-4">{cert.logo}</div>
                    <h4 className="font-bold mb-2">{cert.name}</h4>
                    <p className="text-sm text-muted-foreground mb-3">{cert.description}</p>
                    <div className="flex items-center justify-between text-xs">
                      <span className="bg-blue-500/20 text-blue-400 px-2 py-1 rounded">
                        {cert.category}
                      </span>
                      <span className="text-green-400">Valid: {cert.validUntil}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Audit Partners */}
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-8 flex items-center justify-center space-x-2">
              <Icon name="FileSearch" size={24} className="text-purple-400" />
              <span>Independent Audit Partners</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {auditPartners.map((partner, index) => (
                <div key={index} className="glass-effect rounded-lg p-6 border border-purple-500/20">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-400/20 to-blue-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <Icon name="Building" size={24} className="text-purple-400" />
                    </div>
                    <h4 className="font-bold mb-2">{partner.name}</h4>
                    <p className="text-sm text-purple-400 font-semibold mb-2">{partner.type}</p>
                    <p className="text-sm text-muted-foreground">{partner.focus}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 text-center">
              <div className="inline-flex items-center space-x-2 text-sm text-muted-foreground bg-green-500/10 px-4 py-2 rounded-full">
                <Icon name="CheckCircle" size={16} className="text-green-400" />
                <span>All audits completed successfully with no material findings</span>
              </div>
            </div>
          </div>

          {/* Trust Indicators */}
          <div className="mt-16 text-center">
            <div className="glass-effect rounded-xl p-8 max-w-4xl mx-auto border border-green-500/20">
              <h3 className="text-xl font-bold mb-6 flex items-center justify-center space-x-2">
                <Icon name="Heart" size={20} className="text-red-400" />
                <span>Trusted by Bitcoin Investors Worldwide</span>
              </h3>
              
              <div className="flex flex-wrap items-center justify-center gap-8 opacity-70">
                <div className="flex items-center space-x-2">
                  <Icon name="ShieldCheck" size={20} className="text-green-400" />
                  <span className="text-sm">Bank-Grade Security</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="Award" size={20} className="text-yellow-400" />
                  <span className="text-sm">Industry Certified</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="Globe" size={20} className="text-blue-400" />
                  <span className="text-sm">Globally Compliant</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-orange-400 text-lg">₿</span>
                  <span className="text-sm">Bitcoin Specialized</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SecurityCompliance;