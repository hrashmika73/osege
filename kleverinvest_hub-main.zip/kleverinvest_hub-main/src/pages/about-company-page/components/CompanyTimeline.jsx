import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const CompanyTimeline = () => {
  const [selectedYear, setSelectedYear] = useState(2024);

  const timelineEvents = [
    {
      year: 2019,
      title: 'KleverInvest Hub Founded',
      description: 'Company established with vision to democratize Bitcoin investment',
      achievements: [
        'Secured $5M seed funding',
        'Built core Bitcoin investment platform',
        'Launched beta with 100 early investors'
      ],
      bitcoinPrice: '$7,200',
      icon: 'Rocket',
      color: 'bg-blue-500'
    },
    {
      year: 2020,
      title: 'Institutional Bitcoin Adoption',
      description: 'Expanded platform to serve institutional Bitcoin investors',
      achievements: [
        'Reached $100M in Bitcoin under management',
        'Launched institutional trading desk',
        'Obtained financial services licenses',
        'Served 10,000+ Bitcoin investors'
      ],
      bitcoinPrice: '$29,000',
      icon: 'Building',
      color: 'bg-green-500'
    },
    {
      year: 2021,
      title: 'Global Bitcoin Expansion',
      description: 'International expansion during Bitcoin mainstream adoption',
      achievements: [
        'Expanded to 25+ countries',
        'Reached ₿10,000 under management',
        'Launched mobile Bitcoin app',
        'Won "Best Bitcoin Platform" award'
      ],
      bitcoinPrice: '$47,000',
      icon: 'Globe',
      color: 'bg-orange-500'
    },
    {
      year: 2022,
      title: 'Bitcoin Infrastructure Leadership',
      description: 'Built advanced Bitcoin custody and Lightning Network solutions',
      achievements: [
        'Implemented Lightning Network',
        'Launched Bitcoin staking products',
        'Achieved SOC 2 compliance',
        'Grew to 75,000+ investors'
      ],
      bitcoinPrice: '$16,500',
      icon: 'Zap',
      color: 'bg-yellow-500'
    },
    {
      year: 2023,
      title: 'Bitcoin Innovation Hub',
      description: 'Became leading platform for Bitcoin investment innovation',
      achievements: [
        'Reached ₿35,000 Bitcoin under management',
        'Launched Bitcoin yield strategies',
        'Expanded to 50+ countries',
        'Served 125,000+ investors'
      ],
      bitcoinPrice: '$42,000',
      icon: 'TrendingUp',
      color: 'bg-purple-500'
    },
    {
      year: 2024,
      title: 'Bitcoin Investment Excellence',
      description: 'Achieved market leadership in Bitcoin investment management',
      achievements: [
        'Managing ₿52,847+ in Bitcoin investments',
        'Serving 150,000+ global investors',
        'Launched advanced Bitcoin analytics',
        'Achieved $2.4B+ assets under management'
      ],
      bitcoinPrice: '$45,000',
      icon: 'Award',
      color: 'bg-orange-400'
    }
  ];

  const selectedEvent = timelineEvents.find(event => event.year === selectedYear);

  return (
    <section className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xl font-bold">₿</span>
            </div>
            <h2 className="text-4xl font-bold">Our Bitcoin Journey</h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Five years of innovation and growth in Bitcoin investment management
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Timeline Navigation */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {timelineEvents.map((event) => (
              <button
                key={event.year}
                onClick={() => setSelectedYear(event.year)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-all ${
                  selectedYear === event.year
                    ? 'gradient-gold text-black' :'glass-effect text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
              >
                <div className={`w-8 h-8 ${event.color} rounded-full flex items-center justify-center`}>
                  <Icon name={event.icon} size={16} color="white" />
                </div>
                <span>{event.year}</span>
              </button>
            ))}
          </div>

          {/* Selected Event Details */}
          {selectedEvent && (
            <div className="glass-effect rounded-xl p-8 border border-orange-500/20">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                {/* Event Content */}
                <div>
                  <div className="flex items-center space-x-3 mb-4">
                    <div className={`w-12 h-12 ${selectedEvent.color} rounded-full flex items-center justify-center`}>
                      <Icon name={selectedEvent.icon} size={24} color="white" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold">{selectedEvent.title}</h3>
                      <div className="text-orange-400 font-semibold">{selectedEvent.year}</div>
                    </div>
                  </div>

                  <p className="text-muted-foreground mb-6 text-lg">
                    {selectedEvent.description}
                  </p>

                  <div className="space-y-3">
                    <h4 className="font-semibold flex items-center space-x-2">
                      <Icon name="CheckCircle" size={16} className="text-green-400" />
                      <span>Key Achievements</span>
                    </h4>
                    <ul className="space-y-2">
                      {selectedEvent.achievements.map((achievement, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <Icon name="ArrowRight" size={16} className="text-orange-400 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-muted-foreground">{achievement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Bitcoin Price & Visual */}
                <div className="text-center">
                  <div className="glass-effect rounded-xl p-6 border border-orange-500/20 mb-6">
                    <div className="flex items-center justify-center space-x-2 mb-4">
                      <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-2xl font-bold">₿</span>
                      </div>
                      <div className="text-left">
                        <div className="text-2xl font-bold text-orange-400">{selectedEvent.bitcoinPrice}</div>
                        <div className="text-sm text-muted-foreground">Bitcoin Price in {selectedEvent.year}</div>
                      </div>
                    </div>
                  </div>

                  {/* Growth Metrics for Selected Year */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="glass-effect rounded-lg p-4 border border-orange-500/10">
                      <div className="text-lg font-bold text-blue-400">
                        {selectedEvent.year === 2019 && '100'}
                        {selectedEvent.year === 2020 && '10K+'}
                        {selectedEvent.year === 2021 && '35K+'}
                        {selectedEvent.year === 2022 && '75K+'}
                        {selectedEvent.year === 2023 && '125K+'}
                        {selectedEvent.year === 2024 && '150K+'}
                      </div>
                      <div className="text-xs text-muted-foreground">Bitcoin Investors</div>
                    </div>
                    <div className="glass-effect rounded-lg p-4 border border-orange-500/10">
                      <div className="text-lg font-bold text-green-400">
                        {selectedEvent.year === 2019 && '₿100'}
                        {selectedEvent.year === 2020 && '₿3.4K'}
                        {selectedEvent.year === 2021 && '₿10K'}
                        {selectedEvent.year === 2022 && '₿25K'}
                        {selectedEvent.year === 2023 && '₿35K'}
                        {selectedEvent.year === 2024 && '₿52.8K'}
                      </div>
                      <div className="text-xs text-muted-foreground">Bitcoin Managed</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Bitcoin Market Correlation */}
          <div className="mt-12 text-center">
            <div className="glass-effect rounded-xl p-6 max-w-4xl mx-auto border border-orange-500/20">
              <h3 className="text-xl font-bold mb-4 flex items-center justify-center space-x-2">
                <Icon name="BarChart3" size={20} className="text-orange-400" />
                <span>Growing with Bitcoin Market</span>
              </h3>
              <p className="text-muted-foreground mb-4">
                Our platform has grown alongside Bitcoin's mainstream adoption, maintaining leadership through all market cycles
              </p>
              <div className="flex items-center justify-center space-x-8 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-orange-400 rounded-full"></div>
                  <span>Platform Growth</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                  <span>Bitcoin Adoption</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-blue-400 rounded-full"></div>
                  <span>User Growth</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CompanyTimeline;