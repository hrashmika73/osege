import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LeadershipTeam = () => {
  const [selectedMember, setSelectedMember] = useState(null);

  const teamMembers = [
    {
      id: 1,
      name: 'Sarah Chen',
      position: 'CEO & Co-Founder',
      specialization: 'Bitcoin Strategy & Blockchain Innovation',
      experience: '12+ years in cryptocurrency and fintech',
      education: 'MIT - Computer Science, Stanford MBA',
      achievements: [
        'Former Goldman Sachs VP of Digital Assets',
        'Built first institutional Bitcoin trading desk',
        'Forbes 30 Under 30 in Finance',
        'Author of "Bitcoin Investment Strategies"'
      ],
      bitcoinExpertise: 'Bitcoin market analysis, institutional adoption strategies',
      avatar: '👩‍💼',
      socialLinks: {
        twitter: '#',
        linkedin: '#'
      }
    },
    {
      id: 2,
      name: 'Michael Rodriguez',
      position: 'CTO & Co-Founder',
      specialization: 'Bitcoin Security & Infrastructure',
      experience: '15+ years in cybersecurity and blockchain',
      education: 'Carnegie Mellon - Cybersecurity, PhD Blockchain Technology',
      achievements: [
        'Former Tesla Senior Security Engineer',
        'Designed Bitcoin custody solutions for Fortune 500',
        'Created multi-signature Bitcoin protocols',
        '20+ patents in blockchain security'
      ],
      bitcoinExpertise: 'Bitcoin wallet security, Lightning Network implementation',
      avatar: '👨‍💻',
      socialLinks: {
        twitter: '#',
        linkedin: '#'
      }
    },
    {
      id: 3,
      name: 'David Kim',
      position: 'Head of Bitcoin Research',
      specialization: 'Bitcoin Market Analysis & Trading',
      experience: '10+ years in cryptocurrency research',
      education: 'Wharton School - Finance, CFA Charterholder',
      achievements: [
        'Led Bitcoin research at JP Morgan',
        'Predicted 2020-2021 Bitcoin bull run',
        'Published 100+ Bitcoin market reports',
        'Speaker at Bitcoin conferences worldwide'
      ],
      bitcoinExpertise: 'Bitcoin price modeling, on-chain analysis',
      avatar: '👨‍🔬',
      socialLinks: {
        twitter: '#',
        linkedin: '#'
      }
    },
    {
      id: 4,
      name: 'Emma Thompson',
      position: 'Chief Compliance Officer',
      specialization: 'Bitcoin Regulatory Compliance',
      experience: '8+ years in financial regulation',
      education: 'Harvard Law School JD, Georgetown LLM',
      achievements: [
        'Former SEC Senior Attorney',
        'Expert in cryptocurrency regulations',
        'Advised governments on Bitcoin policy',
        'Built compliance frameworks for Bitcoin firms'
      ],
      bitcoinExpertise: 'Bitcoin regulatory landscape, compliance strategies',
      avatar: '👩‍⚖️',
      socialLinks: {
        twitter: '#',
        linkedin: '#'
      }
    }
  ];

  const advisors = [
    {
      name: 'Dr. Andreas Nakamoto',
      role: 'Bitcoin Technology Advisor',
      background: 'Bitcoin Core Contributor',
      expertise: 'Bitcoin protocol development'
    },
    {
      name: 'Jennifer Walsh',
      role: 'Investment Strategy Advisor',
      background: 'Former BlackRock Managing Director',
      expertise: 'Institutional Bitcoin adoption'
    },
    {
      name: 'Robert Chen',
      role: 'Security Advisor',
      background: 'Former NSA Cryptographer',
      expertise: 'Bitcoin security protocols'
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xl font-bold">₿</span>
            </div>
            <h2 className="text-4xl font-bold">Leadership Team</h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Meet the Bitcoin and cryptocurrency experts leading KleverInvest Hub to revolutionize digital asset investment
          </p>
        </div>

        {/* Leadership Team Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {teamMembers.map((member) => (
            <div 
              key={member.id} 
              className="group cursor-pointer"
              onClick={() => setSelectedMember(member)}
            >
              <div className="glass-effect rounded-xl p-6 hover:bg-card/50 transition-all duration-300 border border-orange-500/10 hover:border-orange-500/30 hover:scale-105">
                {/* Avatar */}
                <div className="text-center mb-4">
                  <div className="text-6xl mb-3">{member.avatar}</div>
                  <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-white text-sm font-bold">₿</span>
                  </div>
                </div>

                <div className="text-center">
                  <h3 className="text-xl font-bold mb-2 group-hover:text-orange-400 transition-colors">
                    {member.name}
                  </h3>
                  <p className="text-sm text-orange-400 font-semibold mb-2">{member.position}</p>
                  <p className="text-sm text-muted-foreground mb-4">{member.specialization}</p>
                  
                  <div className="flex justify-center space-x-2">
                    <div className="w-8 h-8 glass-effect rounded-lg flex items-center justify-center hover:bg-orange-500/10 transition-colors">
                      <Icon name="Twitter" size={14} className="text-muted-foreground hover:text-orange-400" />
                    </div>
                    <div className="w-8 h-8 glass-effect rounded-lg flex items-center justify-center hover:bg-orange-500/10 transition-colors">
                      <Icon name="Linkedin" size={14} className="text-muted-foreground hover:text-orange-400" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Advisory Board */}
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-2xl font-bold mb-4 flex items-center justify-center space-x-2">
              <Icon name="Users" size={24} className="text-orange-400" />
              <span>Bitcoin Advisory Board</span>
            </h3>
            <p className="text-muted-foreground">
              Industry veterans providing strategic guidance on Bitcoin investment and technology
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {advisors.map((advisor, index) => (
              <div key={index} className="glass-effect rounded-lg p-6 border border-orange-500/10">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-orange-400/20 to-yellow-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon name="Award" size={24} className="text-orange-400" />
                  </div>
                  <h4 className="font-bold mb-2">{advisor.name}</h4>
                  <p className="text-sm text-orange-400 font-semibold mb-2">{advisor.role}</p>
                  <p className="text-sm text-muted-foreground mb-2">{advisor.background}</p>
                  <div className="border-t border-orange-500/20 pt-3 mt-3">
                    <p className="text-xs text-orange-300">{advisor.expertise}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Team Stats */}
        <div className="mt-16 text-center">
          <div className="glass-effect rounded-xl p-8 max-w-4xl mx-auto border border-orange-500/20">
            <h3 className="text-2xl font-bold mb-6">Our Team Excellence</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <div className="text-3xl font-bold text-orange-400 mb-2">45+</div>
                <div className="text-sm text-muted-foreground">Combined Years in Bitcoin</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-400 mb-2">25+</div>
                <div className="text-sm text-muted-foreground">Cryptocurrency Patents</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-400 mb-2">100+</div>
                <div className="text-sm text-muted-foreground">Bitcoin Research Papers</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-400 mb-2">15+</div>
                <div className="text-sm text-muted-foreground">Industry Awards</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Member Detail Modal */}
      {selectedMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setSelectedMember(null)}
          />
          <div className="relative glass-effect rounded-xl p-8 max-w-2xl w-full border border-orange-500/20 max-h-[90vh] overflow-y-auto">
            <Button
              variant="ghost"
              size="sm"
              className="absolute top-4 right-4"
              onClick={() => setSelectedMember(null)}
            >
              <Icon name="X" size={20} />
            </Button>

            <div className="text-center mb-6">
              <div className="text-6xl mb-3">{selectedMember.avatar}</div>
              <h3 className="text-2xl font-bold mb-2">{selectedMember.name}</h3>
              <p className="text-orange-400 font-semibold mb-2">{selectedMember.position}</p>
              <p className="text-muted-foreground">{selectedMember.specialization}</p>
            </div>

            <div className="space-y-6">
              <div>
                <h4 className="font-semibold mb-2 flex items-center space-x-2">
                  <Icon name="Briefcase" size={16} className="text-orange-400" />
                  <span>Experience</span>
                </h4>
                <p className="text-muted-foreground">{selectedMember.experience}</p>
              </div>

              <div>
                <h4 className="font-semibold mb-2 flex items-center space-x-2">
                  <Icon name="GraduationCap" size={16} className="text-orange-400" />
                  <span>Education</span>
                </h4>
                <p className="text-muted-foreground">{selectedMember.education}</p>
              </div>

              <div>
                <h4 className="font-semibold mb-2 flex items-center space-x-2">
                  <span className="text-orange-400">₿</span>
                  <span>Bitcoin Expertise</span>
                </h4>
                <p className="text-muted-foreground">{selectedMember.bitcoinExpertise}</p>
              </div>

              <div>
                <h4 className="font-semibold mb-3 flex items-center space-x-2">
                  <Icon name="Award" size={16} className="text-orange-400" />
                  <span>Key Achievements</span>
                </h4>
                <ul className="space-y-2">
                  {selectedMember.achievements.map((achievement, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <Icon name="Check" size={16} className="text-green-400 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-muted-foreground">{achievement}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default LeadershipTeam;