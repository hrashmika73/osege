import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import { adminUserAPI } from '../../services/adminApiService';

const AdminActiveUsers = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('lastActive');
  const [filterBy, setFilterBy] = useState('all');

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-secure-login');
      return;
    }
    loadActiveUsers();

    // Set up periodic refresh every 30 seconds
    const pollInterval = setInterval(() => {
      loadActiveUsers(false);
    }, 30000);

    return () => {
      clearInterval(pollInterval);
    };
  }, [isAdminAuthenticated, navigate]);

  const loadActiveUsers = async (forceRefresh = false) => {
    setLoading(true);

    try {
      const response = await adminUserAPI.getUsers(1, 100, { status: 'active' });

      if (response?.success && response.data?.users) {
        setUsers(response.data.users);
      } else {
        setUsers([]);
      }
    } catch (error) {
      console.error('Error loading active users:', error);
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  const handleUserAction = async (userId, action) => {
    const user = users.find(u => u.id === userId);

    switch (action) {
      case 'view':
        navigate(`/admin-user-details/${userId}`);
        break;
      case 'suspend':
        if (window.confirm(`Are you sure you want to suspend ${user?.fullName}?`)) {
          setUsers(users.map(u =>
            u.id === userId
              ? { ...u, status: 'suspended' }
              : u
          ));
          
          // Update localStorage
          const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
          const userIndex = adminUsers.findIndex(u => u.id === userId);
          if (userIndex !== -1) {
            adminUsers[userIndex].status = 'suspended';
            localStorage.setItem('admin_users_data', JSON.stringify(adminUsers));
          }
        }
        break;
      case 'ban':
        if (window.confirm(`Are you sure you want to ban ${user?.fullName}?`)) {
          setUsers(users.filter(u => u.id !== userId));
          
          // Update localStorage
          const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
          const userIndex = adminUsers.findIndex(u => u.id === userId);
          if (userIndex !== -1) {
            adminUsers[userIndex].status = 'banned';
            localStorage.setItem('admin_users_data', JSON.stringify(adminUsers));
          }
        }
        break;
      case 'edit':
        navigate(`/admin-edit-user/${userId}`);
        break;
      case 'delete':
        if (window.confirm(`Are you sure you want to permanently delete ${user?.fullName}?\n\nThis action cannot be undone.`)) {
          try {
            const { deleteUserCompletely } = await import('../../utils/userDeletion');
            const result = deleteUserCompletely(userId);
            
            if (result.success) {
              setUsers(users.filter(u => u.id !== userId));
            }
          } catch (error) {
            console.error('Error during deletion:', error);
          }
        }
        break;
      default:
        break;
    }
  };

  const filteredUsers = users.filter(user => {
    const username = user.username || '';
    const email = user.email || '';
    const fullName = user.fullName || '';
    const searchTermLower = searchTerm.toLowerCase();

    const matchesSearch = username.toLowerCase().includes(searchTermLower) ||
                         email.toLowerCase().includes(searchTermLower) ||
                         fullName.toLowerCase().includes(searchTermLower);

    if (filterBy === 'all') return matchesSearch;
    if (filterBy === 'high_value') return matchesSearch && (user.totalInvestments || 0) > 20000;
    if (filterBy === 'new') return matchesSearch && user.registrationDate && new Date(user.registrationDate) > new Date('2024-01-01');

    return matchesSearch;
  });

  const sortedUsers = [...filteredUsers].sort((a, b) => {
    switch (sortBy) {
      case 'lastActive':
        return new Date(b.lastActive || 0) - new Date(a.lastActive || 0);
      case 'investments':
        return (b.totalInvestments || 0) - (a.totalInvestments || 0);
      case 'name':
        const nameA = a.fullName || '';
        const nameB = b.fullName || '';
        return nameA.localeCompare(nameB);
      default:
        return 0;
    }
  });

  const getStatusBadge = (status) => {
    const safeStatus = status && typeof status === 'string' ? status.toLowerCase() : 'active';

    const statusClasses = {
      active: 'bg-green-100 text-green-800 border-green-200',
      inactive: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      suspended: 'bg-red-100 text-red-800 border-red-200'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${statusClasses[safeStatus] || statusClasses.active}`}>
        {safeStatus.charAt(0).toUpperCase() + safeStatus.slice(1)}
      </span>
    );
  };

  const getRiskBadge = (level) => {
    const safeLevel = level && typeof level === 'string' ? level.toLowerCase() : 'medium';

    const riskClasses = {
      low: 'bg-green-100 text-green-800 border-green-200',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      high: 'bg-red-100 text-red-800 border-red-200'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${riskClasses[safeLevel] || riskClasses.medium}`}>
        {safeLevel.charAt(0).toUpperCase() + safeLevel.slice(1)}
      </span>
    );
  };

  const formatDateTime = (dateString) => {
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return 'Invalid Date';
      }
      return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    } catch (error) {
      return 'Invalid Date';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Active Users"
        breadcrumb={[
          { label: "User Management", link: "/admin-user-management" },
          { label: "Active Users" }
        ]}
        actions={[
          {
            label: "Export Data",
            icon: "Download",
            variant: "outline",
            onClick: () => {
              if (users.length === 0) {
                alert('No users to export');
                return;
              }
              const csvData = users.map(user => ({
                Username: user.username,
                Email: user.email,
                'Full Name': user.fullName,
                'Last Active': formatDateTime(user.lastActive),
                'Total Investments': user.totalInvestments,
                Location: user.location
              }));
              const csv = [
                Object.keys(csvData[0]).join(','),
                ...csvData.map(row => Object.values(row).join(','))
              ].join('\n');
              const blob = new Blob([csv], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `active_users_${new Date().toISOString().split('T')[0]}.csv`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }
          },
          {
            label: "Refresh",
            icon: "RefreshCw",
            variant: "outline",
            onClick: () => loadActiveUsers(false)
          }
        ]}
      />

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Active</p>
                <p className="text-2xl font-bold text-foreground">{users.length}</p>
              </div>
              <div className="h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center">
                <Icon name="Users" size={16} className="text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">High Value</p>
                <p className="text-2xl font-bold text-foreground">
                  {users.filter(u => (u.totalInvestments || 0) > 20000).length}
                </p>
              </div>
              <div className="h-8 w-8 bg-green-100 rounded-full flex items-center justify-center">
                <Icon name="TrendingUp" size={16} className="text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">New Today</p>
                <p className="text-2xl font-bold text-foreground">
                  {users.filter(u => {
                    const today = new Date().toDateString();
                    const userDate = new Date(u.registrationDate).toDateString();
                    return today === userDate;
                  }).length}
                </p>
              </div>
              <div className="h-8 w-8 bg-purple-100 rounded-full flex items-center justify-center">
                <Icon name="UserPlus" size={16} className="text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Value</p>
                <p className="text-2xl font-bold text-foreground">
                  ${users.reduce((sum, u) => sum + (u.totalInvestments || 0), 0).toLocaleString()}
                </p>
              </div>
              <div className="h-8 w-8 bg-orange-100 rounded-full flex items-center justify-center">
                <Icon name="DollarSign" size={16} className="text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-card border rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium mb-2">Search Users</label>
              <div className="relative">
                <Icon name="Search" size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search by name, email, or username..."
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Filter</label>
              <select
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                value={filterBy}
                onChange={(e) => setFilterBy(e.target.value)}
              >
                <option value="all">All Users</option>
                <option value="high_value">High Value ($20K+)</option>
                <option value="new">New Users</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Sort By</label>
              <select
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
              >
                <option value="lastActive">Last Active</option>
                <option value="investments">Investment Amount</option>
                <option value="name">Name</option>
              </select>
            </div>
          </div>
        </div>

        {/* Users Table */}
        <div className="bg-card border rounded-lg overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Icon name="Loader2" size={24} className="animate-spin text-muted-foreground" />
              <span className="ml-2 text-muted-foreground">Loading users...</span>
            </div>
          ) : sortedUsers.length === 0 ? (
            <div className="text-center py-12">
              <Icon name="Users" size={48} className="mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No active users found</h3>
              <p className="text-muted-foreground">
                {searchTerm || filterBy !== 'all' ? 'Try adjusting your search or filters' : 'No users have registered yet'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">User</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Last Active</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Investments</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Risk Level</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {sortedUsers.map((user, index) => (
                    <tr key={user.id || index} className="hover:bg-muted/50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-10 w-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white font-medium">
                            {(user.fullName || user.username || 'U').charAt(0).toUpperCase()}
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-foreground">{user.fullName || 'N/A'}</div>
                            <div className="text-sm text-muted-foreground">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(user.status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground">
                        {formatDateTime(user.lastActive)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground">
                        ${(user.totalInvestments || 0).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getRiskBadge(user.riskLevel)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUserAction(user.id, 'view')}
                            title="View Details"
                            className="text-blue-700 border-blue-300 hover:bg-blue-100"
                          >
                            <Icon name="Eye" size={14} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUserAction(user.id, 'edit')}
                            title="Edit User"
                            className="text-green-700 border-green-300 hover:bg-green-100"
                          >
                            <Icon name="Edit" size={14} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUserAction(user.id, 'suspend')}
                            title="Suspend User"
                            className="text-yellow-700 border-yellow-300 hover:bg-yellow-100"
                          >
                            <Icon name="Pause" size={14} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUserAction(user.id, 'delete')}
                            title="Delete User"
                            className="text-red-700 border-red-300 hover:bg-red-100"
                          >
                            <Icon name="Trash2" size={14} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminActiveUsers;
