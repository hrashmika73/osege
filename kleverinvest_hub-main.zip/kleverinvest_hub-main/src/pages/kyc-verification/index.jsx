import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

const KYCVerification = () => {
  const navigate = useNavigate();
  const { user, isUserAuthenticated, updateUser } = useUserAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    // Personal Information
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    nationality: '',
    
    // Address Information
    address: '',
    city: '',
    state: '',
    postalCode: '',
    country: '',
    
    // Identity Verification
    idType: 'passport',
    idNumber: '',
    idFrontImage: null,
    idBackImage: null,
    selfieImage: null,
    
    // Employment Information
    employment: '',
    income: '',
    sourceOfFunds: ''
  });
  
  const [errors, setErrors] = useState({});

  // Redirect if not authenticated
  useEffect(() => {
    if (!isUserAuthenticated) {
      navigate('/user-login');
    }
  }, [isUserAuthenticated, navigate]);

  // Redirect if already verified
  useEffect(() => {
    if (user?.kycStatus === 'verified') {
      navigate('/user-dashboard');
    }
  }, [user, navigate]);

  const handleInputChange = (e) => {
    const { name, value, type, files } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'file' ? files[0] : value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateStep = (step) => {
    const newErrors = {};
    
    switch (step) {
      case 1:
        if (!formData.firstName) newErrors.firstName = 'First name is required';
        if (!formData.lastName) newErrors.lastName = 'Last name is required';
        if (!formData.dateOfBirth) newErrors.dateOfBirth = 'Date of birth is required';
        if (!formData.nationality) newErrors.nationality = 'Nationality is required';
        break;
        
      case 2:
        if (!formData.address) newErrors.address = 'Address is required';
        if (!formData.city) newErrors.city = 'City is required';
        if (!formData.country) newErrors.country = 'Country is required';
        if (!formData.postalCode) newErrors.postalCode = 'Postal code is required';
        break;
        
      case 3:
        if (!formData.idNumber) newErrors.idNumber = 'ID number is required';
        if (!formData.idFrontImage) newErrors.idFrontImage = 'Front ID image is required';
        if (!formData.idBackImage) newErrors.idBackImage = 'Back ID image is required';
        if (!formData.selfieImage) newErrors.selfieImage = 'Selfie is required';
        break;
        
      case 4:
        if (!formData.employment) newErrors.employment = 'Employment status is required';
        if (!formData.income) newErrors.income = 'Income range is required';
        if (!formData.sourceOfFunds) newErrors.sourceOfFunds = 'Source of funds is required';
        break;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    setCurrentStep(prev => prev - 1);
  };

  const handleSubmit = async () => {
    if (!validateStep(4)) return;

    setIsLoading(true);

    try {
      // Simulate KYC submission
      await new Promise(resolve => setTimeout(resolve, 3000));

      // Update user with KYC pending status
      updateUser({
        kycStatus: 'pending',
        kycSubmittedAt: new Date().toISOString(),
        personalInfo: {
          firstName: formData.firstName,
          lastName: formData.lastName,
          dateOfBirth: formData.dateOfBirth,
          nationality: formData.nationality
        }
      });

      // Sync with admin KYC system
      try {
        // Update admin user data
        const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
        const userIndex = adminUsers.findIndex(u => u.userId === user.id || u.email === user.email);
        if (userIndex !== -1) {
          adminUsers[userIndex] = {
            ...adminUsers[userIndex],
            kycStatus: 'pending',
            kycSubmittedAt: new Date().toISOString(),
            fullName: `${formData.firstName} ${formData.lastName}`,
            lastActive: new Date().toISOString()
          };
          localStorage.setItem('admin_users_data', JSON.stringify(adminUsers));
        }

        // Update or create KYC request for admin review
        const kycRequests = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
        const existingRequestIndex = kycRequests.findIndex(r => r.userId === user.id || r.email === user.email);

        const kycRequestData = {
          id: existingRequestIndex !== -1 ? kycRequests[existingRequestIndex].id : Date.now(),
          userId: user.id,
          username: user.email?.split('@')[0] || 'unknown',
          email: user.email,
          fullName: `${formData.firstName} ${formData.lastName}`,
          submissionDate: new Date().toISOString(),
          status: 'pending',
          documentType: formData.idType,
          documentNumber: formData.idNumber,
          country: formData.country || formData.nationality,
          phoneNumber: user.phone || 'Not provided',
          address: `${formData.address}, ${formData.city}, ${formData.state} ${formData.postalCode}`,
          priority: 'medium',
          investmentAmount: 0,
          riskLevel: 'low',
          documentsSubmitted: [
            formData.idFrontImage ? 'ID Front' : null,
            formData.idBackImage ? 'ID Back' : null,
            formData.selfieImage ? 'Selfie' : null
          ].filter(Boolean),
          personalInfo: {
            firstName: formData.firstName,
            lastName: formData.lastName,
            dateOfBirth: formData.dateOfBirth,
            nationality: formData.nationality,
            employment: formData.employment,
            income: formData.income,
            sourceOfFunds: formData.sourceOfFunds
          }
        };

        if (existingRequestIndex !== -1) {
          kycRequests[existingRequestIndex] = kycRequestData;
        } else {
          kycRequests.push(kycRequestData);
        }

        localStorage.setItem('admin_pending_kyc', JSON.stringify(kycRequests));

        // KYC data synced with admin system

        // Update user record to reflect KYC submission
        try {
          const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
          const userIndex = adminUsers.findIndex(u => u.email === user?.email);

          if (userIndex !== -1) {
            adminUsers[userIndex] = {
              ...adminUsers[userIndex],
              kycStatus: 'pending_documents',
              verificationStatus: 'pending',
              lastActive: new Date().toISOString(),
              profileComplete: true,
              // Update personal info from KYC form
              firstName: formData.firstName,
              lastName: formData.lastName,
              dateOfBirth: formData.dateOfBirth,
              nationality: formData.nationality,
              address: `${formData.address}, ${formData.city}, ${formData.state} ${formData.postalCode}`,
              phone: user?.phone || 'Not provided',
              employment: formData.employment,
              income: formData.income
            };

            localStorage.setItem('admin_users_data', JSON.stringify(adminUsers));

            // Also update active users list
            const activeUsers = adminUsers.filter(u => u.status === 'active');
            localStorage.setItem('admin_active_users', JSON.stringify(activeUsers));

            // User record updated with KYC submission data
          }
        } catch (userUpdateError) {
          // Failed to update user record
        }

        // Additional sync through connection manager
        try {
          const { connectionManager } = await import('../../utils/connectionManager');
          await connectionManager.syncData('kyc_submit', kycRequestData);
          // KYC data synced through connection manager
        } catch (managerError) {
          // Connection manager KYC sync failed
        }

        // Trigger real-time update events
        window.dispatchEvent(new CustomEvent('kycSubmitted', {
          detail: {
            request: kycRequestData,
            timestamp: new Date().toISOString()
          }
        }));

      } catch (syncError) {
        // Failed to sync KYC data with admin system
      }

      // Show success message and redirect
      alert('KYC verification submitted successfully! We will review your documents within 24-48 hours.');
      navigate('/user-dashboard');

    } catch (error) {
      setErrors({ submit: 'Failed to submit KYC verification. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-foreground mb-2">Personal Information</h2>
        <p className="text-muted-foreground">Please provide your basic personal details</p>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">First Name</label>
          <Input
            name="firstName"
            value={formData.firstName}
            onChange={handleInputChange}
            placeholder="Enter your first name"
            className={errors.firstName ? 'border-red-500' : ''}
          />
          {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>}
        </div>
        
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Last Name</label>
          <Input
            name="lastName"
            value={formData.lastName}
            onChange={handleInputChange}
            placeholder="Enter your last name"
            className={errors.lastName ? 'border-red-500' : ''}
          />
          {errors.lastName && <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>}
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Date of Birth</label>
        <Input
          type="date"
          name="dateOfBirth"
          value={formData.dateOfBirth}
          onChange={handleInputChange}
          className={errors.dateOfBirth ? 'border-red-500' : ''}
        />
        {errors.dateOfBirth && <p className="text-red-500 text-sm mt-1">{errors.dateOfBirth}</p>}
      </div>
      
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Nationality</label>
        <select
          name="nationality"
          value={formData.nationality}
          onChange={handleInputChange}
          className={`w-full px-3 py-2 border rounded-md bg-background ${errors.nationality ? 'border-red-500' : 'border-border'}`}
        >
          <option value="">Select your nationality</option>
          <option value="US">United States</option>
          <option value="GB">United Kingdom</option>
          <option value="CA">Canada</option>
          <option value="AU">Australia</option>
          <option value="DE">Germany</option>
          <option value="FR">France</option>
          <option value="Other">Other</option>
        </select>
        {errors.nationality && <p className="text-red-500 text-sm mt-1">{errors.nationality}</p>}
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-foreground mb-2">Address Information</h2>
        <p className="text-muted-foreground">Please provide your current residential address</p>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Street Address</label>
        <Input
          name="address"
          value={formData.address}
          onChange={handleInputChange}
          placeholder="Enter your street address"
          className={errors.address ? 'border-red-500' : ''}
        />
        {errors.address && <p className="text-red-500 text-sm mt-1">{errors.address}</p>}
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">City</label>
          <Input
            name="city"
            value={formData.city}
            onChange={handleInputChange}
            placeholder="Enter your city"
            className={errors.city ? 'border-red-500' : ''}
          />
          {errors.city && <p className="text-red-500 text-sm mt-1">{errors.city}</p>}
        </div>
        
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">State/Province</label>
          <Input
            name="state"
            value={formData.state}
            onChange={handleInputChange}
            placeholder="Enter your state"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Postal Code</label>
          <Input
            name="postalCode"
            value={formData.postalCode}
            onChange={handleInputChange}
            placeholder="Enter postal code"
            className={errors.postalCode ? 'border-red-500' : ''}
          />
          {errors.postalCode && <p className="text-red-500 text-sm mt-1">{errors.postalCode}</p>}
        </div>
        
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Country</label>
          <select
            name="country"
            value={formData.country}
            onChange={handleInputChange}
            className={`w-full px-3 py-2 border rounded-md bg-background ${errors.country ? 'border-red-500' : 'border-border'}`}
          >
            <option value="">Select your country</option>
            <option value="US">United States</option>
            <option value="GB">United Kingdom</option>
            <option value="CA">Canada</option>
            <option value="AU">Australia</option>
            <option value="DE">Germany</option>
            <option value="FR">France</option>
            <option value="Other">Other</option>
          </select>
          {errors.country && <p className="text-red-500 text-sm mt-1">{errors.country}</p>}
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-foreground mb-2">Identity Verification</h2>
        <p className="text-muted-foreground">Please upload clear photos of your identity documents</p>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Document Type</label>
        <select
          name="idType"
          value={formData.idType}
          onChange={handleInputChange}
          className="w-full px-3 py-2 border rounded-md bg-background border-border"
        >
          <option value="passport">Passport</option>
          <option value="drivers_license">Driver's License</option>
          <option value="national_id">National ID Card</option>
        </select>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">ID Number</label>
        <Input
          name="idNumber"
          value={formData.idNumber}
          onChange={handleInputChange}
          placeholder="Enter your ID number"
          className={errors.idNumber ? 'border-red-500' : ''}
        />
        {errors.idNumber && <p className="text-red-500 text-sm mt-1">{errors.idNumber}</p>}
      </div>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Front of ID Document</label>
          <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
            <input
              type="file"
              name="idFrontImage"
              onChange={handleInputChange}
              accept="image/*"
              className="hidden"
              id="idFrontImage"
            />
            <label htmlFor="idFrontImage" className="cursor-pointer">
              <Icon name="Upload" size={32} className="mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">Click to upload front of ID</p>
              {formData.idFrontImage && <p className="text-sm text-primary mt-1">{formData.idFrontImage.name}</p>}
            </label>
          </div>
          {errors.idFrontImage && <p className="text-red-500 text-sm mt-1">{errors.idFrontImage}</p>}
        </div>
        
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Back of ID Document</label>
          <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
            <input
              type="file"
              name="idBackImage"
              onChange={handleInputChange}
              accept="image/*"
              className="hidden"
              id="idBackImage"
            />
            <label htmlFor="idBackImage" className="cursor-pointer">
              <Icon name="Upload" size={32} className="mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">Click to upload back of ID</p>
              {formData.idBackImage && <p className="text-sm text-primary mt-1">{formData.idBackImage.name}</p>}
            </label>
          </div>
          {errors.idBackImage && <p className="text-red-500 text-sm mt-1">{errors.idBackImage}</p>}
        </div>
        
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Selfie with ID</label>
          <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
            <input
              type="file"
              name="selfieImage"
              onChange={handleInputChange}
              accept="image/*"
              className="hidden"
              id="selfieImage"
            />
            <label htmlFor="selfieImage" className="cursor-pointer">
              <Icon name="Upload" size={32} className="mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">Click to upload selfie holding your ID</p>
              {formData.selfieImage && <p className="text-sm text-primary mt-1">{formData.selfieImage.name}</p>}
            </label>
          </div>
          {errors.selfieImage && <p className="text-red-500 text-sm mt-1">{errors.selfieImage}</p>}
        </div>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-foreground mb-2">Financial Information</h2>
        <p className="text-muted-foreground">Please provide information about your employment and finances</p>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Employment Status</label>
        <select
          name="employment"
          value={formData.employment}
          onChange={handleInputChange}
          className={`w-full px-3 py-2 border rounded-md bg-background ${errors.employment ? 'border-red-500' : 'border-border'}`}
        >
          <option value="">Select employment status</option>
          <option value="employed">Employed</option>
          <option value="self_employed">Self-Employed</option>
          <option value="unemployed">Unemployed</option>
          <option value="retired">Retired</option>
          <option value="student">Student</option>
        </select>
        {errors.employment && <p className="text-red-500 text-sm mt-1">{errors.employment}</p>}
      </div>
      
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Annual Income</label>
        <select
          name="income"
          value={formData.income}
          onChange={handleInputChange}
          className={`w-full px-3 py-2 border rounded-md bg-background ${errors.income ? 'border-red-500' : 'border-border'}`}
        >
          <option value="">Select income range</option>
          <option value="under_25k">Under $25,000</option>
          <option value="25k_50k">$25,000 - $50,000</option>
          <option value="50k_100k">$50,000 - $100,000</option>
          <option value="100k_250k">$100,000 - $250,000</option>
          <option value="250k_500k">$250,000 - $500,000</option>
          <option value="over_500k">Over $500,000</option>
        </select>
        {errors.income && <p className="text-red-500 text-sm mt-1">{errors.income}</p>}
      </div>
      
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Source of Funds</label>
        <select
          name="sourceOfFunds"
          value={formData.sourceOfFunds}
          onChange={handleInputChange}
          className={`w-full px-3 py-2 border rounded-md bg-background ${errors.sourceOfFunds ? 'border-red-500' : 'border-border'}`}
        >
          <option value="">Select source of funds</option>
          <option value="salary">Salary/Wages</option>
          <option value="business">Business Income</option>
          <option value="investments">Investment Returns</option>
          <option value="inheritance">Inheritance</option>
          <option value="savings">Personal Savings</option>
          <option value="other">Other</option>
        </select>
        {errors.sourceOfFunds && <p className="text-red-500 text-sm mt-1">{errors.sourceOfFunds}</p>}
      </div>
    </div>
  );

  if (!isUserAuthenticated) {
    return null;
  }

  return (
    <>
      <Helmet>
        <title>KYC Verification - KleverInvest Hub</title>
        <meta name="description" content="Complete your KYC verification to access full platform features" />
      </Helmet>

      <div className="min-h-screen bg-background py-8">
        <div className="container mx-auto px-4 max-w-2xl">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">KYC Verification</h1>
            <p className="text-muted-foreground">
              Complete your verification to access all platform features and start investing
            </p>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Step {currentStep} of 4</span>
              <span className="text-sm text-muted-foreground">{Math.round((currentStep / 4) * 100)}% Complete</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-primary rounded-full h-2 transition-all duration-300" 
                style={{ width: `${(currentStep / 4) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Steps */}
          <div className="bg-card border rounded-lg p-6 mb-6">
            {currentStep === 1 && renderStep1()}
            {currentStep === 2 && renderStep2()}
            {currentStep === 3 && renderStep3()}
            {currentStep === 4 && renderStep4()}
          </div>

          {/* Navigation */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 1}
            >
              <Icon name="ArrowLeft" size={16} className="mr-2" />
              Back
            </Button>

            {currentStep < 4 ? (
              <Button onClick={handleNext}>
                Next
                <Icon name="ArrowRight" size={16} className="ml-2" />
              </Button>
            ) : (
              <Button 
                onClick={handleSubmit} 
                disabled={isLoading}
                className="bg-primary text-primary-foreground"
              >
                {isLoading ? (
                  <>
                    <Icon name="Loader" size={16} className="mr-2 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    Submit KYC
                    <Icon name="Check" size={16} className="ml-2" />
                  </>
                )}
              </Button>
            )}
          </div>

          {errors.submit && (
            <p className="text-red-500 text-sm mt-4 text-center">{errors.submit}</p>
          )}
        </div>
      </div>
    </>
  );
};

export default KYCVerification;
