import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminBanDetails = () => {
  const navigate = useNavigate();
  const { userId } = useParams();
  const { isAdminAuthenticated } = useAdminAuth();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadUserDetails();
  }, [isAdminAuthenticated, navigate, userId]);

  const loadUserDetails = () => {
    setLoading(true);
    // Load user details from localStorage
    setTimeout(() => {
      const storedUsers = JSON.parse(localStorage.getItem('admin_banned_users') || '[]');
      const foundUser = storedUsers.find(u => u.id === parseInt(userId));
      setUser(foundUser);
      setLoading(false);
    }, 500);
  };

  const handleAction = async (action) => {
    if (!user) return;
    
    setActionLoading(true);
    
    try {
      switch (action) {
        case 'unban':
          if (window.confirm(`Are you sure you want to unban ${user.username}?`)) {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1000));
            alert(`User ${user.username} has been unbanned successfully`);
            navigate('/admin-banned-users');
          }
          break;
        case 'permanent':
          if (window.confirm(`Are you sure you want to permanently ban ${user.username}? This action cannot be undone.`)) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            setUser(prev => ({ ...prev, banType: 'permanent' }));
            alert(`User ${user.username} has been permanently banned`);
          }
          break;
        case 'approve_appeal':
          if (window.confirm(`Are you sure you want to approve the appeal for ${user.username}?`)) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            setUser(prev => ({ ...prev, appealStatus: 'approved' }));
            alert(`Appeal approved. User ${user.username} will be unbanned.`);
          }
          break;
        case 'reject_appeal':
          if (window.confirm(`Are you sure you want to reject the appeal for ${user.username}?`)) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            setUser(prev => ({ ...prev, appealStatus: 'rejected' }));
            alert(`Appeal rejected for user ${user.username}.`);
          }
          break;
        case 'extend_ban':
          const days = prompt('Enter number of days to extend the ban:');
          if (days && parseInt(days) > 0) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            alert(`Ban extended by ${days} days for user ${user.username}.`);
          }
          break;
        default:
          break;
      }
    } catch (error) {
      alert('Action failed. Please try again.');
    } finally {
      setActionLoading(false);
    }
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const getBanTypeBadge = (type) => {
    const typeClasses = {
      temporary: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      permanent: 'bg-red-100 text-red-800 border-red-200'
    };

    return (
      <span className={`px-3 py-1 rounded-full text-sm font-medium border ${typeClasses[type] || typeClasses.temporary}`}>
        {type.charAt(0).toUpperCase() + type.slice(1)}
      </span>
    );
  };

  const getViolationBadge = (type) => {
    const typeClasses = {
      fraud: 'bg-red-100 text-red-800 border-red-200',
      policy: 'bg-orange-100 text-orange-800 border-orange-200',
      spam: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      other: 'bg-gray-100 text-gray-800 border-gray-200'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${typeClasses[type] || typeClasses.other}`}>
        {type.charAt(0).toUpperCase() + type.slice(1)}
      </span>
    );
  };

  const getAppealBadge = (status) => {
    const statusClasses = {
      pending: 'bg-blue-100 text-blue-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      none: 'bg-gray-100 text-gray-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusClasses[status] || statusClasses.none}`}>
        {status === 'none' ? 'No Appeal' : status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  const getRiskScoreColor = (score) => {
    if (score >= 80) return 'text-red-600';
    if (score >= 60) return 'text-orange-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-green-600';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <AdminNavigation
          title="Ban Details"
          breadcrumb={[
            { label: "User Management", link: "/admin-user-management" },
            { label: "Banned Users", link: "/admin-banned-users" },
            { label: "Ban Details" }
          ]}
        />
        <div className="p-6">
          <div className="flex items-center justify-center py-12">
            <Icon name="Loader2" size={32} className="animate-spin text-primary mr-3" />
            <span className="text-lg">Loading ban details...</span>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <AdminNavigation
          title="Ban Details"
          breadcrumb={[
            { label: "User Management", link: "/admin-user-management" },
            { label: "Banned Users", link: "/admin-banned-users" },
            { label: "Ban Details" }
          ]}
        />
        <div className="p-6">
          <div className="text-center py-12">
            <Icon name="AlertTriangle" size={48} className="text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-foreground mb-2">User Not Found</h2>
            <p className="text-muted-foreground mb-6">The banned user you're looking for doesn't exist.</p>
            <Button onClick={() => navigate('/admin-banned-users')}>
              <Icon name="ArrowLeft" size={16} className="mr-2" />
              Back to Banned Users
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title={`Ban Details - ${user.fullName}`}
        breadcrumb={[
          { label: "User Management", link: "/admin-user-management" },
          { label: "Banned Users", link: "/admin-banned-users" },
          { label: user.fullName }
        ]}
        actions={[
          {
            label: "Back to List",
            icon: "ArrowLeft",
            variant: "outline",
            onClick: () => navigate('/admin-banned-users')
          }
        ]}
      />

      <div className="p-6 space-y-6">
        {/* User Overview Card */}
        <div className="bg-card border rounded-lg p-6">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                <Icon name="Ban" size={24} className="text-red-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">{user.fullName}</h1>
                <p className="text-muted-foreground">@{user.username}</p>
                <p className="text-sm text-muted-foreground">{user.email}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {getBanTypeBadge(user.banType)}
              {getViolationBadge(user.violationType)}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Ban Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Ban Date:</span>
                  <span className="text-sm font-medium">{formatDateTime(user.banDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Banned By:</span>
                  <span className="text-sm font-medium">{user.bannedBy}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Risk Score:</span>
                  <span className={`text-sm font-bold ${getRiskScoreColor(user.riskScore)}`}>
                    {user.riskScore}/100
                  </span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Account Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Registration:</span>
                  <span className="text-sm font-medium">{formatDateTime(user.originalRegistration)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Last Login:</span>
                  <span className="text-sm font-medium">{formatDateTime(user.lastLoginBeforeBan)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Verification:</span>
                  <span className="text-sm font-medium capitalize">{user.verificationStatus}</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Financial Overview</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Balance:</span>
                  <span className="text-sm font-medium">{formatCurrency(user.accountBalance)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Total Invested:</span>
                  <span className="text-sm font-medium">{formatCurrency(user.totalInvestments)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Active Investments:</span>
                  <span className="text-sm font-medium">{user.activeInvestments}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Ban Reason and Appeal Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-card border rounded-lg p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">Ban Reason</h2>
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-sm text-red-800">{user.banReason}</p>
            </div>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Previous Warnings:</span>
                <span className="text-sm font-medium">{user.previousWarnings}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Country:</span>
                <span className="text-sm font-medium">{user.registrationCountry}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">IP Address:</span>
                <span className="text-sm font-mono">{user.ipAddress}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Device:</span>
                <span className="text-sm font-medium">{user.deviceInfo}</span>
              </div>
            </div>
          </div>

          <div className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-foreground">Appeal Status</h2>
              {getAppealBadge(user.appealStatus)}
            </div>
            
            {user.appealStatus !== 'none' ? (
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Appeal Date:</label>
                  <p className="text-sm text-foreground">{formatDateTime(user.appealDate)}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Appeal Reason:</label>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-1">
                    <p className="text-sm text-blue-800">{user.appealReason}</p>
                  </div>
                </div>
                
                {user.appealStatus === 'pending' && (
                  <div className="flex space-x-2 pt-2">
                    <Button
                      size="sm"
                      onClick={() => handleAction('approve_appeal')}
                      disabled={actionLoading}
                      className="bg-green-600 hover:bg-green-700 text-white"
                    >
                      <Icon name="Check" size={16} className="mr-1" />
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleAction('reject_appeal')}
                      disabled={actionLoading}
                      className="text-red-600 border-red-200 hover:bg-red-50"
                    >
                      <Icon name="X" size={16} className="mr-1" />
                      Reject
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-6">
                <Icon name="Clock" size={32} className="text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">No appeal submitted</p>
              </div>
            )}
          </div>
        </div>

        {/* Violation History */}
        <div className="bg-card border rounded-lg p-6">
          <h2 className="text-lg font-semibold text-foreground mb-4">Violation History</h2>
          <div className="space-y-3">
            {user.violationHistory.map((violation, index) => (
              <div key={index} className="border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground capitalize">
                    {violation.type.replace('_', ' ')}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {formatDateTime(violation.date)}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">{violation.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="bg-card border rounded-lg p-6">
          <h2 className="text-lg font-semibold text-foreground mb-4">Admin Actions</h2>
          <div className="flex flex-wrap gap-3">
            {user.banType === 'temporary' && (
              <>
                <Button
                  onClick={() => handleAction('unban')}
                  disabled={actionLoading}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <Icon name="UserCheck" size={16} className="mr-2" />
                  Unban User
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleAction('permanent')}
                  disabled={actionLoading}
                  className="text-red-600 border-red-200 hover:bg-red-50"
                >
                  <Icon name="Ban" size={16} className="mr-2" />
                  Make Permanent
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleAction('extend_ban')}
                  disabled={actionLoading}
                  className="text-orange-600 border-orange-200 hover:bg-orange-50"
                >
                  <Icon name="Clock" size={16} className="mr-2" />
                  Extend Ban
                </Button>
              </>
            )}
            
            {user.banType === 'permanent' && (
              <Button
                onClick={() => handleAction('unban')}
                disabled={actionLoading}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <Icon name="UserCheck" size={16} className="mr-2" />
                Unban User
              </Button>
            )}
            
            <Button
              variant="outline"
              onClick={() => navigate(`/admin-user-details/${user.id}`)}
              className="text-blue-600 border-blue-200 hover:bg-blue-50"
            >
              <Icon name="User" size={16} className="mr-2" />
              View Full Profile
            </Button>
            
            <Button
              variant="outline"
              onClick={() => navigate(`/admin-send-message/${user.id}`)}
              className="text-purple-600 border-purple-200 hover:bg-purple-50"
            >
              <Icon name="MessageSquare" size={16} className="mr-2" />
              Send Message
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminBanDetails;
