import React from 'react';
import { useNavigate } from 'react-router-dom';
import AdminNavigation from '../../components/ui/AdminNavigation';
import BackendConnectionDisplay from '../../components/BackendConnectionDisplay';
import BackendIntegrationDemo from '../../components/BackendIntegrationDemo';
import AdminApiTester from '../../components/AdminApiTester';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const BackendIntegrationTestPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation />
      
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Backend Integration Test</h1>
            <p className="text-muted-foreground">
              Test and verify the connection between admin frontend and backend API
            </p>
          </div>
          <Button
            onClick={() => navigate('/admin-dashboard')}
            variant="outline"
          >
            <Icon name="ArrowLeft" size={16} className="mr-2" />
            Back to Dashboard
          </Button>
        </div>

        {/* Connection Status */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <BackendConnectionDisplay />
          </div>
          
          <div className="lg:col-span-2">
            <div className="bg-card border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Backend Setup Instructions</h3>
              
              <div className="space-y-4 text-sm">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-900 mb-2">Environment Configuration</h4>
                  <div className="space-y-2 text-blue-800">
                    <div className="font-mono bg-blue-100 px-2 py-1 rounded">
                      VITE_ENABLE_BACKEND=true
                    </div>
                    <div className="font-mono bg-blue-100 px-2 py-1 rounded">
                      VITE_API_URL=http://localhost:3001/api
                    </div>
                    <p className="text-xs mt-2">Add these to your .env file to enable backend connection</p>
                  </div>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h4 className="font-semibold text-green-900 mb-2">Backend Server Setup</h4>
                  <div className="space-y-1 text-green-800">
                    <div>1. Ensure your backend server is running on the configured port</div>
                    <div>2. Verify API endpoints are accessible at /api/admin/*</div>
                    <div>3. Check CORS settings allow frontend domain</div>
                    <div>4. Confirm authentication endpoints are working</div>
                  </div>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <h4 className="font-semibold text-yellow-900 mb-2">Current Status</h4>
                  <div className="space-y-1 text-yellow-800">
                    <div>Backend Enabled: {import.meta.env.VITE_ENABLE_BACKEND === 'true' ? '✅ Yes' : '❌ No'}</div>
                    <div>API URL: {import.meta.env.VITE_API_URL || 'http://localhost:3001/api'}</div>
                    <div>Mode: {import.meta.env.VITE_ENABLE_BACKEND === 'true' ? 'Live API' : 'Mock Data'}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Integration Demo */}
        <BackendIntegrationDemo />

        {/* Comprehensive API Testing Suite */}
        <AdminApiTester />

        {/* API Endpoints Documentation */}
        <div className="bg-card border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Required API Endpoints</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-foreground mb-3">Authentication Endpoints</h4>
              <div className="space-y-2 text-sm font-mono">
                <div className="bg-muted/50 p-2 rounded">POST /api/admin/auth/login</div>
                <div className="bg-muted/50 p-2 rounded">POST /api/admin/auth/logout</div>
                <div className="bg-muted/50 p-2 rounded">POST /api/admin/auth/verify</div>
                <div className="bg-muted/50 p-2 rounded">GET /api/admin/auth/profile</div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-foreground mb-3">User Management Endpoints</h4>
              <div className="space-y-2 text-sm font-mono">
                <div className="bg-muted/50 p-2 rounded">GET /api/admin/users</div>
                <div className="bg-muted/50 p-2 rounded">GET /api/admin/users/:id</div>
                <div className="bg-muted/50 p-2 rounded">PUT /api/admin/users/:id</div>
                <div className="bg-muted/50 p-2 rounded">GET /api/admin/users/stats</div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-foreground mb-3">System Endpoints</h4>
              <div className="space-y-2 text-sm font-mono">
                <div className="bg-muted/50 p-2 rounded">GET /api/admin/system/health</div>
                <div className="bg-muted/50 p-2 rounded">GET /api/admin/system/metrics</div>
                <div className="bg-muted/50 p-2 rounded">GET /api/admin/system/logs</div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-foreground mb-3">Transaction Endpoints</h4>
              <div className="space-y-2 text-sm font-mono">
                <div className="bg-muted/50 p-2 rounded">GET /api/admin/transactions</div>
                <div className="bg-muted/50 p-2 rounded">PUT /api/admin/transactions/:id</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BackendIntegrationTestPage;
