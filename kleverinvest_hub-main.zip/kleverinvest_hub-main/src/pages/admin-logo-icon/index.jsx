import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminLogoIcon = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [settings, setSettings] = useState({
    logoUrl: '',
    logoAlt: 'KleverInvest Hub',
    logoWidth: '150',
    logoHeight: '40',
    faviconUrl: '',
    appIconUrl: '',
    darkLogoUrl: '',
    mobileLogoUrl: '',
    emailLogoUrl: '',
    watermarkUrl: '',
    showLogo: true,
    showCompanyName: true
  });
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadLogoSettings();
  }, [isAdminAuthenticated, navigate]);

  const loadLogoSettings = () => {
    const savedSettings = localStorage.getItem('admin_logo_settings');
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
  };

  const handleSaveSettings = () => {
    setSaving(true);
    localStorage.setItem('admin_logo_settings', JSON.stringify(settings));
    
    // Apply logo changes to document
    applyLogoChanges(settings);
    
    setTimeout(() => {
      setSaving(false);
      alert('Logo & Icon settings saved successfully!');
    }, 1000);
  };

  const applyLogoChanges = (logoSettings) => {
    // Update favicon
    if (logoSettings.faviconUrl) {
      const favicon = document.querySelector('link[rel="icon"]') || document.createElement('link');
      favicon.rel = 'icon';
      favicon.href = logoSettings.faviconUrl;
      if (!document.querySelector('link[rel="icon"]')) {
        document.head.appendChild(favicon);
      }
    }

    // Dispatch custom event for logo updates
    window.dispatchEvent(new CustomEvent('logoUpdated', { detail: logoSettings }));
  };

  const handleFileUpload = (type) => {
    setUploading(true);
    // Simulate file upload
    setTimeout(() => {
      const mockUrl = `https://via.placeholder.com/150x40/3b82f6/ffffff?text=${type.toUpperCase()}`;
      setSettings({...settings, [`${type}Url`]: mockUrl});
      setUploading(false);
      alert(`${type} uploaded successfully! (Mock URL generated)`);
    }, 2000);
  };

  const removeImage = (type) => {
    if (window.confirm(`Are you sure you want to remove the ${type}?`)) {
      setSettings({...settings, [`${type}Url`]: ''});
    }
  };

  const resetToDefaults = () => {
    if (window.confirm('Reset all logo and icon settings to defaults?')) {
      setSettings({
        logoUrl: '',
        logoAlt: 'KleverInvest Hub',
        logoWidth: '150',
        logoHeight: '40',
        faviconUrl: '',
        appIconUrl: '',
        darkLogoUrl: '',
        mobileLogoUrl: '',
        emailLogoUrl: '',
        watermarkUrl: '',
        showLogo: true,
        showCompanyName: true
      });
    }
  };

  const ImageUploadCard = ({ title, description, type, currentUrl }) => (
    <div className="bg-card border rounded-lg p-6">
      <h4 className="text-md font-semibold text-foreground mb-2">{title}</h4>
      <p className="text-sm text-muted-foreground mb-4">{description}</p>
      
      {currentUrl ? (
        <div className="space-y-3">
          <div className="border border-border rounded-lg p-4 bg-muted/30">
            <img
              src={currentUrl}
              alt={title}
              className="max-h-16 max-w-full object-contain mx-auto"
              onError={(e) => {
                e.target.style.display = 'none';
              }}
            />
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleFileUpload(type)}
              disabled={uploading}
              className="flex-1"
            >
              {uploading ? <Icon name="Loader" size={16} className="animate-spin mr-2" /> : <Icon name="Upload" size={16} className="mr-2" />}
              Replace
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => removeImage(type)}
              className="text-red-600 border-red-200 hover:bg-red-50"
            >
              <Icon name="Trash2" size={16} />
            </Button>
          </div>
        </div>
      ) : (
        <Button
          variant="outline"
          onClick={() => handleFileUpload(type)}
          disabled={uploading}
          className="w-full"
        >
          {uploading ? <Icon name="Loader" size={16} className="animate-spin mr-2" /> : <Icon name="Upload" size={16} className="mr-2" />}
          Upload {title}
        </Button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Logo & Icon Management"
        breadcrumb={[
          { label: "Theme Settings", link: "/admin-theme-settings" },
          { label: "Logo & Icon" }
        ]}
        actions={[
          {
            label: "Reset to Defaults",
            icon: "RotateCcw",
            variant: "outline",
            onClick: resetToDefaults
          },
          {
            label: saving ? "Saving..." : "Save Settings",
            icon: saving ? "Loader" : "Save",
            variant: "default",
            onClick: handleSaveSettings,
            disabled: saving
          }
        ]}
      />

      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Logo Settings */}
          <div className="space-y-6">
            <div className="bg-card border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
                <Icon name="Image" size={20} className="mr-2" />
                Main Logo Settings
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Logo Alt Text</label>
                  <input
                    type="text"
                    value={settings.logoAlt}
                    onChange={(e) => setSettings({...settings, logoAlt: e.target.value})}
                    placeholder="KleverInvest Hub"
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">Width (px)</label>
                    <input
                      type="number"
                      value={settings.logoWidth}
                      onChange={(e) => setSettings({...settings, logoWidth: e.target.value})}
                      placeholder="150"
                      className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">Height (px)</label>
                    <input
                      type="number"
                      value={settings.logoHeight}
                      onChange={(e) => setSettings({...settings, logoHeight: e.target.value})}
                      placeholder="40"
                      className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-foreground">Show Logo</label>
                    <button
                      onClick={() => setSettings({...settings, showLogo: !settings.showLogo})}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.showLogo ? 'bg-primary' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.showLogo ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-foreground">Show Company Name</label>
                    <button
                      onClick={() => setSettings({...settings, showCompanyName: !settings.showCompanyName})}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.showCompanyName ? 'bg-primary' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.showCompanyName ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <ImageUploadCard
              title="Main Logo"
              description="Primary logo displayed in the header and main areas"
              type="logo"
              currentUrl={settings.logoUrl}
            />

            <ImageUploadCard
              title="Dark Mode Logo"
              description="Logo version for dark theme (optional)"
              type="darkLogo"
              currentUrl={settings.darkLogoUrl}
            />
          </div>

          {/* Icons & Alternative Logos */}
          <div className="space-y-6">
            <ImageUploadCard
              title="Favicon"
              description="Small icon displayed in browser tabs (16x16 or 32x32px)"
              type="favicon"
              currentUrl={settings.faviconUrl}
            />

            <ImageUploadCard
              title="App Icon"
              description="Icon for mobile app and PWA (512x512px recommended)"
              type="appIcon"
              currentUrl={settings.appIconUrl}
            />

            <ImageUploadCard
              title="Mobile Logo"
              description="Compact logo for mobile devices"
              type="mobileLogo"
              currentUrl={settings.mobileLogoUrl}
            />

            <ImageUploadCard
              title="Email Logo"
              description="Logo for email templates"
              type="emailLogo"
              currentUrl={settings.emailLogoUrl}
            />

            <ImageUploadCard
              title="Watermark"
              description="Semi-transparent logo for backgrounds"
              type="watermark"
              currentUrl={settings.watermarkUrl}
            />
          </div>
        </div>

        {/* Logo Guidelines */}
        <div className="mt-8 bg-card border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
            <Icon name="Info" size={20} className="mr-2" />
            Logo Guidelines
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
            <div>
              <h4 className="font-semibold text-foreground mb-2">Recommended Formats</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• SVG for best scalability</li>
                <li>• PNG for transparency</li>
                <li>• JPG for photographs</li>
                <li>• WebP for modern browsers</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-2">Size Recommendations</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Main Logo: 150x40px to 300x80px</li>
                <li>• Favicon: 16x16px, 32x32px</li>
                <li>• App Icon: 512x512px</li>
                <li>• Mobile Logo: 120x32px</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-2">Best Practices</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Use high contrast for readability</li>
                <li>• Test on different backgrounds</li>
                <li>• Optimize file sizes for web</li>
                <li>• Maintain aspect ratios</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-2">Dark Mode</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Provide light version for dark themes</li>
                <li>• Test visibility on dark backgrounds</li>
                <li>• Consider outline versions</li>
                <li>• Ensure accessibility compliance</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminLogoIcon;
