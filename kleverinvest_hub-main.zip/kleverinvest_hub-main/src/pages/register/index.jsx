import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import { Checkbox } from '../../components/ui/Checkbox';

const RegisterPage = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1); // 1: basic info, 2: investment profile, 3: verification
  const [formData, setFormData] = useState({
    // Basic Info
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    dateOfBirth: '',
    
    // Investment Profile
    investmentExperience: '',
    riskTolerance: '',
    initialInvestment: '',
    investmentGoals: '',
    
    // Verification
    agreeTerms: false,
    agreePrivacy: false,
    agreeMarketing: false,
    verificationCode: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateStep1 = () => {
    const newErrors = {};
    
    if (!formData.firstName.trim()) newErrors.firstName = 'First name is required';
    if (!formData.lastName.trim()) newErrors.lastName = 'Last name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Email is invalid';
    if (!formData.password) newErrors.password = 'Password is required';
    if (formData.password.length < 8) newErrors.password = 'Password must be at least 8 characters';
    if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords do not match';
    if (!formData.phone.trim()) newErrors.phone = 'Phone number is required';
    if (!formData.dateOfBirth) newErrors.dateOfBirth = 'Date of birth is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors = {};
    
    if (!formData.investmentExperience) newErrors.investmentExperience = 'Investment experience is required';
    if (!formData.riskTolerance) newErrors.riskTolerance = 'Risk tolerance is required';
    if (!formData.initialInvestment) newErrors.initialInvestment = 'Initial investment amount is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep3 = () => {
    const newErrors = {};
    
    if (!formData.agreeTerms) newErrors.agreeTerms = 'You must agree to the terms and conditions';
    if (!formData.agreePrivacy) newErrors.agreePrivacy = 'You must agree to the privacy policy';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = async () => {
    if (step === 1 && !validateStep1()) return;
    if (step === 2 && !validateStep2()) return;
    if (step === 3 && !validateStep3()) return;
    
    if (step < 3) {
      setStep(step + 1);
    } else {
      // Final registration
      setIsLoading(true);

      try {
        // Simulate registration delay
        await new Promise(resolve => setTimeout(resolve, 2000));

        // Create user data
        const userId = `user_${Date.now()}`;
        const newUser = {
          id: userId,
          name: `${formData.firstName} ${formData.lastName}`,
          email: formData.email,
          phone: formData.phone,
          dateOfBirth: formData.dateOfBirth,
          verified: false,
          memberSince: new Date().toISOString().split('T')[0],
          balance: 0,
          wallet: null,
          referralCode: 'REF' + Date.now().toString().slice(-6),
          kycStatus: 'pending_documents',
          investmentProfile: {
            experience: formData.investmentExperience,
            riskTolerance: formData.riskTolerance,
            initialInvestment: formData.initialInvestment,
            goals: formData.investmentGoals
          }
        };

        // Store user session data
        localStorage.setItem('userToken', 'temp_token_' + Date.now());
        localStorage.setItem('userData', JSON.stringify(newUser));

        // Sync with admin user management system
        const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
        const adminUserData = {
          id: parseInt(userId.replace('user_', '')),
          userId: userId,
          username: formData.email.split('@')[0],
          email: formData.email,
          fullName: `${formData.firstName} ${formData.lastName}`,
          status: 'active',
          lastActive: new Date().toISOString(),
          registrationDate: new Date().toISOString(),
          totalInvestments: 0,
          balance: 0,
          kycStatus: 'pending_documents',
          location: 'Unknown',
          riskLevel: formData.riskTolerance || 'low',
          phone: formData.phone,
          dateOfBirth: formData.dateOfBirth,
          investmentProfile: {
            experience: formData.investmentExperience,
            riskTolerance: formData.riskTolerance,
            initialInvestment: formData.initialInvestment,
            goals: formData.investmentGoals
          }
        };
        adminUsers.push(adminUserData);
        localStorage.setItem('admin_users_data', JSON.stringify(adminUsers));

        // Create KYC request for admin
        const kycRequests = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
        const kycRequest = {
          id: Date.now(),
          userId: userId,
          username: formData.email.split('@')[0],
          email: formData.email,
          fullName: `${formData.firstName} ${formData.lastName}`,
          submissionDate: new Date().toISOString(),
          status: 'pending_documents',
          documentType: 'pending',
          documentNumber: 'PENDING',
          country: 'Unknown',
          phoneNumber: formData.phone || 'Not provided',
          address: 'Not provided',
          priority: 'medium',
          investmentAmount: parseInt(formData.initialInvestment || '0'),
          riskLevel: formData.riskTolerance || 'low',
          documentsSubmitted: [],
          personalInfo: {
            firstName: formData.firstName,
            lastName: formData.lastName,
            dateOfBirth: formData.dateOfBirth,
            phone: formData.phone
          }
        };
        kycRequests.push(kycRequest);
        localStorage.setItem('admin_pending_kyc', JSON.stringify(kycRequests));

        console.log('✅ User registration completed and synced with admin system');

        // Dispatch custom event for real-time admin updates
        try {
          window.dispatchEvent(new CustomEvent('userRegistered', {
            detail: { user: adminUserData, timestamp: new Date().toISOString() }
          }));
          console.log('📢 User registration event dispatched');
        } catch (eventError) {
          console.warn('Event dispatch failed:', eventError);
        }

        // Sync with connection manager for backend/frontend consistency
        try {
          const { connectionManager } = await import('../../utils/connectionManager');
          await connectionManager.syncData('user_register', adminUserData);
          console.log('✅ User registration synced through connection manager');
        } catch (syncError) {
          console.warn('Connection manager sync failed:', syncError);
        }

        setIsLoading(false);
        navigate(`/email-verification?email=${encodeURIComponent(formData.email)}`);

      } catch (error) {
        console.error('Registration error:', error);
        setErrors({ submit: 'Registration failed. Please try again.' });
        setIsLoading(false);
      }
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground mb-2">Personal Information</h2>
        <p className="text-muted-foreground">Tell us about yourself to get started</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="First Name"
          name="firstName"
          value={formData.firstName}
          onChange={handleChange}
          placeholder="Enter your first name"
          required
          error={errors.firstName}
        />
        <Input
          label="Last Name"
          name="lastName"
          value={formData.lastName}
          onChange={handleChange}
          placeholder="Enter your last name"
          required
          error={errors.lastName}
        />
      </div>

      <Input
        label="Email Address"
        type="email"
        name="email"
        value={formData.email}
        onChange={handleChange}
        placeholder="Enter your email address"
        required
        error={errors.email}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <Input
            label="Password"
            type={showPassword ? 'text' : 'password'}
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Create a password"
            required
            error={errors.password}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-9 text-muted-foreground hover:text-foreground"
          >
            <Icon name={showPassword ? 'EyeOff' : 'Eye'} size={20} />
          </button>
        </div>
        
        <Input
          label="Confirm Password"
          type="password"
          name="confirmPassword"
          value={formData.confirmPassword}
          onChange={handleChange}
          placeholder="Confirm your password"
          required
          error={errors.confirmPassword}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Phone Number"
          type="tel"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          placeholder="+1 (555) 000-0000"
          required
          error={errors.phone}
        />
        
        <Input
          label="Date of Birth"
          type="date"
          name="dateOfBirth"
          value={formData.dateOfBirth}
          onChange={handleChange}
          required
          error={errors.dateOfBirth}
        />
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground mb-2">Investment Profile</h2>
        <p className="text-muted-foreground">Help us understand your investment preferences</p>
      </div>

      <Select
        label="Investment Experience"
        name="investmentExperience"
        value={formData.investmentExperience}
        onChange={handleChange}
        required
        error={errors.investmentExperience}
      >
        <option value="">Select your experience level</option>
        <option value="beginner">Beginner (0-1 years)</option>
        <option value="intermediate">Intermediate (1-5 years)</option>
        <option value="advanced">Advanced (5+ years)</option>
        <option value="expert">Expert (10+ years)</option>
      </Select>

      <Select
        label="Risk Tolerance"
        name="riskTolerance"
        value={formData.riskTolerance}
        onChange={handleChange}
        required
        error={errors.riskTolerance}
      >
        <option value="">Select your risk tolerance</option>
        <option value="conservative">Conservative - Prefer stable, low-risk investments</option>
        <option value="moderate">Moderate - Balanced risk and return</option>
        <option value="aggressive">Aggressive - Higher risk for higher potential returns</option>
        <option value="very-aggressive">Very Aggressive - Maximum risk for maximum returns</option>
      </Select>

      <Select
        label="Initial Investment Amount"
        name="initialInvestment"
        value={formData.initialInvestment}
        onChange={handleChange}
        required
        error={errors.initialInvestment}
      >
        <option value="">Select initial investment amount</option>
        <option value="1000-5000">$1,000 - $5,000</option>
        <option value="5000-10000">$5,000 - $10,000</option>
        <option value="10000-25000">$10,000 - $25,000</option>
        <option value="25000-50000">$25,000 - $50,000</option>
        <option value="50000-100000">$50,000 - $100,000</option>
        <option value="100000+">$100,000+</option>
      </Select>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Investment Goals
        </label>
        <textarea
          name="investmentGoals"
          value={formData.investmentGoals}
          onChange={handleChange}
          rows={4}
          className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          placeholder="Describe your investment goals and objectives..."
        />
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground mb-2">Terms & Verification</h2>
        <p className="text-muted-foreground">Review and accept our terms to complete registration</p>
      </div>

      <div className="bg-muted/30 border rounded-lg p-6 space-y-4">
        <Checkbox
          name="agreeTerms"
          checked={formData.agreeTerms}
          onChange={handleChange}
          label={
            <span>
              I agree to the{' '}
              <Link to="/terms" className="text-primary hover:text-primary/80 font-medium">
                Terms and Conditions
              </Link>
            </span>
          }
          error={errors.agreeTerms}
        />
        
        <Checkbox
          name="agreePrivacy"
          checked={formData.agreePrivacy}
          onChange={handleChange}
          label={
            <span>
              I agree to the{' '}
              <Link to="/privacy" className="text-primary hover:text-primary/80 font-medium">
                Privacy Policy
              </Link>
            </span>
          }
          error={errors.agreePrivacy}
        />
        
        <Checkbox
          name="agreeMarketing"
          checked={formData.agreeMarketing}
          onChange={handleChange}
          label="I agree to receive marketing communications and investment updates"
        />
      </div>

      <div className="bg-card border rounded-lg p-6">
        <h3 className="font-semibold text-foreground mb-4">Account Summary</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Name:</span>
            <span className="text-foreground">{formData.firstName} {formData.lastName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Email:</span>
            <span className="text-foreground">{formData.email}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Experience:</span>
            <span className="text-foreground capitalize">{formData.investmentExperience}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Risk Tolerance:</span>
            <span className="text-foreground capitalize">{formData.riskTolerance}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Initial Investment:</span>
            <span className="text-foreground">${formData.initialInvestment}</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary rounded-full mx-auto mb-4 flex items-center justify-center">
            <Icon name="UserPlus" size={32} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Join KleverInvest Hub</h1>
          <p className="text-muted-foreground">Start your cryptocurrency investment journey today</p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-4">
            {[1, 2, 3].map((stepNumber) => (
              <React.Fragment key={stepNumber}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium ${
                  step >= stepNumber 
                    ? 'bg-primary text-white' 
                    : 'bg-muted text-muted-foreground'
                }`}>
                  {step > stepNumber ? (
                    <Icon name="Check" size={16} />
                  ) : (
                    stepNumber
                  )}
                </div>
                {stepNumber < 3 && (
                  <div className={`w-12 h-0.5 ${
                    step > stepNumber ? 'bg-primary' : 'bg-muted'
                  }`}></div>
                )}
              </React.Fragment>
            ))}
          </div>
          <div className="flex justify-between text-xs text-muted-foreground mt-2 px-2">
            <span>Personal Info</span>
            <span>Investment Profile</span>
            <span>Verification</span>
          </div>
        </div>

        {/* Registration Form */}
        <div className="bg-card border rounded-lg shadow-lg p-8">
          {step === 1 && renderStep1()}
          {step === 2 && renderStep2()}
          {step === 3 && renderStep3()}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8">
            {step > 1 ? (
              <Button variant="outline" onClick={handleBack}>
                <Icon name="ArrowLeft" size={20} />
                Back
              </Button>
            ) : (
              <Link to="/login">
                <Button variant="outline">
                  <Icon name="ArrowLeft" size={20} />
                  Back to Login
                </Button>
              </Link>
            )}

            <Button 
              onClick={handleNext}
              disabled={isLoading}
              className="min-w-32"
            >
              {isLoading ? (
                <>
                  <Icon name="Loader" size={20} className="animate-spin" />
                  Processing...
                </>
              ) : step === 3 ? (
                <>
                  <Icon name="UserCheck" size={20} />
                  Create Account
                </>
              ) : (
                <>
                  Next
                  <Icon name="ArrowRight" size={20} />
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Login Link */}
        <div className="mt-6 text-center">
          <p className="text-muted-foreground">
            Already have an account?{' '}
            <Link to="/login" className="font-medium text-primary hover:text-primary/80">
              Sign in here
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
