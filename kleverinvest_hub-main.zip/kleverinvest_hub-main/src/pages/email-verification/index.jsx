import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const EmailVerificationPage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { isUserAuthenticated } = useUserAuth();
  const { isAdminAuthenticated } = useAdminAuth();

  // Determine correct dashboard URL based on authentication
  const getDashboardUrl = () => {
    if (isAdminAuthenticated) return '/admin-dashboard';
    if (isUserAuthenticated) return '/user-dashboard';
    return '/login-selection'; // fallback
  };
  const [verificationStatus, setVerificationStatus] = useState('verifying'); // verifying, success, error, expired
  const [isResending, setIsResending] = useState(false);
  const [resendCount, setResendCount] = useState(0);
  const [countdown, setCountdown] = useState(0);

  const email = searchParams.get('email') || 'user@example.com';
  const token = searchParams.get('token');

  useEffect(() => {
    // Simulate email verification process
    const verifyEmail = async () => {
      if (token) {
        // Simulate API call to verify token
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Simulate different verification outcomes
        const random = Math.random();
        if (random > 0.8) {
          setVerificationStatus('expired');
        } else if (random > 0.1) {
          setVerificationStatus('success');
          // Auto-redirect to dashboard after successful verification
          setTimeout(() => {
            navigate('/user-dashboard?verified=true');
          }, 3000);
        } else {
          setVerificationStatus('error');
        }
      } else {
        setVerificationStatus('error');
      }
    };

    if (token) {
      verifyEmail();
    } else {
      setVerificationStatus('waiting');
    }
  }, [token, navigate]);

  // Countdown timer for resend button
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const handleResendEmail = async () => {
    setIsResending(true);
    
    // Simulate resending email
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsResending(false);
    setResendCount(resendCount + 1);
    setCountdown(60); // 60 second cooldown
  };

  const renderVerifying = () => (
    <div className="text-center">
      <div className="w-16 h-16 bg-primary/10 rounded-full mx-auto mb-6 flex items-center justify-center">
        <Icon name="Loader" size={32} className="text-primary animate-spin" />
      </div>
      <h2 className="text-2xl font-bold text-foreground mb-4">Verifying Your Email</h2>
      <p className="text-muted-foreground mb-6">
        Please wait while we verify your email address...
      </p>
      <div className="bg-muted/30 border rounded-lg p-4">
        <p className="text-sm text-muted-foreground">
          This process usually takes a few seconds. Please don't close this page.
        </p>
      </div>
    </div>
  );

  const renderSuccess = () => (
    <div className="text-center">
      <div className="w-16 h-16 bg-success/10 rounded-full mx-auto mb-6 flex items-center justify-center">
        <Icon name="CheckCircle" size={32} className="text-success" />
      </div>
      <h2 className="text-2xl font-bold text-foreground mb-4">Email Verified Successfully!</h2>
      <p className="text-muted-foreground mb-6">
        Your email address has been confirmed. You'll be redirected to your dashboard shortly.
      </p>
      
      <div className="bg-success/10 border border-success/20 rounded-lg p-6 mb-6">
        <h3 className="font-semibold text-foreground mb-2">What's Next?</h3>
        <ul className="text-sm text-muted-foreground space-y-2 text-left">
          <li className="flex items-center space-x-2">
            <Icon name="Check" size={16} className="text-success" />
            <span>Complete your KYC verification for full account access</span>
          </li>
          <li className="flex items-center space-x-2">
            <Icon name="Check" size={16} className="text-success" />
            <span>Set up two-factor authentication for enhanced security</span>
          </li>
          <li className="flex items-center space-x-2">
            <Icon name="Check" size={16} className="text-success" />
            <span>Start exploring investment opportunities</span>
          </li>
        </ul>
      </div>

      <div className="space-y-3">
        <Button className="w-full" onClick={() => navigate(getDashboardUrl())}>
          <Icon name="ArrowRight" size={20} />
          Continue to Dashboard
        </Button>
        
        <Link to="/kyc-verification">
          <Button variant="outline" className="w-full">
            <Icon name="Shield" size={20} />
            Complete KYC Verification
          </Button>
        </Link>
      </div>
    </div>
  );

  const renderError = () => (
    <div className="text-center">
      <div className="w-16 h-16 bg-destructive/10 rounded-full mx-auto mb-6 flex items-center justify-center">
        <Icon name="XCircle" size={32} className="text-destructive" />
      </div>
      <h2 className="text-2xl font-bold text-foreground mb-4">Verification Failed</h2>
      <p className="text-muted-foreground mb-6">
        We couldn't verify your email address. The verification link may be invalid or corrupted.
      </p>
      
      <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 mb-6">
        <h3 className="font-semibold text-foreground mb-2">Possible reasons:</h3>
        <ul className="text-sm text-muted-foreground space-y-1 text-left">
          <li>• Invalid or malformed verification link</li>
          <li>• Link has already been used</li>
          <li>• Technical error during verification</li>
        </ul>
      </div>

      <div className="space-y-3">
        <Button 
          className="w-full" 
          onClick={handleResendEmail}
          disabled={isResending || countdown > 0}
        >
          {isResending ? (
            <>
              <Icon name="Loader" size={20} className="animate-spin" />
              Sending...
            </>
          ) : countdown > 0 ? (
            <>
              <Icon name="Clock" size={20} />
              Resend in {countdown}s
            </>
          ) : (
            <>
              <Icon name="RefreshCw" size={20} />
              Send New Verification Email
            </>
          )}
        </Button>
        
        <Link to="/contact">
          <Button variant="outline" className="w-full">
            <Icon name="MessageCircle" size={20} />
            Contact Support
          </Button>
        </Link>
      </div>
    </div>
  );

  const renderExpired = () => (
    <div className="text-center">
      <div className="w-16 h-16 bg-warning/10 rounded-full mx-auto mb-6 flex items-center justify-center">
        <Icon name="Clock" size={32} className="text-warning" />
      </div>
      <h2 className="text-2xl font-bold text-foreground mb-4">Verification Link Expired</h2>
      <p className="text-muted-foreground mb-6">
        This verification link has expired. Verification links are valid for 24 hours for security reasons.
      </p>
      
      <div className="bg-warning/10 border border-warning/20 rounded-lg p-4 mb-6">
        <p className="text-sm text-muted-foreground">
          Don't worry! You can request a new verification link and complete the process.
        </p>
      </div>

      <div className="space-y-3">
        <Button 
          className="w-full" 
          onClick={handleResendEmail}
          disabled={isResending || countdown > 0}
        >
          {isResending ? (
            <>
              <Icon name="Loader" size={20} className="animate-spin" />
              Sending...
            </>
          ) : countdown > 0 ? (
            <>
              <Icon name="Clock" size={20} />
              Resend in {countdown}s
            </>
          ) : (
            <>
              <Icon name="Send" size={20} />
              Send New Verification Email
            </>
          )}
        </Button>
        
        <Link to="/login">
          <Button variant="outline" className="w-full">
            <Icon name="ArrowLeft" size={20} />
            Back to Login
          </Button>
        </Link>
      </div>
    </div>
  );

  const renderWaiting = () => (
    <div className="text-center">
      <div className="w-16 h-16 bg-primary/10 rounded-full mx-auto mb-6 flex items-center justify-center">
        <Icon name="Mail" size={32} className="text-primary" />
      </div>
      <h2 className="text-2xl font-bold text-foreground mb-4">Check Your Email</h2>
      <p className="text-muted-foreground mb-6">
        We've sent a verification link to <strong>{email}</strong>
      </p>
      
      <div className="bg-primary/10 border border-primary/20 rounded-lg p-6 mb-6">
        <h3 className="font-semibold text-foreground mb-2">Verification Steps:</h3>
        <ol className="text-sm text-muted-foreground space-y-2 text-left">
          <li className="flex items-start space-x-2">
            <span className="text-primary font-medium">1.</span>
            <span>Check your email inbox (and spam folder)</span>
          </li>
          <li className="flex items-start space-x-2">
            <span className="text-primary font-medium">2.</span>
            <span>Click the verification link in the email</span>
          </li>
          <li className="flex items-start space-x-2">
            <span className="text-primary font-medium">3.</span>
            <span>You'll be automatically redirected to complete setup</span>
          </li>
        </ol>
      </div>

      <div className="space-y-3">
        <Button 
          variant="outline"
          className="w-full" 
          onClick={handleResendEmail}
          disabled={isResending || countdown > 0}
        >
          {isResending ? (
            <>
              <Icon name="Loader" size={20} className="animate-spin" />
              Sending...
            </>
          ) : countdown > 0 ? (
            <>
              <Icon name="Clock" size={20} />
              Resend in {countdown}s
            </>
          ) : (
            <>
              <Icon name="RefreshCw" size={20} />
              Resend Verification Email
            </>
          )}
        </Button>
        
        {resendCount > 0 && (
          <div className="text-sm text-success">
            ✓ Verification email sent! ({resendCount} email{resendCount > 1 ? 's' : ''} sent)
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-primary rounded-full mx-auto mb-6 flex items-center justify-center">
            <Icon name="TrendingUp" size={40} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">KleverInvest Hub</h1>
          <p className="text-muted-foreground">Email Verification</p>
        </div>

        {/* Verification Content */}
        <div className="bg-card border rounded-lg shadow-lg p-8">
          {verificationStatus === 'verifying' && renderVerifying()}
          {verificationStatus === 'success' && renderSuccess()}
          {verificationStatus === 'error' && renderError()}
          {verificationStatus === 'expired' && renderExpired()}
          {verificationStatus === 'waiting' && renderWaiting()}
        </div>

        {/* Help Section */}
        <div className="mt-6 bg-muted/50 border rounded-lg p-4">
          <div className="text-center">
            <h3 className="text-sm font-medium text-foreground mb-2">Need Help?</h3>
            <p className="text-xs text-muted-foreground mb-3">
              If you're having trouble with email verification, our support team is here to help.
            </p>
            <Link to="/contact">
              <Button variant="outline" size="sm">
                <Icon name="HelpCircle" size={16} />
                Get Support
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailVerificationPage;
