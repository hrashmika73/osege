import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import AdminNavigation from '../../components/ui/AdminNavigation';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const AdminEmailSettings = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated } = useAdminAuth();
  const [settings, setSettings] = useState({
    smtpHost: '',
    smtpPort: '587',
    smtpUsername: '',
    smtpPassword: '',
    smtpSecurity: 'tls',
    fromEmail: '',
    fromName: '',
    replyToEmail: '',
    emailEnabled: true,
    welcomeEmailEnabled: true,
    transactionEmailEnabled: true,
    marketingEmailEnabled: false,
    maxEmailsPerHour: '100'
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testingConnection, setTestingConnection] = useState(false);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin-login');
      return;
    }
    loadEmailSettings();
  }, [isAdminAuthenticated, navigate]);

  const loadEmailSettings = () => {
    setLoading(true);
    // Load saved settings from localStorage
    const savedSettings = localStorage.getItem('admin_email_settings');
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
    setLoading(false);
  };

  const handleSaveSettings = () => {
    setSaving(true);
    // Save settings to localStorage
    localStorage.setItem('admin_email_settings', JSON.stringify(settings));
    
    setTimeout(() => {
      setSaving(false);
      alert('Email settings saved successfully!');
    }, 1000);
  };

  const testEmailConnection = () => {
    setTestingConnection(true);
    // Simulate testing email connection
    setTimeout(() => {
      setTestingConnection(false);
      if (settings.smtpHost && settings.smtpUsername && settings.smtpPassword) {
        alert('Email connection test successful!');
      } else {
        alert('Please fill in all SMTP details before testing.');
      }
    }, 2000);
  };

  const sendTestEmail = () => {
    if (!settings.fromEmail) {
      alert('Please set the From Email address first.');
      return;
    }
    
    const testEmail = prompt('Enter email address to send test email to:');
    if (testEmail) {
      alert(`Test email will be sent to ${testEmail}`);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminNavigation
        title="Email Settings"
        breadcrumb={[
          { label: "Controls", link: "/admin-controls" },
          { label: "Email Settings" }
        ]}
        actions={[
          {
            label: "Test Connection",
            icon: "Zap",
            variant: "outline",
            onClick: testEmailConnection,
            disabled: testingConnection
          },
          {
            label: "Send Test Email",
            icon: "Mail",
            variant: "outline",
            onClick: sendTestEmail
          },
          {
            label: saving ? "Saving..." : "Save Settings",
            icon: saving ? "Loader" : "Save",
            variant: "default",
            onClick: handleSaveSettings,
            disabled: saving
          }
        ]}
      />

      <div className="p-6">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Icon name="Loader" size={24} className="animate-spin mr-2" />
            Loading email settings...
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* SMTP Configuration */}
            <div className="bg-card border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
                <Icon name="Server" size={20} className="mr-2" />
                SMTP Configuration
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">SMTP Host</label>
                  <input
                    type="text"
                    value={settings.smtpHost}
                    onChange={(e) => setSettings({...settings, smtpHost: e.target.value})}
                    placeholder="smtp.gmail.com"
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">SMTP Port</label>
                    <input
                      type="number"
                      value={settings.smtpPort}
                      onChange={(e) => setSettings({...settings, smtpPort: e.target.value})}
                      placeholder="587"
                      className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">Security</label>
                    <select
                      value={settings.smtpSecurity}
                      onChange={(e) => setSettings({...settings, smtpSecurity: e.target.value})}
                      className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="none">None</option>
                      <option value="ssl">SSL</option>
                      <option value="tls">TLS</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Username</label>
                  <input
                    type="text"
                    value={settings.smtpUsername}
                    onChange={(e) => setSettings({...settings, smtpUsername: e.target.value})}
                    placeholder="your-email@example.com"
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Password</label>
                  <input
                    type="password"
                    value={settings.smtpPassword}
                    onChange={(e) => setSettings({...settings, smtpPassword: e.target.value})}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>
            </div>

            {/* Email Identity */}
            <div className="bg-card border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
                <Icon name="User" size={20} className="mr-2" />
                Email Identity
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">From Email</label>
                  <input
                    type="email"
                    value={settings.fromEmail}
                    onChange={(e) => setSettings({...settings, fromEmail: e.target.value})}
                    placeholder="noreply@kleverinvest.com"
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">From Name</label>
                  <input
                    type="text"
                    value={settings.fromName}
                    onChange={(e) => setSettings({...settings, fromName: e.target.value})}
                    placeholder="KleverInvest Hub"
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Reply-To Email</label>
                  <input
                    type="email"
                    value={settings.replyToEmail}
                    onChange={(e) => setSettings({...settings, replyToEmail: e.target.value})}
                    placeholder="support@kleverinvest.com"
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Max Emails Per Hour</label>
                  <input
                    type="number"
                    value={settings.maxEmailsPerHour}
                    onChange={(e) => setSettings({...settings, maxEmailsPerHour: e.target.value})}
                    placeholder="100"
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Rate limiting to prevent abuse</p>
                </div>
              </div>
            </div>

            {/* Email Types */}
            <div className="bg-card border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
                <Icon name="Settings" size={20} className="mr-2" />
                Email Types
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-foreground">Email System</label>
                    <p className="text-xs text-muted-foreground">Enable/disable entire email system</p>
                  </div>
                  <button
                    onClick={() => setSettings({...settings, emailEnabled: !settings.emailEnabled})}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      settings.emailEnabled ? 'bg-primary' : 'bg-gray-200'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings.emailEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-foreground">Welcome Emails</label>
                    <p className="text-xs text-muted-foreground">Send welcome emails to new users</p>
                  </div>
                  <button
                    onClick={() => setSettings({...settings, welcomeEmailEnabled: !settings.welcomeEmailEnabled})}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      settings.welcomeEmailEnabled ? 'bg-primary' : 'bg-gray-200'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings.welcomeEmailEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-foreground">Transaction Emails</label>
                    <p className="text-xs text-muted-foreground">Send transaction confirmations</p>
                  </div>
                  <button
                    onClick={() => setSettings({...settings, transactionEmailEnabled: !settings.transactionEmailEnabled})}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      settings.transactionEmailEnabled ? 'bg-primary' : 'bg-gray-200'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings.transactionEmailEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-foreground">Marketing Emails</label>
                    <p className="text-xs text-muted-foreground">Send promotional emails</p>
                  </div>
                  <button
                    onClick={() => setSettings({...settings, marketingEmailEnabled: !settings.marketingEmailEnabled})}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      settings.marketingEmailEnabled ? 'bg-primary' : 'bg-gray-200'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings.marketingEmailEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>

            {/* Email Templates */}
            <div className="bg-card border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
                <Icon name="FileText" size={20} className="mr-2" />
                Email Templates
              </h3>
              <div className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Icon name="Edit" size={16} className="mr-2" />
                  Welcome Email Template
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Icon name="Edit" size={16} className="mr-2" />
                  Transaction Confirmation Template
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Icon name="Edit" size={16} className="mr-2" />
                  Password Reset Template
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Icon name="Edit" size={16} className="mr-2" />
                  KYC Verification Template
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Icon name="Edit" size={16} className="mr-2" />
                  Marketing Newsletter Template
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Email Status */}
        <div className="mt-8 bg-card border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
            <Icon name="Activity" size={20} className="mr-2" />
            Email Statistics
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">1,247</div>
              <div className="text-sm text-muted-foreground">Emails Sent Today</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">98.5%</div>
              <div className="text-sm text-muted-foreground">Delivery Rate</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">45.2%</div>
              <div className="text-sm text-muted-foreground">Open Rate</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">12.8%</div>
              <div className="text-sm text-muted-foreground">Click Rate</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminEmailSettings;
