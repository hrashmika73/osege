import { useState, useEffect, useCallback, useRef } from 'react';
import builderApiService from '../services/builderApiService';

/**
 * React hook for Builder.io content with cache-busting and real-time updates
 * Equivalent to PHP's always-fresh content fetching
 */
export const useBuilderContent = (modelName, options = {}) => {
  const {
    url = window.location.pathname,
    query = {},
    cacheBust = true,
    autoRefresh = true,
    refreshInterval = 30000, // 30 seconds
    realTimeUpdates = false
  } = options;

  const [content, setContent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  
  const unsubscribeRef = useRef(null);
  const intervalRef = useRef(null);

  /**
   * Fetch content with cache-busting
   */
  const fetchContent = useCallback(async (forceRefresh = false) => {
    try {
      setLoading(true);
      setError(null);

      const data = await builderApiService.getContent(modelName, {
        url,
        query,
        cacheBust: cacheBust || forceRefresh,
        forceRefresh
      });

      setContent(data);
      setLastUpdated(new Date());
    } catch (err) {
      setError(err.message);
      console.error(`Error fetching Builder.io content for ${modelName}:`, err);
    } finally {
      setLoading(false);
    }
  }, [modelName, url, query, cacheBust]);

  /**
   * Force refresh content (bypass all caches)
   */
  const forceRefresh = useCallback(() => {
    return fetchContent(true);
  }, [fetchContent]);

  /**
   * Manual refresh
   */
  const refresh = useCallback(() => {
    return fetchContent(false);
  }, [fetchContent]);

  // Initial load
  useEffect(() => {
    fetchContent();
  }, [fetchContent]);

  // Auto-refresh interval
  useEffect(() => {
    if (autoRefresh && refreshInterval > 0) {
      intervalRef.current = setInterval(() => {
        fetchContent(false);
      }, refreshInterval);

      return () => {
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
        }
      };
    }
  }, [autoRefresh, refreshInterval, fetchContent]);

  // Real-time updates via WebSocket
  useEffect(() => {
    if (realTimeUpdates) {
      unsubscribeRef.current = builderApiService.subscribeToUpdates(
        modelName,
        (updateData) => {
          console.log(`Real-time update received for ${modelName}:`, updateData);
          // Force refresh when content is updated
          forceRefresh();
        }
      );

      return () => {
        if (unsubscribeRef.current) {
          unsubscribeRef.current();
        }
      };
    }
  }, [realTimeUpdates, modelName, forceRefresh]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (unsubscribeRef.current) {
        unsubscribeRef.current();
      }
    };
  }, []);

  return {
    content,
    loading,
    error,
    lastUpdated,
    refresh,
    forceRefresh,
    isStale: lastUpdated && (Date.now() - lastUpdated.getTime()) > refreshInterval
  };
};

/**
 * Hook for multiple Builder.io models
 */
export const useBuilderContents = (models = [], options = {}) => {
  const [contents, setContents] = useState({});
  const [loading, setLoading] = useState(true);
  const [errors, setErrors] = useState({});

  const fetchAllContents = useCallback(async (forceRefresh = false) => {
    setLoading(true);
    const newContents = {};
    const newErrors = {};

    await Promise.all(
      models.map(async (model) => {
        try {
          const data = await builderApiService.getContent(model, {
            ...options,
            forceRefresh
          });
          newContents[model] = data;
        } catch (error) {
          newErrors[model] = error.message;
          console.error(`Error fetching ${model}:`, error);
        }
      })
    );

    setContents(newContents);
    setErrors(newErrors);
    setLoading(false);
  }, [models, options]);

  useEffect(() => {
    if (models.length > 0) {
      fetchAllContents();
    }
  }, [fetchAllContents]);

  const refresh = useCallback(() => fetchAllContents(false), [fetchAllContents]);
  const forceRefresh = useCallback(() => fetchAllContents(true), [fetchAllContents]);

  return {
    contents,
    loading,
    errors,
    refresh,
    forceRefresh
  };
};

export default useBuilderContent;
