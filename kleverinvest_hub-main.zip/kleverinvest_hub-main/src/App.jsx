import React, { useEffect } from "react";
import { AdminAuthProvider } from "./contexts/AdminAuthContext";
import { UserAuthProvider } from "./contexts/UserAuthContext";
import Routes from "./Routes";
import LiveChatWidget from "./components/ui/LiveChatWidget";
import GlobalNotificationSystem from "./components/GlobalNotificationSystem";
import { initializeTestUsers } from "./utils/initTestUser";
import { initializeAPIErrorHandling } from "./utils/apiErrorHandler";
import resourceLoader from "./utils/resourceLoader";
import networkErrorDetector from "./utils/networkErrorDetector";
import applyImmediateFixes from "./utils/immediateNetworkFix";
import networkErrorEliminator from "./utils/eliminateNetworkErrors";
import connectionManager from "./utils/connectionManager";
import routingFix from "./utils/routingFix";

// Apply immediate fixes before anything else
try {
  applyImmediateFixes();
  // NetworkError eliminator is auto-activated on import
  console.log('🛡️ NetworkError protection systems active');
} catch (error) {
  console.warn('Failed to apply immediate fixes:', error);
}

function App() {
  useEffect(() => {
    // Initialize all error handling systems
    try {
      // 1. Initialize API error handling first
      initializeAPIErrorHandling();

      // 2. Start network error detection
      networkErrorDetector.startMonitoring();

      // 3. Preload critical resources
      resourceLoader.preloadCriticalResources();

      // 4. Initialize test users
      initializeTestUsers();

      // 5. Initialize connection manager for backend/frontend sync
      connectionManager.forceReconnect();

      // 6. Initialize routing fix for 404 issues
      routingFix.fixCurrentRoute();

      console.log('🚀 All systems initialized successfully');
    } catch (error) {
      console.warn('Failed to initialize systems:', error);
    }

    // Handle force offline mode
    const handleForceOffline = (event) => {
      console.log('💾 Forced offline mode:', event.detail.reason);
      // Could show a notification or update UI state
    };

    window.addEventListener('forceOfflineMode', handleForceOffline);

    return () => {
      window.removeEventListener('forceOfflineMode', handleForceOffline);
    };
  }, []);

  return (
    <AdminAuthProvider>
      <UserAuthProvider>
        <Routes />
        <LiveChatWidget />
        <GlobalNotificationSystem />
      </UserAuthProvider>
    </AdminAuthProvider>
  );
}

export default App;
