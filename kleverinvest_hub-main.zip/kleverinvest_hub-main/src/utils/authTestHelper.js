// Authentication Test Helper for Debugging

export const setupTestAdmin = () => {
  const adminUser = {
    id: 2,
    name: 'Test Admin',
    email: 'admin@kleverinvest.com',
    role: 'admin',
    verified: true,
    memberSince: new Date().toISOString().split('T')[0],
    balance: 0,
    wallet: null,
    username: 'TestAdmin'
  };

  const token = `admin_test_${Date.now()}`;

  localStorage.setItem('userToken', token);
  localStorage.setItem('userData', JSON.stringify(adminUser));
  localStorage.setItem('userRole', 'admin');

  console.log('Test admin user setup complete');
  return adminUser;
};

export const setupTestUser = () => {
  const testUser = {
    id: 1,
    name: 'Test User',
    email: 'user@kleverinvest.com',
    role: 'user',
    verified: true,
    memberSince: new Date().toISOString().split('T')[0],
    balance: 5000,
    wallet: 'bc1qtest123456789',
    username: 'TestUser'
  };

  const token = `user_test_${Date.now()}`;

  localStorage.setItem('userToken', token);
  localStorage.setItem('userData', JSON.stringify(testUser));
  localStorage.setItem('userRole', 'user');

  console.log('Test user setup complete');
  return testUser;
};

export const clearTestAuth = () => {
  localStorage.removeItem('userToken');
  localStorage.removeItem('userData');
  localStorage.removeItem('userRole');
  console.log('Test auth data cleared');
};

// Auto-setup for testing if needed
if (typeof window !== 'undefined' && window.location.hostname.includes('fly.dev')) {
  // Auto-setup admin for production testing
  if (!localStorage.getItem('userToken')) {
    console.log('Setting up test admin for production debugging...');
    setupTestAdmin();
  }
}

export default {
  setupTestAdmin,
  setupTestUser,
  clearTestAuth
};
