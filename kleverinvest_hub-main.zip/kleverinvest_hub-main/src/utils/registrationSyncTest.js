/**
 * Registration Sync Test Utility
 * Tests the sync between frontend registration and admin dashboard
 */

import { addNewUser, createKYCRequest } from './userDataManager.js';

export const testRegistrationSync = () => {
  console.log('🧪 Testing registration sync...');
  
  try {
    // Create test user data
    const testUserData = {
      id: 'user_test_' + Date.now(),
      name: 'Test User ' + Math.floor(Math.random() * 1000),
      email: `testuser${Math.floor(Math.random() * 10000)}@example.com`,
      password: 'TestPassword123!',
      phone: '+1-555-' + Math.floor(Math.random() * 10000),
      country: 'US',
      kycStatus: 'pending',
      balance: 0
    };

    console.log('📝 Creating test user:', testUserData.email);

    // Add user to admin system (same as registration page does)
    const adminUserData = addNewUser(testUserData);
    console.log('✅ User added to admin system:', adminUserData);

    // Create KYC request
    const kycRequest = createKYCRequest(testUserData);
    console.log('✅ KYC request created:', kycRequest);

    // Trigger real-time sync events (same as registration page does)
    window.dispatchEvent(new CustomEvent('userRegistered', {
      detail: { 
        user: adminUserData, 
        timestamp: new Date().toISOString(),
        source: 'sync_test'
      }
    }));

    // Trigger storage change event
    window.dispatchEvent(new StorageEvent('storage', {
      key: 'admin_users_data',
      newValue: JSON.stringify([...JSON.parse(localStorage.getItem('admin_users_data') || '[]')]),
      oldValue: null,
      storageArea: localStorage
    }));

    // Set registration flag
    localStorage.setItem('new_user_registered', 'true');
    localStorage.setItem('last_registration_timestamp', new Date().toISOString());

    console.log('🎉 Registration sync test completed successfully');
    
    return {
      success: true,
      testUser: adminUserData,
      kycRequest,
      message: `Test user ${testUserData.email} created successfully`
    };
    
  } catch (error) {
    console.error('❌ Registration sync test failed:', error);
    return {
      success: false,
      error: error.message,
      message: 'Registration sync test failed'
    };
  }
};

export const checkRegistrationSync = () => {
  console.log('🔍 Checking registration sync status...');
  
  try {
    // Check localStorage data
    const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
    const kycRequests = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
    const lastRegistration = localStorage.getItem('last_registration_timestamp');
    const newUserFlag = localStorage.getItem('new_user_registered');

    const status = {
      adminUsersCount: adminUsers.length,
      kycRequestsCount: kycRequests.length,
      lastRegistrationTime: lastRegistration,
      newUserFlagSet: newUserFlag === 'true',
      recentRegistrations: adminUsers.filter(user => {
        if (!user.registrationDate) return false;
        const registrationTime = new Date(user.registrationDate);
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
        return registrationTime > fiveMinutesAgo;
      }),
      syncHealthy: true
    };

    console.log('📊 Registration sync status:', status);
    return status;
    
  } catch (error) {
    console.error('❌ Error checking registration sync:', error);
    return {
      syncHealthy: false,
      error: error.message
    };
  }
};

export const simulateRegistration = (userEmail = null) => {
  const email = userEmail || `newuser${Date.now()}@test.com`;
  
  console.log('🔄 Simulating user registration for:', email);
  
  const userData = {
    id: 'user_' + Date.now(),
    name: email.split('@')[0].replace(/\d+/, '').replace('newuser', 'New User'),
    email: email,
    password: 'Password123!',
    phone: '+1-555-0123',
    country: 'US',
    kycStatus: 'pending',
    balance: 0
  };

  return testRegistrationSync(userData);
};

export const clearTestData = () => {
  try {
    const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
    const kycRequests = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
    
    // Remove test users
    const filteredUsers = adminUsers.filter(user => !user.email.includes('testuser') && !user.email.includes('@test.com'));
    const filteredKyc = kycRequests.filter(request => !request.email.includes('testuser') && !request.email.includes('@test.com'));
    
    localStorage.setItem('admin_users_data', JSON.stringify(filteredUsers));
    localStorage.setItem('admin_pending_kyc', JSON.stringify(filteredKyc));
    
    console.log('🧹 Test data cleared');
    return {
      success: true,
      removedUsers: adminUsers.length - filteredUsers.length,
      removedKyc: kycRequests.length - filteredKyc.length
    };
  } catch (error) {
    console.error('❌ Error clearing test data:', error);
    return { success: false, error: error.message };
  }
};

// Auto-run sync check on import
if (typeof window !== 'undefined') {
  console.log('🔧 Registration sync utility loaded');
  window.testRegistrationSync = testRegistrationSync;
  window.checkRegistrationSync = checkRegistrationSync;
  window.simulateRegistration = simulateRegistration;
  window.clearTestData = clearTestData;
}

export default {
  testRegistrationSync,
  checkRegistrationSync,
  simulateRegistration,
  clearTestData
};
