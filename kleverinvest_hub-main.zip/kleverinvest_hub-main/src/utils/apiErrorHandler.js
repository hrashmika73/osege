/**
 * API Error Handler - Catches and handles all NetworkErrors
 * Provides graceful fallbacks for when backend is unavailable
 */

export class APIError extends Error {
  constructor(message, type = 'error', originalError = null) {
    super(message);
    this.name = 'APIError';
    this.type = type;
    this.originalError = originalError;
  }
}

/**
 * Wrapper for fetch requests with automatic error handling
 */
export const safeFetch = async (url, options = {}) => {
  try {
    // Check if backend is enabled
    const ENABLE_BACKEND = import.meta.env?.VITE_ENABLE_BACKEND === 'true' || 
                          process.env?.REACT_APP_ENABLE_BACKEND === 'true';
    
    if (!ENABLE_BACKEND) {
      throw new APIError('Backend disabled - using mock mode', 'warning');
    }

    // Add AbortController for timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), options.timeout || 5000);

    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new APIError(`HTTP Error: ${response.status} - ${response.statusText}`, 'error');
    }

    return response;
  } catch (error) {
    if (error instanceof TypeError && (
        error.message.includes('Failed to fetch') ||
        error.message.includes('NetworkError') ||
        error.message.includes('fetch')
      )) {
      throw new APIError('Network unavailable - backend server not reachable', 'error', error);
    }

    if (error.name === 'AbortError' || error.message.includes('aborted')) {
      throw new APIError('Request timeout - backend server too slow', 'error', error);
    }

    if (error instanceof APIError) {
      throw error;
    }

    throw new APIError(`Unexpected error: ${error.message}`, 'error', error);
  }
};

/**
 * Wrapper for axios requests with automatic error handling
 */
export const safeAxiosCall = async (axiosPromise, fallbackData = null) => {
  try {
    const response = await axiosPromise;
    return {
      success: true,
      data: response.data,
      message: 'Request successful',
      type: 'success'
    };
  } catch (error) {
    console.warn('Axios request failed:', error.message);

    // Return fallback data instead of throwing
    return {
      success: false,
      data: fallbackData,
      message: error.response?.data?.message || 'Backend unavailable - using fallback data',
      type: 'warning',
      originalError: error
    };
  }
};

/**
 * Global error handler for unhandled API errors
 */
export const setupGlobalErrorHandler = () => {
  // Handle unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const message = reason?.message || reason?.toString() || '';

    // Check for various types of network errors
    if (reason instanceof APIError ||
        (message && (
          message.includes('fetch') ||
          message.includes('Network') ||
          message.includes('ECONNREFUSED') ||
          message.includes('Failed to fetch') ||
          message.includes('NetworkError') ||
          message.includes('ERR_NETWORK') ||
          message.includes('ERR_INTERNET_DISCONNECTED') ||
          message.includes('TypeError: Failed to fetch') ||
          message.includes('AbortError') ||
          message.includes('The user aborted a request') ||
          message.includes('Load failed') ||
          message.includes('Connection refused')
        ))) {
      console.warn('🛡️ Caught unhandled network error:', message);
      event.preventDefault(); // Prevent console error

      // Dispatch custom event for global handling
      window.dispatchEvent(new CustomEvent('networkError', {
        detail: { error: reason, message: message }
      }));
    }

    // Handle dynamic import errors
    if (message && (
        message.includes('Failed to fetch dynamically imported module') ||
        message.includes('Loading CSS chunk') ||
        message.includes('Loading module') ||
        message.includes('ChunkLoadError')
      )) {
      console.warn('🛡️ Caught dynamic import error:', message);
      event.preventDefault();

      // Attempt to reload the page after a short delay
      setTimeout(() => {
        console.log('🔄 Attempting to reload due to chunk loading error...');
        window.location.reload();
      }, 2000);
    }
  });

  // Handle general errors that might be network-related
  window.addEventListener('error', (event) => {
    const error = event.error;
    const message = error?.message || event.message || '';
    const filename = event.filename || '';

    if (message && (
        message.includes('fetch') ||
        message.includes('Network') ||
        message.includes('ECONNREFUSED') ||
        message.includes('Failed to fetch') ||
        message.includes('NetworkError') ||
        message.includes('ERR_NETWORK') ||
        message.includes('Loading CSS chunk') ||
        message.includes('Loading module') ||
        message.includes('ChunkLoadError') ||
        message.includes('TypeError: Failed to fetch') ||
        filename.includes('chunk')
      )) {
      console.warn('🛡️ Caught network/loading error:', message);
      event.preventDefault(); // Prevent console error

      // For chunk loading errors, attempt reload
      if (message.includes('chunk') || message.includes('Loading') || filename.includes('chunk')) {
        setTimeout(() => {
          console.log('🔄 Reloading due to chunk error...');
          window.location.reload();
        }, 1000);
      }
    }
  });

  // Handle resource loading errors (images, scripts, etc.)
  window.addEventListener('error', (event) => {
    if (event.target && event.target !== window) {
      const target = event.target;
      if (target.tagName === 'IMG' || target.tagName === 'SCRIPT' || target.tagName === 'LINK') {
        console.warn('🛡️ Caught resource loading error:', target.src || target.href);
        event.preventDefault();
      }
    }
  }, true); // Use capture phase

  // Add a global network error listener
  window.addEventListener('networkError', (event) => {
    const { error, message } = event.detail;

    // Show user-friendly notification if needed
    if (window.showNotification) {
      window.showNotification({
        type: 'warning',
        title: 'Connection Issue',
        message: 'Working in offline mode. Some features may be limited.',
        duration: 5000
      });
    }
  });

  // Detect online/offline status
  window.addEventListener('online', () => {
    console.log('🔗 Connection restored');
    if (window.showNotification) {
      window.showNotification({
        type: 'success',
        title: 'Connection Restored',
        message: 'Back online! All features are available.',
        duration: 3000
      });
    }
  });

  window.addEventListener('offline', () => {
    console.log('🚫 Connection lost');
    if (window.showNotification) {
      window.showNotification({
        type: 'warning',
        title: 'Connection Lost',
        message: 'Working offline. Data will sync when connection is restored.',
        duration: 5000
      });
    }
  });

  console.log('🛡️ Enhanced Global API error handlers installed');
  console.log('🔍 Network status monitoring enabled');
};

/**
 * Mock data generator for common API responses
 */
/**
 * Create a network error safe wrapper for any async function
 */
export const withNetworkErrorHandling = (asyncFn, fallbackValue = null, fallbackMessage = 'Operation failed - using fallback') => {
  return async (...args) => {
    try {
      return await asyncFn(...args);
    } catch (error) {
      const message = error?.message || error?.toString() || '';

      if (message.includes('fetch') ||
          message.includes('Network') ||
          message.includes('Failed to fetch') ||
          message.includes('NetworkError') ||
          error instanceof TypeError) {
        console.warn(`🛡️ Network error caught in ${asyncFn.name || 'anonymous function'}:`, message);

        return {
          success: false,
          data: fallbackValue,
          message: fallbackMessage,
          type: 'warning',
          networkError: true,
          originalError: error
        };
      }

      // Re-throw non-network errors
      throw error;
    }
  };
};

/**
 * Test network connectivity
 */
export const testNetworkConnectivity = async () => {
  try {
    // Test with a simple HEAD request to the current origin
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    const response = await fetch(window.location.origin + '/favicon.ico', {
      method: 'HEAD',
      cache: 'no-cache',
      signal: controller.signal,
    });

    clearTimeout(timeoutId);
    return { online: true, latency: Date.now() - performance.now() };
  } catch (error) {
    return { online: false, error: error.message };
  }
};

/**
 * Mock data generator for common API responses
 */
export const generateMockResponse = (type, data = {}) => {
  const mockResponses = {
    users: {
      success: true,
      data: {
        users: [],
        total: 0,
        page: 1,
        limit: 10,
        ...data
      },
      message: 'Mock user data (backend disabled)',
      type: 'warning'
    },
    transactions: {
      success: true,
      data: {
        transactions: [],
        total: 0,
        page: 1,
        limit: 20,
        ...data
      },
      message: 'Mock transaction data (backend disabled)',
      type: 'warning'
    },
    stats: {
      success: true,
      data: {
        totalUsers: 0,
        activeUsers: 0,
        totalDeposits: 0,
        totalWithdrawals: 0,
        pendingTransactions: 0,
        systemHealth: 'Mock Mode',
        ...data
      },
      message: 'Mock statistics (backend disabled)',
      type: 'warning'
    },
    auth: {
      success: true,
      data: {
        token: 'mock-token',
        user: {
          id: 1,
          username: 'mockuser',
          email: 'mock@example.com',
          role: 'user'
        },
        ...data
      },
      message: 'Mock authentication (backend disabled)',
      type: 'warning'
    }
  };

  return mockResponses[type] || {
    success: false,
    data: null,
    message: 'Unknown mock response type',
    type: 'error'
  };
};

/**
 * Initialize error handling system
 */
export const initializeAPIErrorHandling = () => {
  setupGlobalErrorHandler();

  // Test initial connectivity
  testNetworkConnectivity().then(result => {
    console.log('🌐 Network connectivity:', result.online ? 'Online' : 'Offline');
  });

  // Log initialization
  console.log('🛡️ API Error Handling System Initialized');
  console.log('📡 Backend Status:', import.meta.env?.VITE_ENABLE_BACKEND === 'true' ? 'Enabled' : 'Disabled (Mock Mode)');
};
