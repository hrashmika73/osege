/**
 * Enhanced Admin Security Utilities
 * Advanced security features for admin authentication
 */

// Device fingerprinting for enhanced security
export const generateDeviceFingerprint = async () => {
  try {
    const fingerprint = {
      userAgent: navigator.userAgent,
      language: navigator.language,
      platform: navigator.platform,
      cookieEnabled: navigator.cookieEnabled,
      screenResolution: `${screen.width}x${screen.height}`,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      hardware: navigator.hardwareConcurrency || 'unknown',
      connection: navigator.connection?.effectiveType || 'unknown',
      timestamp: Date.now()
    };

    // Generate unique hash from device characteristics
    const fingerprintString = JSON.stringify(fingerprint);
    const encoder = new TextEncoder();
    const data = encoder.encode(fingerprintString);
    
    if (window.crypto && window.crypto.subtle) {
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      
      return {
        id: hashHex.substring(0, 32),
        details: fingerprint,
        securityLevel: calculateSecurityLevel(fingerprint)
      };
    }
    
    // Fallback
    return {
      id: btoa(fingerprintString).substring(0, 32),
      details: fingerprint,
      securityLevel: 'medium'
    };
  } catch (error) {
    console.error('Device fingerprinting failed:', error);
    return {
      id: 'unknown_device',
      details: { error: 'fingerprinting_failed' },
      securityLevel: 'low'
    };
  }
};

// Calculate device security level
const calculateSecurityLevel = (fingerprint) => {
  let score = 0;
  
  // Check for secure features
  if (window.crypto && window.crypto.subtle) score += 20;
  if (navigator.serviceWorker) score += 10;
  if (window.location.protocol === 'https:') score += 20;
  if (fingerprint.hardware && fingerprint.hardware > 4) score += 10;
  if (fingerprint.connection !== 'slow-2g') score += 10;
  
  // Check for potential security risks
  if (fingerprint.userAgent.includes('HeadlessChrome')) score -= 30;
  if (fingerprint.userAgent.includes('PhantomJS')) score -= 30;
  if (fingerprint.userAgent.includes('webdriver')) score -= 30;
  
  if (score >= 50) return 'high';
  if (score >= 30) return 'medium';
  return 'low';
};

// Biometric authentication wrapper
export const biometricAuth = {
  // Check if biometric authentication is available
  async isAvailable() {
    try {
      if (!window.PublicKeyCredential) return false;
      
      const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      return available;
    } catch (error) {
      console.warn('Biometric availability check failed:', error);
      return false;
    }
  },

  // Register biometric credential
  async register(userId, userName) {
    try {
      if (!await this.isAvailable()) {
        throw new Error('Biometric authentication not available');
      }

      const challenge = window.crypto.getRandomValues(new Uint8Array(32));
      
      const publicKeyCredentialCreationOptions = {
        challenge,
        rp: {
          name: "KleverInvest Admin",
          id: window.location.hostname
        },
        user: {
          id: new TextEncoder().encode(userId),
          name: userName,
          displayName: userName
        },
        pubKeyCredParams: [
          { alg: -7, type: "public-key" },
          { alg: -257, type: "public-key" }
        ],
        authenticatorSelection: {
          authenticatorAttachment: "platform",
          userVerification: "required"
        },
        timeout: 60000,
        attestation: "direct"
      };

      const credential = await navigator.credentials.create({
        publicKey: publicKeyCredentialCreationOptions
      });

      if (credential) {
        const credentialInfo = {
          id: credential.id,
          rawId: Array.from(new Uint8Array(credential.rawId)),
          type: credential.type,
          publicKey: Array.from(new Uint8Array(credential.response.publicKey)),
          userId: userId,
          registeredAt: new Date().toISOString()
        };

        // Store credential info securely
        localStorage.setItem(`biometric_${userId}`, JSON.stringify(credentialInfo));
        
        return {
          success: true,
          credentialId: credential.id,
          message: 'Biometric authentication registered successfully'
        };
      }
      
      throw new Error('Failed to create credential');
    } catch (error) {
      console.error('Biometric registration failed:', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Authenticate using biometric
  async authenticate(userId) {
    try {
      if (!await this.isAvailable()) {
        throw new Error('Biometric authentication not available');
      }

      const storedCredential = localStorage.getItem(`biometric_${userId}`);
      if (!storedCredential) {
        throw new Error('No biometric credential found for user');
      }

      const credentialInfo = JSON.parse(storedCredential);
      const challenge = window.crypto.getRandomValues(new Uint8Array(32));

      const publicKeyCredentialRequestOptions = {
        challenge,
        allowCredentials: [{
          id: new Uint8Array(credentialInfo.rawId),
          type: 'public-key'
        }],
        userVerification: 'required',
        timeout: 60000
      };

      const assertion = await navigator.credentials.get({
        publicKey: publicKeyCredentialRequestOptions
      });

      if (assertion) {
        return {
          success: true,
          credentialId: assertion.id,
          message: 'Biometric authentication successful',
          lastUsed: new Date().toISOString()
        };
      }

      throw new Error('Biometric authentication failed');
    } catch (error) {
      console.error('Biometric authentication failed:', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Check if user has registered biometric
  isRegistered(userId) {
    return !!localStorage.getItem(`biometric_${userId}`);
  },

  // Remove biometric credential
  remove(userId) {
    localStorage.removeItem(`biometric_${userId}`);
  }
};

// Advanced rate limiting with IP and device tracking
export class AdvancedRateLimiter {
  constructor(options = {}) {
    this.maxAttempts = options.maxAttempts || 3;
    this.windowMs = options.windowMs || 30 * 60 * 1000; // 30 minutes
    this.progressiveLockout = options.progressiveLockout || true;
    this.attempts = new Map();
    this.deviceAttempts = new Map();
    this.suspiciousIPs = new Set();
  }

  // Generate attempt key
  getAttemptKey(ip, deviceId) {
    return `${ip}_${deviceId}`;
  }

  // Check if attempt is allowed
  async isAllowed(ip = 'unknown', deviceFingerprint = null) {
    const deviceId = deviceFingerprint?.id || 'unknown';
    const key = this.getAttemptKey(ip, deviceId);
    const now = Date.now();

    // Check IP blacklist
    if (this.suspiciousIPs.has(ip)) {
      return {
        allowed: false,
        reason: 'IP_BLACKLISTED',
        resetTime: null
      };
    }

    // Get attempt data
    const attemptData = this.attempts.get(key) || {
      count: 0,
      resetTime: now + this.windowMs,
      lockouts: 0
    };

    // Reset if window expired
    if (now >= attemptData.resetTime) {
      attemptData.count = 0;
      attemptData.resetTime = now + this.windowMs;
    }

    // Calculate max attempts with progressive lockout
    let currentMaxAttempts = this.maxAttempts;
    if (this.progressiveLockout && attemptData.lockouts > 0) {
      currentMaxAttempts = Math.max(1, this.maxAttempts - attemptData.lockouts);
    }

    const allowed = attemptData.count < currentMaxAttempts;
    
    return {
      allowed,
      reason: allowed ? 'ALLOWED' : 'RATE_LIMITED',
      resetTime: attemptData.resetTime,
      remainingAttempts: Math.max(0, currentMaxAttempts - attemptData.count),
      lockoutLevel: attemptData.lockouts
    };
  }

  // Record login attempt
  async recordAttempt(ip = 'unknown', deviceFingerprint = null, success = false) {
    const deviceId = deviceFingerprint?.id || 'unknown';
    const key = this.getAttemptKey(ip, deviceId);
    const now = Date.now();

    if (success) {
      // Clear attempts on successful login
      this.attempts.delete(key);
      this.deviceAttempts.delete(deviceId);
      return;
    }

    // Record failed attempt
    const attemptData = this.attempts.get(key) || {
      count: 0,
      resetTime: now + this.windowMs,
      lockouts: 0
    };

    // Reset if window expired
    if (now >= attemptData.resetTime) {
      attemptData.count = 0;
      attemptData.resetTime = now + this.windowMs;
    }

    attemptData.count++;

    // Check if should lockout
    let currentMaxAttempts = this.maxAttempts;
    if (this.progressiveLockout && attemptData.lockouts > 0) {
      currentMaxAttempts = Math.max(1, this.maxAttempts - attemptData.lockouts);
    }

    if (attemptData.count >= currentMaxAttempts) {
      attemptData.lockouts++;
      attemptData.resetTime = now + (this.windowMs * attemptData.lockouts); // Progressive timeout
      
      // Mark IP as suspicious after multiple lockouts
      if (attemptData.lockouts >= 3) {
        this.suspiciousIPs.add(ip);
        console.warn(`IP ${ip} marked as suspicious due to repeated failed attempts`);
      }
    }

    this.attempts.set(key, attemptData);

    // Track device-specific attempts
    const deviceAttempts = this.deviceAttempts.get(deviceId) || { total: 0, ips: new Set() };
    deviceAttempts.total++;
    deviceAttempts.ips.add(ip);
    this.deviceAttempts.set(deviceId, deviceAttempts);

    // Alert on suspicious device behavior
    if (deviceAttempts.ips.size > 3) {
      console.warn(`Suspicious device behavior detected: Device ${deviceId} used from ${deviceAttempts.ips.size} different IPs`);
    }
  }

  // Get attempt statistics
  getStats(ip = 'unknown', deviceFingerprint = null) {
    const deviceId = deviceFingerprint?.id || 'unknown';
    const key = this.getAttemptKey(ip, deviceId);
    const attemptData = this.attempts.get(key);
    const deviceData = this.deviceAttempts.get(deviceId);

    return {
      attempts: attemptData?.count || 0,
      lockouts: attemptData?.lockouts || 0,
      resetTime: attemptData?.resetTime || null,
      deviceAttempts: deviceData?.total || 0,
      uniqueIPs: deviceData?.ips?.size || 0,
      isIPSuspicious: this.suspiciousIPs.has(ip)
    };
  }

  // Clean up old data
  cleanup() {
    const now = Date.now();
    
    // Clean up expired attempts
    for (const [key, data] of this.attempts.entries()) {
      if (now >= data.resetTime && data.count === 0) {
        this.attempts.delete(key);
      }
    }

    // Clean up old device data (older than 24 hours)
    const dayAgo = now - (24 * 60 * 60 * 1000);
    for (const [deviceId, data] of this.deviceAttempts.entries()) {
      if (data.lastAttempt && data.lastAttempt < dayAgo) {
        this.deviceAttempts.delete(deviceId);
      }
    }
  }
}

// Security headers and CSP
export const securityHeaders = {
  // Set security headers
  setupHeaders() {
    // Content Security Policy
    const csp = [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: https: blob:",
      "connect-src 'self' https: wss:",
      "media-src 'self'",
      "object-src 'none'",
      "frame-ancestors 'none'",
      "form-action 'self'",
      "upgrade-insecure-requests"
    ].join('; ');

    // Add meta tag for CSP
    let cspMeta = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
    if (!cspMeta) {
      cspMeta = document.createElement('meta');
      cspMeta.setAttribute('http-equiv', 'Content-Security-Policy');
      document.head.appendChild(cspMeta);
    }
    cspMeta.setAttribute('content', csp);

    // Add other security headers via meta tags where possible
    this.addMetaTag('referrer', 'strict-origin-when-cross-origin');
    this.addMetaTag('X-Content-Type-Options', 'nosniff');
    this.addMetaTag('X-Frame-Options', 'DENY');
  },

  // Add meta tag helper
  addMetaTag(name, content) {
    let meta = document.querySelector(`meta[name="${name}"], meta[http-equiv="${name}"]`);
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute(name.startsWith('X-') ? 'http-equiv' : 'name', name);
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', content);
  }
};

// Initialize security features
export const initializeSecurity = async () => {
  try {
    // Setup security headers
    securityHeaders.setupHeaders();

    // Initialize rate limiter
    const rateLimiter = new AdvancedRateLimiter({
      maxAttempts: 3,
      windowMs: 30 * 60 * 1000, // 30 minutes
      progressiveLockout: true
    });

    // Check biometric availability
    const biometricAvailable = await biometricAuth.isAvailable();
    
    // Generate device fingerprint
    const deviceFingerprint = await generateDeviceFingerprint();

    console.log('Security features initialized:', {
      biometricAvailable,
      deviceSecurity: deviceFingerprint.securityLevel,
      rateLimiterActive: true
    });

    return {
      rateLimiter,
      biometricAvailable,
      deviceFingerprint,
      securityLevel: deviceFingerprint.securityLevel
    };
  } catch (error) {
    console.error('Security initialization failed:', error);
    return {
      rateLimiter: new AdvancedRateLimiter(),
      biometricAvailable: false,
      deviceFingerprint: { id: 'unknown', securityLevel: 'low' },
      securityLevel: 'low'
    };
  }
};

// Export singleton instances
export const adminRateLimiter = new AdvancedRateLimiter({
  maxAttempts: 3,
  windowMs: 30 * 60 * 1000,
  progressiveLockout: true
});

export default {
  generateDeviceFingerprint,
  biometricAuth,
  AdvancedRateLimiter,
  securityHeaders,
  initializeSecurity,
  adminRateLimiter
};
