/**
 * Network-Safe External Resource Loader
 * Handles external scripts, fonts, and APIs with fallbacks
 */

export class ResourceLoader {
  constructor() {
    this.loadedResources = new Set();
    this.failedResources = new Set();
    this.loadingPromises = new Map();
  }

  /**
   * Load external script with fallback
   */
  async loadScript(src, options = {}) {
    const {
      timeout = 10000,
      fallback = null,
      id = null,
      onError = null
    } = options;

    // Check if already loaded
    if (this.loadedResources.has(src)) {
      return { success: true, cached: true };
    }

    // Check if already failed
    if (this.failedResources.has(src)) {
      console.warn(`🚫 Script ${src} previously failed, skipping`);
      return { success: false, error: 'Previously failed', fallback };
    }

    // Check if currently loading
    if (this.loadingPromises.has(src)) {
      return await this.loadingPromises.get(src);
    }

    const loadPromise = new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = src;
      if (id) script.id = id;
      script.async = true;
      script.defer = true;

      const timeoutId = setTimeout(() => {
        cleanup();
        console.warn(`⏰ Script loading timeout: ${src}`);
        this.failedResources.add(src);
        resolve({ success: false, error: 'Timeout', fallback });
      }, timeout);

      const cleanup = () => {
        clearTimeout(timeoutId);
        script.onload = null;
        script.onerror = null;
        this.loadingPromises.delete(src);
      };

      script.onload = () => {
        cleanup();
        this.loadedResources.add(src);
        console.log(`✅ Script loaded: ${src}`);
        resolve({ success: true });
      };

      script.onerror = () => {
        cleanup();
        this.failedResources.add(src);
        const errorMsg = `Failed to load script: ${src}`;
        console.warn(`❌ ${errorMsg}`);
        
        if (onError) {
          onError(new Error(errorMsg));
        }
        
        resolve({ success: false, error: errorMsg, fallback });
      };

      document.head.appendChild(script);
    });

    this.loadingPromises.set(src, loadPromise);
    return await loadPromise;
  }

  /**
   * Load external CSS with fallback
   */
  async loadCSS(href, options = {}) {
    const {
      timeout = 5000,
      fallback = null,
      id = null
    } = options;

    // Check if already loaded
    if (this.loadedResources.has(href)) {
      return { success: true, cached: true };
    }

    return new Promise((resolve) => {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = href;
      if (id) link.id = id;

      const timeoutId = setTimeout(() => {
        console.warn(`⏰ CSS loading timeout: ${href}`);
        this.failedResources.add(href);
        resolve({ success: false, error: 'Timeout', fallback });
      }, timeout);

      link.onload = () => {
        clearTimeout(timeoutId);
        this.loadedResources.add(href);
        console.log(`✅ CSS loaded: ${href}`);
        resolve({ success: true });
      };

      link.onerror = () => {
        clearTimeout(timeoutId);
        this.failedResources.add(href);
        console.warn(`❌ Failed to load CSS: ${href}`);
        resolve({ success: false, error: 'Load failed', fallback });
      };

      document.head.appendChild(link);
    });
  }

  /**
   * Load external API with timeout and retry
   */
  async loadAPI(url, options = {}) {
    const {
      method = 'GET',
      timeout = 5000,
      retries = 2,
      fallback = null,
      headers = {}
    } = options;

    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);

        const response = await fetch(url, {
          method,
          headers: {
            'Content-Type': 'application/json',
            ...headers
          },
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();
        return { success: true, data };

      } catch (error) {
        const isLastAttempt = attempt === retries;
        const errorMsg = `API call failed (attempt ${attempt + 1}/${retries + 1}): ${error.message}`;
        
        if (isLastAttempt) {
          console.warn(`❌ ${errorMsg}`);
          return { success: false, error: error.message, fallback };
        } else {
          console.warn(`⚠️ ${errorMsg}, retrying...`);
          await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)));
        }
      }
    }
  }

  /**
   * Preload critical resources
   */
  async preloadCriticalResources() {
    const criticalResources = [
      // Google Fonts fallback
      {
        type: 'css',
        url: 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
        fallback: () => this.setupFontFallbacks()
      }
    ];

    const results = await Promise.allSettled(
      criticalResources.map(async (resource) => {
        try {
          if (resource.type === 'css') {
            return await this.loadCSS(resource.url, { fallback: resource.fallback });
          } else if (resource.type === 'script') {
            return await this.loadScript(resource.url, { fallback: resource.fallback });
          }
        } catch (error) {
          console.warn(`Failed to preload ${resource.url}:`, error);
          if (resource.fallback) resource.fallback();
          return { success: false, error: error.message };
        }
      })
    );

    console.log('🚀 Critical resources preload completed:', results);
  }

  /**
   * Setup font fallbacks if Google Fonts fail
   */
  setupFontFallbacks() {
    const fallbackCSS = `
      :root {
        font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      .font-inter {
        font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
    `;

    const style = document.createElement('style');
    style.textContent = fallbackCSS;
    document.head.appendChild(style);
    console.log('🔤 Font fallbacks applied');
  }

  /**
   * Handle OAuth script loading with fallbacks
   */
  async loadOAuthScript(provider) {
    const oauthScripts = {
      google: 'https://accounts.google.com/gsi/client',
      apple: 'https://appleid.cdn-apple.com/appleauth/static/jsapi/appleid.auth.js'
    };

    const scriptUrl = oauthScripts[provider];
    if (!scriptUrl) {
      return { success: false, error: 'Unknown OAuth provider' };
    }

    const result = await this.loadScript(scriptUrl, {
      timeout: 15000,
      id: `${provider}-oauth`,
      fallback: () => {
        console.log(`🔒 ${provider} OAuth unavailable - manual login only`);
        // Hide OAuth buttons or show manual login
        const oauthButtons = document.querySelectorAll(`[data-oauth="${provider}"]`);
        oauthButtons.forEach(btn => {
          btn.style.display = 'none';
        });
      }
    });

    return result;
  }

  /**
   * Monitor and report network status
   */
  setupNetworkMonitoring() {
    let isOnline = navigator.onLine;

    const updateNetworkStatus = (online) => {
      if (online !== isOnline) {
        isOnline = online;
        console.log(`🌐 Network status: ${online ? 'Online' : 'Offline'}`);
        
        // Clear failed resources when back online
        if (online) {
          this.failedResources.clear();
          console.log('🔄 Cleared failed resources cache');
        }

        // Dispatch custom event
        window.dispatchEvent(new CustomEvent('networkStatusChange', {
          detail: { online, timestamp: Date.now() }
        }));
      }
    };

    window.addEventListener('online', () => updateNetworkStatus(true));
    window.addEventListener('offline', () => updateNetworkStatus(false));

    // Initial check
    updateNetworkStatus(navigator.onLine);
  }

  /**
   * Get status report
   */
  getStatus() {
    return {
      loaded: Array.from(this.loadedResources),
      failed: Array.from(this.failedResources),
      loading: Array.from(this.loadingPromises.keys()),
      online: navigator.onLine
    };
  }
}

// Create singleton instance
const resourceLoader = new ResourceLoader();

// Initialize monitoring
resourceLoader.setupNetworkMonitoring();

export default resourceLoader;

// Export convenience methods
export const {
  loadScript,
  loadCSS,
  loadAPI,
  preloadCriticalResources,
  loadOAuthScript,
  getStatus
} = resourceLoader;
