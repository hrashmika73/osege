// Avatar helper to generate consistent placeholder avatars
// This prevents network errors from external image URLs

export const generateAvatar = (name, index = 0) => {
  // Generate a consistent color based on name or index
  const colors = [
    '#F0B90B', // Gold
    '#00D084', // Green  
    '#F6465D', // Red
    '#00D2FF', // Cyan
    '#8B5CF6', // Purple
    '#F59E0B', // Orange
    '#10B981', // Emerald
    '#3B82F6', // Blue
  ];
  
  const colorIndex = index % colors.length;
  const color = colors[colorIndex];
  
  // Get initials from name
  const initials = name
    ? name.split(' ')
        .map(word => word[0])
        .join('')
        .toUpperCase()
        .slice(0, 2)
    : 'U';

  // Create a data URL for the avatar
  return `data:image/svg+xml;base64,${btoa(`
    <svg width="150" height="150" viewBox="0 0 150 150" xmlns="http://www.w3.org/2000/svg">
      <rect width="150" height="150" fill="${color}"/>
      <text x="75" y="85" font-family="Arial, sans-serif" font-size="60" font-weight="bold" 
            text-anchor="middle" fill="white">${initials}</text>
    </svg>
  `)}`;
};

// Pre-defined avatar URLs for common use cases
export const defaultAvatars = {
  user1: generateAvatar('John Smith', 0),
  user2: generateAvatar('Sarah Johnson', 1), 
  user3: generateAvatar('Michael Chen', 2),
  user4: generateAvatar('Emily Rodriguez', 3),
  user5: generateAvatar('David Wilson', 4),
  support: generateAvatar('Support', 5),
  admin: generateAvatar('Admin', 6),
  default: generateAvatar('User', 7)
};

export default {
  generateAvatar,
  defaultAvatars
};
