/**
 * Cross-Platform Biometric Authentication
 * Enhanced support for PC and mobile devices
 */

// Device detection utilities
export const deviceDetection = {
  isMobile: () => {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  },
  
  isIOS: () => {
    return /iPad|iPhone|iPod/.test(navigator.userAgent);
  },
  
  isAndroid: () => {
    return /Android/.test(navigator.userAgent);
  },
  
  isWindows: () => {
    return /Win/.test(navigator.platform);
  },
  
  isMac: () => {
    return /Mac/.test(navigator.platform);
  },
  
  hasTouch: () => {
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  },
  
  getDeviceType: () => {
    if (deviceDetection.isMobile()) {
      return deviceDetection.isIOS() ? 'iOS' : 
             deviceDetection.isAndroid() ? 'Android' : 'Mobile';
    }
    return deviceDetection.isWindows() ? 'Windows' : 
           deviceDetection.isMac() ? 'macOS' : 'Desktop';
  }
};

// Enhanced biometric authentication with cross-platform support
export const enhancedBiometricAuth = {
  // Check availability with device-specific optimizations
  async isAvailable() {
    try {
      // Check basic WebAuthn support
      if (!window.PublicKeyCredential) {
        console.log('WebAuthn not supported on this browser');
        return false;
      }

      // Check for platform authenticator
      const platformSupport = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      
      if (!platformSupport) {
        console.log('Platform authenticator not available');
        return false;
      }

      // Device-specific checks
      const deviceType = deviceDetection.getDeviceType();
      console.log(`Biometric check on ${deviceType}:`, { platformSupport });

      return {
        available: true,
        deviceType,
        capabilities: await this.getCapabilities()
      };
    } catch (error) {
      console.warn('Biometric availability check failed:', error);
      return false;
    }
  },

  // Get device capabilities
  async getCapabilities() {
    const capabilities = {
      touch: deviceDetection.hasTouch(),
      mobile: deviceDetection.isMobile(),
      platform: deviceDetection.getDeviceType(),
      userAgent: navigator.userAgent
    };

    // Check for specific biometric features
    if (deviceDetection.isIOS()) {
      capabilities.faceID = true;
      capabilities.touchID = true;
    } else if (deviceDetection.isAndroid()) {
      capabilities.fingerprint = true;
      capabilities.faceUnlock = true;
    } else if (deviceDetection.isWindows()) {
      capabilities.windowsHello = true;
      capabilities.fingerprint = true;
      capabilities.faceRecognition = true;
    } else if (deviceDetection.isMac()) {
      capabilities.touchID = true;
      capabilities.faceID = true;
    }

    return capabilities;
  },

  // Register with device-optimized settings
  async register(userId, userName) {
    try {
      const availability = await this.isAvailable();
      if (!availability || !availability.available) {
        throw new Error('Biometric authentication not available');
      }

      const challenge = window.crypto.getRandomValues(new Uint8Array(32));
      const deviceType = availability.deviceType;
      
      // Device-optimized options
      const baseOptions = {
        challenge,
        rp: {
          name: "KleverInvest Admin",
          id: window.location.hostname
        },
        user: {
          id: new TextEncoder().encode(userId),
          name: userName,
          displayName: userName
        },
        pubKeyCredParams: [
          { alg: -7, type: "public-key" },   // ES256
          { alg: -257, type: "public-key" }  // RS256
        ],
        timeout: deviceDetection.isMobile() ? 120000 : 60000, // Longer timeout for mobile
        attestation: "direct"
      };

      // Platform-specific authenticator selection
      if (deviceDetection.isMobile()) {
        baseOptions.authenticatorSelection = {
          authenticatorAttachment: "platform",
          userVerification: "required",
          requireResidentKey: false
        };
      } else {
        baseOptions.authenticatorSelection = {
          authenticatorAttachment: "platform", 
          userVerification: "preferred",
          requireResidentKey: true
        };
      }

      // iOS-specific optimizations
      if (deviceDetection.isIOS()) {
        baseOptions.extensions = {
          largeBlob: { support: "preferred" }
        };
      }

      const credential = await navigator.credentials.create({
        publicKey: baseOptions
      });

      if (credential) {
        const credentialInfo = {
          id: credential.id,
          rawId: Array.from(new Uint8Array(credential.rawId)),
          type: credential.type,
          publicKey: Array.from(new Uint8Array(credential.response.publicKey)),
          userId: userId,
          deviceType: deviceType,
          registeredAt: new Date().toISOString(),
          capabilities: availability.capabilities
        };

        // Store with device-specific key
        const storageKey = `biometric_${deviceType}_${userId}`;
        localStorage.setItem(storageKey, JSON.stringify(credentialInfo));
        
        return {
          success: true,
          credentialId: credential.id,
          deviceType: deviceType,
          message: `Biometric authentication registered successfully on ${deviceType}`
        };
      }
      
      throw new Error('Failed to create credential');
    } catch (error) {
      console.error('Biometric registration failed:', error);
      return {
        success: false,
        error: error.message,
        suggestion: this.getErrorSuggestion(error)
      };
    }
  },

  // Authenticate with device optimization
  async authenticate(userId) {
    try {
      const availability = await this.isAvailable();
      if (!availability || !availability.available) {
        throw new Error('Biometric authentication not available');
      }

      const deviceType = availability.deviceType;
      const storageKey = `biometric_${deviceType}_${userId}`;
      const storedCredential = localStorage.getItem(storageKey);
      
      if (!storedCredential) {
        throw new Error(`No biometric credential found for ${deviceType}`);
      }

      const credentialInfo = JSON.parse(storedCredential);
      const challenge = window.crypto.getRandomValues(new Uint8Array(32));

      const requestOptions = {
        challenge,
        allowCredentials: [{
          id: new Uint8Array(credentialInfo.rawId),
          type: 'public-key',
          transports: deviceDetection.isMobile() 
            ? ['internal'] 
            : ['internal', 'usb', 'nfc', 'ble']
        }],
        userVerification: 'required',
        timeout: deviceDetection.isMobile() ? 120000 : 60000
      };

      const assertion = await navigator.credentials.get({
        publicKey: requestOptions
      });

      if (assertion) {
        // Update last used
        credentialInfo.lastUsed = new Date().toISOString();
        localStorage.setItem(storageKey, JSON.stringify(credentialInfo));
        
        return {
          success: true,
          credentialId: assertion.id,
          deviceType: deviceType,
          message: `Biometric authentication successful on ${deviceType}`,
          lastUsed: credentialInfo.lastUsed
        };
      }

      throw new Error('Biometric authentication failed');
    } catch (error) {
      console.error('Biometric authentication failed:', error);
      return {
        success: false,
        error: error.message,
        suggestion: this.getErrorSuggestion(error)
      };
    }
  },

  // Check if user has registered biometric for current device
  isRegistered(userId) {
    const deviceType = deviceDetection.getDeviceType();
    const storageKey = `biometric_${deviceType}_${userId}`;
    return !!localStorage.getItem(storageKey);
  },

  // Remove biometric credential for current device
  remove(userId) {
    const deviceType = deviceDetection.getDeviceType();
    const storageKey = `biometric_${deviceType}_${userId}`;
    localStorage.removeItem(storageKey);
  },

  // Get error suggestions based on device type
  getErrorSuggestion(error) {
    const deviceType = deviceDetection.getDeviceType();
    const errorMessage = error.message.toLowerCase();

    if (errorMessage.includes('not allowed')) {
      if (deviceDetection.isMobile()) {
        return 'Please enable biometric authentication in your device settings and try again.';
      }
      return 'Please ensure biometric authentication is enabled in your system settings.';
    }

    if (errorMessage.includes('timeout')) {
      return 'Authentication timed out. Please try again and respond to the biometric prompt quickly.';
    }

    if (errorMessage.includes('not supported')) {
      return `Biometric authentication is not supported on this ${deviceType} device or browser.`;
    }

    if (errorMessage.includes('cancelled')) {
      return 'Authentication was cancelled. Please try again and complete the biometric scan.';
    }

    switch (deviceType) {
      case 'iOS':
        return 'Please use Face ID or Touch ID when prompted.';
      case 'Android':
        return 'Please use your fingerprint or face unlock when prompted.';
      case 'Windows':
        return 'Please use Windows Hello, fingerprint, or face recognition when prompted.';
      case 'macOS':
        return 'Please use Touch ID or Face ID when prompted.';
      default:
        return 'Please complete the biometric authentication when prompted.';
    }
  },

  // Get user-friendly device capabilities description
  getCapabilitiesDescription() {
    const deviceType = deviceDetection.getDeviceType();
    const hasTouch = deviceDetection.hasTouch();

    const descriptions = {
      'iOS': hasTouch ? 'Face ID or Touch ID' : 'Face ID',
      'Android': 'Fingerprint or Face Unlock',
      'Windows': 'Windows Hello, Fingerprint, or Face Recognition',
      'macOS': 'Touch ID or Face ID',
      'Desktop': 'Platform Biometric Authentication',
      'Mobile': 'Device Biometric Authentication'
    };

    return descriptions[deviceType] || 'Biometric Authentication';
  }
};

export default enhancedBiometricAuth;
