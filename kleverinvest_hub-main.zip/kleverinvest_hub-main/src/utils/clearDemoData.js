/**
 * Utility to clear all demo/mock data from localStorage
 * Call this function to ensure a clean start for new accounts
 */

export const clearAllDemoData = () => {
  const demoDataKeys = [
    // Admin data keys
    'admin_banned_users',
    'admin_active_users', 
    'admin_users_data',
    'admin_pending_deposits',
    'admin_pending_withdraws',
    'admin_transactions',
    'admin_kyc_pending',
    'admin_system_logs',
    'admin_investment_plans',
    'admin_site_settings',
    'admin_gateway_settings',
    'admin_payment_gateways',
    
    // User data keys  
    'user_investments',
    'user_transactions',
    'user_profile_data',
    'user_notifications',
    'user_referrals',
    'user_kyc_data',
    
    // System data keys
    'system_analytics',
    'market_data',
    'btc_price_history',
    'earnings_calculations',
    
    // Auth related demo data
    'demo_accounts',
    'mock_sessions'
  ];
  
  // Clear all demo data keys
  demoDataKeys.forEach(key => {
    localStorage.removeItem(key);
  });
  
  console.log('All demo data cleared successfully');
  
  // Optional: Also clear any keys that contain 'mock', 'demo', or 'test'
  const allKeys = Object.keys(localStorage);
  const demoKeys = allKeys.filter(key => 
    key.toLowerCase().includes('mock') ||
    key.toLowerCase().includes('demo') ||
    key.toLowerCase().includes('test') ||
    key.toLowerCase().includes('example')
  );
  
  demoKeys.forEach(key => {
    localStorage.removeItem(key);
  });
  
  if (demoKeys.length > 0) {
    console.log('Additional demo keys removed:', demoKeys);
  }
  
  return {
    removedKeys: [...demoDataKeys, ...demoKeys],
    totalRemoved: demoDataKeys.length + demoKeys.length
  };
};

/**
 * Check if demo data exists in localStorage
 */
export const hasDemoData = () => {
  const demoDataKeys = [
    'admin_banned_users',
    'admin_active_users', 
    'admin_users_data'
  ];
  
  return demoDataKeys.some(key => localStorage.getItem(key) !== null);
};

/**
 * Initialize clean admin environment 
 */
export const initializeCleanAdmin = () => {
  clearAllDemoData();
  
  // Set up clean initial structures if needed
  const cleanStructures = {
    'admin_banned_users': [],
    'admin_active_users': [],
    'admin_users_data': [],
    'admin_pending_deposits': [],
    'admin_pending_withdraws': [],
    'admin_transactions': [],
    'admin_kyc_pending': []
  };
  
  Object.entries(cleanStructures).forEach(([key, value]) => {
    localStorage.setItem(key, JSON.stringify(value));
  });
  
  console.log('Clean admin environment initialized');
};

// Auto-run cleanup on import if in development
if (process.env.NODE_ENV === 'development') {
  // Uncomment the line below to auto-clear demo data in development
  // clearAllDemoData();
}
