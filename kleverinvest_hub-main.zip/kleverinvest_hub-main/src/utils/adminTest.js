// Admin testing utility
export const setupAdminTest = () => {
  // Set up admin authentication for testing
  const adminUser = {
    id: 2,
    name: 'Admin User',
    email: 'admin@kleverinvest.com',
    role: 'admin',
    verified: true,
    memberSince: new Date().toISOString().split('T')[0],
    balance: 0,
    wallet: null,
    username: 'Admin'
  };

  const token = `admin_test_token_${Date.now()}`;

  // Store admin credentials in localStorage
  localStorage.setItem('userToken', token);
  localStorage.setItem('userData', JSON.stringify(adminUser));
  localStorage.setItem('userRole', 'admin');

  console.log('Admin test user setup complete');
  return adminUser;
};

export const clearAdminTest = () => {
  localStorage.removeItem('userToken');
  localStorage.removeItem('userData');
  localStorage.removeItem('userRole');
  console.log('Admin test data cleared');
};

export const testAdminNavigation = () => {
  const routes = [
    '/admin-dashboard',
    '/admin-user-management-enhanced',
    '/admin-payment-gateway',
    '/admin-transaction-management',
    '/admin-system-analytics',
    '/admin-system-logs',
    '/admin-site-settings',
    '/support-chat-system'
  ];

  console.log('Testing admin navigation routes:', routes);
  return routes;
};
