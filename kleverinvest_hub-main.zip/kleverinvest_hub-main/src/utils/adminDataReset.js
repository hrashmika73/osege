/**
 * Admin Data Reset Utility
 * Helps test and reset admin data to verify deletion fixes
 */

export const resetAdminData = () => {
  try {
    console.log('🔄 Resetting admin data to test state...');
    
    // Clear all admin data
    const adminKeys = [
      'admin_users_data',
      'admin_active_users',
      'admin_banned_users',
      'admin_pending_kyc'
    ];
    
    adminKeys.forEach(key => {
      localStorage.removeItem(key);
      console.log(`✅ Cleared ${key}`);
    });
    
    // This will trigger the first-time setup when next accessed
    console.log('🎯 Admin data reset complete - next load will use mock data');
    
    return {
      success: true,
      message: 'Admin data reset successfully',
      nextAction: 'Refresh page to see mock users, then test deletion'
    };
    
  } catch (error) {
    console.error('❌ Error resetting admin data:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

export const forceEmptyState = () => {
  try {
    console.log('📭 Forcing empty user state...');
    
    // Set empty arrays to simulate all users deleted
    localStorage.setItem('admin_users_data', '[]');
    localStorage.setItem('admin_active_users', '[]');
    localStorage.setItem('admin_banned_users', '[]');
    localStorage.setItem('admin_pending_kyc', '[]');
    
    console.log('✅ All admin data set to empty arrays');
    
    return {
      success: true,
      message: 'Forced empty state - admin should show no users',
      nextAction: 'Refresh page to verify no users appear'
    };
    
  } catch (error) {
    console.error('❌ Error forcing empty state:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

export const checkCurrentState = () => {
  try {
    console.log('🔍 Checking current admin data state...');
    
    const state = {};
    const keys = [
      'admin_users_data',
      'admin_active_users', 
      'admin_banned_users',
      'admin_pending_kyc'
    ];
    
    keys.forEach(key => {
      const exists = localStorage.getItem(key) !== null;
      let data = [];
      let count = 0;
      
      if (exists) {
        try {
          data = JSON.parse(localStorage.getItem(key) || '[]');
          count = Array.isArray(data) ? data.length : 0;
        } catch (error) {
          data = 'ERROR: Invalid JSON';
          count = 0;
        }
      }
      
      state[key] = {
        exists,
        count,
        data: exists ? data : 'NOT_SET'
      };
    });
    
    console.log('📊 Current state:', state);
    
    const totalUsers = state.admin_users_data.count;
    const adminUsersExists = state.admin_users_data.exists;
    
    return {
      state,
      summary: {
        adminUsersKeyExists: adminUsersExists,
        totalUsers,
        isEmpty: adminUsersExists && totalUsers === 0,
        isFirstTime: !adminUsersExists
      }
    };
    
  } catch (error) {
    console.error('❌ Error checking state:', error);
    return {
      error: error.message
    };
  }
};

export const testDeletionFlow = async () => {
  try {
    console.log('🧪 Testing complete deletion flow...');
    
    // Step 1: Check initial state
    const initialState = checkCurrentState();
    console.log('1️⃣ Initial state:', initialState.summary);
    
    // Step 2: Ensure we have users to delete
    if (initialState.summary.totalUsers === 0) {
      console.log('2️⃣ No users found, resetting to get mock users...');
      resetAdminData();
      
      // Wait a moment and check again
      setTimeout(async () => {
        const afterReset = checkCurrentState();
        console.log('2️⃣ After reset:', afterReset.summary);
        
        if (afterReset.summary.totalUsers === 0) {
          console.log('2️⃣ Still no users - triggering API call to initialize...');
          try {
            const { adminUserAPI } = await import('../services/adminApiService');
            const response = await adminUserAPI.getUsers();
            console.log('2️⃣ API response:', response);
          } catch (error) {
            console.warn('API call failed:', error);
          }
        }
      }, 100);
    }
    
    // Step 3: Delete all users
    console.log('3️⃣ Deleting all users...');
    forceEmptyState();
    
    // Step 4: Check final state
    const finalState = checkCurrentState();
    console.log('4️⃣ Final state:', finalState.summary);
    
    // Step 5: Test API response
    console.log('5️⃣ Testing API response with empty state...');
    try {
      const { adminUserAPI } = await import('../services/adminApiService');
      const response = await adminUserAPI.getUsers();
      console.log('5️⃣ API response with empty localStorage:', response);
      
      const userCount = response?.data?.users?.length || 0;
      console.log('5️⃣ Users returned by API:', userCount);
      
      if (userCount === 0) {
        console.log('✅ DELETION FIX WORKING - API returns no users when localStorage is empty');
        return { 
          success: true, 
          message: 'Deletion fix is working correctly',
          usersReturned: userCount
        };
      } else {
        console.log('❌ DELETION FIX NOT WORKING - API still returns users from mock data');
        return { 
          success: false, 
          message: 'Deletion fix needs more work - mock users still returned',
          usersReturned: userCount
        };
      }
    } catch (error) {
      console.error('❌ Error testing API:', error);
      return {
        success: false,
        error: error.message
      };
    }
    
  } catch (error) {
    console.error('❌ Error in deletion flow test:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

// Auto-expose for debugging
if (typeof window !== 'undefined') {
  window.resetAdminData = resetAdminData;
  window.forceEmptyState = forceEmptyState;
  window.checkCurrentState = checkCurrentState;
  window.testDeletionFlow = testDeletionFlow;
}

export default {
  resetAdminData,
  forceEmptyState,
  checkCurrentState,
  testDeletionFlow
};
