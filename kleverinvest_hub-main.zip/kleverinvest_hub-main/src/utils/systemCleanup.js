/**
 * System Data Cleanup Utility
 * Ensures localStorage data consistency and fixes common data issues
 */

export const cleanupSystemData = () => {
  try {
    console.log('🧹 Starting system data cleanup...');
    
    const keysToClean = [
      'admin_users_data',
      'admin_pending_kyc', 
      'user_session_data',
      'admin_transactions',
      'admin_data'
    ];

    let cleanedCount = 0;
    let fixedCount = 0;

    keysToClean.forEach(key => {
      try {
        const rawData = localStorage.getItem(key);
        
        if (rawData) {
          // Try to parse the data
          const parsedData = JSON.parse(rawData);
          
          // Clean and validate the data
          const cleanedData = cleanAndValidateData(key, parsedData);
          
          // Re-save cleaned data
          localStorage.setItem(key, JSON.stringify(cleanedData));
          cleanedCount++;
          
          console.log(`✅ Cleaned ${key}: ${Array.isArray(cleanedData) ? cleanedData.length : 'object'} items`);
        }
      } catch (error) {
        console.warn(`⚠️ Error cleaning ${key}, removing corrupted data:`, error.message);
        localStorage.removeItem(key);
        fixedCount++;
      }
    });

    // Fix any missing required data
    fixMissingData();

    console.log(`🎉 System cleanup completed: ${cleanedCount} cleaned, ${fixedCount} fixed`);
    
    return {
      success: true,
      cleaned: cleanedCount,
      fixed: fixedCount,
      message: 'System data cleanup completed successfully'
    };
    
  } catch (error) {
    console.error('❌ System cleanup failed:', error);
    return {
      success: false,
      error: error.message,
      message: 'System cleanup failed'
    };
  }
};

const cleanAndValidateData = (key, data) => {
  switch (key) {
    case 'admin_users_data':
      return cleanUsersData(data);
    case 'admin_pending_kyc':
      return cleanKycData(data);
    case 'admin_transactions':
      return cleanTransactionsData(data);
    default:
      return data;
  }
};

const cleanUsersData = (users) => {
  if (!Array.isArray(users)) return [];
  
  return users.map(user => ({
    ...user,
    id: user.id || generateId(),
    status: user.status || 'active',
    balance: parseFloat(user.balance) || 0,
    kycStatus: user.kycStatus || 'pending',
    registrationDate: user.registrationDate || new Date().toISOString(),
    lastActive: user.lastActive || new Date().toISOString()
  })).filter(user => user.email && user.username);
};

const cleanKycData = (kycRequests) => {
  if (!Array.isArray(kycRequests)) return [];
  
  return kycRequests.map(request => ({
    ...request,
    id: request.id || generateId(),
    status: request.status || 'pending',
    submittedAt: request.submittedAt || new Date().toISOString()
  })).filter(request => request.userId);
};

const cleanTransactionsData = (transactions) => {
  if (!Array.isArray(transactions)) return [];
  
  return transactions.map(tx => ({
    ...tx,
    id: tx.id || generateId(),
    amount: parseFloat(tx.amount) || 0,
    status: tx.status || 'pending',
    createdAt: tx.createdAt || new Date().toISOString()
  })).filter(tx => tx.userId && tx.type);
};

const fixMissingData = () => {
  // Ensure admin_users_data exists with at least test data
  if (!localStorage.getItem('admin_users_data')) {
    const defaultUserData = [
      {
        id: 1,
        username: 'testuser',
        email: 'test@example.com',
        fullName: 'Test User',
        status: 'active',
        balance: 1000,
        kycStatus: 'verified',
        registrationDate: new Date().toISOString(),
        lastActive: new Date().toISOString()
      }
    ];
    localStorage.setItem('admin_users_data', JSON.stringify(defaultUserData));
    console.log('📝 Created default user data');
  }

  // Ensure admin_pending_kyc exists
  if (!localStorage.getItem('admin_pending_kyc')) {
    localStorage.setItem('admin_pending_kyc', JSON.stringify([]));
    console.log('📝 Created empty KYC requests');
  }
};

const generateId = () => {
  return Math.random().toString(36).substr(2, 9);
};

// Force refresh all localStorage data
export const forceRefreshData = () => {
  try {
    const result = cleanupSystemData();
    
    // Dispatch custom event to notify all components
    window.dispatchEvent(new CustomEvent('systemDataRefreshed', {
      detail: result
    }));
    
    return result;
  } catch (error) {
    console.error('Force refresh failed:', error);
    return { success: false, error: error.message };
  }
};

// Check data integrity
export const checkDataIntegrity = () => {
  const issues = [];
  
  try {
    // Check users data
    const usersData = localStorage.getItem('admin_users_data');
    if (usersData) {
      const users = JSON.parse(usersData);
      if (!Array.isArray(users)) {
        issues.push('admin_users_data is not an array');
      } else {
        const invalidUsers = users.filter(u => !u.email || !u.username);
        if (invalidUsers.length > 0) {
          issues.push(`${invalidUsers.length} users missing required fields`);
        }
      }
    }

    // Check KYC data
    const kycData = localStorage.getItem('admin_pending_kyc');
    if (kycData) {
      const kyc = JSON.parse(kycData);
      if (!Array.isArray(kyc)) {
        issues.push('admin_pending_kyc is not an array');
      }
    }

    return {
      healthy: issues.length === 0,
      issues,
      lastCheck: new Date().toISOString()
    };
    
  } catch (error) {
    return {
      healthy: false,
      issues: ['Error checking data integrity: ' + error.message],
      lastCheck: new Date().toISOString()
    };
  }
};

export default {
  cleanupSystemData,
  forceRefreshData,
  checkDataIntegrity
};
