/**
 * Fallback User Data Manager
 * Used when main userDataManager fails to load
 */

export const getUserStatistics = () => {
  console.warn('Using fallback user statistics');
  return {
    total: 0,
    active: 0,
    inactive: 0,
    suspended: 0,
    banned: 0,
    verified: 0,
    pending: 0,
    totalBalance: 0,
    totalInvestments: 0,
    newToday: 0,
    newThisWeek: 0
  };
};

export const initializeAdminListeners = (callbacks = {}) => {
  console.warn('Using fallback admin listeners (no-op)');
  return () => {}; // Return empty cleanup function
};

export const getAllUsers = () => {
  console.warn('Using fallback getAllUsers');
  return [];
};

export default {
  getUserStatistics,
  initializeAdminListeners,
  getAllUsers
};
