/**
 * Automated System Issues Fix Utility
 * Detects and automatically resolves common system problems
 */

import { cleanupSystemData, forceRefreshData, checkDataIntegrity } from './systemCleanup.js';

export const detectSystemIssues = async () => {
  const issues = [];
  
  try {
    console.log('🔍 Detecting system issues...');
    
    // Check data integrity
    const dataCheck = checkDataIntegrity();
    if (!dataCheck.healthy) {
      issues.push({
        type: 'data_integrity',
        severity: 'high',
        description: 'Data integrity issues detected',
        details: dataCheck.issues,
        autoFixable: true
      });
    }

    // Check for build warnings (simulated)
    const buildWarnings = checkBuildWarnings();
    if (buildWarnings.length > 0) {
      issues.push({
        type: 'build_warnings',
        severity: 'medium',
        description: 'Build warnings detected',
        details: buildWarnings,
        autoFixable: true
      });
    }

    // Check localStorage corruption
    const storageIssues = checkLocalStorageIssues();
    if (storageIssues.length > 0) {
      issues.push({
        type: 'storage_corruption',
        severity: 'high',
        description: 'localStorage corruption detected',
        details: storageIssues,
        autoFixable: true
      });
    }

    // Check for connection issues
    const connectionIssues = await checkConnectionIssues();
    if (connectionIssues.length > 0) {
      issues.push({
        type: 'connection_issues',
        severity: 'medium',
        description: 'Connection issues detected',
        details: connectionIssues,
        autoFixable: true
      });
    }

    // Check for registration sync issues
    const syncIssues = checkRegistrationSync();
    if (syncIssues.length > 0) {
      issues.push({
        type: 'sync_issues',
        severity: 'medium',
        description: 'Registration sync issues detected',
        details: syncIssues,
        autoFixable: true
      });
    }

    console.log(`📊 System scan complete: ${issues.length} issues detected`);
    
    return {
      hasIssues: issues.length > 0,
      issues,
      scanTime: new Date().toISOString()
    };
    
  } catch (error) {
    console.error('❌ Error detecting system issues:', error);
    return {
      hasIssues: true,
      issues: [{
        type: 'scan_error',
        severity: 'high',
        description: 'Error during system scan',
        details: [error.message],
        autoFixable: false
      }],
      scanTime: new Date().toISOString()
    };
  }
};

export const autoFixSystemIssues = async () => {
  const fixResults = [];
  
  try {
    console.log('🔧 Starting automated system fixes...');
    
    // Fix 1: Clean up data integrity issues
    try {
      const dataCleanup = cleanupSystemData();
      fixResults.push({
        type: 'data_cleanup',
        success: dataCleanup.success,
        message: dataCleanup.message,
        details: dataCleanup
      });
    } catch (error) {
      fixResults.push({
        type: 'data_cleanup',
        success: false,
        message: 'Data cleanup failed',
        error: error.message
      });
    }

    // Fix 2: Refresh localStorage data
    try {
      const refreshResult = forceRefreshData();
      fixResults.push({
        type: 'data_refresh',
        success: refreshResult.success,
        message: 'Data refresh completed',
        details: refreshResult
      });
    } catch (error) {
      fixResults.push({
        type: 'data_refresh',
        success: false,
        message: 'Data refresh failed',
        error: error.message
      });
    }

    // Fix 3: Clear problematic cache
    try {
      clearProblematicCache();
      fixResults.push({
        type: 'cache_clear',
        success: true,
        message: 'Cache cleared successfully'
      });
    } catch (error) {
      fixResults.push({
        type: 'cache_clear',
        success: false,
        message: 'Cache clear failed',
        error: error.message
      });
    }

    // Fix 4: Reset connection status
    try {
      await resetConnectionStatus();
      fixResults.push({
        type: 'connection_reset',
        success: true,
        message: 'Connection status reset'
      });
    } catch (error) {
      fixResults.push({
        type: 'connection_reset',
        success: false,
        message: 'Connection reset failed',
        error: error.message
      });
    }

    // Fix 5: Ensure required data exists
    try {
      ensureRequiredData();
      fixResults.push({
        type: 'data_ensure',
        success: true,
        message: 'Required data ensured'
      });
    } catch (error) {
      fixResults.push({
        type: 'data_ensure',
        success: false,
        message: 'Data ensure failed',
        error: error.message
      });
    }

    const successCount = fixResults.filter(r => r.success).length;
    
    console.log(`✅ System fixes completed: ${successCount}/${fixResults.length} successful`);
    
    // Dispatch system fixed event
    window.dispatchEvent(new CustomEvent('systemIssuesFixed', {
      detail: {
        results: fixResults,
        successCount,
        totalFixes: fixResults.length,
        timestamp: new Date().toISOString()
      }
    }));
    
    return {
      success: successCount > 0,
      results: fixResults,
      summary: `${successCount}/${fixResults.length} fixes applied successfully`,
      timestamp: new Date().toISOString()
    };
    
  } catch (error) {
    console.error('❌ Auto-fix system failed:', error);
    return {
      success: false,
      error: error.message,
      results: fixResults,
      timestamp: new Date().toISOString()
    };
  }
};

// Individual check functions
const checkBuildWarnings = () => {
  const warnings = [];
  
  // Check for common build warning indicators
  if (typeof window !== 'undefined') {
    // These would be detected by actual build process monitoring
    // For now, we'll return empty as warnings are handled in build process
  }
  
  return warnings;
};

const checkLocalStorageIssues = () => {
  const issues = [];
  
  try {
    const keys = ['admin_users_data', 'admin_pending_kyc', 'user_session_data'];
    
    keys.forEach(key => {
      try {
        const data = localStorage.getItem(key);
        if (data) {
          JSON.parse(data); // Test if data is valid JSON
        }
      } catch (error) {
        issues.push(`Corrupted data in ${key}: ${error.message}`);
      }
    });
  } catch (error) {
    issues.push(`localStorage access error: ${error.message}`);
  }
  
  return issues;
};

const checkConnectionIssues = async () => {
  const issues = [];
  
  try {
    // Test if connection manager is available
    if (typeof window !== 'undefined' && window.navigator) {
      if (!window.navigator.onLine) {
        issues.push('Browser reports offline status');
      }
    }
  } catch (error) {
    issues.push(`Connection check failed: ${error.message}`);
  }
  
  return issues;
};

const checkRegistrationSync = () => {
  const issues = [];
  
  try {
    const usersData = localStorage.getItem('admin_users_data');
    const kycData = localStorage.getItem('admin_pending_kyc');
    
    if (!usersData) {
      issues.push('No user registration data found');
    }
    
    if (!kycData) {
      issues.push('No KYC data found');
    }
  } catch (error) {
    issues.push(`Registration sync check failed: ${error.message}`);
  }
  
  return issues;
};

// Individual fix functions
const clearProblematicCache = () => {
  try {
    // Clear any problematic cached data
    const cachesToClear = [
      'app_cache',
      'temp_data',
      'error_logs'
    ];
    
    cachesToClear.forEach(cache => {
      try {
        localStorage.removeItem(cache);
      } catch (error) {
        console.warn(`Could not clear ${cache}:`, error);
      }
    });
  } catch (error) {
    throw new Error(`Cache clearing failed: ${error.message}`);
  }
};

const resetConnectionStatus = async () => {
  try {
    // Reset any cached connection status
    localStorage.removeItem('connection_status');
    localStorage.removeItem('backend_status');
    
    // If connection manager is available, force a reconnection test
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('forceConnectionTest'));
    }
  } catch (error) {
    throw new Error(`Connection reset failed: ${error.message}`);
  }
};

const ensureRequiredData = () => {
  try {
    // Ensure all required localStorage keys exist with valid data
    const requiredKeys = {
      'admin_users_data': [],
      'admin_pending_kyc': [],
      'user_session_data': null
    };
    
    Object.entries(requiredKeys).forEach(([key, defaultValue]) => {
      if (!localStorage.getItem(key)) {
        localStorage.setItem(key, JSON.stringify(defaultValue));
      }
    });
  } catch (error) {
    throw new Error(`Data ensure failed: ${error.message}`);
  }
};

// Public API
export const fixSystemIssues = autoFixSystemIssues;
export const scanForIssues = detectSystemIssues;

export default {
  detectSystemIssues,
  autoFixSystemIssues,
  fixSystemIssues,
  scanForIssues
};
