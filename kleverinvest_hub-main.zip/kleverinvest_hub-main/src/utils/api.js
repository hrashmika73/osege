import axios from 'axios';

// API Configuration - Safe environment variable access
const getEnvVar = (viteName, reactName, defaultValue) => {
  try {
    return (import.meta.env && import.meta.env[viteName]) ||
           (process.env && process.env[reactName]) ||
           defaultValue;
  } catch (error) {
    console.warn(`Environment variable access failed, using default: ${defaultValue}`);
    return defaultValue;
  }
};

const API_BASE_URL = getEnvVar('VITE_API_URL', 'REACT_APP_API_URL', 'http://localhost:3001/api');
const API_TIMEOUT = parseInt(getEnvVar('VITE_API_TIMEOUT', 'REACT_APP_API_TIMEOUT', '10000'));
const ENABLE_BACKEND = getEnvVar('VITE_ENABLE_BACKEND', 'REACT_APP_ENABLE_BACKEND', 'false') === 'true';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: API_TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor for auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Add response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Handle unauthorized access
      localStorage.removeItem('auth_token');
      window.location.href = '/admin-login';
    }
    return Promise.reject(error);
  }
);

// Backend connection test with improved error handling
export const testBackendConnection = async () => {
  try {
    console.log('Testing backend connection to:', API_BASE_URL);

    if (!ENABLE_BACKEND) {
      return {
        success: false,
        message: 'Backend is disabled. Using mock mode.',
        type: 'warning'
      };
    }

    const response = await api.get('/health');
    return {
      success: true,
      message: 'Backend connection successful',
      data: response.data,
      type: 'success'
    };
  } catch (error) {
    console.error('Backend connection failed, falling back to mock mode:', error);

    // Auto-fallback to mock mode when backend is unavailable
    console.warn('Automatically switching to mock mode due to backend unavailability');

    if (error.code === 'ECONNREFUSED' || error.message.includes('Network Error')) {
      return {
        success: false,
        message: 'Backend server unavailable. Switched to mock mode.',
        error: 'Connection refused - backend server not running',
        type: 'warning',
        fallbackToMock: true
      };
    }

    if (error.response) {
      return {
        success: false,
        message: `Backend error: ${error.response.status}. Using mock mode.`,
        error: error.response.data?.message || error.message,
        type: 'warning',
        fallbackToMock: true
      };
    }

    return {
      success: false,
      message: 'Network error. Switched to mock mode.',
      error: error.message,
      type: 'warning',
      fallbackToMock: true
    };
  }
};

// Auth API calls with automatic fallback
export const authAPI = {
  login: async (credentials) => {
    if (!ENABLE_BACKEND) {
      // Mock response for development
      await new Promise(resolve => setTimeout(resolve, 1000));
      if ((credentials.username === 'admin' || credentials.email === 'admin@kleverinvest.com') && credentials.password === 'Admin@123!') {
        return {
          success: true,
          data: {
            token: 'mock-jwt-token',
            user: {
              id: 1,
              username: 'admin',
              email: 'admin@kleverinvest.com',
              role: 'admin'
            }
          }
        };
      }
      throw new Error('Invalid credentials');
    }

    try {
      const response = await api.post('/auth/login', credentials);
      return response.data;
    } catch (error) {
      console.warn('Backend login failed, falling back to mock authentication:', error);
      // Fallback to mock authentication on network error
      if (error.code === 'ECONNREFUSED' || error.message.includes('Network Error')) {
        return authAPI.login({ ...credentials, __mockFallback: true });
      }
      throw error;
    }
  },

  logout: async () => {
    if (!ENABLE_BACKEND) {
      await new Promise(resolve => setTimeout(resolve, 500));
      return { success: true };
    }

    try {
      const response = await api.post('/auth/logout');
      return response.data;
    } catch (error) {
      console.warn('Backend logout failed, using mock response:', error);
      return { success: true };
    }
  },

  verifyToken: async () => {
    if (!ENABLE_BACKEND) {
      await new Promise(resolve => setTimeout(resolve, 500));
      const token = localStorage.getItem('auth_token');
      return {
        success: !!token,
        message: 'Token verification (mock mode)',
        type: 'warning'
      };
    }

    try {
      const response = await api.get('/auth/verify');
      return response.data;
    } catch (error) {
      console.warn('Backend token verification failed, using mock response:', error);
      return {
        success: false,
        message: 'Backend unavailable - token verification failed',
        type: 'error'
      };
    }
  }
};

// Admin API calls with proper error handling
export const adminAPI = {
  getUsers: async (filters = {}) => {
    if (!ENABLE_BACKEND) {
      // Return mock data
      await new Promise(resolve => setTimeout(resolve, 500));
      return {
        success: true,
        message: 'Mock data (backend disabled)',
        data: {
          users: [],
          total: 0,
          page: 1,
          limit: 10
        },
        type: 'warning'
      };
    }

    try {
      const response = await api.get('/admin/users', { params: filters });
      return response.data;
    } catch (error) {
      console.warn('Admin getUsers failed, returning empty data:', error);
      return {
        success: false,
        message: 'Backend unavailable - using empty data',
        data: {
          users: [],
          total: 0,
          page: 1,
          limit: 10
        },
        type: 'error'
      };
    }
  },

  getTransactions: async (filters = {}) => {
    if (!ENABLE_BACKEND) {
      // Return mock data
      await new Promise(resolve => setTimeout(resolve, 500));
      return {
        success: true,
        message: 'Mock data (backend disabled)',
        data: {
          transactions: [],
          total: 0,
          page: 1,
          limit: 20
        },
        type: 'warning'
      };
    }

    try {
      const response = await api.get('/admin/transactions', { params: filters });
      return response.data;
    } catch (error) {
      console.warn('Admin getTransactions failed, returning empty data:', error);
      return {
        success: false,
        message: 'Backend unavailable - using empty data',
        data: {
          transactions: [],
          total: 0,
          page: 1,
          limit: 20
        },
        type: 'error'
      };
    }
  },

  getSystemStats: async () => {
    if (!ENABLE_BACKEND) {
      // Return mock data
      await new Promise(resolve => setTimeout(resolve, 500));
      return {
        success: true,
        message: 'Mock data (backend disabled)',
        data: {
          totalUsers: 0,
          activeUsers: 0,
          totalDeposits: 0,
          totalWithdrawals: 0,
          pendingTransactions: 0,
          systemHealth: 'Mock Mode'
        },
        type: 'warning'
      };
    }

    try {
      const response = await api.get('/admin/stats');
      return response.data;
    } catch (error) {
      console.warn('Admin getSystemStats failed, returning mock data:', error);
      return {
        success: false,
        message: 'Backend unavailable - using mock data',
        data: {
          totalUsers: 0,
          activeUsers: 0,
          totalDeposits: 0,
          totalWithdrawals: 0,
          pendingTransactions: 0,
          systemHealth: 'Backend Unavailable'
        },
        type: 'error'
      };
    }
  }
};

// Export configured axios instance
export default api;

// Export configuration
export const apiConfig = {
  baseURL: API_BASE_URL,
  timeout: API_TIMEOUT,
  backendEnabled: ENABLE_BACKEND
};
