// Quick Admin Login Utility for Testing
export const quickAdminLogin = () => {
  // Set up admin authentication immediately
  const adminUser = {
    id: 2,
    name: 'Admin User',
    email: 'admin@kleverinvest.com',
    role: 'admin',
    verified: true,
    memberSince: new Date().toISOString().split('T')[0],
    balance: 0,
    wallet: null,
    username: 'Admin'
  };

  const token = `admin_token_${Date.now()}`;

  // Store in localStorage for immediate access
  localStorage.setItem('userToken', token);
  localStorage.setItem('userData', JSON.stringify(adminUser));
  localStorage.setItem('userRole', 'admin');

  // Reload page to trigger auth context update
  window.location.href = '/admin-dashboard';
  
  return adminUser;
};

// Auto-setup admin if needed
if (window.location.pathname.includes('/admin') && !localStorage.getItem('userToken')) {
  console.log('Auto-setting up admin access...');
  quickAdminLogin();
}
