/**
 * Authentication Utilities
 * Handles password hashing, JWT tokens, and security
 */

// Password hashing (client-side simplified version)
export const hashPassword = async (password) => {
  // In a real application, password hashing should be done server-side
  // This is a simplified client-side implementation for demo purposes
  
  try {
    // Use Web Crypto API if available
    if (window.crypto && window.crypto.subtle) {
      const encoder = new TextEncoder();
      const data = encoder.encode(password + 'kleverinvest_salt_2024');
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      return `$sha256$${hashHex}`;
    } else {
      // Fallback for environments without Web Crypto API
      return `$simple$${btoa(password + 'kleverinvest_salt_2024')}`;
    }
  } catch (error) {
    console.error('Password hashing failed:', error);
    // Fallback to simple base64 encoding
    return `$simple$${btoa(password + 'kleverinvest_salt_2024')}`;
  }
};

// Password verification
export const verifyPassword = async (password, hash) => {
  try {
    if (hash.startsWith('$sha256$')) {
      const expectedHash = await hashPassword(password);
      return hash === expectedHash;
    } else if (hash.startsWith('$simple$')) {
      const expectedHash = `$simple$${btoa(password + 'kleverinvest_salt_2024')}`;
      return hash === expectedHash;
    } else if (hash.startsWith('$2b$')) {
      // bcrypt hash - would need server-side verification
      console.warn('bcrypt verification requires server-side processing');
      return false;
    } else {
      // Plain text comparison (for backward compatibility)
      return password === hash;
    }
  } catch (error) {
    console.error('Password verification failed:', error);
    return false;
  }
};

// Generate secure random token
export const generateToken = (length = 32) => {
  const array = new Uint8Array(length);
  window.crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
};

// Generate JWT-like token (simplified client-side version)
export const generateJWT = (payload, expiresIn = '24h') => {
  try {
    const header = {
      alg: 'HS256',
      typ: 'JWT'
    };

    // Calculate expiration
    const now = Math.floor(Date.now() / 1000);
    let exp = now;
    
    if (expiresIn.endsWith('h')) {
      exp += parseInt(expiresIn) * 3600;
    } else if (expiresIn.endsWith('d')) {
      exp += parseInt(expiresIn) * 86400;
    } else if (expiresIn.endsWith('m')) {
      exp += parseInt(expiresIn) * 60;
    } else {
      exp += 86400; // Default 24 hours
    }

    const jwtPayload = {
      ...payload,
      iat: now,
      exp: exp,
      iss: 'kleverinvest-hub'
    };

    // Encode header and payload
    const encodedHeader = btoa(JSON.stringify(header)).replace(/[+/]/g, c => c === '+' ? '-' : '_').replace(/=/g, '');
    const encodedPayload = btoa(JSON.stringify(jwtPayload)).replace(/[+/]/g, c => c === '+' ? '-' : '_').replace(/=/g, '');
    
    // Simple signature (in production, use proper HMAC)
    const signature = btoa(`${encodedHeader}.${encodedPayload}.kleverinvest_secret`).replace(/[+/]/g, c => c === '+' ? '-' : '_').replace(/=/g, '');
    
    return `${encodedHeader}.${encodedPayload}.${signature}`;
  } catch (error) {
    console.error('JWT generation failed:', error);
    return generateToken();
  }
};

// Verify JWT token
export const verifyJWT = (token) => {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) {
      return null;
    }

    const [header, payload, signature] = parts;
    
    // Decode payload
    const decodedPayload = JSON.parse(atob(payload.replace(/[-_]/g, c => c === '-' ? '+' : '/')));
    
    // Check expiration
    const now = Math.floor(Date.now() / 1000);
    if (decodedPayload.exp && decodedPayload.exp < now) {
      return null; // Token expired
    }

    // Verify signature (simplified)
    const expectedSignature = btoa(`${header}.${payload}.kleverinvest_secret`).replace(/[+/]/g, c => c === '+' ? '-' : '_').replace(/=/g, '');
    if (signature !== expectedSignature) {
      return null; // Invalid signature
    }

    return decodedPayload;
  } catch (error) {
    console.error('JWT verification failed:', error);
    return null;
  }
};

// Session management
export class SessionManager {
  constructor() {
    this.sessionKey = 'kleverinvest_session';
    this.refreshKey = 'kleverinvest_refresh';
  }

  // Create user session
  createSession(user, options = {}) {
    const sessionData = {
      userId: user.id,
      email: user.email,
      role: user.role || 'user',
      permissions: user.permissions || [],
      loginTime: new Date().toISOString(),
      lastActivity: new Date().toISOString(),
      ipAddress: this.getClientIP(),
      userAgent: navigator.userAgent,
      ...options
    };

    const token = generateJWT(sessionData, '24h');
    const refreshToken = generateJWT({ userId: user.id, type: 'refresh' }, '7d');

    // Store in localStorage
    localStorage.setItem(this.sessionKey, token);
    localStorage.setItem(this.refreshKey, refreshToken);

    return {
      token,
      refreshToken,
      user: sessionData
    };
  }

  // Get current session
  getSession() {
    try {
      const token = localStorage.getItem(this.sessionKey);
      if (!token) return null;

      const session = verifyJWT(token);
      if (!session) {
        this.clearSession();
        return null;
      }

      // Update last activity
      this.updateActivity();

      return session;
    } catch (error) {
      console.error('Get session failed:', error);
      this.clearSession();
      return null;
    }
  }

  // Update last activity
  updateActivity() {
    try {
      const token = localStorage.getItem(this.sessionKey);
      if (!token) return;

      const session = verifyJWT(token);
      if (!session) return;

      // Create new token with updated activity
      session.lastActivity = new Date().toISOString();
      const newToken = generateJWT(session, '24h');
      localStorage.setItem(this.sessionKey, newToken);
    } catch (error) {
      console.error('Update activity failed:', error);
    }
  }

  // Refresh session
  async refreshSession() {
    try {
      const refreshToken = localStorage.getItem(this.refreshKey);
      if (!refreshToken) return null;

      const refreshData = verifyJWT(refreshToken);
      if (!refreshData || refreshData.type !== 'refresh') {
        this.clearSession();
        return null;
      }

      // In a real app, you'd validate with the server
      // For now, we'll just create a new session
      const currentSession = this.getSession();
      if (currentSession) {
        const newToken = generateJWT(currentSession, '24h');
        localStorage.setItem(this.sessionKey, newToken);
        return verifyJWT(newToken);
      }

      return null;
    } catch (error) {
      console.error('Refresh session failed:', error);
      this.clearSession();
      return null;
    }
  }

  // Clear session
  clearSession() {
    localStorage.removeItem(this.sessionKey);
    localStorage.removeItem(this.refreshKey);
    localStorage.removeItem('userData');
    localStorage.removeItem('userToken');
    localStorage.removeItem('adminData');
    localStorage.removeItem('adminToken');
  }

  // Check if user is authenticated
  isAuthenticated() {
    return this.getSession() !== null;
  }

  // Check if user has permission
  hasPermission(permission) {
    const session = this.getSession();
    if (!session) return false;

    return session.permissions && session.permissions.includes(permission);
  }

  // Check if user has role
  hasRole(role) {
    const session = this.getSession();
    if (!session) return false;

    return session.role === role;
  }

  // Get client IP (simplified)
  getClientIP() {
    // In a real application, this would be handled server-side
    return '127.0.0.1';
  }

  // Get session expiry time
  getExpiryTime() {
    const session = this.getSession();
    if (!session || !session.exp) return null;

    return new Date(session.exp * 1000);
  }

  // Check if session is about to expire (within 5 minutes)
  isAboutToExpire() {
    const expiryTime = this.getExpiryTime();
    if (!expiryTime) return false;

    const fiveMinutesFromNow = new Date(Date.now() + 5 * 60 * 1000);
    return expiryTime <= fiveMinutesFromNow;
  }
}

// Rate limiting for login attempts
export class RateLimiter {
  constructor(maxAttempts = 5, windowMs = 15 * 60 * 1000) {
    this.maxAttempts = maxAttempts;
    this.windowMs = windowMs;
    this.attempts = new Map();
  }

  // Check if action is allowed
  isAllowed(identifier) {
    const now = Date.now();
    const key = `rate_limit_${identifier}`;
    
    if (!this.attempts.has(key)) {
      this.attempts.set(key, { count: 0, resetTime: now + this.windowMs });
      return true;
    }

    const attemptData = this.attempts.get(key);
    
    // Reset if window has expired
    if (now >= attemptData.resetTime) {
      this.attempts.set(key, { count: 0, resetTime: now + this.windowMs });
      return true;
    }

    // Check if limit exceeded
    return attemptData.count < this.maxAttempts;
  }

  // Record an attempt
  recordAttempt(identifier) {
    const now = Date.now();
    const key = `rate_limit_${identifier}`;
    
    if (!this.attempts.has(key)) {
      this.attempts.set(key, { count: 1, resetTime: now + this.windowMs });
    } else {
      const attemptData = this.attempts.get(key);
      if (now >= attemptData.resetTime) {
        this.attempts.set(key, { count: 1, resetTime: now + this.windowMs });
      } else {
        attemptData.count++;
      }
    }
  }

  // Get remaining attempts
  getRemainingAttempts(identifier) {
    const key = `rate_limit_${identifier}`;
    if (!this.attempts.has(key)) {
      return this.maxAttempts;
    }

    const attemptData = this.attempts.get(key);
    const now = Date.now();
    
    if (now >= attemptData.resetTime) {
      return this.maxAttempts;
    }

    return Math.max(0, this.maxAttempts - attemptData.count);
  }

  // Get time until reset
  getResetTime(identifier) {
    const key = `rate_limit_${identifier}`;
    if (!this.attempts.has(key)) {
      return 0;
    }

    const attemptData = this.attempts.get(key);
    const now = Date.now();
    
    return Math.max(0, attemptData.resetTime - now);
  }
}

// Create singleton instances
export const sessionManager = new SessionManager();
export const loginRateLimiter = new RateLimiter(5, 15 * 60 * 1000); // 5 attempts per 15 minutes

// Export utility functions
export default {
  hashPassword,
  verifyPassword,
  generateToken,
  generateJWT,
  verifyJWT,
  SessionManager,
  RateLimiter,
  sessionManager,
  loginRateLimiter,
};
