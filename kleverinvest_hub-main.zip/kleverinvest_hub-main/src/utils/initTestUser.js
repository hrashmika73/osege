/**
 * Initialize a test user with verified KYC status
 * This fixes 403 Forbidden errors by ensuring a valid user exists
 */

import { addNewUser } from './userDataManager';

export const createTestUserWithVerifiedKYC = () => {
  const testUser = {
    id: 'user_test_verified',
    email: 'test@kleverinvest.com',
    name: 'Test User Verified',
    password: 'test123',
    balance: 1000,
    country: 'United States',
    phone: '+1234567890',
    kycStatus: 'verified',
    referralCode: 'TESTREF001'
  };

  // Check if user already exists
  const existingUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
  const userExists = existingUsers.find(u => u.email === testUser.email);
  
  if (!userExists) {
    const adminUserData = addNewUser(testUser);
    console.log('Test user created:', adminUserData);
    return adminUserData;
  } else {
    // Update existing user to be verified
    const userIndex = existingUsers.findIndex(u => u.email === testUser.email);
    existingUsers[userIndex] = {
      ...existingUsers[userIndex],
      kycStatus: 'verified',
      verificationStatus: 'verified',
      password: 'test123'
    };
    localStorage.setItem('admin_users_data', JSON.stringify(existingUsers));
    console.log('Test user updated to verified:', existingUsers[userIndex]);
    return existingUsers[userIndex];
  }
};

export const createDefaultTestUser = () => {
  const defaultUser = {
    id: 'user_default_001',
    email: 'user@kleverinvest.com',
    name: 'Default Test User',
    password: 'password123',
    balance: 5000,
    country: 'United States',
    phone: '+1987654321',
    kycStatus: 'verified',
    referralCode: 'REF000001'
  };

  // Check if user already exists
  const existingUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
  const userExists = existingUsers.find(u => u.email === defaultUser.email);
  
  if (!userExists) {
    const adminUserData = addNewUser(defaultUser);
    console.log('Default test user created:', adminUserData);
    return adminUserData;
  } else {
    // Update existing user to be verified
    const userIndex = existingUsers.findIndex(u => u.email === defaultUser.email);
    existingUsers[userIndex] = {
      ...existingUsers[userIndex],
      kycStatus: 'verified',
      verificationStatus: 'verified',
      password: 'password123'
    };
    localStorage.setItem('admin_users_data', JSON.stringify(existingUsers));
    console.log('Default test user updated to verified:', existingUsers[userIndex]);
    return existingUsers[userIndex];
  }
};

export const initializeTestUsers = () => {
  console.log('Initializing test users...');
  createDefaultTestUser();
  createTestUserWithVerifiedKYC();
  console.log('Test users initialized successfully');
};
