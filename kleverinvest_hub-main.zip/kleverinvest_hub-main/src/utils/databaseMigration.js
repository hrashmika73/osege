/**
 * Database Migration Utility
 * Handles migration from localStorage to database and data synchronization
 */

import databaseService from '../services/databaseService.js';
import userRepository from '../models/User.js';
import { hashPassword } from './auth.js';

export class DatabaseMigration {
  constructor() {
    this.migrationKey = 'kleverinvest_migration_status';
    this.backupKey = 'kleverinvest_backup_';
  }

  // Check if migration is needed
  async needsMigration() {
    const migrationStatus = localStorage.getItem(this.migrationKey);
    const hasLocalStorageData = this.hasLocalStorageData();
    
    return !migrationStatus && hasLocalStorageData;
  }

  // Check if localStorage has data
  hasLocalStorageData() {
    const keys = [
      'admin_users_data',
      'admin_active_users', 
      'admin_pending_kyc',
      'admin_transactions',
      'userData'
    ];

    return keys.some(key => {
      const data = localStorage.getItem(key);
      return data && data !== '[]' && data !== 'null';
    });
  }

  // Run complete migration
  async runMigration(options = {}) {
    const {
      createBackup = true,
      clearLocalStorage = false,
      dryRun = false
    } = options;

    try {
      console.log('🚀 Starting database migration...');

      // Create backup if requested
      if (createBackup && !dryRun) {
        await this.createBackup();
      }

      // Initialize database
      await databaseService.initialize();

      // Migrate users
      const usersMigrated = await this.migrateUsers(dryRun);
      console.log(`✅ Users migrated: ${usersMigrated}`);

      // Migrate KYC requests
      const kycMigrated = await this.migrateKycRequests(dryRun);
      console.log(`✅ KYC requests migrated: ${kycMigrated}`);

      // Migrate transactions
      const transactionsMigrated = await this.migrateTransactions(dryRun);
      console.log(`✅ Transactions migrated: ${transactionsMigrated}`);

      // Migrate notifications
      const notificationsMigrated = await this.migrateNotifications(dryRun);
      console.log(`✅ Notifications migrated: ${notificationsMigrated}`);

      if (!dryRun) {
        // Mark migration as completed
        localStorage.setItem(this.migrationKey, JSON.stringify({
          completed: true,
          timestamp: new Date().toISOString(),
          version: '1.0.0',
          usersMigrated,
          kycMigrated,
          transactionsMigrated,
          notificationsMigrated
        }));

        // Clear localStorage if requested
        if (clearLocalStorage) {
          await this.clearLocalStorageData();
        }
      }

      console.log('🎉 Migration completed successfully!');

      return {
        success: true,
        migrated: {
          users: usersMigrated,
          kyc: kycMigrated,
          transactions: transactionsMigrated,
          notifications: notificationsMigrated
        }
      };

    } catch (error) {
      console.error('❌ Migration failed:', error);
      
      if (createBackup && !dryRun) {
        console.log('🔄 Attempting to restore backup...');
        await this.restoreBackup();
      }

      throw error;
    }
  }

  // Migrate users from localStorage to database
  async migrateUsers(dryRun = false) {
    try {
      const localUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
      let migratedCount = 0;

      console.log(`📊 Found ${localUsers.length} users to migrate`);

      for (const localUser of localUsers) {
        try {
          // Check if user already exists
          const existingUser = await userRepository.findByEmail(localUser.email);
          if (existingUser) {
            console.log(`⏭️  User ${localUser.email} already exists, skipping`);
            continue;
          }

          if (dryRun) {
            console.log(`[DRY RUN] Would migrate user: ${localUser.email}`);
            migratedCount++;
            continue;
          }

          // Prepare user data
          const userData = {
            email: localUser.email,
            username: localUser.username || localUser.email.split('@')[0],
            firstName: localUser.firstName || localUser.fullName?.split(' ')[0] || '',
            lastName: localUser.lastName || localUser.fullName?.split(' ').slice(1).join(' ') || '',
            fullName: localUser.fullName || `${localUser.firstName || ''} ${localUser.lastName || ''}`.trim(),
            phone: localUser.phone,
            country: localUser.location || localUser.country,
            status: localUser.status || 'active',
            emailVerified: localUser.emailVerified || true,
            kycStatus: this.mapKycStatus(localUser.kycStatus || localUser.verificationStatus),
            riskLevel: localUser.riskLevel || 'low',
            accountType: localUser.accountType || 'standard',
            referralCode: localUser.referralCode,
            balance: parseFloat(localUser.balance || 0),
            totalInvested: parseFloat(localUser.totalInvestments || 0),
            registrationIp: localUser.registrationIP || '127.0.0.1',
            deviceInfo: localUser.deviceInfo || 'Migration',
          };

          // Use stored password or default
          const password = localUser.password || 'password123';

          // Create user in database
          await userRepository.create(userData, password);
          
          console.log(`✅ Migrated user: ${localUser.email}`);
          migratedCount++;

        } catch (error) {
          console.error(`❌ Failed to migrate user ${localUser.email}:`, error);
        }
      }

      return migratedCount;

    } catch (error) {
      console.error('Users migration failed:', error);
      throw error;
    }
  }

  // Migrate KYC requests
  async migrateKycRequests(dryRun = false) {
    try {
      const localKyc = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
      let migratedCount = 0;

      console.log(`📊 Found ${localKyc.length} KYC requests to migrate`);

      for (const kycRequest of localKyc) {
        try {
          if (dryRun) {
            console.log(`[DRY RUN] Would migrate KYC for: ${kycRequest.email}`);
            migratedCount++;
            continue;
          }

          // Find user
          const user = await userRepository.findByEmail(kycRequest.email);
          if (!user) {
            console.log(`⚠️  User not found for KYC: ${kycRequest.email}`);
            continue;
          }

          // Prepare KYC data
          const kycData = {
            user_id: user.id,
            document_type: kycRequest.documentType || 'passport',
            document_number: kycRequest.documentNumber || 'PENDING',
            submission_date: kycRequest.submissionDate || kycRequest.createdAt || new Date().toISOString(),
            verification_status: this.mapKycStatus(kycRequest.verificationStatus),
            notes: kycRequest.notes || 'Migrated from localStorage',
            priority: kycRequest.priority || 'medium'
          };

          // Insert KYC request
          const result = await databaseService.query('kyc_requests', 'insert', kycData);
          
          if (result.success) {
            console.log(`✅ Migrated KYC for: ${kycRequest.email}`);
            migratedCount++;
          }

        } catch (error) {
          console.error(`❌ Failed to migrate KYC for ${kycRequest.email}:`, error);
        }
      }

      return migratedCount;

    } catch (error) {
      console.error('KYC migration failed:', error);
      throw error;
    }
  }

  // Migrate transactions
  async migrateTransactions(dryRun = false) {
    try {
      const localTransactions = JSON.parse(localStorage.getItem('admin_transactions') || '[]');
      let migratedCount = 0;

      console.log(`📊 Found ${localTransactions.length} transactions to migrate`);

      for (const transaction of localTransactions) {
        try {
          if (dryRun) {
            console.log(`[DRY RUN] Would migrate transaction: ${transaction.id}`);
            migratedCount++;
            continue;
          }

          // Find user
          const user = await userRepository.findByEmail(transaction.user?.email);
          if (!user) {
            console.log(`⚠️  User not found for transaction: ${transaction.user?.email}`);
            continue;
          }

          // Prepare transaction data
          const transactionData = {
            transaction_code: transaction.id || `TXN-${Date.now()}`,
            user_id: user.id,
            type: transaction.type || 'deposit',
            amount: parseFloat(transaction.amount || 0),
            cryptocurrency: transaction.cryptocurrency || 'BTC',
            usd_value: parseFloat(transaction.usdValue || transaction.amount || 0),
            status: transaction.status || 'completed',
            payment_method: transaction.method || 'Bitcoin',
            network: transaction.network || 'Bitcoin',
            confirmations: parseInt(transaction.confirmations || 6),
            transaction_hash: transaction.txHash,
            notes: transaction.note || 'Migrated transaction'
          };

          // Insert transaction
          const result = await databaseService.query('transactions', 'insert', transactionData);
          
          if (result.success) {
            console.log(`✅ Migrated transaction: ${transaction.id}`);
            migratedCount++;
          }

        } catch (error) {
          console.error(`❌ Failed to migrate transaction ${transaction.id}:`, error);
        }
      }

      return migratedCount;

    } catch (error) {
      console.error('Transactions migration failed:', error);
      throw error;
    }
  }

  // Migrate notifications
  async migrateNotifications(dryRun = false) {
    try {
      // Notifications aren't stored in localStorage currently, so we'll create welcome notifications
      const users = await userRepository.getAll({ limit: 1000 });
      let migratedCount = 0;

      console.log(`📊 Creating welcome notifications for ${users.users.length} users`);

      for (const user of users.users) {
        try {
          if (dryRun) {
            console.log(`[DRY RUN] Would create notification for: ${user.email}`);
            migratedCount++;
            continue;
          }

          const notificationData = {
            user_id: user.id,
            title: 'Welcome to KleverInvest Hub!',
            message: 'Thank you for joining our platform. Your account has been migrated to our new database system.',
            type: 'system',
            category: 'migration',
            priority: 'medium',
            is_read: false
          };

          const result = await databaseService.query('notifications', 'insert', notificationData);
          
          if (result.success) {
            migratedCount++;
          }

        } catch (error) {
          console.error(`❌ Failed to create notification for ${user.email}:`, error);
        }
      }

      return migratedCount;

    } catch (error) {
      console.error('Notifications migration failed:', error);
      throw error;
    }
  }

  // Map old KYC status to new format
  mapKycStatus(oldStatus) {
    const statusMap = {
      'verified': 'approved',
      'pending': 'pending',
      'rejected': 'rejected',
      'pending_documents': 'pending',
      'submitted': 'in_review'
    };

    return statusMap[oldStatus] || 'pending';
  }

  // Create backup of localStorage data
  async createBackup() {
    try {
      const backup = {
        timestamp: new Date().toISOString(),
        data: {}
      };

      const keys = [
        'admin_users_data',
        'admin_active_users',
        'admin_pending_kyc', 
        'admin_transactions',
        'admin_banned_users',
        'admin_sent_messages',
        'userData',
        'userToken',
        'adminData',
        'adminToken'
      ];

      keys.forEach(key => {
        const data = localStorage.getItem(key);
        if (data) {
          backup.data[key] = data;
        }
      });

      const backupKey = `${this.backupKey}${Date.now()}`;
      localStorage.setItem(backupKey, JSON.stringify(backup));
      
      console.log(`💾 Backup created: ${backupKey}`);
      
      return backupKey;

    } catch (error) {
      console.error('Backup creation failed:', error);
      throw error;
    }
  }

  // Restore from backup
  async restoreBackup(backupKey = null) {
    try {
      // Find most recent backup if not specified
      if (!backupKey) {
        const allKeys = Object.keys(localStorage);
        const backupKeys = allKeys.filter(key => key.startsWith(this.backupKey));
        
        if (backupKeys.length === 0) {
          throw new Error('No backup found');
        }

        backupKey = backupKeys.sort().pop(); // Get most recent
      }

      const backup = JSON.parse(localStorage.getItem(backupKey));
      if (!backup) {
        throw new Error('Backup not found');
      }

      // Restore data
      Object.entries(backup.data).forEach(([key, value]) => {
        localStorage.setItem(key, value);
      });

      console.log(`🔄 Restored from backup: ${backupKey}`);

    } catch (error) {
      console.error('Backup restoration failed:', error);
      throw error;
    }
  }

  // Clear localStorage data after successful migration
  async clearLocalStorageData() {
    const keys = [
      'admin_users_data',
      'admin_active_users',
      'admin_pending_kyc',
      'admin_transactions',
      'admin_banned_users',
      'admin_sent_messages'
    ];

    keys.forEach(key => {
      localStorage.removeItem(key);
    });

    console.log('🧹 Cleared localStorage data');
  }

  // Get migration status
  getMigrationStatus() {
    const status = localStorage.getItem(this.migrationKey);
    return status ? JSON.parse(status) : null;
  }

  // Reset migration status (for testing)
  resetMigrationStatus() {
    localStorage.removeItem(this.migrationKey);
  }

  // Sync data between localStorage and database
  async syncData(direction = 'to_database') {
    try {
      if (direction === 'to_database') {
        return await this.runMigration({ createBackup: false, dryRun: false });
      } else if (direction === 'from_database') {
        // Export from database to localStorage (for fallback)
        return await this.exportToLocalStorage();
      }
    } catch (error) {
      console.error('Data sync failed:', error);
      throw error;
    }
  }

  // Export database data to localStorage (fallback)
  async exportToLocalStorage() {
    try {
      console.log('📤 Exporting database to localStorage...');

      // Export users
      const users = await userRepository.getAll({ limit: 10000 });
      const localUsers = users.users.map(user => ({
        id: user.id,
        userId: user.id,
        email: user.email,
        username: user.username,
        fullName: user.fullName,
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        status: user.status,
        balance: user.balance,
        kycStatus: user.kycStatus,
        verificationStatus: user.kycStatus,
        registrationDate: user.createdAt,
        ...user.toJSON()
      }));

      localStorage.setItem('admin_users_data', JSON.stringify(localUsers));
      localStorage.setItem('admin_active_users', JSON.stringify(localUsers.filter(u => u.status === 'active')));

      console.log(`✅ Exported ${localUsers.length} users to localStorage`);

      return {
        success: true,
        exported: {
          users: localUsers.length
        }
      };

    } catch (error) {
      console.error('Export to localStorage failed:', error);
      throw error;
    }
  }
}

// Create singleton instance
const databaseMigration = new DatabaseMigration();

export default databaseMigration;

// Export utility functions
export const {
  needsMigration,
  runMigration,
  getMigrationStatus,
  syncData,
  resetMigrationStatus
} = databaseMigration;
