/**
 * Centralized User Data Management System
 * Connects user registration, admin dashboard, and real-time updates
 */

// Storage keys
export const STORAGE_KEYS = {
  ADMIN_USERS: 'admin_users_data',
  ADMIN_ACTIVE_USERS: 'admin_active_users',
  ADMIN_PENDING_KYC: 'admin_pending_kyc',
  USER_DATA: 'userData',
  USER_TOKEN: 'userToken'
};

/**
 * Get all users from storage
 */
export const getAllUsers = () => {
  const users = localStorage.getItem(STORAGE_KEYS.ADMIN_USERS);
  return users ? JSON.parse(users) : [];
};

/**
 * Add a new user to the system
 */
export const addNewUser = (userData) => {
  const users = getAllUsers();
  const timestamp = new Date().toISOString();

  // Create comprehensive user data for admin
  const adminUserData = {
    id: parseInt(userData.id.replace('user_', '')) || Date.now(),
    userId: userData.id,
    username: userData.email.split('@')[0],
    email: userData.email,
    fullName: userData.name,
    password: userData.password, // Store actual password for login
    status: 'active',
    lastActive: timestamp,
    registrationDate: timestamp,
    totalInvestments: 0,
    balance: userData.balance || 0,
    kycStatus: userData.kycStatus || 'pending',
    verificationStatus: userData.kycStatus === 'verified' ? 'verified' : 'pending',
    location: userData.country || 'Unknown',
    phone: userData.phone || 'Not provided',
    riskLevel: 'low',
    referralCode: userData.referralCode || `REF${Date.now().toString().slice(-6)}`,
    accountType: 'standard',
    twoFactorEnabled: false,
    emailVerified: true,
    profileComplete: false,
    lastLoginIP: 'Unknown',
    registrationIP: 'Unknown',
    deviceInfo: navigator.userAgent || 'Unknown',
    createdAt: timestamp,
    updatedAt: timestamp,
    // Additional user profile data
    firstName: userData.name.split(' ')[0] || userData.name,
    lastName: userData.name.split(' ').slice(1).join(' ') || '',
    dateOfBirth: null,
    address: null
  };

  // Add to users list
  users.push(adminUserData);
  
  // Save to localStorage
  localStorage.setItem(STORAGE_KEYS.ADMIN_USERS, JSON.stringify(users));
  localStorage.setItem(STORAGE_KEYS.ADMIN_ACTIVE_USERS, JSON.stringify(users.filter(u => u.status === 'active')));

  // Trigger custom event for real-time updates
  window.dispatchEvent(new CustomEvent('userRegistered', { 
    detail: { 
      user: adminUserData,
      timestamp: timestamp 
    } 
  }));

  return adminUserData;
};

/**
 * Update user data
 */
export const updateUser = (userId, updateData) => {
  const users = getAllUsers();
  const userIndex = users.findIndex(u => u.userId === userId || u.id === userId);
  
  if (userIndex !== -1) {
    users[userIndex] = {
      ...users[userIndex],
      ...updateData,
      updatedAt: new Date().toISOString()
    };
    
    localStorage.setItem(STORAGE_KEYS.ADMIN_USERS, JSON.stringify(users));
    localStorage.setItem(STORAGE_KEYS.ADMIN_ACTIVE_USERS, JSON.stringify(users.filter(u => u.status === 'active')));
    
    // Trigger update event
    window.dispatchEvent(new CustomEvent('userUpdated', { 
      detail: { 
        user: users[userIndex],
        timestamp: new Date().toISOString() 
      } 
    }));
    
    return users[userIndex];
  }
  
  return null;
};

/**
 * Get active users only
 */
export const getActiveUsers = () => {
  const users = getAllUsers();
  return users.filter(user => user.status === 'active');
};

/**
 * Get users by status
 */
export const getUsersByStatus = (status) => {
  const users = getAllUsers();
  return users.filter(user => user.status === status);
};

/**
 * Create KYC request for new user
 */
export const createKYCRequest = (userData) => {
  const kycRequests = JSON.parse(localStorage.getItem(STORAGE_KEYS.ADMIN_PENDING_KYC) || '[]');
  
  const kycRequest = {
    id: Date.now(),
    userId: userData.id,
    username: userData.email.split('@')[0],
    email: userData.email,
    fullName: userData.name,
    submissionDate: new Date().toISOString(),
    documentType: 'pending',
    documentNumber: 'PENDING',
    country: userData.country || 'Unknown',
    phoneNumber: userData.phone || 'Not provided',
    address: 'Not provided',
    priority: 'normal',
    investmentAmount: 0,
    riskLevel: 'low',
    documentsSubmitted: [],
    verificationStatus: 'pending',
    notes: 'New user registration - awaiting document submission',
    createdAt: new Date().toISOString()
  };
  
  kycRequests.push(kycRequest);
  localStorage.setItem(STORAGE_KEYS.ADMIN_PENDING_KYC, JSON.stringify(kycRequests));
  
  // Trigger KYC event
  window.dispatchEvent(new CustomEvent('kycRequestCreated', { 
    detail: { 
      request: kycRequest,
      timestamp: new Date().toISOString() 
    } 
  }));
  
  return kycRequest;
};

/**
 * Get user statistics
 */
export const getUserStatistics = () => {
  const users = getAllUsers();
  
  return {
    total: users.length,
    active: users.filter(u => u.status === 'active').length,
    inactive: users.filter(u => u.status === 'inactive').length,
    suspended: users.filter(u => u.status === 'suspended').length,
    banned: users.filter(u => u.status === 'banned').length,
    verified: users.filter(u => u.verificationStatus === 'verified').length,
    pending: users.filter(u => u.verificationStatus === 'pending').length,
    totalBalance: users.reduce((sum, user) => sum + (user.balance || 0), 0),
    totalInvestments: users.reduce((sum, user) => sum + (user.totalInvestments || 0), 0),
    newToday: users.filter(u => {
      const today = new Date().toDateString();
      const userDate = new Date(u.registrationDate).toDateString();
      return today === userDate;
    }).length,
    newThisWeek: users.filter(u => {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return new Date(u.registrationDate) >= weekAgo;
    }).length
  };
};

/**
 * Initialize real-time listeners for admin dashboard
 */
export const initializeAdminListeners = (callbacks = {}) => {
  const handleUserRegistered = (event) => {
    if (callbacks.onUserRegistered) {
      callbacks.onUserRegistered(event.detail);
    }
  };

  const handleUserUpdated = (event) => {
    if (callbacks.onUserUpdated) {
      callbacks.onUserUpdated(event.detail);
    }
  };

  const handleKYCRequest = (event) => {
    if (callbacks.onKYCRequest) {
      callbacks.onKYCRequest(event.detail);
    }
  };

  // Add event listeners
  window.addEventListener('userRegistered', handleUserRegistered);
  window.addEventListener('userUpdated', handleUserUpdated);
  window.addEventListener('kycRequestCreated', handleKYCRequest);

  // Return cleanup function
  return () => {
    window.removeEventListener('userRegistered', handleUserRegistered);
    window.removeEventListener('userUpdated', handleUserUpdated);
    window.removeEventListener('kycRequestCreated', handleKYCRequest);
  };
};

/**
 * Clear all user data (for testing/reset)
 */
export const clearAllUserData = () => {
  Object.values(STORAGE_KEYS).forEach(key => {
    localStorage.removeItem(key);
  });
  
  // Trigger clear event
  window.dispatchEvent(new CustomEvent('userDataCleared', { 
    detail: { timestamp: new Date().toISOString() } 
  }));
};

/**
 * Export user data for admin
 */
export const exportUserData = (format = 'json') => {
  const users = getAllUsers();
  const timestamp = new Date().toISOString().split('T')[0];
  
  if (format === 'csv') {
    const headers = ['ID', 'Username', 'Email', 'Full Name', 'Status', 'Registration Date', 'Balance', 'KYC Status'];
    const csv = [
      headers.join(','),
      ...users.map(user => [
        user.id,
        user.username,
        user.email,
        user.fullName,
        user.status,
        user.registrationDate,
        user.balance,
        user.verificationStatus
      ].join(','))
    ].join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `users_export_${timestamp}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } else {
    const data = JSON.stringify(users, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `users_export_${timestamp}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
};
