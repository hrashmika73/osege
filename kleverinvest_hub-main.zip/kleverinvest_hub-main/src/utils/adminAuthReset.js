/**
 * Admin Authentication Reset Utility
 * Clears all admin authentication data and ensures fresh login
 */

export const clearAllAdminAuth = () => {
  try {
    // Clear all admin-related localStorage data
    const adminKeys = [
      'adminToken',
      'adminData', 
      'adminSession',
      'adminLoginAttempts',
      'adminLockoutUntil'
    ];

    adminKeys.forEach(key => {
      localStorage.removeItem(key);
    });

    // Clear any biometric data (starts with 'biometric_')
    const allKeys = Object.keys(localStorage);
    allKeys.forEach(key => {
      if (key.startsWith('biometric_')) {
        localStorage.removeItem(key);
      }
    });

    // Clear any old legacy auth data
    const legacyKeys = [
      'userRole',
      'token',
      'authToken',
      'adminRole'
    ];
    
    legacyKeys.forEach(key => {
      localStorage.removeItem(key);
    });

    console.log('All admin authentication data cleared');
    return true;
  } catch (error) {
    console.error('Failed to clear admin auth data:', error);
    return false;
  }
};

export const isAdminLoggedIn = () => {
  try {
    const adminToken = localStorage.getItem('adminToken');
    const adminData = localStorage.getItem('adminData');
    
    if (!adminToken || !adminData) {
      return false;
    }

    // Parse admin data to verify role
    const parsedAdminData = JSON.parse(adminData);
    if (parsedAdminData.role !== 'admin') {
      return false;
    }

    // If token is JWT, verify it's not expired
    if (adminToken.includes('.')) {
      try {
        const parts = adminToken.split('.');
        const payload = JSON.parse(atob(parts[1].replace(/[-_]/g, c => c === '-' ? '+' : '/')));
        
        // Check if token is expired
        if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
          console.log('Admin JWT token expired');
          return false;
        }
      } catch (jwtError) {
        console.warn('Invalid JWT token format');
        return false;
      }
    }

    return true;
  } catch (error) {
    console.error('Error checking admin login status:', error);
    return false;
  }
};

export const forceAdminLogout = () => {
  clearAllAdminAuth();
  
  // Redirect to login page
  if (window.location.pathname.startsWith('/admin')) {
    window.location.href = '/admin-secure-login';
  }
};

export const getAdminInfo = () => {
  try {
    const adminData = localStorage.getItem('adminData');
    if (!adminData) return null;

    return JSON.parse(adminData);
  } catch (error) {
    console.error('Error getting admin info:', error);
    return null;
  }
};

// Auto-clear on import only if data is actually corrupted - preserve valid sessions
if (typeof window !== 'undefined') {
  // Only clear if there's corrupted data, never clear valid sessions
  try {
    const adminData = localStorage.getItem('adminData');
    const adminToken = localStorage.getItem('adminToken');

    // Only validate if there's actually data to validate
    if (adminData) {
      const parsed = JSON.parse(adminData);
      // Only clear if data is actually corrupted (missing required fields)
      if (!parsed.role || typeof parsed !== 'object' || !parsed.id) {
        console.log('Corrupted admin data detected, clearing');
        clearAllAdminAuth();
      } else {
        console.log('Valid admin session data found, preserving');
      }
    }

    // Don't clear anything if just missing data - that's normal for non-logged-in state
  } catch (error) {
    console.log('Corrupted admin data detected due to parse error, clearing');
    clearAllAdminAuth();
  }
}

export default {
  clearAllAdminAuth,
  isAdminLoggedIn,
  forceAdminLogout,
  getAdminInfo
};
