// Debug utilities removed for production
// This file has been cleaned for production deployment
