/**
 * Simple Reload Test Utility
 * Basic reload testing without complex dependencies
 */

export const simpleReloadTest = {
  // Test page reload and session persistence
  testReload: () => {
    console.log('🔄 Testing page reload...');
    
    // Store test timestamp
    sessionStorage.setItem('reloadTestTime', Date.now().toString());
    
    // Check current auth state
    const hasAdminToken = !!localStorage.getItem('adminToken');
    const hasAdminData = !!localStorage.getItem('adminData');
    
    console.log('📊 Session state before reload:', {
      hasAdminToken,
      hasAdminData,
      currentPage: window.location.pathname
    });
    
    // Reload the page
    window.location.reload();
  },

  // Check if we just completed a reload test
  checkAfterReload: () => {
    const testTime = sessionStorage.getItem('reloadTestTime');
    if (testTime) {
      const hasAdminToken = !!localStorage.getItem('adminToken');
      const hasAdminData = !!localStorage.getItem('adminData');
      
      console.log('✅ Reload test completed:', {
        testTime: new Date(parseInt(testTime)).toLocaleTimeString(),
        sessionPreserved: hasAdminToken && hasAdminData,
        currentPage: window.location.pathname
      });
      
      // Clean up
      sessionStorage.removeItem('reloadTestTime');
      
      return true;
    }
    return false;
  }
};

export default simpleReloadTest;
