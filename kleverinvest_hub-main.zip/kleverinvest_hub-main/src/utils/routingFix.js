/**
 * Routing Fix Utility
 * Handles common routing issues and 404 errors
 */

class RoutingFix {
  constructor() {
    this.validRoutes = new Set();
    this.redirectRules = new Map();
    this.initialize();
  }

  initialize() {
    // Define all valid routes
    this.validRoutes = new Set([
      '/',
      '/home-landing-page',
      '/about-company-page',
      '/about',
      '/why-choose-klever-invest',
      '/investment-plans',
      '/how-it-works',
      '/customer-testimonials',
      '/testimonials',
      '/faq',
      '/contact',
      '/login',
      '/login-selection',
      '/user-login',
      '/register',
      '/signup',
      '/password-recovery',
      '/forgot-password',
      '/reset-password',
      '/kyc-verification',
      '/user-login-portal',
      '/user-dashboard',
      '/auth-debug',
      '/fix-403',
      '/user-dashboard-test',
      '/network-error-fix',
      '/deposit',
      
      // Admin routes
      '/admin-secure-login',
      '/admin',
      '/admin-login',
      '/admin-dashboard',
      '/admin-system-analytics',
      '/admin-user-management',
      '/admin-transaction-management',
      '/admin-payment-gateway',
      '/admin-site-settings',
      '/admin-system-logs',
      '/admin-user-management-enhanced',
      '/admin-investment-plans',
      '/admin-security-test',
      '/admin-login-info',
      '/biometric-demo',
      '/backend-integration-test',
      
      // User management
      '/admin-active-users',
      '/admin-banned-users',
      '/admin-pending-kyc',
      '/admin-kyc-log',
      
      // Gateway management
      '/admin-gateways',
      '/admin-pending-deposits',
      '/admin-accepted-deposits',
      '/admin-rejected-deposits',
      '/admin-deposit-log',
      '/admin-pending-withdraws',
      '/admin-withdraw-log',
      
      // Settings
      '/admin-theme-settings',
      '/admin-email-settings',
      '/admin-language-manager',
      '/admin-google-tools',
      '/admin-logo-icon',
      '/admin-web-interface',
      
      // Other pages
      '/site-accessibility-audit-dashboard',
      '/c-panel-hosting-configuration-center',
      '/support-chat-system',
      '/referral-program',
      '/user-profile-settings',
      '/withdrawal-requests',
      '/notifications-center',
      '/investment-portfolio-dashboard',
      '/investment-opportunities',
      '/transaction-history',
      '/btc-live-trading-interface',
      '/trading-dashboard',
      '/market-analysis-center'
    ]);

    // Define redirect rules for common mistakes
    this.redirectRules = new Map([
      ['/admin-login/', '/admin-secure-login'],
      ['/admin/', '/admin-secure-login'],
      ['/login/', '/login-selection'],
      ['/dashboard', '/user-dashboard'],
      ['/profile', '/user-profile-settings'],
      ['/settings', '/admin-site-settings'],
      ['/users', '/admin-active-users'],
      ['/transactions', '/admin-transaction-management'],
      ['/home', '/home-landing-page'],
      ['/landing', '/home-landing-page']
    ]);

    this.setupRouteInterceptor();
  }

  setupRouteInterceptor() {
    // Intercept navigation and fix common issues
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;

    history.pushState = (state, title, url) => {
      const fixedUrl = this.fixRoute(url);
      return originalPushState.call(history, state, title, fixedUrl);
    };

    history.replaceState = (state, title, url) => {
      const fixedUrl = this.fixRoute(url);
      return originalReplaceState.call(history, state, title, fixedUrl);
    };

    // Handle browser back/forward buttons
    window.addEventListener('popstate', (event) => {
      const currentPath = window.location.pathname;
      if (!this.isValidRoute(currentPath)) {
        const fixedPath = this.fixRoute(currentPath);
        if (fixedPath !== currentPath) {
          window.location.replace(fixedPath);
        }
      }
    });
  }

  fixRoute(url) {
    if (typeof url !== 'string') return url;

    // Extract pathname from full URL
    let pathname = url;
    try {
      const urlObj = new URL(url, window.location.origin);
      pathname = urlObj.pathname;
    } catch (error) {
      // If not a full URL, treat as pathname
      pathname = url.startsWith('/') ? url : '/' + url;
    }

    // Remove trailing slashes (except for root)
    if (pathname !== '/' && pathname.endsWith('/')) {
      pathname = pathname.slice(0, -1);
    }

    // Check if it's a valid route
    if (this.isValidRoute(pathname)) {
      return pathname;
    }

    // Apply redirect rules
    if (this.redirectRules.has(pathname)) {
      return this.redirectRules.get(pathname);
    }

    // Handle dynamic routes
    const dynamicRouteFix = this.fixDynamicRoute(pathname);
    if (dynamicRouteFix) {
      return dynamicRouteFix;
    }

    // If all else fails, redirect based on path segments
    return this.intelligentRedirect(pathname);
  }

  isValidRoute(pathname) {
    // Check exact match
    if (this.validRoutes.has(pathname)) {
      return true;
    }

    // Check dynamic routes
    const dynamicPatterns = [
      /^\/admin-user-details\/\d+$/,
      /^\/admin-edit-user\/\d+$/,
      /^\/admin-send-message\/\d+$/,
      /^\/admin-ban-details\/\d+$/,
      /^\/admin-ban-appeal\/\d+$/,
      /^\/admin-gateway-edit\/\d+$/
    ];

    return dynamicPatterns.some(pattern => pattern.test(pathname));
  }

  fixDynamicRoute(pathname) {
    // Handle user ID routes
    if (pathname.match(/^\/admin-user-details\/\w+$/)) {
      return pathname; // Valid dynamic route
    }
    if (pathname.match(/^\/admin-edit-user\/\w+$/)) {
      return pathname; // Valid dynamic route
    }
    if (pathname.match(/^\/admin-send-message\/\w+$/)) {
      return pathname; // Valid dynamic route
    }
    if (pathname.match(/^\/admin-ban-details\/\w+$/)) {
      return pathname; // Valid dynamic route
    }
    if (pathname.match(/^\/admin-ban-appeal\/\w+$/)) {
      return pathname; // Valid dynamic route
    }

    return null;
  }

  intelligentRedirect(pathname) {
    const segments = pathname.split('/').filter(Boolean);
    
    if (segments.length === 0) {
      return '/';
    }

    const firstSegment = segments[0];

    // Admin-related redirects
    if (firstSegment === 'admin' || pathname.startsWith('/admin')) {
      if (segments.includes('login') || segments.length === 1) {
        return '/admin-secure-login';
      }
      if (segments.includes('dashboard')) {
        return '/admin-dashboard';
      }
      if (segments.includes('users')) {
        return '/admin-active-users';
      }
      return '/admin-dashboard';
    }

    // User-related redirects
    if (firstSegment === 'user') {
      if (segments.includes('login')) {
        return '/user-login';
      }
      if (segments.includes('dashboard')) {
        return '/user-dashboard';
      }
      return '/user-login';
    }

    // Auth-related redirects
    if (firstSegment === 'login' || firstSegment === 'signin') {
      return '/login-selection';
    }

    if (firstSegment === 'register' || firstSegment === 'signup') {
      return '/register';
    }

    // Default fallback
    return '/';
  }

  // Manual route fixing method
  fixCurrentRoute() {
    const currentPath = window.location.pathname;
    const fixedPath = this.fixRoute(currentPath);
    
    if (fixedPath !== currentPath) {
      console.log(`Fixing route from ${currentPath} to ${fixedPath}`);
      window.location.replace(fixedPath);
      return true;
    }
    
    return false;
  }

  // Check if current route is valid
  validateCurrentRoute() {
    const currentPath = window.location.pathname;
    return this.isValidRoute(currentPath);
  }

  // Get suggested route for invalid paths
  getSuggestedRoute(pathname) {
    return this.fixRoute(pathname);
  }
}

// Create singleton instance
const routingFix = new RoutingFix();

// Initialize on page load
if (typeof window !== 'undefined') {
  window.addEventListener('load', () => {
    // Fix current route if needed
    setTimeout(() => {
      routingFix.fixCurrentRoute();
    }, 100);
  });
}

export default routingFix;
export { routingFix };
