/**
 * Backend Connection and Sync Test Utility
 * Tests if frontend properly connects to your backend/database
 */

export const testBackendConnection = async () => {
  const config = {
    apiUrl: import.meta.env.VITE_API_URL,
    enableBackend: import.meta.env.VITE_ENABLE_BACKEND === 'true',
    dbType: import.meta.env.VITE_DB_TYPE
  };

  console.log('🔍 Testing backend connection...', config);

  const results = {
    config,
    tests: [],
    success: false,
    recommendations: []
  };

  // Test 1: Check API URL accessibility
  if (config.enableBackend && config.apiUrl) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);

      const response = await fetch(`${config.apiUrl}/health`, {
        signal: controller.signal,
        method: 'GET'
      });

      clearTimeout(timeoutId);

      results.tests.push({
        name: 'API Health Check',
        passed: response.ok,
        details: `${response.status} ${response.statusText}`,
        url: `${config.apiUrl}/health`
      });

    } catch (error) {
      results.tests.push({
        name: 'API Health Check',
        passed: false,
        details: error.message,
        url: `${config.apiUrl}/health`
      });
    }
  } else {
    results.tests.push({
      name: 'API Configuration',
      passed: false,
      details: 'Backend disabled or API URL not configured',
      recommendation: 'Set VITE_ENABLE_BACKEND=true and configure VITE_API_URL'
    });
  }

  // Test 2: Check database connection
  try {
    const { checkDatabaseStatus } = await import('../config/database.js');
    const dbStatus = await checkDatabaseStatus();
    
    results.tests.push({
      name: 'Database Connection',
      passed: dbStatus.status === 'connected',
      details: dbStatus.message || dbStatus.error || dbStatus.status,
      dbType: config.dbType
    });

    if (dbStatus.status !== 'connected') {
      if (config.dbType === 'localStorage') {
        results.recommendations.push('Using localStorage - consider upgrading to Supabase for real backend sync');
      } else {
        results.recommendations.push(`${config.dbType} connection failed - check credentials and network`);
      }
    }
    
  } catch (error) {
    results.tests.push({
      name: 'Database Connection',
      passed: false,
      details: error.message
    });
  }

  // Test 3: Check registration sync
  try {
    const users = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
    const kycRequests = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
    
    results.tests.push({
      name: 'Registration Data Sync',
      passed: true,
      details: `${users.length} users, ${kycRequests.length} KYC requests in localStorage`,
      localStorage: true
    });

    if (config.dbType === 'localStorage') {
      results.recommendations.push('Registrations sync within frontend only - no external database connected');
    }
    
  } catch (error) {
    results.tests.push({
      name: 'Registration Data Sync',
      passed: false,
      details: error.message
    });
  }

  // Test 4: Test registration endpoint
  if (config.enableBackend && config.apiUrl) {
    try {
      const testData = {
        email: 'test@example.com',
        name: 'Test User'
      };

      const response = await fetch(`${config.apiUrl}/users/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(testData)
      });

      results.tests.push({
        name: 'Registration Endpoint',
        passed: response.ok || response.status === 409, // 409 = user exists is OK
        details: `${response.status} ${response.statusText}`,
        endpoint: `${config.apiUrl}/users/register`
      });

    } catch (error) {
      results.tests.push({
        name: 'Registration Endpoint',
        passed: false,
        details: error.message,
        endpoint: `${config.apiUrl}/users/register`
      });
    }
  }

  // Determine overall success
  results.success = results.tests.every(test => test.passed);

  // Generate recommendations
  if (!results.success) {
    if (config.dbType === 'localStorage') {
      results.recommendations.push('✅ Your registrations ARE syncing - they\'re stored in browser localStorage');
      results.recommendations.push('💡 To sync with external backend: Set up Supabase or configure VITE_API_URL');
    } else {
      results.recommendations.push('❌ Backend/database connection failed');
      results.recommendations.push('🔧 Check your database credentials and network connectivity');
    }
  }

  console.log('📊 Backend connection test results:', results);
  return results;
};

export const fixCommonSyncIssues = async () => {
  console.log('🔧 Attempting to fix common sync issues...');
  
  const fixes = [];

  // Fix 1: Ensure localStorage has proper structure
  try {
    const requiredKeys = ['admin_users_data', 'admin_pending_kyc'];
    requiredKeys.forEach(key => {
      if (!localStorage.getItem(key)) {
        localStorage.setItem(key, '[]');
        fixes.push(`✅ Initialized ${key} in localStorage`);
      }
    });
  } catch (error) {
    fixes.push(`❌ localStorage fix failed: ${error.message}`);
  }

  // Fix 2: Trigger registration sync test
  try {
    const { testRegistrationSync } = await import('./registrationSyncTest.js');
    const result = testRegistrationSync();
    if (result.success) {
      fixes.push('✅ Registration sync test passed');
    } else {
      fixes.push(`❌ Registration sync test failed: ${result.message}`);
    }
  } catch (error) {
    fixes.push(`⚠️ Could not run registration sync test: ${error.message}`);
  }

  // Fix 3: Check if data exists but admin not showing
  const users = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
  if (users.length > 0) {
    fixes.push(`📊 Found ${users.length} users in localStorage - they should appear in admin panel`);
    fixes.push('💡 If admin panel is empty, try refreshing or clearing browser cache');
  } else {
    fixes.push('📭 No users found in localStorage - register a test user to verify sync');
  }

  console.log('🔧 Sync fixes applied:', fixes);
  return fixes;
};

// Auto-expose to window for easy testing
if (typeof window !== 'undefined') {
  window.testBackendConnection = testBackendConnection;
  window.fixCommonSyncIssues = fixCommonSyncIssues;
}

export default {
  testBackendConnection,
  fixCommonSyncIssues
};
