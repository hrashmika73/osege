/**
 * Admin Notification System for Real-time Updates
 * Shows notifications when new users register
 */

export const showRegistrationNotification = (userData) => {
  try {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg z-50 transform transition-all duration-300 translate-x-full';
    notification.innerHTML = `
      <div class="flex items-center space-x-3">
        <div class="flex-shrink-0">
          <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
          </svg>
        </div>
        <div>
          <p class="font-semibold">New User Registration!</p>
          <p class="text-sm">${userData.email || 'Unknown user'} just registered</p>
        </div>
        <button onclick="this.parentElement.parentElement.remove()" class="text-white hover:text-gray-200">
          <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
          </svg>
        </button>
      </div>
    `;

    // Add to page
    document.body.appendChild(notification);

    // Animate in
    setTimeout(() => {
      notification.classList.remove('translate-x-full');
    }, 100);

    // Auto-remove after 5 seconds
    setTimeout(() => {
      notification.classList.add('translate-x-full');
      setTimeout(() => {
        if (notification.parentElement) {
          notification.parentElement.removeChild(notification);
        }
      }, 300);
    }, 5000);

    console.log('📢 Registration notification displayed for:', userData.email);

  } catch (error) {
    console.error('Error showing registration notification:', error);
  }
};

export const initializeAdminNotifications = () => {
  // Listen for new user registrations
  const handleUserRegistered = (event) => {
    const { user } = event.detail;
    showRegistrationNotification(user);
  };

  window.addEventListener('userRegistered', handleUserRegistered);

  // Return cleanup function
  return () => {
    window.removeEventListener('userRegistered', handleUserRegistered);
  };
};

// Auto-initialize if in admin context
if (typeof window !== 'undefined' && window.location.pathname.includes('/admin')) {
  initializeAdminNotifications();
}

export default {
  showRegistrationNotification,
  initializeAdminNotifications
};
