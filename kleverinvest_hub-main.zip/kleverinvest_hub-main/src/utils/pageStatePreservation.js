/**
 * Page State Preservation Utility
 * Ensures users stay on the same page after reload
 */

export const pageStatePreservation = {
  // Store current page state before potential navigation
  storePage: (pagePath = window.location.pathname + window.location.search) => {
    try {
      sessionStorage.setItem('preservedPagePath', pagePath);
      sessionStorage.setItem('preservedPageTimestamp', Date.now().toString());
      console.log('📌 Page state stored:', pagePath);
    } catch (error) {
      console.warn('Could not store page state:', error);
    }
  },

  // Get stored page state
  getStoredPage: () => {
    try {
      const pagePath = sessionStorage.getItem('preservedPagePath');
      const timestamp = sessionStorage.getItem('preservedPageTimestamp');
      
      if (pagePath && timestamp) {
        const age = Date.now() - parseInt(timestamp);
        const maxAge = 10 * 60 * 1000; // 10 minutes
        
        if (age < maxAge) {
          return pagePath;
        } else {
          // Clean up old data
          pageStatePreservation.clearStoredPage();
        }
      }
      
      return null;
    } catch (error) {
      console.warn('Could not get stored page state:', error);
      return null;
    }
  },

  // Clear stored page state
  clearStoredPage: () => {
    try {
      sessionStorage.removeItem('preservedPagePath');
      sessionStorage.removeItem('preservedPageTimestamp');
    } catch (error) {
      console.warn('Could not clear page state:', error);
    }
  },

  // Check if current page should be preserved
  shouldPreservePage: () => {
    const path = window.location.pathname;
    
    // Don't preserve login pages
    if (path.includes('/login') || path.includes('/auth')) {
      return false;
    }
    
    // Preserve all admin pages
    if (path.startsWith('/admin')) {
      return true;
    }
    
    // Preserve user dashboard and related pages
    if (path.startsWith('/user') || path.startsWith('/dashboard')) {
      return true;
    }
    
    return false;
  },

  // Auto-store page if it should be preserved
  autoStorePage: () => {
    if (pageStatePreservation.shouldPreservePage()) {
      pageStatePreservation.storePage();
    }
  },

  // Restore page if there's a valid stored state and user is authenticated
  restorePageIfAuthenticated: (isAuthenticated = false, navigate = null) => {
    if (!isAuthenticated || !navigate) {
      return false;
    }
    
    const storedPage = pageStatePreservation.getStoredPage();
    const currentPage = window.location.pathname + window.location.search;
    
    if (storedPage && storedPage !== currentPage) {
      console.log('🔄 Restoring page state:', storedPage);
      navigate(storedPage);
      pageStatePreservation.clearStoredPage();
      return true;
    }
    
    return false;
  }
};

// Auto-store page state on page load (if applicable)
if (typeof window !== 'undefined') {
  // Store page state when navigating away or before refresh
  window.addEventListener('beforeunload', () => {
    pageStatePreservation.autoStorePage();
  });
  
  // Store page state on visibility change (mobile browsers)
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      pageStatePreservation.autoStorePage();
    }
  });
  
  // Store page state periodically (every 30 seconds) for long-running sessions
  setInterval(() => {
    if (pageStatePreservation.shouldPreservePage()) {
      pageStatePreservation.autoStorePage();
    }
  }, 30000);
}

export default pageStatePreservation;
