// Email Verification and Security Utilities

// Email verification API (Mock implementation)
export const emailVerificationAPI = {
  // Send verification email
  sendVerificationEmail: async (email, userId) => {
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const verificationToken = generateVerificationToken();
      
      // In production, this would send an actual email
      console.log(`Verification email sent to ${email}`);
      console.log(`Verification link: https://kleverinvest.com/verify-email?token=${verificationToken}&user=${userId}`);
      
      return {
        success: true,
        data: {
          email,
          token: verificationToken,
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours
          message: 'Verification email sent successfully'
        }
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Verify email token
  verifyEmailToken: async (token, userId) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Simulate token validation
      const isValid = token && token.length > 20;
      
      if (isValid) {
        return {
          success: true,
          data: {
            userId,
            verified: true,
            verifiedAt: new Date().toISOString(),
            message: 'Email verified successfully'
          }
        };
      } else {
        return {
          success: false,
          error: 'Invalid or expired verification token'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Resend verification email
  resendVerificationEmail: async (email, userId) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      return await emailVerificationAPI.sendVerificationEmail(email, userId);
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
};

// Two-Factor Authentication (2FA) utilities
export const twoFactorAuth = {
  // Generate 2FA setup
  setup2FA: async (userId) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const secret = generateSecret();
      const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=otpauth://totp/KleverInvest:user${userId}?secret=${secret}&issuer=KleverInvest`;
      
      return {
        success: true,
        data: {
          secret,
          qrCodeUrl,
          backupCodes: generateBackupCodes(),
          setupUrl: `otpauth://totp/KleverInvest:user${userId}?secret=${secret}&issuer=KleverInvest`
        }
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Verify 2FA code
  verify2FA: async (userId, code) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Simulate code validation
      const isValid = code && code.length === 6 && /^\d+$/.test(code);
      
      return {
        success: true,
        data: {
          valid: isValid,
          message: isValid ? '2FA code verified' : 'Invalid 2FA code'
        }
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Disable 2FA
  disable2FA: async (userId, currentCode) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 400));
      
      const verification = await twoFactorAuth.verify2FA(userId, currentCode);
      
      if (verification.data.valid) {
        return {
          success: true,
          data: {
            disabled: true,
            message: '2FA has been disabled'
          }
        };
      } else {
        return {
          success: false,
          error: 'Invalid 2FA code'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
};

// Password security utilities
export const passwordSecurity = {
  // Check password strength
  checkPasswordStrength: (password) => {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    let score = 0;
    let feedback = [];
    
    if (password.length >= minLength) score++;
    else feedback.push('Use at least 8 characters');
    
    if (hasUpperCase) score++;
    else feedback.push('Include uppercase letters');
    
    if (hasLowerCase) score++;
    else feedback.push('Include lowercase letters');
    
    if (hasNumbers) score++;
    else feedback.push('Include numbers');
    
    if (hasSpecialChar) score++;
    else feedback.push('Include special characters');
    
    const strength = score <= 2 ? 'weak' : score <= 3 ? 'medium' : score <= 4 ? 'good' : 'strong';
    
    return {
      score,
      strength,
      feedback,
      isValid: score >= 3
    };
  },

  // Hash password (mock implementation)
  hashPassword: async (password) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // In production, use bcrypt or similar
      const salt = Math.random().toString(36).substring(2, 15);
      const hash = btoa(password + salt); // Simple encoding for demo
      
      return {
        success: true,
        data: {
          hash: hash,
          salt: salt
        }
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Verify password
  verifyPassword: async (password, hash, salt) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const testHash = btoa(password + salt);
      const isValid = testHash === hash;
      
      return {
        success: true,
        data: {
          valid: isValid
        }
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
};

// Session security
export const sessionSecurity = {
  // Generate secure session token
  generateSessionToken: () => {
    return Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  },

  // Validate session
  validateSession: async (token) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 200));
      
      // In production, validate against database
      const isValid = token && token.length === 64;
      
      return {
        success: true,
        data: {
          valid: isValid,
          expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString() // 1 hour
        }
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  },

  // Rate limiting
  checkRateLimit: async (identifier, maxAttempts = 5, windowMs = 15 * 60 * 1000) => {
    try {
      const key = `rate_limit_${identifier}`;
      const now = Date.now();
      
      // Get stored attempts (in production, use Redis or database)
      const stored = localStorage.getItem(key);
      let attempts = stored ? JSON.parse(stored) : { count: 0, resetTime: now + windowMs };
      
      // Reset if window expired
      if (now > attempts.resetTime) {
        attempts = { count: 0, resetTime: now + windowMs };
      }
      
      // Check if rate limited
      if (attempts.count >= maxAttempts) {
        const remainingTime = Math.ceil((attempts.resetTime - now) / 1000 / 60);
        return {
          success: false,
          rateLimited: true,
          remainingTime: remainingTime,
          error: `Too many attempts. Try again in ${remainingTime} minutes.`
        };
      }
      
      // Increment attempt count
      attempts.count++;
      localStorage.setItem(key, JSON.stringify(attempts));
      
      return {
        success: true,
        remainingAttempts: maxAttempts - attempts.count
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
};

// Utility functions
const generateVerificationToken = () => {
  return Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
};

const generateSecret = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let secret = '';
  for (let i = 0; i < 32; i++) {
    secret += chars[Math.floor(Math.random() * chars.length)];
  }
  return secret;
};

const generateBackupCodes = () => {
  const codes = [];
  for (let i = 0; i < 10; i++) {
    const code = Math.random().toString(36).substring(2, 10).toUpperCase();
    codes.push(code);
  }
  return codes;
};

// CSRF protection
export const csrfProtection = {
  // Generate CSRF token
  generateCSRFToken: () => {
    const token = Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
    
    // Store in session storage
    sessionStorage.setItem('csrf_token', token);
    return token;
  },

  // Validate CSRF token
  validateCSRFToken: (token) => {
    const storedToken = sessionStorage.getItem('csrf_token');
    return storedToken === token;
  },

  // Get CSRF token for forms
  getCSRFToken: () => {
    let token = sessionStorage.getItem('csrf_token');
    if (!token) {
      token = csrfProtection.generateCSRFToken();
    }
    return token;
  }
};

export default {
  emailVerificationAPI,
  twoFactorAuth,
  passwordSecurity,
  sessionSecurity,
  csrfProtection
};
