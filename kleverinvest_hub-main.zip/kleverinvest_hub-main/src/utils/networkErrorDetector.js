/**
 * Network Error Detection and Reporting System
 * Identifies and reports specific NetworkError sources
 */

export class NetworkErrorDetector {
  constructor() {
    this.errorLog = [];
    this.errorCounts = new Map();
    this.isLogging = true;
    this.maxLogSize = 100;
  }

  /**
   * Start comprehensive error monitoring
   */
  startMonitoring() {
    this.setupErrorListeners();
    this.setupPerformanceMonitoring();
    this.setupResourceMonitoring();
    console.log('🔍 Network error detection started');
  }

  /**
   * Setup error event listeners
   */
  setupErrorListeners() {
    // Global error handler
    window.addEventListener('error', (event) => {
      this.handleError({
        type: 'javascript_error',
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        error: event.error,
        timestamp: Date.now(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
    });

    // Unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      this.handleError({
        type: 'unhandled_rejection',
        message: event.reason?.message || event.reason?.toString() || 'Unknown rejection',
        reason: event.reason,
        timestamp: Date.now(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
    });

    // Resource loading errors
    window.addEventListener('error', (event) => {
      if (event.target && event.target !== window) {
        const target = event.target;
        this.handleError({
          type: 'resource_error',
          message: `Failed to load ${target.tagName}: ${target.src || target.href}`,
          element: target.tagName,
          src: target.src || target.href,
          timestamp: Date.now(),
          userAgent: navigator.userAgent,
          url: window.location.href
        });
      }
    }, true);
  }

  /**
   * Setup performance monitoring
   */
  setupPerformanceMonitoring() {
    if ('PerformanceObserver' in window) {
      // Monitor navigation timing
      const navObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.entryType === 'navigation') {
            this.analyzeNavigationTiming(entry);
          }
        }
      });
      navObserver.observe({ entryTypes: ['navigation'] });

      // Monitor resource timing
      const resourceObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.entryType === 'resource') {
            this.analyzeResourceTiming(entry);
          }
        }
      });
      resourceObserver.observe({ entryTypes: ['resource'] });
    }
  }

  /**
   * Setup resource monitoring
   */
  setupResourceMonitoring() {
    // Monitor fetch requests
    const originalFetch = window.fetch;
    window.fetch = async (...args) => {
      const startTime = performance.now();
      const url = args[0];
      
      try {
        const response = await originalFetch(...args);
        const endTime = performance.now();
        
        this.logFetchSuccess(url, response, endTime - startTime);
        return response;
      } catch (error) {
        const endTime = performance.now();
        this.handleError({
          type: 'fetch_error',
          message: `Fetch failed: ${error.message}`,
          url: url,
          error: error,
          duration: endTime - startTime,
          timestamp: Date.now(),
          userAgent: navigator.userAgent,
          pageUrl: window.location.href
        });
        throw error;
      }
    };

    // Monitor XMLHttpRequest
    const originalXHR = window.XMLHttpRequest;
    window.XMLHttpRequest = function() {
      const xhr = new originalXHR();
      const originalOpen = xhr.open;
      const originalSend = xhr.send;
      
      let method, url, startTime;
      
      xhr.open = function(m, u, ...args) {
        method = m;
        url = u;
        return originalOpen.call(this, m, u, ...args);
      };
      
      xhr.send = function(...args) {
        startTime = performance.now();
        
        const originalOnError = xhr.onerror;
        xhr.onerror = function(event) {
          const endTime = performance.now();
          NetworkErrorDetector.instance.handleError({
            type: 'xhr_error',
            message: `XHR failed: ${method} ${url}`,
            method: method,
            url: url,
            duration: endTime - startTime,
            timestamp: Date.now(),
            userAgent: navigator.userAgent,
            pageUrl: window.location.href
          });
          
          if (originalOnError) originalOnError.call(this, event);
        };
        
        return originalSend.call(this, ...args);
      };
      
      return xhr;
    };
  }

  /**
   * Handle detected errors
   */
  handleError(errorData) {
    if (!this.isLogging) return;

    // Categorize the error
    const category = this.categorizeError(errorData);
    errorData.category = category;

    // Count errors by type
    const errorKey = `${errorData.type}_${category}`;
    this.errorCounts.set(errorKey, (this.errorCounts.get(errorKey) || 0) + 1);

    // Log the error
    this.errorLog.push(errorData);
    
    // Maintain log size
    if (this.errorLog.length > this.maxLogSize) {
      this.errorLog.shift();
    }

    // Log to console with appropriate level
    this.logError(errorData);

    // Check for critical patterns
    this.checkCriticalPatterns(errorData);
  }

  /**
   * Categorize error types
   */
  categorizeError(errorData) {
    const message = errorData.message.toLowerCase();
    const url = (errorData.url || errorData.src || '').toLowerCase();

    if (message.includes('failed to fetch') || message.includes('networkerror')) {
      if (url.includes('api') || url.includes('/database/')) return 'api_network_error';
      if (url.includes('fonts.googleapis.com')) return 'font_loading_error';
      if (url.includes('.js') || url.includes('chunk')) return 'script_loading_error';
      if (url.includes('.css')) return 'css_loading_error';
      return 'general_network_error';
    }

    if (message.includes('chunk') || message.includes('loading css chunk')) {
      return 'chunk_loading_error';
    }

    if (message.includes('dynamically imported module')) {
      return 'dynamic_import_error';
    }

    if (message.includes('timeout') || message.includes('aborted')) {
      return 'timeout_error';
    }

    if (url.includes('google') || url.includes('apple') || url.includes('oauth')) {
      return 'oauth_error';
    }

    return 'unknown_error';
  }

  /**
   * Log error with appropriate level
   */
  logError(errorData) {
    const { type, category, message, url } = errorData;
    const prefix = this.getLogPrefix(category);

    switch (category) {
      case 'api_network_error':
        console.warn(`${prefix} API Network Error:`, message, url);
        break;
      case 'chunk_loading_error':
        console.error(`${prefix} Chunk Loading Error:`, message);
        break;
      case 'font_loading_error':
        console.warn(`${prefix} Font Loading Error:`, message);
        break;
      case 'script_loading_error':
        console.warn(`${prefix} Script Loading Error:`, message);
        break;
      case 'oauth_error':
        console.warn(`${prefix} OAuth Error:`, message);
        break;
      default:
        console.warn(`${prefix} Network Error (${category}):`, message);
    }
  }

  /**
   * Get log prefix for error category
   */
  getLogPrefix(category) {
    const prefixes = {
      api_network_error: '🌐',
      chunk_loading_error: '📦',
      font_loading_error: '🔤',
      script_loading_error: '📜',
      css_loading_error: '🎨',
      oauth_error: '🔐',
      timeout_error: '⏰',
      dynamic_import_error: '🔄',
      general_network_error: '🚫',
      unknown_error: '❓'
    };
    return prefixes[category] || '⚠️';
  }

  /**
   * Check for critical error patterns
   */
  checkCriticalPatterns(errorData) {
    const { category } = errorData;
    const count = this.errorCounts.get(`${errorData.type}_${category}`);

    // Critical thresholds
    if (category === 'chunk_loading_error' && count >= 3) {
      console.error('🚨 Critical: Multiple chunk loading errors detected - suggesting page reload');
      this.suggestPageReload();
    }

    if (category === 'api_network_error' && count >= 5) {
      console.warn('🚨 Warning: Multiple API errors - switching to offline mode');
      this.suggestOfflineMode();
    }
  }

  /**
   * Suggest page reload for critical errors
   */
  suggestPageReload() {
    if (window.confirm('Multiple loading errors detected. Reload the page to fix the issue?')) {
      window.location.reload();
    }
  }

  /**
   * Suggest offline mode
   */
  suggestOfflineMode() {
    console.log('💾 Switching to offline/localStorage mode');
    window.dispatchEvent(new CustomEvent('forceOfflineMode', {
      detail: { reason: 'Multiple API errors detected' }
    }));
  }

  /**
   * Analyze navigation timing
   */
  analyzeNavigationTiming(entry) {
    const timing = {
      dns: entry.domainLookupEnd - entry.domainLookupStart,
      connect: entry.connectEnd - entry.connectStart,
      request: entry.responseStart - entry.requestStart,
      response: entry.responseEnd - entry.responseStart,
      total: entry.loadEventEnd - entry.navigationStart
    };

    if (timing.total > 10000) { // > 10 seconds
      console.warn('🐌 Slow page load detected:', timing);
    }

    if (timing.dns > 3000) { // > 3 seconds DNS
      console.warn('🌐 Slow DNS resolution detected:', timing.dns + 'ms');
    }
  }

  /**
   * Analyze resource timing
   */
  analyzeResourceTiming(entry) {
    const duration = entry.duration;
    const name = entry.name;

    if (duration > 5000 && name.includes('api')) { // > 5 seconds for API
      console.warn('🐌 Slow API request:', name, duration + 'ms');
    }

    if (entry.transferSize === 0 && duration > 0) {
      // Possibly failed request
      console.warn('❌ Potential failed resource:', name);
    }
  }

  /**
   * Log successful fetch for monitoring
   */
  logFetchSuccess(url, response, duration) {
    if (duration > 3000) { // > 3 seconds
      console.warn('🐌 Slow fetch request:', url, duration + 'ms', response.status);
    }
  }

  /**
   * Get error report
   */
  getErrorReport() {
    const summary = {};
    for (const [key, count] of this.errorCounts.entries()) {
      summary[key] = count;
    }

    return {
      summary,
      recentErrors: this.errorLog.slice(-10),
      totalErrors: this.errorLog.length,
      networkStatus: navigator.onLine ? 'online' : 'offline',
      timestamp: Date.now()
    };
  }

  /**
   * Clear error log
   */
  clearLog() {
    this.errorLog = [];
    this.errorCounts.clear();
    console.log('🧹 Error log cleared');
  }

  /**
   * Stop monitoring
   */
  stopMonitoring() {
    this.isLogging = false;
    console.log('🔍 Network error detection stopped');
  }
}

// Create singleton instance
const detector = new NetworkErrorDetector();
NetworkErrorDetector.instance = detector;

export default detector;

// Export convenience methods
export const {
  startMonitoring,
  getErrorReport,
  clearLog,
  stopMonitoring
} = detector;
