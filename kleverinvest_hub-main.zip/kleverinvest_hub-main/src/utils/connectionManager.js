/**
 * Connection Manager for Backend/Frontend Communication
 * Handles all connectivity issues and synchronization
 */

class ConnectionManager {
  constructor() {
    this.isOnline = navigator.onLine;
    this.backendStatus = 'unknown';
    this.connectionAttempts = 0;
    this.maxRetries = 3;
    this.retryDelay = 1000;
    this.listeners = new Set();
    
    this.initialize();
  }

  initialize() {
    // Monitor online/offline status
    window.addEventListener('online', () => {
      this.isOnline = true;
      this.notifyListeners('online', true);
      this.testBackendConnection();
    });

    window.addEventListener('offline', () => {
      this.isOnline = false;
      this.notifyListeners('online', false);
    });

    // Initial connection test
    this.testBackendConnection();
    
    // Periodic connection testing
    setInterval(() => {
      this.testBackendConnection();
    }, 30000); // Test every 30 seconds
  }

  async testBackendConnection() {
    if (!this.isOnline) {
      this.backendStatus = 'offline';
      this.notifyListeners('backend', 'offline');
      return false;
    }

    try {
      // Test multiple endpoints to ensure backend is working
      const tests = [
        this.testEndpoint('/api/health'),
        this.testEndpoint('/api/admin/health'),
        this.testApiService()
      ];

      const results = await Promise.allSettled(tests);
      const successfulTests = results.filter(result => result.status === 'fulfilled').length;
      
      if (successfulTests > 0) {
        this.backendStatus = 'connected';
        this.connectionAttempts = 0;
        this.notifyListeners('backend', 'connected');
        return true;
      } else {
        throw new Error('All backend tests failed');
      }
    } catch (error) {
      console.warn('Backend connection test failed:', error.message);
      this.backendStatus = 'disconnected';
      this.connectionAttempts++;
      this.notifyListeners('backend', 'disconnected');
      
      // Auto-retry with exponential backoff
      if (this.connectionAttempts < this.maxRetries) {
        setTimeout(() => {
          this.testBackendConnection();
        }, this.retryDelay * Math.pow(2, this.connectionAttempts));
      }
      
      return false;
    }
  }

  async testEndpoint(endpoint) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    try {
      const response = await fetch(endpoint, {
        method: 'GET',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
        }
      });
      
      clearTimeout(timeoutId);
      return response.ok;
    } catch (error) {
      clearTimeout(timeoutId);
      throw error;
    }
  }

  async testApiService() {
    try {
      // Test the admin API service directly to avoid dynamic import warnings
      const response = await fetch('/api/admin/health', {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      });
      return response.ok;
    } catch (error) {
      return false;
    }
  }

  // Synchronization methods
  async syncData(action, data) {
    if (this.backendStatus === 'connected') {
      try {
        return await this.sendToBackend(action, data);
      } catch (error) {
        console.warn('Backend sync failed, using local storage:', error.message);
        return this.syncToLocalStorage(action, data);
      }
    } else {
      return this.syncToLocalStorage(action, data);
    }
  }

  async sendToBackend(action, data) {
    // Implement actual backend API calls here
    const endpoint = this.getEndpointForAction(action);
    
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('adminToken') || localStorage.getItem('userToken')}`
      },
      body: JSON.stringify(data)
    });

    if (!response.ok) {
      throw new Error(`Backend request failed: ${response.status}`);
    }

    return response.json();
  }

  syncToLocalStorage(action, data) {
    try {
      const key = this.getStorageKeyForAction(action);
      const existingData = JSON.parse(localStorage.getItem(key) || '[]');
      
      switch (action) {
        case 'user_register':
          existingData.push(data);
          break;
        case 'user_update':
          const userIndex = existingData.findIndex(u => u.id === data.id);
          if (userIndex !== -1) {
            existingData[userIndex] = { ...existingData[userIndex], ...data };
          }
          break;
        case 'kyc_submit':
          const kycData = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
          kycData.push(data);
          localStorage.setItem('admin_pending_kyc', JSON.stringify(kycData));
          break;
        default:
          console.warn('Unknown sync action:', action);
          return false;
      }
      
      localStorage.setItem(key, JSON.stringify(existingData));
      this.notifyListeners('data_synced', { action, data });
      return true;
    } catch (error) {
      console.error('Local storage sync failed:', error);
      return false;
    }
  }

  getEndpointForAction(action) {
    const endpoints = {
      'user_register': '/api/users/register',
      'user_update': '/api/users/update',
      'kyc_submit': '/api/kyc/submit',
      'admin_update': '/api/admin/update'
    };
    return endpoints[action] || '/api/sync';
  }

  getStorageKeyForAction(action) {
    const keys = {
      'user_register': 'admin_users_data',
      'user_update': 'admin_users_data',
      'kyc_submit': 'admin_pending_kyc',
      'admin_update': 'admin_data'
    };
    return keys[action] || 'sync_data';
  }

  // Event listeners for connection status changes
  addListener(callback) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  notifyListeners(type, data) {
    this.listeners.forEach(callback => {
      try {
        callback(type, data);
      } catch (error) {
        console.error('Connection listener error:', error);
      }
    });
  }

  // Status getters
  getConnectionStatus() {
    return {
      isOnline: this.isOnline,
      backendStatus: this.backendStatus,
      connectionAttempts: this.connectionAttempts,
      lastCheck: new Date().toISOString()
    };
  }

  // Force reconnection
  async forceReconnect() {
    this.connectionAttempts = 0;
    this.backendStatus = 'unknown';
    return this.testBackendConnection();
  }

  // Clear all cached data and force fresh sync
  async clearAndResync() {
    try {
      // Clear problematic data
      const keysToCheck = [
        'admin_users_data',
        'admin_pending_kyc',
        'user_session_data',
        'app_cache'
      ];

      keysToCheck.forEach(key => {
        try {
          const data = localStorage.getItem(key);
          if (data) {
            console.log(`Refreshing ${key} data`);
            // Re-parse and clean data
            const parsed = JSON.parse(data);
            localStorage.setItem(key, JSON.stringify(parsed));
          }
        } catch (error) {
          console.warn(`Error refreshing ${key}:`, error);
          localStorage.removeItem(key);
        }
      });

      // Force connection test
      await this.forceReconnect();
      
      return true;
    } catch (error) {
      console.error('Clear and resync failed:', error);
      return false;
    }
  }
}

// Create singleton instance
const connectionManager = new ConnectionManager();

export default connectionManager;

// Export specific methods for easy use
export const {
  testBackendConnection,
  syncData,
  addListener,
  getConnectionStatus,
  forceReconnect,
  clearAndResync
} = connectionManager;
