/**
 * Registration and KYC Debug Utility
 * Helps debug why registrations and KYC submissions aren't showing in admin
 */

export const debugRegistrationKycFlow = () => {
  console.log('🔍 Debugging Registration and KYC Flow...');
  
  try {
    // Check all storage keys
    const storageKeys = [
      'admin_users_data',
      'admin_active_users',
      'admin_pending_kyc',
      'userData',
      'userToken'
    ];
    
    const storageData = {};
    storageKeys.forEach(key => {
      const rawData = localStorage.getItem(key);
      storageData[key] = {
        exists: rawData !== null,
        raw: rawData,
        parsed: null,
        count: 0,
        error: null
      };
      
      if (rawData) {
        try {
          const parsed = JSON.parse(rawData);
          storageData[key].parsed = parsed;
          storageData[key].count = Array.isArray(parsed) ? parsed.length : (typeof parsed === 'object' ? 1 : 0);
        } catch (error) {
          storageData[key].error = error.message;
        }
      }
    });
    
    console.log('📊 Storage Analysis:', storageData);
    
    // Check data format issues
    const adminUsers = storageData.admin_users_data.parsed || [];
    const kycRequests = storageData.admin_pending_kyc.parsed || [];
    
    console.log('👥 Admin Users Details:', adminUsers);
    console.log('📋 KYC Requests Details:', kycRequests);
    
    // Check for data format issues
    const formatIssues = [];
    
    adminUsers.forEach((user, index) => {
      if (!user.id) formatIssues.push(`User ${index}: Missing id`);
      if (!user.email) formatIssues.push(`User ${index}: Missing email`);
      if (!user.status) formatIssues.push(`User ${index}: Missing status`);
      if (!user.fullName) formatIssues.push(`User ${index}: Missing fullName`);
    });
    
    kycRequests.forEach((request, index) => {
      if (!request.userId) formatIssues.push(`KYC ${index}: Missing userId`);
      if (!request.email) formatIssues.push(`KYC ${index}: Missing email`);
      if (!request.status) formatIssues.push(`KYC ${index}: Missing status`);
    });
    
    if (formatIssues.length > 0) {
      console.warn('⚠️ Data Format Issues Found:', formatIssues);
    } else {
      console.log('✅ Data format looks correct');
    }
    
    // Test API response
    return {
      storageData,
      formatIssues,
      summary: {
        totalUsers: adminUsers.length,
        activeUsers: adminUsers.filter(u => u.status === 'active').length,
        pendingKyc: kycRequests.length,
        hasUsers: adminUsers.length > 0,
        hasKyc: kycRequests.length > 0
      }
    };
    
  } catch (error) {
    console.error('❌ Debug error:', error);
    return { error: error.message };
  }
};

export const testAdminApiResponse = async () => {
  console.log('🧪 Testing Admin API Response...');
  
  try {
    const { adminUserAPI } = await import('../services/adminApiService');
    
    // Test getUsers API
    const usersResponse = await adminUserAPI.getUsers(1, 100, { status: 'active' });
    console.log('👥 Users API Response:', usersResponse);
    
    // Test getUserStats API  
    const statsResponse = await adminUserAPI.getUserStats();
    console.log('📊 Stats API Response:', statsResponse);
    
    return {
      usersResponse,
      statsResponse,
      usersReturned: usersResponse?.data?.users?.length || 0,
      success: usersResponse?.success || false
    };
    
  } catch (error) {
    console.error('❌ API test error:', error);
    return { error: error.message };
  }
};

export const simulateRegistrationFlow = async () => {
  console.log('🎭 Simulating Registration Flow...');
  
  try {
    // Step 1: Create test user data
    const testUser = {
      id: 'user_debug_' + Date.now(),
      name: 'Debug Test User',
      email: 'debugtest@example.com',
      password: 'TestPass123!',
      phone: '+1-555-DEBUG',
      country: 'US',
      kycStatus: 'pending',
      balance: 0
    };
    
    console.log('1️⃣ Test user data:', testUser);
    
    // Step 2: Add through userDataManager
    const { addNewUser, createKYCRequest } = await import('./userDataManager');
    
    console.log('2️⃣ Adding user through userDataManager...');
    const adminUserData = addNewUser(testUser);
    console.log('✅ User added:', adminUserData);
    
    console.log('3️⃣ Creating KYC request...');
    const kycRequest = createKYCRequest(testUser);
    console.log('✅ KYC created:', kycRequest);
    
    // Step 3: Verify data was saved correctly
    const verification = debugRegistrationKycFlow();
    console.log('4️⃣ Verification after registration:', verification.summary);
    
    // Step 4: Test admin API response
    const apiTest = await testAdminApiResponse();
    console.log('5️⃣ API test after registration:', apiTest);
    
    return {
      testUser,
      adminUserData,
      kycRequest,
      verification,
      apiTest,
      success: apiTest.usersReturned > 0
    };
    
  } catch (error) {
    console.error('❌ Simulation error:', error);
    return { error: error.message };
  }
};

export const fixRegistrationKycSync = async () => {
  console.log('🔧 Attempting to fix registration/KYC sync issues...');
  
  try {
    const fixes = [];
    
    // Fix 1: Ensure all required localStorage keys exist
    const requiredKeys = {
      'admin_users_data': [],
      'admin_active_users': [],
      'admin_pending_kyc': []
    };
    
    Object.entries(requiredKeys).forEach(([key, defaultValue]) => {
      if (!localStorage.getItem(key)) {
        localStorage.setItem(key, JSON.stringify(defaultValue));
        fixes.push(`✅ Created missing ${key}`);
      }
    });
    
    // Fix 2: Check for data corruption and clean it
    try {
      const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
      const cleanUsers = adminUsers.filter(user => 
        user && 
        typeof user === 'object' && 
        user.id && 
        user.email
      );
      
      if (cleanUsers.length !== adminUsers.length) {
        localStorage.setItem('admin_users_data', JSON.stringify(cleanUsers));
        fixes.push(`✅ Cleaned corrupted user data: ${adminUsers.length} -> ${cleanUsers.length}`);
      }
      
      // Update active users list
      const activeUsers = cleanUsers.filter(u => u.status === 'active');
      localStorage.setItem('admin_active_users', JSON.stringify(activeUsers));
      fixes.push(`✅ Updated active users list: ${activeUsers.length} active`);
      
    } catch (error) {
      fixes.push(`❌ Error cleaning user data: ${error.message}`);
    }
    
    // Fix 3: Test the admin API to see if it works now
    const apiTest = await testAdminApiResponse();
    if (apiTest.success && apiTest.usersReturned > 0) {
      fixes.push(`✅ Admin API now returns ${apiTest.usersReturned} users`);
    } else {
      fixes.push(`⚠️ Admin API still returns ${apiTest.usersReturned} users`);
    }
    
    console.log('🔧 Fixes applied:', fixes);
    return { success: true, fixes };
    
  } catch (error) {
    console.error('❌ Fix attempt failed:', error);
    return { success: false, error: error.message };
  }
};

// Auto-expose for debugging
if (typeof window !== 'undefined') {
  window.debugRegistrationKycFlow = debugRegistrationKycFlow;
  window.testAdminApiResponse = testAdminApiResponse;
  window.simulateRegistrationFlow = simulateRegistrationFlow;
  window.fixRegistrationKycSync = fixRegistrationKycSync;
}

export default {
  debugRegistrationKycFlow,
  testAdminApiResponse,
  simulateRegistrationFlow,
  fixRegistrationKycSync
};
