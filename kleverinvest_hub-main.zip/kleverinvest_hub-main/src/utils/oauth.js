// OAuth Configuration and utilities
const GOOGLE_CLIENT_ID = getEnvVar('VITE_GOOGLE_CLIENT_ID', 'REACT_APP_GOOGLE_CLIENT_ID', '');
const APPLE_CLIENT_ID = getEnvVar('VITE_APPLE_CLIENT_ID', 'REACT_APP_APPLE_CLIENT_ID', '');

// Safe environment variable access helper
function getEnvVar(viteName, reactName, defaultValue) {
  try {
    return (import.meta.env && import.meta.env[viteName]) || 
           (process.env && process.env[reactName]) || 
           defaultValue;
  } catch (error) {
    console.warn(`Environment variable access failed, using default: ${defaultValue}`);
    return defaultValue;
  }
}

// Google OAuth Configuration
export const googleConfig = {
  clientId: GOOGLE_CLIENT_ID,
  scope: 'email profile',
  redirectUri: window.location.origin + '/auth/callback/google'
};

// Apple OAuth Configuration  
export const appleConfig = {
  clientId: APPLE_CLIENT_ID,
  scope: 'name email',
  redirectUri: window.location.origin + '/auth/callback/apple',
  responseType: 'code id_token',
  responseMode: 'form_post'
};

// Google Sign-In implementation
export const signInWithGoogle = async () => {
  try {
    // Check if Google API is available
    if (!window.google) {
      throw new Error('Google API not loaded');
    }

    // For production implementation, you would use:
    // const response = await window.google.accounts.oauth2.initTokenClient({
    //   client_id: googleConfig.clientId,
    //   scope: googleConfig.scope,
    //   callback: handleGoogleCallback
    // });

    // Mock implementation for now
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    return {
      success: true,
      user: {
        id: 'google_' + Date.now(),
        email: 'user@gmail.com',
        name: 'Google User',
        avatar: 'https://lh3.googleusercontent.com/a/default-user',
        provider: 'google'
      },
      token: 'mock_google_token_' + Date.now()
    };
  } catch (error) {
    console.error('Google Sign-In error:', error);
    throw new Error('Google Sign-In failed: ' + error.message);
  }
};

// Apple Sign-In implementation
export const signInWithApple = async () => {
  try {
    // Check if Apple ID is available
    if (!window.AppleID) {
      throw new Error('Apple ID API not loaded');
    }

    // For production implementation, you would use:
    // const response = await window.AppleID.auth.signIn({
    //   clientId: appleConfig.clientId,
    //   redirectURI: appleConfig.redirectUri,
    //   scope: appleConfig.scope,
    //   responseType: appleConfig.responseType,
    //   responseMode: appleConfig.responseMode
    // });

    // Mock implementation for now
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    return {
      success: true,
      user: {
        id: 'apple_' + Date.now(),
        email: 'user@privaterelay.appleid.com',
        name: 'Apple User',
        avatar: null,
        provider: 'apple'
      },
      token: 'mock_apple_token_' + Date.now()
    };
  } catch (error) {
    console.error('Apple Sign-In error:', error);
    throw new Error('Apple Sign-In failed: ' + error.message);
  }
};

// Load Google OAuth script
export const loadGoogleOAuthScript = () => {
  return new Promise((resolve, reject) => {
    if (window.google) {
      resolve();
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.onload = () => {
      // Initialize Google OAuth
      if (window.google && googleConfig.clientId) {
        window.google.accounts.id.initialize({
          client_id: googleConfig.clientId,
          callback: (response) => {
            console.log('Google OAuth initialized', response);
          }
        });
      }
      resolve();
    };
    script.onerror = () => reject(new Error('Failed to load Google OAuth script'));
    document.head.appendChild(script);
  });
};

// Load Apple ID script
export const loadAppleIDScript = () => {
  return new Promise((resolve, reject) => {
    if (window.AppleID) {
      resolve();
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://appleid.cdn-apple.com/appleauth/static/jsapi/appleid/1/en_US/appleid.auth.js';
    script.onload = () => {
      // Initialize Apple ID
      if (window.AppleID && appleConfig.clientId) {
        window.AppleID.auth.init({
          clientId: appleConfig.clientId,
          scope: appleConfig.scope,
          redirectURI: appleConfig.redirectUri,
          responseType: appleConfig.responseType,
          responseMode: appleConfig.responseMode
        });
      }
      resolve();
    };
    script.onerror = () => reject(new Error('Failed to load Apple ID script'));
    document.head.appendChild(script);
  });
};

// Initialize OAuth providers
export const initializeOAuth = async () => {
  try {
    const promises = [];
    
    if (googleConfig.clientId) {
      promises.push(loadGoogleOAuthScript());
    }
    
    if (appleConfig.clientId) {
      promises.push(loadAppleIDScript());
    }
    
    await Promise.allSettled(promises);
    
    return {
      google: !!window.google && !!googleConfig.clientId,
      apple: !!window.AppleID && !!appleConfig.clientId
    };
  } catch (error) {
    console.error('OAuth initialization failed:', error);
    return {
      google: false,
      apple: false
    };
  }
};

// OAuth provider status
export const getOAuthStatus = () => {
  return {
    google: {
      available: !!window.google,
      configured: !!googleConfig.clientId,
      ready: !!window.google && !!googleConfig.clientId
    },
    apple: {
      available: !!window.AppleID,
      configured: !!appleConfig.clientId,
      ready: !!window.AppleID && !!appleConfig.clientId
    }
  };
};
