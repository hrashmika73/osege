/**
 * Comprehensive User Deletion Utility
 * Ensures users are completely removed from all data stores
 */

export const deleteUserCompletely = (userId) => {
  try {
    console.log(`🗑️ Starting complete deletion of user: ${userId}`);
    
    const deletionLog = [];
    
    // 1. Remove from admin_users_data
    try {
      const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
      const originalCount = adminUsers.length;
      const updatedUsers = adminUsers.filter(u => u.id !== userId && u.userId !== userId);
      localStorage.setItem('admin_users_data', JSON.stringify(updatedUsers));
      deletionLog.push(`Admin users: ${originalCount} -> ${updatedUsers.length}`);
    } catch (error) {
      deletionLog.push(`Error removing from admin_users_data: ${error.message}`);
    }

    // 2. Remove from admin_active_users
    try {
      const activeUsers = JSON.parse(localStorage.getItem('admin_active_users') || '[]');
      const originalCount = activeUsers.length;
      const updatedUsers = activeUsers.filter(u => u.id !== userId && u.userId !== userId);
      localStorage.setItem('admin_active_users', JSON.stringify(updatedUsers));
      deletionLog.push(`Active users: ${originalCount} -> ${updatedUsers.length}`);
    } catch (error) {
      deletionLog.push(`Error removing from admin_active_users: ${error.message}`);
    }

    // 3. Remove from admin_banned_users
    try {
      const bannedUsers = JSON.parse(localStorage.getItem('admin_banned_users') || '[]');
      const originalCount = bannedUsers.length;
      const updatedUsers = bannedUsers.filter(u => u.id !== userId && u.userId !== userId);
      localStorage.setItem('admin_banned_users', JSON.stringify(updatedUsers));
      deletionLog.push(`Banned users: ${originalCount} -> ${updatedUsers.length}`);
    } catch (error) {
      deletionLog.push(`Error removing from admin_banned_users: ${error.message}`);
    }

    // 4. Remove from admin_pending_kyc
    try {
      const kycRequests = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
      const originalCount = kycRequests.length;
      const updatedRequests = kycRequests.filter(r => 
        r.userId !== userId && 
        r.id !== userId &&
        r.userID !== userId // Handle different ID field names
      );
      localStorage.setItem('admin_pending_kyc', JSON.stringify(updatedRequests));
      deletionLog.push(`KYC requests: ${originalCount} -> ${updatedRequests.length}`);
    } catch (error) {
      deletionLog.push(`Error removing from admin_pending_kyc: ${error.message}`);
    }

    // 5. Remove user session data if exists
    try {
      const userDataKey = `userData_${userId}`;
      if (localStorage.getItem(userDataKey)) {
        localStorage.removeItem(userDataKey);
        deletionLog.push(`Removed user session data: ${userDataKey}`);
      }
    } catch (error) {
      deletionLog.push(`Error removing user session: ${error.message}`);
    }

    // 6. Remove any user-specific keys
    try {
      const allKeys = Object.keys(localStorage);
      const userKeys = allKeys.filter(key => 
        key.includes(userId) || 
        key.includes(`user_${userId}`) ||
        key.includes(`_${userId}_`)
      );
      
      userKeys.forEach(key => {
        localStorage.removeItem(key);
        deletionLog.push(`Removed user-specific key: ${key}`);
      });
    } catch (error) {
      deletionLog.push(`Error removing user-specific keys: ${error.message}`);
    }

    console.log('🗑️ User deletion completed:', deletionLog);

    // Trigger deletion event for any listeners
    window.dispatchEvent(new CustomEvent('userDeleted', {
      detail: {
        userId,
        timestamp: new Date().toISOString(),
        deletionLog
      }
    }));

    return {
      success: true,
      userId,
      deletionLog,
      message: `User ${userId} completely removed from system`
    };

  } catch (error) {
    console.error('❌ User deletion failed:', error);
    return {
      success: false,
      userId,
      error: error.message,
      message: `Failed to delete user ${userId}`
    };
  }
};

export const deleteMultipleUsers = (userIds) => {
  const results = [];
  
  userIds.forEach(userId => {
    const result = deleteUserCompletely(userId);
    results.push(result);
  });
  
  const successful = results.filter(r => r.success).length;
  const failed = results.filter(r => !r.success).length;
  
  console.log(`🗑️ Bulk deletion completed: ${successful} successful, ${failed} failed`);
  
  return {
    successful,
    failed,
    results,
    message: `Bulk deletion: ${successful}/${userIds.length} users removed`
  };
};

export const verifyUserDeletion = (userId) => {
  try {
    console.log(`🔍 Verifying deletion of user: ${userId}`);
    
    const checks = [];
    
    // Check all storage locations
    const storageKeys = [
      'admin_users_data',
      'admin_active_users', 
      'admin_banned_users',
      'admin_pending_kyc'
    ];
    
    storageKeys.forEach(key => {
      try {
        const data = JSON.parse(localStorage.getItem(key) || '[]');
        const found = data.some(item => 
          item.id === userId || 
          item.userId === userId ||
          item.userID === userId
        );
        
        checks.push({
          storage: key,
          found,
          count: data.length
        });
      } catch (error) {
        checks.push({
          storage: key,
          error: error.message
        });
      }
    });
    
    const stillExists = checks.some(check => check.found);
    
    console.log('🔍 Deletion verification:', checks);
    
    return {
      userId,
      completelyDeleted: !stillExists,
      checks,
      message: stillExists ? 
        `User ${userId} still exists in some storage` : 
        `User ${userId} completely removed from all storage`
    };
    
  } catch (error) {
    console.error('❌ Verification failed:', error);
    return {
      userId,
      completelyDeleted: false,
      error: error.message
    };
  }
};

// Auto-expose for debugging
if (typeof window !== 'undefined') {
  window.deleteUserCompletely = deleteUserCompletely;
  window.verifyUserDeletion = verifyUserDeletion;
}

export default {
  deleteUserCompletely,
  deleteMultipleUsers,
  verifyUserDeletion
};
