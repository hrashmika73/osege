/**
 * Database Configuration for KleverInvest Hub
 * Supports multiple database providers: Supabase, PostgreSQL, MySQL
 */

// Database configuration based on environment
const getDatabaseConfig = () => {
  const dbType = import.meta.env.VITE_DB_TYPE || 'localStorage'; // localStorage, supabase, postgresql, mysql
  
  const configs = {
    // Supabase configuration (recommended)
    supabase: {
      url: import.meta.env.VITE_SUPABASE_URL || '',
      anonKey: import.meta.env.VITE_SUPABASE_ANON_KEY || '',
      serviceKey: import.meta.env.VITE_SUPABASE_SERVICE_KEY || '',
    },
    
    // PostgreSQL configuration
    postgresql: {
      host: import.meta.env.VITE_DB_HOST || 'localhost',
      port: import.meta.env.VITE_DB_PORT || 5432,
      database: import.meta.env.VITE_DB_NAME || 'kleverinvest',
      username: import.meta.env.VITE_DB_USER || 'postgres',
      password: import.meta.env.VITE_DB_PASSWORD || '',
      ssl: import.meta.env.VITE_DB_SSL === 'true',
    },
    
    // MySQL configuration
    mysql: {
      host: import.meta.env.VITE_DB_HOST || 'localhost',
      port: import.meta.env.VITE_DB_PORT || 3306,
      database: import.meta.env.VITE_DB_NAME || 'kleverinvest',
      username: import.meta.env.VITE_DB_USER || 'root',
      password: import.meta.env.VITE_DB_PASSWORD || '',
      ssl: import.meta.env.VITE_DB_SSL === 'true',
    },
    
    // localStorage fallback (development only)
    localStorage: {
      enabled: true,
      prefix: 'kleverinvest_',
    }
  };
  
  return {
    type: dbType,
    config: configs[dbType] || configs.localStorage,
    apiUrl: import.meta.env.VITE_API_URL || '/api',
    timeout: parseInt(import.meta.env.VITE_DB_TIMEOUT) || 10000,
  };
};

// Database connection status
let connectionStatus = 'disconnected';
let dbClient = null;

// Initialize database connection
export const initializeDatabase = async () => {
  const config = getDatabaseConfig();
  
  try {
    switch (config.type) {
      case 'supabase':
        return await initializeSupabase(config.config);
      case 'postgresql':
      case 'mysql':
        return await initializeSQL(config);
      case 'localStorage':
      default:
        return initializeLocalStorage(config.config);
    }
  } catch (error) {
    console.warn('🔄 Database initialization failed, falling back to localStorage:', error.message);
    return initializeLocalStorage(config.config || { enabled: true, prefix: 'kleverinvest_' });
  }
};

// Supabase initialization
const initializeSupabase = async (config) => {
  try {
    if (!config.url || !config.anonKey) {
      throw new Error('Supabase URL and anon key are required');
    }

    // Dynamic import to avoid bundling if not used
    let createClient;
    try {
      // Check if Supabase is available without causing build errors
      if (typeof window !== 'undefined' && window.supabase) {
        createClient = window.supabase.createClient;
      } else {
        // Try dynamic import with proper error handling - completely optional
        try {
          // Use a more robust dynamic import that won't fail builds
          const supabaseModule = await import(/* @vite-ignore */ '@supabase/supabase-js').catch(() => {
            // If package not found, return null without causing build errors
            return null;
          });

          if (!supabaseModule) {
            console.info('📦 @supabase/supabase-js not installed, using localStorage fallback');
            throw new Error('Supabase package not available');
          }

          createClient = supabaseModule.createClient;
        } catch (moduleError) {
          console.info('📦 @supabase/supabase-js not available, using localStorage fallback');
          throw new Error('Supabase package not available');
        }
      }
    } catch (importError) {
      console.warn('📦 @supabase/supabase-js not installed, falling back to localStorage');
      throw new Error('Supabase package not available');
    }

    dbClient = createClient(config.url, config.anonKey, {
      auth: {
        persistSession: true,
        storageKey: 'kleverinvest-auth',
      },
      realtime: {
        params: {
          eventsPerSecond: 10,
        },
      },
    });

    // Test connection with timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    try {
      const { data, error } = await dbClient.from('users').select('count').limit(1);
      clearTimeout(timeoutId);

      if (error && error.code !== 'PGRST116') { // PGRST116 is "table not found" which is OK for new setups
        throw error;
      }
    } catch (testError) {
      clearTimeout(timeoutId);
      if (testError.name === 'AbortError') {
        throw new Error('Supabase connection timeout');
      }
      throw testError;
    }

    connectionStatus = 'connected';
    console.log('✅ Supabase connected successfully');

    return {
      client: dbClient,
      type: 'supabase',
      status: 'connected',
      features: ['realtime', 'auth', 'storage', 'edge_functions'],
    };

  } catch (error) {
    console.warn(`📡 Supabase connection failed: ${error.message}`);
    throw error;
  }
};

// SQL database initialization (PostgreSQL/MySQL)
const initializeSQL = async (config) => {
  try {
    // Check if API URL is properly configured
    if (!config.apiUrl || config.apiUrl === '/api') {
      console.warn('📡 API URL not configured, falling back to localStorage');
      throw new Error('API URL not configured');
    }

    // Add timeout controller
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), config.timeout || 5000);

    // This would typically use a backend API
    const response = await fetch(`${config.apiUrl}/database/connect`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(config.config),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Database connection failed: ${response.statusText}`);
    }

    const result = await response.json();
    connectionStatus = 'connected';

    console.log(`✅ ${config.type.toUpperCase()} connected successfully`);

    return {
      client: 'api',
      type: config.type,
      status: 'connected',
      apiUrl: config.apiUrl,
      features: ['transactions', 'relationships', 'indexes'],
    };

  } catch (error) {
    console.warn(`📡 ${config.type.toUpperCase()} connection failed: ${error.message}`);
    throw error;
  }
};

// localStorage initialization (fallback)
const initializeLocalStorage = (config) => {
  try {
    // Test localStorage availability
    const testKey = `${config.prefix}test`;
    localStorage.setItem(testKey, 'test');
    localStorage.removeItem(testKey);
    
    connectionStatus = 'connected';
    console.log('📦 Using localStorage as database (development mode)');
    
    return {
      client: 'localStorage',
      type: 'localStorage',
      status: 'connected',
      prefix: config.prefix,
      features: ['local_storage', 'sync_storage'],
    };
    
  } catch (error) {
    console.error('localStorage initialization failed:', error);
    throw new Error('No database available');
  }
};

// Get current database connection
export const getDatabase = () => {
  return {
    client: dbClient,
    status: connectionStatus,
    config: getDatabaseConfig(),
  };
};

// Check database connection status
export const checkDatabaseStatus = async () => {
  const config = getDatabaseConfig();
  
  try {
    switch (config.type) {
      case 'supabase':
        if (dbClient) {
          const { data, error } = await dbClient.from('users').select('count').limit(1);
          return { status: error ? 'error' : 'connected', error };
        }
        return { status: 'disconnected' };
        
      case 'postgresql':
      case 'mysql':
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 5000);

          const response = await fetch(`${config.apiUrl}/database/status`, {
            signal: controller.signal
          });

          clearTimeout(timeoutId);
          const result = await response.json();
          return result;
        } catch (error) {
          return {
            status: 'error',
            error: 'API unavailable - using localStorage fallback',
            fallback: true
          };
        }
        
      case 'localStorage':
      default:
        return { 
          status: typeof(Storage) !== "undefined" ? 'connected' : 'error',
          message: typeof(Storage) !== "undefined" ? 'localStorage available' : 'localStorage not supported'
        };
    }
  } catch (error) {
    return { status: 'error', error: error.message };
  }
};

// Database migration utilities
export const runMigrations = async () => {
  const config = getDatabaseConfig();
  
  try {
    switch (config.type) {
      case 'supabase':
        return await runSupabaseMigrations();
      case 'postgresql':
      case 'mysql':
        return await runSQLMigrations(config);
      case 'localStorage':
      default:
        return await runLocalStorageMigrations();
    }
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  }
};

// Supabase migrations
const runSupabaseMigrations = async () => {
  // In a real app, you'd use Supabase CLI or API to run migrations
  console.log('🔄 Running Supabase migrations...');
  
  try {
    // Check if tables exist, create if not
    const { data, error } = await dbClient.from('users').select('count').limit(1);
    
    if (error && error.code === 'PGRST116') {
      console.log('📋 Database schema not found, please run migrations in Supabase dashboard');
      return { success: false, message: 'Please set up database schema in Supabase' };
    }
    
    console.log('✅ Database schema verified');
    return { success: true, message: 'Migrations completed' };
    
  } catch (error) {
    console.error('Migration error:', error);
    return { success: false, error: error.message };
  }
};

// SQL migrations
const runSQLMigrations = async (config) => {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    const response = await fetch(`${config.apiUrl}/database/migrate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
    });

    clearTimeout(timeoutId);
    const result = await response.json();
    return result;
  } catch (error) {
    console.warn('🔄 SQL migration unavailable, using localStorage:', error.message);
    return { success: false, error: error.message, fallback: true };
  }
};

// localStorage migrations (data structure updates)
const runLocalStorageMigrations = async () => {
  console.log('🔄 Running localStorage migrations...');
  
  try {
    // Migrate old data structure to new format if needed
    const oldUserData = localStorage.getItem('admin_users_data');
    if (oldUserData) {
      console.log('📦 Migrating localStorage data structure...');
      // Migration logic would go here
    }
    
    console.log('✅ localStorage migrations completed');
    return { success: true, message: 'LocalStorage migrations completed' };
    
  } catch (error) {
    console.error('localStorage migration error:', error);
    return { success: false, error: error.message };
  }
};

// Export database configuration
export const databaseConfig = getDatabaseConfig();

// Export connection utilities
export default {
  initialize: initializeDatabase,
  getConnection: getDatabase,
  checkStatus: checkDatabaseStatus,
  runMigrations,
  config: databaseConfig,
};
