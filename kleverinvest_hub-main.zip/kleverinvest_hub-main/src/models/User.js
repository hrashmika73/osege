/**
 * User Model and Repository
 * Handles all user-related database operations
 */

import databaseService from '../services/databaseService.js';
import { hashPassword, verifyPassword } from '../utils/auth.js';

export class User {
  constructor(data = {}) {
    this.id = data.id;
    this.email = data.email;
    this.username = data.username;
    this.firstName = data.first_name || data.firstName;
    this.lastName = data.last_name || data.lastName;
    this.fullName = data.full_name || data.fullName || `${this.firstName || ''} ${this.lastName || ''}`.trim();
    this.phone = data.phone;
    this.dateOfBirth = data.date_of_birth || data.dateOfBirth;
    this.country = data.country;
    this.address = data.address;
    this.status = data.status || 'active';
    this.emailVerified = data.email_verified || data.emailVerified || false;
    this.twoFactorEnabled = data.two_factor_enabled || data.twoFactorEnabled || false;
    this.kycStatus = data.kyc_status || data.kycStatus || 'pending';
    this.riskLevel = data.risk_level || data.riskLevel || 'low';
    this.accountType = data.account_type || data.accountType || 'standard';
    this.referralCode = data.referral_code || data.referralCode;
    this.referredByCode = data.referred_by_code || data.referredByCode;
    this.balance = parseFloat(data.balance || 0);
    this.totalInvested = parseFloat(data.total_invested || data.totalInvested || 0);
    this.totalEarnings = parseFloat(data.total_earnings || data.totalEarnings || 0);
    this.lastLoginAt = data.last_login_at || data.lastLoginAt;
    this.lastLoginIp = data.last_login_ip || data.lastLoginIp;
    this.registrationIp = data.registration_ip || data.registrationIp;
    this.deviceInfo = data.device_info || data.deviceInfo;
    this.createdAt = data.created_at || data.createdAt;
    this.updatedAt = data.updated_at || data.updatedAt;
  }

  // Convert to database format
  toDatabase() {
    return {
      id: this.id,
      email: this.email,
      username: this.username,
      first_name: this.firstName,
      last_name: this.lastName,
      full_name: this.fullName,
      phone: this.phone,
      date_of_birth: this.dateOfBirth,
      country: this.country,
      address: this.address,
      status: this.status,
      email_verified: this.emailVerified,
      two_factor_enabled: this.twoFactorEnabled,
      kyc_status: this.kycStatus,
      risk_level: this.riskLevel,
      account_type: this.accountType,
      referral_code: this.referralCode,
      referred_by_code: this.referredByCode,
      balance: this.balance,
      total_invested: this.totalInvested,
      total_earnings: this.totalEarnings,
      last_login_at: this.lastLoginAt,
      last_login_ip: this.lastLoginIp,
      registration_ip: this.registrationIp,
      device_info: this.deviceInfo,
    };
  }

  // Convert to API/Frontend format
  toJSON() {
    return {
      id: this.id,
      email: this.email,
      username: this.username,
      firstName: this.firstName,
      lastName: this.lastName,
      fullName: this.fullName,
      phone: this.phone,
      dateOfBirth: this.dateOfBirth,
      country: this.country,
      address: this.address,
      status: this.status,
      emailVerified: this.emailVerified,
      twoFactorEnabled: this.twoFactorEnabled,
      kycStatus: this.kycStatus,
      riskLevel: this.riskLevel,
      accountType: this.accountType,
      referralCode: this.referralCode,
      referredByCode: this.referredByCode,
      balance: this.balance,
      totalInvested: this.totalInvested,
      totalEarnings: this.totalEarnings,
      lastLoginAt: this.lastLoginAt,
      lastLoginIp: this.lastLoginIp,
      registrationIp: this.registrationIp,
      deviceInfo: this.deviceInfo,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
    };
  }

  // Check if user is verified
  isVerified() {
    return this.kycStatus === 'approved' && this.emailVerified;
  }

  // Check if user can invest
  canInvest() {
    return this.status === 'active' && this.isVerified();
  }

  // Check if user can withdraw
  canWithdraw() {
    return this.status === 'active' && this.isVerified() && this.balance > 0;
  }

  // Generate unique referral code
  generateReferralCode() {
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.random().toString(36).substr(2, 4).toUpperCase();
    return `REF${timestamp}${random}`;
  }
}

export class UserRepository {
  constructor() {
    this.tableName = 'users';
  }

  // Create a new user
  async create(userData, password) {
    try {
      const passwordHash = await hashPassword(password);
      
      const user = new User({
        ...userData,
        referralCode: userData.referralCode || new User().generateReferralCode(),
        registrationIp: this.getClientIp(),
        deviceInfo: navigator.userAgent,
      });

      const dbData = {
        ...user.toDatabase(),
        password_hash: passwordHash,
      };

      const result = await databaseService.query(
        this.tableName,
        'insert',
        dbData,
        { returning: true }
      );

      if (!result.success) {
        throw new Error(result.error);
      }

      return new User(result.data[0]);
    } catch (error) {
      console.error('User creation failed:', error);
      throw error;
    }
  }

  // Find user by ID
  async findById(id) {
    try {
      const result = await databaseService.query(
        this.tableName,
        'select',
        {},
        { where: { id }, limit: 1 }
      );

      if (!result.success) {
        throw new Error(result.error);
      }

      return result.data.length > 0 ? new User(result.data[0]) : null;
    } catch (error) {
      console.error('Find user by ID failed:', error);
      throw error;
    }
  }

  // Find user by email
  async findByEmail(email) {
    try {
      const result = await databaseService.query(
        this.tableName,
        'select',
        {},
        { where: { email }, limit: 1 }
      );

      if (!result.success) {
        throw new Error(result.error);
      }

      return result.data.length > 0 ? new User(result.data[0]) : null;
    } catch (error) {
      console.error('Find user by email failed:', error);
      throw error;
    }
  }

  // Authenticate user
  async authenticate(email, password) {
    try {
      // For database systems, we need to get password hash
      const result = await databaseService.query(
        this.tableName,
        'select',
        {},
        { 
          where: { email }, 
          limit: 1,
          select: '*' // Include password_hash for verification
        }
      );

      if (!result.success || result.data.length === 0) {
        return null;
      }

      const userData = result.data[0];
      
      // Verify password
      if (userData.password_hash && !(await verifyPassword(password, userData.password_hash))) {
        return null;
      }

      // For localStorage, check plain text password (temporary)
      if (!userData.password_hash && userData.password && userData.password !== password) {
        return null;
      }

      // Update last login
      await this.updateLastLogin(userData.id);

      return new User(userData);
    } catch (error) {
      console.error('User authentication failed:', error);
      throw error;
    }
  }

  // Update user
  async update(id, updateData) {
    try {
      const user = new User(updateData);
      const dbData = user.toDatabase();
      
      // Remove undefined values
      Object.keys(dbData).forEach(key => {
        if (dbData[key] === undefined) {
          delete dbData[key];
        }
      });

      const result = await databaseService.query(
        this.tableName,
        'update',
        dbData,
        { where: { id }, returning: true }
      );

      if (!result.success) {
        throw new Error(result.error);
      }

      return result.data.length > 0 ? new User(result.data[0]) : null;
    } catch (error) {
      console.error('User update failed:', error);
      throw error;
    }
  }

  // Update last login
  async updateLastLogin(id) {
    try {
      return await this.update(id, {
        lastLoginAt: new Date().toISOString(),
        lastLoginIp: this.getClientIp(),
      });
    } catch (error) {
      console.error('Update last login failed:', error);
      throw error;
    }
  }

  // Update balance
  async updateBalance(id, newBalance) {
    try {
      return await this.update(id, { balance: newBalance });
    } catch (error) {
      console.error('Update balance failed:', error);
      throw error;
    }
  }

  // Update KYC status
  async updateKycStatus(id, status, verifiedBy = null) {
    try {
      const updateData = { kycStatus: status };
      
      if (verifiedBy) {
        updateData.verifiedBy = verifiedBy;
        updateData.verifiedAt = new Date().toISOString();
      }

      return await this.update(id, updateData);
    } catch (error) {
      console.error('Update KYC status failed:', error);
      throw error;
    }
  }

  // Get all users with pagination
  async getAll(options = {}) {
    try {
      const {
        page = 1,
        limit = 25,
        orderBy = 'created_at',
        ascending = false,
        filters = {}
      } = options;

      const offset = (page - 1) * limit;

      const result = await databaseService.query(
        this.tableName,
        'select',
        {},
        {
          where: filters,
          orderBy: { column: orderBy, ascending },
          limit,
          offset,
        }
      );

      if (!result.success) {
        throw new Error(result.error);
      }

      return {
        users: result.data.map(userData => new User(userData)),
        total: result.count,
        page,
        limit,
        totalPages: Math.ceil(result.count / limit),
      };
    } catch (error) {
      console.error('Get all users failed:', error);
      throw error;
    }
  }

  // Get users by status
  async getByStatus(status, options = {}) {
    try {
      return await this.getAll({
        ...options,
        filters: { status }
      });
    } catch (error) {
      console.error('Get users by status failed:', error);
      throw error;
    }
  }

  // Get users by KYC status
  async getByKycStatus(kycStatus, options = {}) {
    try {
      return await this.getAll({
        ...options,
        filters: { kyc_status: kycStatus }
      });
    } catch (error) {
      console.error('Get users by KYC status failed:', error);
      throw error;
    }
  }

  // Search users
  async search(query, options = {}) {
    try {
      // For now, we'll implement a simple search in localStorage
      // In a real database, you'd use full-text search
      const allUsers = await this.getAll({ limit: 1000 });
      
      const searchQuery = query.toLowerCase();
      const filteredUsers = allUsers.users.filter(user => 
        user.email.toLowerCase().includes(searchQuery) ||
        user.fullName.toLowerCase().includes(searchQuery) ||
        user.username?.toLowerCase().includes(searchQuery)
      );

      return {
        users: filteredUsers,
        total: filteredUsers.length,
        query,
      };
    } catch (error) {
      console.error('User search failed:', error);
      throw error;
    }
  }

  // Delete user (soft delete)
  async delete(id) {
    try {
      return await this.update(id, { 
        status: 'deleted',
        deletedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error('User deletion failed:', error);
      throw error;
    }
  }

  // Get user statistics
  async getStatistics() {
    try {
      const allUsers = await this.getAll({ limit: 10000 });
      const users = allUsers.users;

      const stats = {
        total: users.length,
        active: users.filter(u => u.status === 'active').length,
        inactive: users.filter(u => u.status === 'inactive').length,
        suspended: users.filter(u => u.status === 'suspended').length,
        banned: users.filter(u => u.status === 'banned').length,
        verified: users.filter(u => u.kycStatus === 'approved').length,
        pending: users.filter(u => u.kycStatus === 'pending').length,
        totalBalance: users.reduce((sum, user) => sum + user.balance, 0),
        totalInvestments: users.reduce((sum, user) => sum + user.totalInvested, 0),
        newToday: users.filter(u => {
          const today = new Date().toDateString();
          const userDate = new Date(u.createdAt).toDateString();
          return today === userDate;
        }).length,
        newThisWeek: users.filter(u => {
          const weekAgo = new Date();
          weekAgo.setDate(weekAgo.getDate() - 7);
          return new Date(u.createdAt) >= weekAgo;
        }).length,
      };

      return stats;
    } catch (error) {
      console.error('Get user statistics failed:', error);
      throw error;
    }
  }

  // Helper method to get client IP (simplified)
  getClientIp() {
    // In a real application, this would be handled server-side
    return '127.0.0.1';
  }
}

// Create singleton instance
const userRepository = new UserRepository();

export default userRepository;
