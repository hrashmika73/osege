import React, { useState, useEffect } from 'react';
import Icon from './AppIcon';
import Button from './ui/Button';

const SystemStatusMonitor = () => {
  const [systemStatus, setSystemStatus] = useState({
    routing: 'checking',
    backend: 'checking',
    localStorage: 'checking',
    sync: 'checking'
  });
  const [details, setDetails] = useState({});
  const [isFixing, setIsFixing] = useState(false);

  useEffect(() => {
    checkSystemStatus();
    
    // Check status every 30 seconds
    const interval = setInterval(checkSystemStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const checkSystemStatus = async () => {
    const newStatus = {};
    const newDetails = {};

    // Check routing
    try {
      const routingModule = await import('../utils/routingFix');
      const routingFix = routingModule.default || routingModule.routingFix;

      if (routingFix && typeof routingFix.validateCurrentRoute === 'function') {
        const isValidRoute = routingFix.validateCurrentRoute();
        newStatus.routing = isValidRoute ? 'working' : 'error';
        newDetails.routing = {
          currentPath: window.location.pathname,
          isValid: isValidRoute,
          suggested: !isValidRoute && typeof routingFix.getSuggestedRoute === 'function'
            ? routingFix.getSuggestedRoute(window.location.pathname) : null
        };
      } else {
        newStatus.routing = 'warning';
        newDetails.routing = {
          currentPath: window.location.pathname,
          error: 'Routing utility not available'
        };
      }
    } catch (error) {
      newStatus.routing = 'error';
      newDetails.routing = {
        currentPath: window.location.pathname,
        error: error.message
      };
    }

    // Check backend connection
    try {
      const connectionModule = await import('../utils/connectionManager');
      const connectionManager = connectionModule.default || connectionModule.connectionManager;

      if (connectionManager && typeof connectionManager.getConnectionStatus === 'function') {
        const connectionStatus = connectionManager.getConnectionStatus();
        newStatus.backend = connectionStatus.backendStatus === 'connected' ? 'working' :
                           connectionStatus.backendStatus === 'disconnected' ? 'error' : 'warning';
        newDetails.backend = connectionStatus;
      } else {
        newStatus.backend = 'warning';
        newDetails.backend = {
          error: 'Connection manager not available',
          backendStatus: 'unknown'
        };
      }
    } catch (error) {
      newStatus.backend = 'error';
      newDetails.backend = {
        error: error.message,
        backendStatus: 'failed'
      };
    }

    // Check localStorage
    try {
      const testKey = 'system_test_' + Date.now();
      localStorage.setItem(testKey, 'test');
      localStorage.removeItem(testKey);
      
      // Check for key data
      const userData = localStorage.getItem('admin_users_data');
      const kycData = localStorage.getItem('admin_pending_kyc');
      
      newStatus.localStorage = 'working';
      newDetails.localStorage = {
        available: true,
        userData: userData ? JSON.parse(userData).length : 0,
        kycData: kycData ? JSON.parse(kycData).length : 0
      };
    } catch (error) {
      newStatus.localStorage = 'error';
      newDetails.localStorage = { error: error.message };
    }

    // Check data synchronization
    try {
      const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
      const kycRequests = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
      
      // Check if data seems synchronized
      const hasRecentActivity = adminUsers.some(u => {
        const registrationDate = new Date(u.registrationDate);
        const daysDiff = (new Date() - registrationDate) / (1000 * 60 * 60 * 24);
        return daysDiff < 7; // Recent activity in last 7 days
      });

      newStatus.sync = (adminUsers.length > 0 || kycRequests.length > 0) ? 'working' : 'warning';
      newDetails.sync = {
        adminUsers: adminUsers.length,
        kycRequests: kycRequests.length,
        hasRecentActivity,
        lastSync: localStorage.getItem('last_sync_timestamp') || 'Never'
      };
    } catch (error) {
      newStatus.sync = 'error';
      newDetails.sync = { error: error.message };
    }

    setSystemStatus(newStatus);
    setDetails(newDetails);
  };

  const fixAllIssues = async () => {
    setIsFixing(true);

    try {
      console.log('🔧 Starting automated system fixes...');

      // Fix routing issues
      if (systemStatus.routing === 'error') {
        try {
          const routingModule = await import('../utils/routingFix');
          const routingFix = routingModule.default || routingModule.routingFix;
          if (routingFix && typeof routingFix.fixCurrentRoute === 'function') {
            routingFix.fixCurrentRoute();
            console.log('✅ Routing issues fixed');
          }
        } catch (error) {
          console.error('❌ Failed to fix routing:', error);
        }
      }

      // Fix backend connection
      if (systemStatus.backend === 'error' || systemStatus.backend === 'warning') {
        try {
          const connectionModule = await import('../utils/connectionManager');
          const connectionManager = connectionModule.default || connectionModule.connectionManager;
          if (connectionManager && typeof connectionManager.forceReconnect === 'function') {
            await connectionManager.forceReconnect();
            console.log('✅ Backend connection reset');
          }
        } catch (error) {
          console.error('❌ Failed to fix backend connection:', error);
        }
      }

      // Fix localStorage issues
      if (systemStatus.localStorage === 'error') {
        try {
          // Try to clean localStorage without clearing everything
          const keysToRemove = [];
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('temp_') || key.startsWith('cache_'))) {
              keysToRemove.push(key);
            }
          }
          keysToRemove.forEach(key => localStorage.removeItem(key));

          // Ensure essential data exists
          if (!localStorage.getItem('admin_users_data')) {
            localStorage.setItem('admin_users_data', '[]');
          }
          if (!localStorage.getItem('admin_pending_kyc')) {
            localStorage.setItem('admin_pending_kyc', '[]');
          }
          console.log('✅ localStorage issues fixed');
        } catch (error) {
          console.error('❌ Failed to fix localStorage:', error);
        }
      }

      // Fix synchronization
      if (systemStatus.sync === 'error' || systemStatus.sync === 'warning') {
        try {
          const connectionModule = await import('../utils/connectionManager');
          const connectionManager = connectionModule.default || connectionModule.connectionManager;
          if (connectionManager && typeof connectionManager.clearAndResync === 'function') {
            await connectionManager.clearAndResync();
            localStorage.setItem('last_sync_timestamp', new Date().toISOString());
            console.log('✅ Synchronization issues fixed');
          }
        } catch (error) {
          console.error('❌ Failed to fix sync issues:', error);
        }
      }

      // Try to use the auto-fix utility if available
      try {
        const autoFixModule = await import('../utils/autoFixIssues');
        if (autoFixModule.autoFixSystemIssues) {
          const result = await autoFixModule.autoFixSystemIssues();
          console.log('🔧 Auto-fix results:', result);
        }
      } catch (error) {
        console.warn('Auto-fix utility not available:', error.message);
      }

      console.log('🎉 System fixes completed');

      // Recheck status after fixes
      setTimeout(() => {
        checkSystemStatus();
        setIsFixing(false);
      }, 2000);

    } catch (error) {
      console.error('❌ Error during system fix:', error);
      setIsFixing(false);

      // Show user-friendly error message
      alert('System fix encountered an error. Please try refreshing the page or contact support if the issue persists.');
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'working': return 'CheckCircle';
      case 'error': return 'XCircle';
      case 'warning': return 'AlertTriangle';
      case 'checking': return 'Loader2';
      default: return 'HelpCircle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'working': return 'text-green-600';
      case 'error': return 'text-red-600';
      case 'warning': return 'text-yellow-600';
      case 'checking': return 'text-blue-600';
      default: return 'text-gray-600';
    }
  };

  const getOverallStatus = () => {
    const statuses = Object.values(systemStatus);
    if (statuses.includes('error')) return 'error';
    if (statuses.includes('warning')) return 'warning';
    if (statuses.includes('checking')) return 'checking';
    return 'working';
  };

  const overallStatus = getOverallStatus();

  return (
    <div className="bg-card border rounded-lg p-4 mb-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon 
            name={getStatusIcon(overallStatus)} 
            size={20} 
            className={`${getStatusColor(overallStatus)} ${systemStatus.checking ? 'animate-spin' : ''}`} 
          />
          <h3 className="font-semibold text-foreground">System Status</h3>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={checkSystemStatus}
            disabled={isFixing}
          >
            <Icon name="RefreshCw" size={14} className="mr-1" />
            Refresh
          </Button>
          <Button 
            size="sm" 
            onClick={fixAllIssues}
            disabled={isFixing || overallStatus === 'working'}
          >
            <Icon name={isFixing ? "Loader2" : "Wrench"} size={14} className={`mr-1 ${isFixing ? 'animate-spin' : ''}`} />
            {isFixing ? 'Fixing...' : 'Fix Issues'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Routing Status */}
        <div className="bg-muted/30 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-2">
            <Icon 
              name={getStatusIcon(systemStatus.routing)} 
              size={16} 
              className={getStatusColor(systemStatus.routing)} 
            />
            <span className="font-medium text-sm">Routing</span>
          </div>
          <div className="text-xs text-muted-foreground">
            {details.routing?.currentPath && (
              <div>Path: {details.routing.currentPath}</div>
            )}
            {details.routing?.suggested && (
              <div className="text-yellow-600">Suggested: {details.routing.suggested}</div>
            )}
          </div>
        </div>

        {/* Backend Status */}
        <div className="bg-muted/30 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-2">
            <Icon 
              name={getStatusIcon(systemStatus.backend)} 
              size={16} 
              className={getStatusColor(systemStatus.backend)} 
            />
            <span className="font-medium text-sm">Backend</span>
          </div>
          <div className="text-xs text-muted-foreground">
            {details.backend?.backendStatus && (
              <div>Status: {details.backend.backendStatus}</div>
            )}
            {details.backend?.connectionAttempts && (
              <div>Attempts: {details.backend.connectionAttempts}</div>
            )}
          </div>
        </div>

        {/* LocalStorage Status */}
        <div className="bg-muted/30 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-2">
            <Icon 
              name={getStatusIcon(systemStatus.localStorage)} 
              size={16} 
              className={getStatusColor(systemStatus.localStorage)} 
            />
            <span className="font-medium text-sm">Storage</span>
          </div>
          <div className="text-xs text-muted-foreground">
            {details.localStorage?.userData !== undefined && (
              <div>Users: {details.localStorage.userData}</div>
            )}
            {details.localStorage?.kycData !== undefined && (
              <div>KYC: {details.localStorage.kycData}</div>
            )}
          </div>
        </div>

        {/* Sync Status */}
        <div className="bg-muted/30 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-2">
            <Icon 
              name={getStatusIcon(systemStatus.sync)} 
              size={16} 
              className={getStatusColor(systemStatus.sync)} 
            />
            <span className="font-medium text-sm">Sync</span>
          </div>
          <div className="text-xs text-muted-foreground">
            {details.sync?.adminUsers !== undefined && (
              <div>Data: {details.sync.adminUsers + details.sync.kycRequests} items</div>
            )}
            {details.sync?.hasRecentActivity !== undefined && (
              <div>Recent: {details.sync.hasRecentActivity ? 'Yes' : 'No'}</div>
            )}
          </div>
        </div>
      </div>

      {overallStatus === 'error' && (
        <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-center space-x-2 text-red-800">
            <Icon name="AlertCircle" size={16} />
            <span className="font-medium">Issues Detected</span>
          </div>
          <p className="text-sm text-red-700 mt-1">
            System issues detected. Click "Fix Issues" to automatically resolve common problems.
          </p>
        </div>
      )}
    </div>
  );
};

export default SystemStatusMonitor;
