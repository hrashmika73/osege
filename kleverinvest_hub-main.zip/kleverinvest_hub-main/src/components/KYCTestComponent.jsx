import React, { useState } from 'react';
import Button from './ui/Button';
import Icon from './AppIcon';

const KYCTestComponent = () => {
  const [testResult, setTestResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const createTestUser = async () => {
    setIsLoading(true);
    setTestResult('');

    try {
      // Create a test user that needs KYC verification
      const testUserData = {
        id: 'user_test_kyc_' + Date.now(),
        name: 'Test KYC User',
        email: `kyctest.${Date.now()}@example.com`,
        phone: '+1-555-999-0000',
        country: 'US',
        password: 'testkyc123',
        role: 'user',
        verified: false,
        kycStatus: 'pending',
        balance: 0
      };

      // Add user using centralized system
      const { addNewUser } = await import('../utils/userDataManager');
      const newUser = addNewUser(testUserData);

      setTestResult(`✅ Test user created successfully:

📧 Login Credentials:
• Email: ${newUser.email}
• Password: ${testUserData.password}

🔒 KYC Status: ${newUser.kycStatus}
🚫 Dashboard Access: BLOCKED (KYC required)

📝 Test Instructions:
1. Try to login with above credentials
2. You should be redirected to KYC verification page
3. User cannot access dashboard until KYC is verified

To verify this user's KYC:
- Go to Admin Panel > Pending KYC
- Find this user and approve their verification`);

    } catch (error) {
      setTestResult(`❌ Error creating test user: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const verifyTestUser = async () => {
    setIsLoading(true);
    
    try {
      // Get the most recent test user
      const { getAllUsers, updateUser } = await import('../utils/userDataManager');
      const users = getAllUsers();
      const testUser = users.find(u => u.email.includes('kyctest'));
      
      if (!testUser) {
        setTestResult('❌ No test user found. Create a test user first.');
        return;
      }

      // Update user's KYC status to verified
      await updateUser(testUser.userId || testUser.id, {
        kycStatus: 'verified',
        verificationStatus: 'verified'
      });

      setTestResult(`✅ KYC Verification completed for test user:

📧 User: ${testUser.email}
✅ KYC Status: VERIFIED
🚀 Dashboard Access: ALLOWED

📝 Test Instructions:
1. Login with the test user credentials
2. You should now have full dashboard access
3. Profile settings should show real user data`);

    } catch (error) {
      setTestResult(`❌ Error verifying user: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const clearTestUsers = async () => {
    try {
      const { getAllUsers, updateUser } = await import('../utils/userDataManager');
      const users = getAllUsers();
      const testUsers = users.filter(u => u.email.includes('kyctest'));
      
      // Remove test users by setting their status to deleted
      for (const user of testUsers) {
        await updateUser(user.userId || user.id, { status: 'deleted' });
      }
      
      setTestResult(`🗑️ Cleared ${testUsers.length} test users`);
    } catch (error) {
      setTestResult(`❌ Error clearing test users: ${error.message}`);
    }
  };

  return (
    <div className="bg-card border rounded-lg p-6 max-w-2xl mx-auto">
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold text-foreground mb-2">
          KYC Verification Test
        </h2>
        <p className="text-muted-foreground">
          Test the KYC verification requirement for dashboard access
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Button
          onClick={createTestUser}
          disabled={isLoading}
          className="flex-1"
        >
          {isLoading ? (
            <>
              <Icon name="Loader2" size={16} className="animate-spin mr-2" />
              Creating...
            </>
          ) : (
            <>
              <Icon name="UserPlus" size={16} className="mr-2" />
              Create Test User (Unverified)
            </>
          )}
        </Button>
        
        <Button
          variant="outline"
          onClick={verifyTestUser}
          disabled={isLoading}
        >
          <Icon name="CheckCircle" size={16} className="mr-2" />
          Verify KYC
        </Button>

        <Button
          variant="outline"
          onClick={clearTestUsers}
          disabled={isLoading}
        >
          <Icon name="Trash2" size={16} className="mr-2" />
          Clear Tests
        </Button>
      </div>

      {testResult && (
        <div className="bg-muted/50 border rounded-lg p-4">
          <h3 className="font-medium text-foreground mb-2">Test Result:</h3>
          <pre className="text-sm text-foreground whitespace-pre-wrap font-mono">
            {testResult}
          </pre>
        </div>
      )}

      <div className="mt-6 text-xs text-muted-foreground">
        <p className="mb-2">🔍 What this test does:</p>
        <ul className="list-disc list-inside space-y-1">
          <li>Creates users with unverified KYC status</li>
          <li>Tests dashboard access blocking for unverified users</li>
          <li>Verifies KYC approval flow</li>
          <li>Tests profile data integration</li>
          <li>Validates entire user journey</li>
        </ul>
      </div>
    </div>
  );
};

export default KYCTestComponent;
