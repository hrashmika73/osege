import React, { useState } from 'react';
import Button from './ui/Button';
import Icon from './AppIcon';

const TestRegistrationFlow = () => {
  const [testResult, setTestResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const runTest = async () => {
    setIsLoading(true);
    setTestResult('');

    try {
      // Import the user data manager
      const { addNewUser, getAllUsers, getUserStatistics } = await import('../utils/userDataManager');

      // Get initial stats
      const initialStats = getUserStatistics();
      
      // Create a test user
      const testUserData = {
        id: 'user_test_' + Date.now(),
        name: 'Test User',
        email: `test.user.${Date.now()}@example.com`,
        phone: '+1-555-123-4567',
        country: 'US',
        role: 'user',
        verified: false,
        kycStatus: 'pending',
        balance: 0,
        referralCode: 'TEST' + Date.now().toString().slice(-6)
      };

      // Add the test user
      const addedUser = addNewUser(testUserData);

      // Get updated stats
      const updatedStats = getUserStatistics();

      // Verify the user was added
      const allUsers = getAllUsers();
      const foundUser = allUsers.find(u => u.email === testUserData.email);

      if (foundUser) {
        setTestResult(`✅ SUCCESS! Test user registered successfully:
        
📊 Statistics Updated:
• Total Users: ${initialStats.total} → ${updatedStats.total}
• Active Users: ${initialStats.active} → ${updatedStats.active}

👤 User Details:
• Name: ${foundUser.fullName}
• Email: ${foundUser.email}
• Status: ${foundUser.status}
• Registration: ${new Date(foundUser.registrationDate).toLocaleString()}

🔔 Real-time notification should appear in admin panel!`);
      } else {
        setTestResult('❌ FAILED: User not found after registration');
      }

    } catch (error) {
      setTestResult(`❌ ERROR: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const clearTestData = async () => {
    try {
      const { clearAllUserData } = await import('../utils/userDataManager');
      clearAllUserData();
      setTestResult('🗑️ All test data cleared');
    } catch (error) {
      setTestResult(`❌ Error clearing data: ${error.message}`);
    }
  };

  return (
    <div className="bg-card border rounded-lg p-6 max-w-2xl mx-auto">
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold text-foreground mb-2">
          Registration Flow Test
        </h2>
        <p className="text-muted-foreground">
          Test the connection between user registration and admin dashboard
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Button
          onClick={runTest}
          disabled={isLoading}
          className="flex-1"
        >
          {isLoading ? (
            <>
              <Icon name="Loader2" size={16} className="animate-spin mr-2" />
              Testing...
            </>
          ) : (
            <>
              <Icon name="Play" size={16} className="mr-2" />
              Run Test Registration
            </>
          )}
        </Button>
        
        <Button
          variant="outline"
          onClick={clearTestData}
          disabled={isLoading}
        >
          <Icon name="Trash2" size={16} className="mr-2" />
          Clear Test Data
        </Button>
      </div>

      {testResult && (
        <div className="bg-muted/50 border rounded-lg p-4">
          <h3 className="font-medium text-foreground mb-2">Test Result:</h3>
          <pre className="text-sm text-foreground whitespace-pre-wrap font-mono">
            {testResult}
          </pre>
        </div>
      )}

      <div className="mt-6 text-xs text-muted-foreground">
        <p className="mb-2">🔍 What this test does:</p>
        <ul className="list-disc list-inside space-y-1">
          <li>Creates a test user registration</li>
          <li>Adds user to admin system</li>
          <li>Triggers real-time notifications</li>
          <li>Updates dashboard statistics</li>
          <li>Verifies data persistence</li>
        </ul>
      </div>
    </div>
  );
};

export default TestRegistrationFlow;
