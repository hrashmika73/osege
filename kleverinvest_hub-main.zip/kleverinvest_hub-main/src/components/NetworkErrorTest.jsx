import React, { useState } from 'react';
import Button from './ui/Button';
import Icon from './AppIcon';

const NetworkErrorTest = () => {
  const [testResults, setTestResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const runNetworkTests = async () => {
    setIsLoading(true);
    setTestResults([]);

    const tests = [
      {
        name: 'Test Backend Connection',
        test: async () => {
          const { testBackendConnection } = await import('../utils/api');
          return await testBackendConnection();
        }
      },
      {
        name: 'Test Auth API',
        test: async () => {
          const { authAPI } = await import('../utils/api');
          return await authAPI.verifyToken();
        }
      },
      {
        name: 'Test Admin API - Stats',
        test: async () => {
          const { adminAPI } = await import('../utils/api');
          return await adminAPI.getSystemStats();
        }
      },
      {
        name: 'Test Admin API - Users',
        test: async () => {
          const { adminAPI } = await import('../utils/api');
          return await adminAPI.getUsers();
        }
      },
      {
        name: 'Test Fake Fetch (Should Fail Gracefully)',
        test: async () => {
          try {
            const response = await fetch('http://localhost:9999/nonexistent');
            return {
              success: true,
              message: 'Unexpected success',
              type: 'warning'
            };
          } catch (error) {
            return {
              success: false,
              message: 'Fetch failed as expected (handled gracefully)',
              error: error.message,
              type: 'success' // This is expected
            };
          }
        }
      }
    ];

    const results = [];
    for (const test of tests) {
      try {
        console.log(`Running test: ${test.name}`);
        const result = await test.test();
        results.push({
          name: test.name,
          result,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        console.warn(`Test failed: ${test.name}`, error);
        results.push({
          name: test.name,
          result: {
            success: false,
            message: 'Test threw an error (this should not happen)',
            error: error.message,
            type: 'error'
          },
          timestamp: new Date().toISOString()
        });
      }
      
      // Small delay between tests
      await new Promise(resolve => setTimeout(resolve, 300));
    }

    setTestResults(results);
    setIsLoading(false);
  };

  const getResultIcon = (result) => {
    switch (result.type) {
      case 'success': return 'CheckCircle';
      case 'warning': return 'AlertTriangle';
      case 'error': return 'XCircle';
      default: return 'Info';
    }
  };

  const getResultColor = (result) => {
    switch (result.type) {
      case 'success': return 'text-green-600 bg-green-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'error': return 'text-red-600 bg-red-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  return (
    <div className="bg-card border rounded-lg p-6 max-w-4xl mx-auto">
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold text-foreground mb-2">
          Network Error Test Suite
        </h2>
        <p className="text-muted-foreground">
          Test all API calls to ensure no NetworkErrors break the application
        </p>
      </div>

      <div className="mb-6">
        <Button
          onClick={runNetworkTests}
          disabled={isLoading}
          className="w-full"
        >
          {isLoading ? (
            <>
              <Icon name="Loader2" size={16} className="animate-spin mr-2" />
              Running Tests...
            </>
          ) : (
            <>
              <Icon name="Play" size={16} className="mr-2" />
              Run Network Error Tests
            </>
          )}
        </Button>
      </div>

      {testResults.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-medium text-foreground">Test Results:</h3>
          {testResults.map((test, index) => (
            <div key={index} className="border border-border rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${getResultColor(test.result)}`}>
                  <Icon name={getResultIcon(test.result)} size={16} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-foreground">{test.name}</h4>
                    <span className="text-xs text-muted-foreground">
                      {new Date(test.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{test.result.message}</p>
                  
                  {test.result.error && (
                    <div className="text-xs font-mono text-red-600 bg-red-50 border border-red-200 rounded p-2 mb-2">
                      Error: {test.result.error}
                    </div>
                  )}
                  
                  {test.result.data && (
                    <details className="text-xs">
                      <summary className="cursor-pointer text-muted-foreground hover:text-foreground">
                        View Response Data
                      </summary>
                      <pre className="mt-2 bg-muted/50 border rounded p-2 overflow-x-auto">
                        {JSON.stringify(test.result.data, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-6 text-xs text-muted-foreground">
        <p className="mb-2">🔍 What this test does:</p>
        <ul className="list-disc list-inside space-y-1">
          <li>Tests all API endpoints for proper error handling</li>
          <li>Verifies NetworkErrors are caught and handled gracefully</li>
          <li>Ensures no errors break the application</li>
          <li>Tests both successful and failed network requests</li>
          <li>Validates fallback mechanisms work correctly</li>
        </ul>
      </div>
    </div>
  );
};

export default NetworkErrorTest;
