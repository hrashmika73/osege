import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAdminAuth } from '../contexts/AdminAuthContext';
import { isAdminLoggedIn, clearAllAdminAuth } from '../utils/adminAuthReset';
import Icon from './AppIcon';

// Loading component for auth checks
const AdminAuthLoader = () => (
  <div className="min-h-screen bg-gradient-to-br from-red-900 via-red-800 to-slate-900 flex items-center justify-center">
    <div className="text-center">
      <div className="w-16 h-16 bg-red-600 rounded-xl mx-auto mb-4 flex items-center justify-center">
        <Icon name="Shield" size={32} className="text-white animate-pulse" />
      </div>
      <div className="text-white">
        <Icon name="Loader2" size={24} className="animate-spin mx-auto mb-2" />
        <p className="text-sm">Verifying admin credentials...</p>
      </div>
    </div>
  </div>
);

// Unauthorized access component
const AdminUnauthorized = () => (
  <div className="min-h-screen bg-gradient-to-br from-red-900 via-red-800 to-slate-900 flex items-center justify-center p-4">
    <div className="text-center max-w-md">
      <div className="w-16 h-16 bg-red-600 rounded-xl mx-auto mb-4 flex items-center justify-center">
        <Icon name="AlertTriangle" size={32} className="text-white" />
      </div>
      <h1 className="text-2xl font-bold text-white mb-4">Access Denied</h1>
      <p className="text-red-200 mb-6">
        Administrative privileges required. This area is restricted to authorized personnel only.
      </p>
      <div className="space-y-3">
        <button
          onClick={() => window.location.href = '/admin-secure-login'}
          className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
        >
          Admin Login
        </button>
        <button
          onClick={() => window.location.href = '/'}
          className="w-full bg-slate-600 hover:bg-slate-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
        >
          Return Home
        </button>
      </div>
    </div>
  </div>
);

// Admin-only protected route
export const ProtectedAdminRoute = ({ children }) => {
  const { admin, loading, isAdminAuthenticated } = useAdminAuth();
  const location = useLocation();

  // Show loading while authentication is being checked
  if (loading) {
    return <AdminAuthLoader />;
  }

  // Only check session validity after loading is complete
  const isValidAdminSession = isAdminLoggedIn();

  // If no authentication or invalid session, redirect to login
  if (!isAdminAuthenticated || !isValidAdminSession) {
    console.log('Admin authentication required, redirecting to login');
    return <Navigate to="/admin-secure-login" state={{ from: location }} replace />;
  }

  return children;
};

export default ProtectedAdminRoute;
