import React, { useState } from 'react';
import Icon from './AppIcon';
import Button from './ui/Button';
import { adminUserAPI } from '../services/adminApiService';

const AdminDataRefresh = ({ onRefresh }) => {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(null);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    
    try {
      // Test the API to make sure data is being read properly
      const response = await adminUserAPI.getUserStats();
      
      if (response?.success) {
        setLastRefresh(new Date().toLocaleTimeString());
        
        // Call the parent refresh callback if provided
        if (onRefresh && typeof onRefresh === 'function') {
          onRefresh(response.data);
        }
        
        // Force a small delay to show the loading state
        await new Promise(resolve => setTimeout(resolve, 500));
        
        console.log('✅ Admin data refreshed successfully', response.data);
      } else {
        console.warn('Failed to refresh admin data');
      }
    } catch (error) {
      console.error('Error refreshing admin data:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <div className="flex items-center space-x-2 text-sm">
      <Button
        variant="outline"
        size="sm"
        onClick={handleRefresh}
        disabled={isRefreshing}
        className="flex items-center space-x-1"
      >
        <Icon 
          name="RefreshCw" 
          size={14} 
          className={isRefreshing ? 'animate-spin' : ''} 
        />
        <span>{isRefreshing ? 'Refreshing...' : 'Refresh Data'}</span>
      </Button>
      
      {lastRefresh && (
        <span className="text-muted-foreground text-xs">
          Last updated: {lastRefresh}
        </span>
      )}
    </div>
  );
};

export default AdminDataRefresh;
