import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useUserAuth } from '../contexts/UserAuthContext';
import Icon from './AppIcon';

// Loading component for auth checks
const UserAuthLoader = () => (
  <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 flex items-center justify-center">
    <div className="text-center">
      <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-xl mx-auto mb-4 flex items-center justify-center">
        <Icon name="TrendingUp" size={32} className="text-white animate-pulse" />
      </div>
      <div className="text-foreground">
        <Icon name="Loader2" size={24} className="animate-spin mx-auto mb-2" />
        <p className="text-sm">Verifying your account...</p>
      </div>
    </div>
  </div>
);

// Unauthorized access component
const UserUnauthorized = () => (
  <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 flex items-center justify-center p-4">
    <div className="text-center max-w-md">
      <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-xl mx-auto mb-4 flex items-center justify-center">
        <Icon name="Lock" size={32} className="text-white" />
      </div>
      <h1 className="text-2xl font-bold text-foreground mb-4">Login Required</h1>
      <p className="text-muted-foreground mb-6">
        Please log in to access your investment dashboard and portfolio.
      </p>
      <div className="space-y-3">
        <button
          onClick={() => window.location.href = '/user-login'}
          className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
        >
          Login to Account
        </button>
        <button
          onClick={() => window.location.href = '/register'}
          className="w-full bg-muted hover:bg-muted/80 text-foreground font-semibold py-2 px-4 rounded-lg transition-colors"
        >
          Create Account
        </button>
        <button
          onClick={() => window.location.href = '/'}
          className="w-full text-muted-foreground hover:text-foreground font-medium py-2 px-4 transition-colors"
        >
          Return Home
        </button>
      </div>
    </div>
  </div>
);

// User-only protected route
export const ProtectedUserRoute = ({ children }) => {
  const { user, loading, isUserAuthenticated } = useUserAuth();
  const location = useLocation();

  if (loading) {
    return <UserAuthLoader />;
  }

  if (!isUserAuthenticated) {
    return <Navigate to="/user-login" state={{ from: location }} replace />;
  }

  return children;
};

export default ProtectedUserRoute;
