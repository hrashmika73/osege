import React, { useState, useEffect } from 'react';
import { useAdminAuth } from '../contexts/AdminAuthContext';
import { 
  biometricAuth, 
  adminRateLimiter, 
  generateDeviceFingerprint,
  initializeSecurity 
} from '../utils/adminSecurity';
import Icon from './AppIcon';
import Button from './ui/Button';

const AdminSecurityTest = () => {
  const { admin, sessionInfo, securityLevel } = useAdminAuth();
  const [testResults, setTestResults] = useState({});
  const [isRunning, setIsRunning] = useState(false);
  const [testLogs, setTestLogs] = useState([]);

  const addLog = (message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    setTestLogs(prev => [...prev, { timestamp, message, type }]);
  };

  const runSecurityTests = async () => {
    setIsRunning(true);
    setTestResults({});
    setTestLogs([]);
    
    addLog('Starting comprehensive security tests...', 'info');

    const results = {};

    try {
      // Test 1: Device Fingerprinting
      addLog('Testing device fingerprinting...', 'info');
      try {
        const fingerprint = await generateDeviceFingerprint();
        results.deviceFingerprinting = {
          success: !!fingerprint.id,
          deviceId: fingerprint.id,
          securityLevel: fingerprint.securityLevel,
          details: fingerprint.details
        };
        addLog(`✓ Device fingerprint generated: ${fingerprint.id.substring(0, 12)}...`, 'success');
        addLog(`✓ Security level: ${fingerprint.securityLevel}`, 'success');
      } catch (error) {
        results.deviceFingerprinting = { success: false, error: error.message };
        addLog(`✗ Device fingerprinting failed: ${error.message}`, 'error');
      }

      // Test 2: Biometric Authentication
      addLog('Testing biometric authentication...', 'info');
      try {
        const biometricAvailable = await biometricAuth.isAvailable();
        results.biometricAuth = {
          available: biometricAvailable,
          registered: admin ? biometricAuth.isRegistered(admin.username) : false
        };
        
        if (biometricAvailable) {
          addLog('✓ Biometric authentication is available on this device', 'success');
        } else {
          addLog('⚠ Biometric authentication not available on this device', 'warning');
        }
      } catch (error) {
        results.biometricAuth = { available: false, error: error.message };
        addLog(`✗ Biometric test failed: ${error.message}`, 'error');
      }

      // Test 3: Rate Limiting
      addLog('Testing rate limiting system...', 'info');
      try {
        const deviceFingerprint = await generateDeviceFingerprint();
        const clientIP = '127.0.0.1';
        
        // Test normal access
        const normalAccess = await adminRateLimiter.isAllowed(clientIP, deviceFingerprint);
        results.rateLimiting = {
          normalAccess: normalAccess.allowed,
          remainingAttempts: normalAccess.remainingAttempts,
          resetTime: normalAccess.resetTime
        };
        
        if (normalAccess.allowed) {
          addLog(`✓ Rate limiting allows access (${normalAccess.remainingAttempts} attempts remaining)`, 'success');
        } else {
          addLog(`⚠ Rate limiting blocking access (resets at ${new Date(normalAccess.resetTime).toLocaleTimeString()})`, 'warning');
        }

        // Test getting stats
        const stats = adminRateLimiter.getStats(clientIP, deviceFingerprint);
        addLog(`✓ Rate limiting stats: ${stats.attempts} attempts, ${stats.lockouts} lockouts`, 'info');
        
      } catch (error) {
        results.rateLimiting = { success: false, error: error.message };
        addLog(`✗ Rate limiting test failed: ${error.message}`, 'error');
      }

      // Test 4: Session Management
      addLog('Testing session management...', 'info');
      try {
        if (admin && sessionInfo) {
          const sessionAge = Date.now() - new Date(sessionInfo.loginTime).getTime();
          const sessionAgeMinutes = Math.floor(sessionAge / 1000 / 60);
          
          results.sessionManagement = {
            hasSession: true,
            sessionId: sessionInfo.sessionId,
            loginMethod: sessionInfo.loginMethod,
            deviceId: sessionInfo.deviceId,
            sessionAge: sessionAgeMinutes,
            securityLevel: securityLevel
          };
          
          addLog(`✓ Active admin session found (${sessionAgeMinutes} minutes old)`, 'success');
          addLog(`✓ Login method: ${sessionInfo.loginMethod}`, 'success');
          addLog(`✓ Security level: ${securityLevel}`, 'success');
        } else {
          results.sessionManagement = { hasSession: false };
          addLog('⚠ No active admin session', 'warning');
        }
      } catch (error) {
        results.sessionManagement = { success: false, error: error.message };
        addLog(`✗ Session management test failed: ${error.message}`, 'error');
      }

      // Test 5: JWT Token Validation
      addLog('Testing JWT token validation...', 'info');
      try {
        if (admin && admin.token) {
          const tokenParts = admin.token.split('.');
          const isJWT = tokenParts.length === 3;
          
          results.jwtValidation = {
            hasToken: true,
            isJWT: isJWT,
            tokenLength: admin.token.length
          };
          
          if (isJWT) {
            addLog('✓ Valid JWT token format detected', 'success');
            
            // Try to decode payload (basic check)
            try {
              const payload = JSON.parse(atob(tokenParts[1].replace(/[-_]/g, c => c === '-' ? '+' : '/')));
              addLog(`✓ JWT payload decoded successfully (expires: ${new Date(payload.exp * 1000).toLocaleString()})`, 'success');
            } catch (decodeError) {
              addLog('⚠ JWT payload could not be decoded', 'warning');
            }
          } else {
            addLog('⚠ Token is not in JWT format', 'warning');
          }
        } else {
          results.jwtValidation = { hasToken: false };
          addLog('⚠ No admin token found', 'warning');
        }
      } catch (error) {
        results.jwtValidation = { success: false, error: error.message };
        addLog(`✗ JWT validation test failed: ${error.message}`, 'error');
      }

      // Test 6: Security Headers
      addLog('Testing security headers...', 'info');
      try {
        const cspMeta = document.querySelector('meta[http-equiv=\"Content-Security-Policy\"]');
        const referrerMeta = document.querySelector('meta[name=\"referrer\"]');
        
        results.securityHeaders = {
          csp: !!cspMeta,
          referrer: !!referrerMeta,
          https: window.location.protocol === 'https:'
        };
        
        if (cspMeta) {
          addLog('✓ Content Security Policy header found', 'success');
        } else {
          addLog('⚠ Content Security Policy header missing', 'warning');
        }
        
        if (referrerMeta) {
          addLog('✓ Referrer policy header found', 'success');
        } else {
          addLog('⚠ Referrer policy header missing', 'warning');
        }
        
        if (window.location.protocol === 'https:') {
          addLog('✓ HTTPS protocol detected', 'success');
        } else {
          addLog('⚠ HTTPS protocol not detected (development environment)', 'warning');
        }
      } catch (error) {
        results.securityHeaders = { success: false, error: error.message };
        addLog(`✗ Security headers test failed: ${error.message}`, 'error');
      }

      // Test 7: Overall Security Score
      addLog('Calculating overall security score...', 'info');
      try {
        let score = 0;
        let maxScore = 0;

        // Device fingerprinting (20 points)
        maxScore += 20;
        if (results.deviceFingerprinting?.success) score += 20;

        // Biometric availability (15 points)
        maxScore += 15;
        if (results.biometricAuth?.available) score += 15;

        // Rate limiting (20 points)
        maxScore += 20;
        if (results.rateLimiting?.normalAccess !== false) score += 20;

        // Session management (20 points)
        maxScore += 20;
        if (results.sessionManagement?.hasSession) score += 20;

        // JWT tokens (15 points)
        maxScore += 15;
        if (results.jwtValidation?.isJWT) score += 15;

        // Security headers (10 points)
        maxScore += 10;
        if (results.securityHeaders?.csp && results.securityHeaders?.referrer) score += 10;

        const percentage = Math.round((score / maxScore) * 100);
        results.overallScore = { score, maxScore, percentage };

        let scoreLevel = 'low';
        if (percentage >= 80) scoreLevel = 'high';
        else if (percentage >= 60) scoreLevel = 'medium';

        addLog(`✓ Overall security score: ${score}/${maxScore} (${percentage}%) - ${scoreLevel.toUpperCase()}`, 
               scoreLevel === 'high' ? 'success' : scoreLevel === 'medium' ? 'warning' : 'error');
      } catch (error) {
        addLog(`✗ Security score calculation failed: ${error.message}`, 'error');
      }

      setTestResults(results);
      addLog('Security testing completed!', 'success');

    } catch (error) {
      addLog(`✗ Security testing failed: ${error.message}`, 'error');
    } finally {
      setIsRunning(false);
    }
  };

  const getLogColor = (type) => {
    switch (type) {
      case 'success': return 'text-green-400';
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      default: return 'text-gray-300';
    }
  };

  const getScoreColor = (percentage) => {
    if (percentage >= 80) return 'text-green-400';
    if (percentage >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="bg-card border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <Icon name="Shield" size={20} className="text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">Admin Security Test Suite</h2>
              <p className="text-sm text-muted-foreground">Comprehensive security feature validation</p>
            </div>
          </div>
          <Button
            onClick={runSecurityTests}
            disabled={isRunning}
            loading={isRunning}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isRunning ? 'Running Tests...' : 'Run Security Tests'}
          </Button>
        </div>

        {/* Test Results Grid */}
        {Object.keys(testResults).length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {/* Overall Score */}
            {testResults.overallScore && (
              <div className="col-span-full bg-background border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-foreground">Overall Security Score</h3>
                    <p className="text-sm text-muted-foreground">Comprehensive security rating</p>
                  </div>
                  <div className="text-right">
                    <div className={`text-2xl font-bold ${getScoreColor(testResults.overallScore.percentage)}`}>
                      {testResults.overallScore.percentage}%
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {testResults.overallScore.score}/{testResults.overallScore.maxScore} points
                    </div>
                  </div>
                </div>
                <div className="mt-3 bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-500 ${
                      testResults.overallScore.percentage >= 80 ? 'bg-green-500' :
                      testResults.overallScore.percentage >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${testResults.overallScore.percentage}%` }}
                  />
                </div>
              </div>
            )}

            {/* Individual Test Results */}
            {Object.entries(testResults).map(([testName, result]) => {
              if (testName === 'overallScore') return null;
              
              const success = result.success !== false && (result.available !== false || result.hasSession !== false || result.hasToken !== false);
              
              return (
                <div key={testName} className="bg-background border rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Icon 
                      name={success ? "CheckCircle" : "XCircle"} 
                      size={16} 
                      className={success ? "text-green-400" : "text-red-400"} 
                    />
                    <h3 className="font-medium text-foreground capitalize">
                      {testName.replace(/([A-Z])/g, ' $1').toLowerCase()}
                    </h3>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {JSON.stringify(result, null, 2).substring(0, 100)}...
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Test Logs */}
        <div className="bg-black rounded-lg p-4 h-96 overflow-y-auto">
          <div className="flex items-center space-x-2 mb-3">
            <Icon name="Terminal" size={16} className="text-green-400" />
            <span className="text-green-400 font-mono text-sm">Security Test Console</span>
          </div>
          <div className="space-y-1 font-mono text-xs">
            {testLogs.length === 0 ? (
              <div className="text-gray-500">Click "Run Security Tests" to begin comprehensive security validation...</div>
            ) : (
              testLogs.map((log, index) => (
                <div key={index} className="flex space-x-2">
                  <span className="text-gray-500">[{log.timestamp}]</span>
                  <span className={getLogColor(log.type)}>{log.message}</span>
                </div>
              ))
            )}
            {isRunning && (
              <div className="flex items-center space-x-2 text-blue-400">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
                <span>Running security tests...</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSecurityTest;
