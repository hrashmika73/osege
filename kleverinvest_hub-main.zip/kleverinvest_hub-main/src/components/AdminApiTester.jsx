import React, { useState, useEffect } from 'react';
import Icon from './AppIcon';
import Button from './ui/Button';
import { 
  adminAuthAPI,
  adminUserAPI,
  adminSystemAPI,
  adminTransactionAPI,
  testBackendConnection
} from '../services/adminApiService';

const AdminApiTester = () => {
  const [testResults, setTestResults] = useState([]);
  const [testing, setTesting] = useState(false);
  const [overallStatus, setOverallStatus] = useState('idle');
  const [networkTests, setNetworkTests] = useState({});

  // Comprehensive test suite for all API endpoints
  const testSuite = [
    {
      category: 'Authentication',
      tests: [
        {
          name: 'Valid Admin Login',
          description: 'Tests admin login with valid credentials',
          test: async () => {
            const result = await adminAuthAPI.login({
              username: 'admin',
              password: 'Admin@123!'
            });
            return {
              success: result.success,
              message: result.success ? 'Login successful' : 'Login failed',
              data: result.data,
              mockMode: result.mockMode,
              fallbackReason: result.fallbackReason
            };
          }
        },
        {
          name: 'Invalid Admin Login',
          description: 'Tests error handling for invalid credentials',
          test: async () => {
            try {
              const result = await adminAuthAPI.login({
                username: 'invalid',
                password: 'wrong'
              });
              return {
                success: false,
                message: 'Should have failed with invalid credentials',
                expected: 'error',
                actual: 'success'
              };
            } catch (error) {
              return {
                success: true,
                message: 'Properly handled invalid credentials',
                error: error.message,
                expectedBehavior: true
              };
            }
          }
        },
        {
          name: 'Token Verification',
          description: 'Tests token verification endpoint',
          test: async () => {
            const result = await adminAuthAPI.verifyToken('test_token');
            return {
              success: result.success,
              message: result.success ? 'Token verification working' : 'Token verification failed',
              data: result.data,
              mockMode: result.mockMode
            };
          }
        },
        {
          name: 'Admin Profile',
          description: 'Tests admin profile retrieval',
          test: async () => {
            const result = await adminAuthAPI.getProfile();
            return {
              success: result.success,
              message: result.success ? 'Profile retrieved successfully' : 'Profile retrieval failed',
              data: result.data,
              mockMode: result.mockMode
            };
          }
        }
      ]
    },
    {
      category: 'User Management',
      tests: [
        {
          name: 'Get Users List',
          description: 'Tests user list retrieval with pagination',
          test: async () => {
            const result = await adminUserAPI.getUsers(1, 10);
            return {
              success: result.success,
              message: result.success ? `Retrieved ${result.data?.users?.length || 0} users` : 'Failed to retrieve users',
              data: result.data,
              mockMode: result.mockMode
            };
          }
        },
        {
          name: 'Get User by ID',
          description: 'Tests single user retrieval',
          test: async () => {
            const result = await adminUserAPI.getUser(1);
            return {
              success: result.success,
              message: result.success ? 'User retrieved successfully' : 'User retrieval failed',
              data: result.data,
              mockMode: result.mockMode
            };
          }
        },
        {
          name: 'User Statistics',
          description: 'Tests user statistics endpoint',
          test: async () => {
            const result = await adminUserAPI.getUserStats();
            return {
              success: result.success,
              message: result.success ? 'User stats retrieved' : 'User stats failed',
              data: result.data,
              mockMode: result.mockMode
            };
          }
        },
        {
          name: 'Update User (Error Test)',
          description: 'Tests user update with invalid data',
          test: async () => {
            try {
              const result = await adminUserAPI.updateUser(999999, { invalid: 'data' });
              return {
                success: result.success,
                message: 'Update processed (may be mock)',
                data: result.data,
                mockMode: result.mockMode
              };
            } catch (error) {
              return {
                success: true,
                message: 'Properly handled invalid update',
                error: error.message,
                expectedBehavior: true
              };
            }
          }
        }
      ]
    },
    {
      category: 'System Management',
      tests: [
        {
          name: 'System Health Check',
          description: 'Tests system health monitoring',
          test: async () => {
            const result = await adminSystemAPI.getSystemHealth();
            return {
              success: result.success,
              message: result.success ? 'System health retrieved' : 'Health check failed',
              data: result.data,
              mockMode: result.mockMode
            };
          }
        },
        {
          name: 'System Metrics',
          description: 'Tests system metrics retrieval',
          test: async () => {
            const result = await adminSystemAPI.getMetrics();
            return {
              success: result.success,
              message: result.success ? 'Metrics retrieved' : 'Metrics failed',
              data: result.data,
              mockMode: result.mockMode
            };
          }
        },
        {
          name: 'System Logs',
          description: 'Tests system log retrieval',
          test: async () => {
            const result = await adminSystemAPI.getLogs('all', 10);
            return {
              success: result.success,
              message: result.success ? `Retrieved ${result.data?.length || 0} log entries` : 'Log retrieval failed',
              data: result.data,
              mockMode: result.mockMode
            };
          }
        }
      ]
    },
    {
      category: 'Transaction Management',
      tests: [
        {
          name: 'Get Transactions',
          description: 'Tests transaction list retrieval',
          test: async () => {
            const result = await adminTransactionAPI.getTransactions(1, 10);
            return {
              success: result.success,
              message: result.success ? `Retrieved ${result.data?.transactions?.length || 0} transactions` : 'Transaction retrieval failed',
              data: result.data,
              mockMode: result.mockMode
            };
          }
        },
        {
          name: 'Update Transaction Status',
          description: 'Tests transaction status update',
          test: async () => {
            const result = await adminTransactionAPI.updateTransaction('tx_001', 'completed');
            return {
              success: result.success,
              message: result.success ? 'Transaction status updated' : 'Transaction update failed',
              data: result.data,
              mockMode: result.mockMode
            };
          }
        }
      ]
    },
    {
      category: 'Network & Error Handling',
      tests: [
        {
          name: 'Backend Connection Test',
          description: 'Tests direct backend connectivity',
          test: async () => {
            const result = await testBackendConnection();
            return {
              success: result.connected || result.mockMode,
              message: result.message,
              connected: result.connected,
              mockMode: result.mockMode,
              status: result.status,
              error: result.error
            };
          }
        },
        {
          name: 'Timeout Handling Test',
          description: 'Tests API timeout handling',
          test: async () => {
            // Simulate a delayed response test
            const startTime = Date.now();
            try {
              const result = await Promise.race([
                adminSystemAPI.getSystemHealth(),
                new Promise((_, reject) => 
                  setTimeout(() => reject(new Error('Test timeout')), 5000)
                )
              ]);
              const endTime = Date.now();
              return {
                success: true,
                message: `Request completed in ${endTime - startTime}ms`,
                responseTime: endTime - startTime,
                data: result.data,
                mockMode: result.mockMode
              };
            } catch (error) {
              return {
                success: true,
                message: 'Timeout handled gracefully',
                error: error.message,
                expectedBehavior: true
              };
            }
          }
        },
        {
          name: 'Network Error Simulation',
          description: 'Tests network error fallback behavior',
          test: async () => {
            // This test verifies that the API service properly falls back to mock data
            const result = await adminUserAPI.getUsers(1, 1);
            return {
              success: true,
              message: result.mockMode ? 'Fallback to mock data working' : 'Backend connection active',
              mockMode: result.mockMode,
              fallbackReason: result.fallbackReason,
              data: result.data
            };
          }
        }
      ]
    }
  ];

  const runAllTests = async () => {
    setTesting(true);
    setOverallStatus('running');
    setTestResults([]);

    const allResults = [];
    let totalPassed = 0;
    let totalTests = 0;

    for (const category of testSuite) {
      for (const test of category.tests) {
        totalTests++;
        
        try {
          console.log(`Running test: ${category.category} - ${test.name}`);
          
          const startTime = Date.now();
          const result = await test.test();
          const endTime = Date.now();
          
          const testResult = {
            category: category.category,
            name: test.name,
            description: test.description,
            result: {
              ...result,
              duration: endTime - startTime,
              timestamp: new Date().toISOString()
            },
            passed: result.success || result.expectedBehavior
          };

          if (testResult.passed) totalPassed++;
          
          allResults.push(testResult);
          setTestResults([...allResults]);

          // Small delay between tests
          await new Promise(resolve => setTimeout(resolve, 200));
          
        } catch (error) {
          console.error(`Test failed: ${test.name}`, error);
          
          const testResult = {
            category: category.category,
            name: test.name,
            description: test.description,
            result: {
              success: false,
              message: 'Test execution failed',
              error: error.message,
              timestamp: new Date().toISOString(),
              duration: 0
            },
            passed: false
          };
          
          allResults.push(testResult);
          setTestResults([...allResults]);
        }
      }
    }

    const successRate = (totalPassed / totalTests) * 100;
    setOverallStatus(successRate >= 80 ? 'passed' : successRate >= 60 ? 'warning' : 'failed');
    setTesting(false);

    // Store network test summary
    setNetworkTests({
      total: totalTests,
      passed: totalPassed,
      failed: totalTests - totalPassed,
      successRate: successRate.toFixed(1)
    });
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'passed': return 'CheckCircle';
      case 'failed': return 'XCircle';
      case 'warning': return 'AlertTriangle';
      case 'running': return 'Loader2';
      default: return 'Circle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'passed': return 'text-green-600';
      case 'failed': return 'text-red-600';
      case 'warning': return 'text-yellow-600';
      case 'running': return 'text-blue-600';
      default: return 'text-gray-600';
    }
  };

  const getTestStatusIcon = (passed) => {
    return passed ? 'CheckCircle' : 'XCircle';
  };

  const getTestStatusColor = (passed) => {
    return passed ? 'text-green-600' : 'text-red-600';
  };

  const groupedResults = testResults.reduce((acc, result) => {
    if (!acc[result.category]) {
      acc[result.category] = [];
    }
    acc[result.category].push(result);
    return acc;
  }, {});

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-semibold text-foreground flex items-center">
              <Icon name="TestTube" size={24} className="mr-2 text-primary" />
              Admin API Testing Suite
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              Comprehensive testing for API endpoints, error handling, and network resilience
            </p>
          </div>
          <div className="flex items-center space-x-4">
            {overallStatus !== 'idle' && (
              <div className={`flex items-center space-x-2 ${getStatusColor(overallStatus)}`}>
                <Icon 
                  name={getStatusIcon(overallStatus)} 
                  size={20} 
                  className={testing ? 'animate-spin' : ''} 
                />
                <span className="font-medium">
                  {overallStatus === 'running' ? 'Testing...' : 
                   overallStatus === 'passed' ? 'All Tests Passed' :
                   overallStatus === 'warning' ? 'Some Issues Found' : 'Tests Failed'}
                </span>
              </div>
            )}
            <Button 
              onClick={runAllTests}
              disabled={testing}
              size="sm"
            >
              <Icon name="Play" size={16} className="mr-2" />
              {testing ? 'Running Tests...' : 'Run All Tests'}
            </Button>
          </div>
        </div>

        {/* Test Statistics */}
        {networkTests.total > 0 && (
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="bg-muted/50 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-foreground">{networkTests.total}</div>
              <div className="text-sm text-muted-foreground">Total Tests</div>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-green-600">{networkTests.passed}</div>
              <div className="text-sm text-green-700">Passed</div>
            </div>
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-red-600">{networkTests.failed}</div>
              <div className="text-sm text-red-700">Failed</div>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-blue-600">{networkTests.successRate}%</div>
              <div className="text-sm text-blue-700">Success Rate</div>
            </div>
          </div>
        )}
      </div>

      {/* Test Results */}
      <div className="space-y-6">
        {testing && testResults.length === 0 && (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <Icon name="Loader2" size={48} className="text-primary animate-spin mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">Running API Tests</h3>
              <p className="text-muted-foreground">Testing all endpoints for proper error handling and network resilience...</p>
            </div>
          </div>
        )}

        {Object.entries(groupedResults).map(([category, results]) => (
          <div key={category} className="border border-border rounded-lg p-4">
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
              <Icon name="Folder" size={20} className="mr-2" />
              {category}
              <span className="ml-auto text-sm text-muted-foreground">
                {results.filter(r => r.passed).length}/{results.length} passed
              </span>
            </h3>
            
            <div className="space-y-3">
              {results.map((test, index) => (
                <div key={index} className="bg-muted/30 rounded-lg p-3">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Icon 
                        name={getTestStatusIcon(test.passed)} 
                        size={16} 
                        className={getTestStatusColor(test.passed)} 
                      />
                      <span className="font-medium text-foreground">{test.name}</span>
                      {test.result.mockMode && (
                        <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
                          Mock Mode
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {test.result.duration}ms
                    </span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-2">{test.description}</p>
                  <p className="text-sm text-foreground mb-2">{test.result.message}</p>
                  
                  {test.result.error && (
                    <div className="bg-red-50 border border-red-200 rounded p-2 mb-2">
                      <p className="text-xs text-red-700 font-mono">{test.result.error}</p>
                    </div>
                  )}
                  
                  {test.result.fallbackReason && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded p-2 mb-2">
                      <p className="text-xs text-yellow-700">
                        <strong>Fallback:</strong> {test.result.fallbackReason}
                      </p>
                    </div>
                  )}
                  
                  {test.result.data && (
                    <details className="text-xs">
                      <summary className="cursor-pointer text-muted-foreground hover:text-foreground">
                        View Response Data
                      </summary>
                      <pre className="mt-2 bg-background border rounded p-2 overflow-x-auto max-h-32">
                        {JSON.stringify(test.result.data, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}

        {!testing && testResults.length === 0 && (
          <div className="text-center py-12">
            <Icon name="TestTube" size={48} className="text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">Ready to Test</h3>
            <p className="text-muted-foreground mb-4">
              Click "Run All Tests" to verify API endpoints, error handling, and network resilience
            </p>
            <div className="text-sm text-muted-foreground space-y-1">
              <div>✅ Tests all API endpoints for proper error handling</div>
              <div>✅ Verifies NetworkErrors are caught and handled gracefully</div>
              <div>✅ Ensures no errors break the application</div>
              <div>✅ Tests both successful and failed network requests</div>
              <div>✅ Validates fallback mechanisms work correctly</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminApiTester;
