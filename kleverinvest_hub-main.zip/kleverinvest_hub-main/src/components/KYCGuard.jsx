import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useUserAuth } from '../contexts/UserAuthContext';
import Icon from './AppIcon';
import Button from './ui/Button';

const KYCGuard = ({ children }) => {
  const { user, loading } = useUserAuth();
  const location = useLocation();

  // Show loading while checking auth
  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Icon name="Loader2" size={32} className="animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Checking authentication...</p>
        </div>
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!user) {
    // If we've been redirected from user-dashboard, show helpful message
    if (location.pathname === '/user-dashboard') {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <div className="max-w-md w-full text-center">
            <div className="bg-card border rounded-lg p-8">
              <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="Lock" size={32} className="text-destructive" />
              </div>
              <h1 className="text-2xl font-bold text-foreground mb-4">
                Access Denied
              </h1>
              <p className="text-muted-foreground mb-6">
                You need to be logged in to access the user dashboard.
              </p>
              <div className="space-y-3">
                <Button
                  className="w-full"
                  onClick={() => window.location.href = '/user-login'}
                >
                  <Icon name="LogIn" size={16} className="mr-2" />
                  Login to Continue
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => window.location.href = '/fix-403'}
                >
                  <Icon name="Wrench" size={16} className="mr-2" />
                  Fix 403 Error
                </Button>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return <Navigate to="/user-login" state={{ from: location }} replace />;
  }

  // Check KYC status - allow access only if verified
  if (user.kycStatus !== 'verified' && user.verified !== true) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          <div className="bg-card border rounded-lg p-8">
            <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="AlertTriangle" size={32} className="text-warning" />
            </div>
            
            <h1 className="text-2xl font-bold text-foreground mb-4">
              KYC Verification Required
            </h1>
            
            <p className="text-muted-foreground mb-6">
              To access your dashboard and investment features, you need to complete your KYC (Know Your Customer) verification process. This helps us ensure account security and comply with regulations.
            </p>

            <div className="space-y-3 mb-6">
              <div className="flex items-center space-x-3 text-sm">
                <Icon name="FileText" size={16} className="text-primary" />
                <span>Identity verification</span>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <Icon name="Shield" size={16} className="text-primary" />
                <span>Address confirmation</span>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <Icon name="CreditCard" size={16} className="text-primary" />
                <span>Financial information</span>
              </div>
            </div>

            <div className="space-y-3">
              <Button 
                className="w-full" 
                onClick={() => window.location.href = '/kyc-verification'}
              >
                <Icon name="Upload" size={16} className="mr-2" />
                Start KYC Verification
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.location.href = '/user-login'}
              >
                <Icon name="LogOut" size={16} className="mr-2" />
                Logout
              </Button>
            </div>

            <div className="mt-6 p-4 bg-muted/30 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="Clock" size={16} className="text-muted-foreground" />
                <span className="text-sm font-medium text-foreground">Verification Status</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Current Status: <span className="font-medium text-warning">
                  {user.kycStatus === 'pending' ? 'Pending Documents' : user.kycStatus}
                </span>
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Verification typically takes 1-2 business days after document submission.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // User is verified, render children
  return children;
};

export default KYCGuard;
