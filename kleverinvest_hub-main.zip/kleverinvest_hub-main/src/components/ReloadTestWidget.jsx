import React, { useState } from 'react';
import Icon from './AppIcon';
import Button from './ui/Button';
import { pageStatePreservation } from '../utils/pageStatePreservation';

const ReloadTestWidget = () => {
  const [testRunning, setTestRunning] = useState(false);
  const [lastTest, setLastTest] = useState(null);

  const runReloadTest = () => {
    setTestRunning(true);
    
    // Store test data
    const testData = {
      timestamp: Date.now(),
      currentPage: window.location.pathname + window.location.search,
      sessionData: {
        adminToken: !!localStorage.getItem('adminToken'),
        adminData: !!localStorage.getItem('adminData'),
        adminSession: !!localStorage.getItem('adminSession')
      }
    };
    
    sessionStorage.setItem('reloadTestData', JSON.stringify(testData));
    
    // Store page state
    pageStatePreservation.storePage();
    
    console.log('🧪 Running reload test...', testData);
    
    // Reload the page
    window.location.reload();
  };

  React.useEffect(() => {
    // Check if we just completed a reload test
    const testData = sessionStorage.getItem('reloadTestData');
    if (testData) {
      try {
        const test = JSON.parse(testData);
        const currentSessionData = {
          adminToken: !!localStorage.getItem('adminToken'),
          adminData: !!localStorage.getItem('adminData'),
          adminSession: !!localStorage.getItem('adminSession')
        };
        
        const result = {
          testTime: new Date(test.timestamp).toLocaleTimeString(),
          expectedPage: test.currentPage,
          actualPage: window.location.pathname + window.location.search,
          sessionPreserved: 
            test.sessionData.adminToken === currentSessionData.adminToken &&
            test.sessionData.adminData === currentSessionData.adminData &&
            test.sessionData.adminSession === currentSessionData.adminSession,
          pagePreserved: test.currentPage === (window.location.pathname + window.location.search)
        };
        
        setLastTest(result);
        setTestRunning(false);
        
        // Clean up
        sessionStorage.removeItem('reloadTestData');
        
        console.log('🧪 Reload test completed:', result);
        
      } catch (error) {
        console.error('Failed to parse reload test data:', error);
        sessionStorage.removeItem('reloadTestData');
      }
    }
  }, []);

  return (
    <div className="bg-card border rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <Icon name="RefreshCw" size={16} className="text-blue-500" />
          <h3 className="font-semibold text-foreground">Reload Test</h3>
        </div>
        <Button
          onClick={runReloadTest}
          disabled={testRunning}
          size="sm"
          variant="outline"
        >
          {testRunning ? (
            <Icon name="Loader2" size={14} className="animate-spin mr-2" />
          ) : (
            <Icon name="RefreshCw" size={14} className="mr-2" />
          )}
          Test Reload
        </Button>
      </div>

      <p className="text-sm text-muted-foreground mb-3">
        Test that admin session and page state persist across page reloads
      </p>

      {lastTest && (
        <div className="space-y-2">
          <div className="text-xs font-medium text-foreground">Last Test Results:</div>
          
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center justify-between p-2 bg-muted/50 rounded">
              <span>Session:</span>
              <span className={`font-medium ${
                lastTest.sessionPreserved ? 'text-green-600' : 'text-red-600'
              }`}>
                {lastTest.sessionPreserved ? '✓ Preserved' : '✗ Lost'}
              </span>
            </div>
            
            <div className="flex items-center justify-between p-2 bg-muted/50 rounded">
              <span>Page:</span>
              <span className={`font-medium ${
                lastTest.pagePreserved ? 'text-green-600' : 'text-red-600'
              }`}>
                {lastTest.pagePreserved ? '✓ Same Page' : '✗ Redirected'}
              </span>
            </div>
          </div>

          <div className="text-xs text-muted-foreground">
            <div>Test Time: {lastTest.testTime}</div>
            {!lastTest.pagePreserved && (
              <div className="text-yellow-600">
                Expected: {lastTest.expectedPage}
                <br />
                Actual: {lastTest.actualPage}
              </div>
            )}
          </div>
        </div>
      )}

      {testRunning && (
        <div className="flex items-center space-x-2 text-sm text-blue-600">
          <Icon name="Loader2" size={14} className="animate-spin" />
          <span>Running reload test...</span>
        </div>
      )}
    </div>
  );
};

export default ReloadTestWidget;
