import React, { useState, useEffect } from 'react';
import Icon from './AppIcon';
import Button from './ui/Button';
import { testBackendConnection, adminSystemAPI } from '../services/adminApiService';

const BackendConnectionDisplay = () => {
  const [connectionStatus, setConnectionStatus] = useState({
    status: 'checking',
    connected: false,
    mockMode: false,
    message: 'Checking backend connection...',
    lastChecked: null
  });
  const [systemHealth, setSystemHealth] = useState(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isTesting, setIsTesting] = useState(false);

  useEffect(() => {
    checkConnection();
    // Check connection every 5 minutes
    const interval = setInterval(checkConnection, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const checkConnection = async () => {
    try {
      const result = await testBackendConnection();
      setConnectionStatus({
        ...result,
        lastChecked: new Date().toISOString()
      });

      // If connected, get system health
      if (result.connected) {
        try {
          const healthResponse = await adminSystemAPI.getSystemHealth();
          if (healthResponse.success) {
            setSystemHealth(healthResponse.data);
          }
        } catch (healthError) {
          console.warn('Failed to get system health:', healthError);
        }
      }
    } catch (error) {
      setConnectionStatus({
        status: 'error',
        connected: false,
        mockMode: true,
        message: `Connection test failed: ${error.message}`,
        lastChecked: new Date().toISOString()
      });
    }
  };

  const testConnection = async () => {
    setIsTesting(true);
    await checkConnection();
    setIsTesting(false);
  };

  const getStatusColor = () => {
    switch (connectionStatus.status) {
      case 'connected': return 'text-green-500';
      case 'mock': return 'text-yellow-500';
      case 'failed': return 'text-red-500';
      case 'checking': return 'text-blue-500';
      default: return 'text-gray-500';
    }
  };

  const getStatusIcon = () => {
    switch (connectionStatus.status) {
      case 'connected': return 'CheckCircle';
      case 'mock': return 'AlertTriangle';
      case 'failed': return 'XCircle';
      case 'checking': return 'Loader2';
      default: return 'HelpCircle';
    }
  };

  const getStatusText = () => {
    switch (connectionStatus.status) {
      case 'connected': return 'Backend Connected';
      case 'mock': return 'Mock Mode';
      case 'failed': return 'Backend Unavailable';
      case 'checking': return 'Checking...';
      default: return 'Unknown';
    }
  };

  return (
    <div className="bg-card border rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <Icon 
            name={getStatusIcon()} 
            size={16} 
            className={`${getStatusColor()} ${connectionStatus.status === 'checking' ? 'animate-spin' : ''}`} 
          />
          <h3 className="font-semibold text-foreground">Backend Status</h3>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            onClick={() => setIsExpanded(!isExpanded)}
            variant="ghost"
            size="sm"
          >
            <Icon name={isExpanded ? "ChevronUp" : "ChevronDown"} size={14} />
          </Button>
          <Button
            onClick={testConnection}
            disabled={isTesting}
            variant="outline"
            size="sm"
          >
            <Icon name="RefreshCw" size={14} className={`mr-1 ${isTesting ? 'animate-spin' : ''}`} />
            Test
          </Button>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Status:</span>
          <span className={`text-sm font-medium ${getStatusColor()}`}>
            {getStatusText()}
          </span>
        </div>

        <div className="text-xs text-muted-foreground">
          {connectionStatus.message}
        </div>

        {connectionStatus.lastChecked && (
          <div className="text-xs text-muted-foreground">
            Last checked: {new Date(connectionStatus.lastChecked).toLocaleTimeString()}
          </div>
        )}
      </div>

      {isExpanded && (
        <div className="mt-4 pt-4 border-t space-y-3">
          {/* Connection Details */}
          <div className="space-y-2">
            <div className="text-sm font-medium text-foreground">Connection Details</div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Mode:</span>
                <span className={connectionStatus.mockMode ? 'text-yellow-600' : 'text-green-600'}>
                  {connectionStatus.mockMode ? 'Mock' : 'Live'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">API:</span>
                <span className={connectionStatus.connected ? 'text-green-600' : 'text-red-600'}>
                  {connectionStatus.connected ? 'Online' : 'Offline'}
                </span>
              </div>
            </div>
          </div>

          {/* System Health (if available) */}
          {systemHealth && (
            <div className="space-y-2">
              <div className="text-sm font-medium text-foreground">System Health</div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status:</span>
                  <span className="text-green-600 capitalize">{systemHealth.status}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Uptime:</span>
                  <span className="text-foreground">{systemHealth.uptime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Database:</span>
                  <span className={systemHealth.database?.status === 'connected' ? 'text-green-600' : 'text-red-600'}>
                    {systemHealth.database?.status || 'Unknown'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Version:</span>
                  <span className="text-foreground">{systemHealth.version}</span>
                </div>
              </div>
            </div>
          )}

          {/* Environment Info */}
          <div className="space-y-2">
            <div className="text-sm font-medium text-foreground">Environment</div>
            <div className="grid grid-cols-1 gap-1 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Backend Enabled:</span>
                <span className="text-foreground">
                  {import.meta.env.VITE_ENABLE_BACKEND === 'true' ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">API URL:</span>
                <span className="text-foreground font-mono text-xs">
                  {import.meta.env.VITE_API_URL || 'http://localhost:3001/api'}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="space-y-2">
            <div className="text-sm font-medium text-foreground">Backend Setup</div>
            <div className="text-xs text-muted-foreground space-y-1">
              <div>• Set VITE_ENABLE_BACKEND=true to enable backend</div>
              <div>• Set VITE_API_URL to your backend URL</div>
              <div>• Ensure backend server is running</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BackendConnectionDisplay;
