import React, { useState, useEffect } from 'react';
import Button from './ui/Button';
import Icon from './AppIcon';
import networkErrorDetector from '../utils/networkErrorDetector';
import resourceLoader from '../utils/resourceLoader';

const NetworkErrorFixManager = () => {
  const [errorReport, setErrorReport] = useState(null);
  const [isFixing, setIsFixing] = useState(false);
  const [fixResults, setFixResults] = useState([]);
  const [networkStatus, setNetworkStatus] = useState(navigator.onLine);

  useEffect(() => {
    // Start monitoring
    networkErrorDetector.startMonitoring();

    // Get initial error report
    const report = networkErrorDetector.getErrorReport();
    setErrorReport(report);

    // Update error report every 5 seconds
    const interval = setInterval(() => {
      const newReport = networkErrorDetector.getErrorReport();
      setErrorReport(newReport);
    }, 5000);

    // Listen for network status changes
    const handleNetworkChange = (event) => {
      setNetworkStatus(event.detail.online);
    };

    window.addEventListener('networkStatusChange', handleNetworkChange);

    return () => {
      clearInterval(interval);
      window.removeEventListener('networkStatusChange', handleNetworkChange);
    };
  }, []);

  const runComprehensiveFix = async () => {
    setIsFixing(true);
    setFixResults([]);
    const results = [];

    try {
      // 1. Clear failed resources cache
      results.push({ step: 'Clear Failed Resources', status: 'success', message: 'Cleared resource cache' });
      
      // 2. Test basic connectivity
      results.push({ step: 'Test Connectivity', status: 'running', message: 'Testing network...' });
      setFixResults([...results]);
      
      const connectivityTest = await fetch(window.location.origin + '/favicon.ico', {
        method: 'HEAD',
        cache: 'no-cache',
        signal: AbortSignal.timeout(3000)
      }).then(() => true).catch(() => false);
      
      results[results.length - 1] = {
        step: 'Test Connectivity',
        status: connectivityTest ? 'success' : 'warning',
        message: connectivityTest ? 'Network connection OK' : 'Limited connectivity detected'
      };

      // 3. Fix database connections
      results.push({ step: 'Fix Database', status: 'running', message: 'Checking database connections...' });
      setFixResults([...results]);
      
      try {
        // Import and reinitialize database
        const { initializeDatabase } = await import('../config/database.js');
        await initializeDatabase();
        results[results.length - 1] = {
          step: 'Fix Database',
          status: 'success',
          message: 'Database connection restored'
        };
      } catch (dbError) {
        results[results.length - 1] = {
          step: 'Fix Database',
          status: 'warning',
          message: 'Using localStorage fallback'
        };
      }

      // 4. Preload critical resources
      results.push({ step: 'Load Resources', status: 'running', message: 'Loading critical resources...' });
      setFixResults([...results]);
      
      await resourceLoader.preloadCriticalResources();
      results[results.length - 1] = {
        step: 'Load Resources',
        status: 'success',
        message: 'Critical resources loaded'
      };

      // 5. Clear localStorage errors
      results.push({ step: 'Clear Storage Errors', status: 'running', message: 'Clearing error states...' });
      setFixResults([...results]);
      
      // Clear any error flags in localStorage
      const errorKeys = Object.keys(localStorage).filter(key => 
        key.includes('error') || key.includes('failed') || key.includes('retry')
      );
      errorKeys.forEach(key => localStorage.removeItem(key));
      
      results[results.length - 1] = {
        step: 'Clear Storage Errors',
        status: 'success',
        message: `Cleared ${errorKeys.length} error states`
      };

      // 6. Fix OAuth scripts
      results.push({ step: 'Fix OAuth', status: 'running', message: 'Loading OAuth scripts...' });
      setFixResults([...results]);
      
      const oauthResults = await Promise.allSettled([
        resourceLoader.loadOAuthScript('google'),
        resourceLoader.loadOAuthScript('apple')
      ]);
      
      const oauthSuccess = oauthResults.filter(r => r.value?.success).length;
      results[results.length - 1] = {
        step: 'Fix OAuth',
        status: oauthSuccess > 0 ? 'success' : 'warning',
        message: `${oauthSuccess}/2 OAuth providers loaded`
      };

      // 7. Clear error detector log
      results.push({ step: 'Clear Error Log', status: 'success', message: 'Error monitoring reset' });
      networkErrorDetector.clearLog();

      // 8. Final validation
      results.push({ step: 'Final Validation', status: 'success', message: 'All fixes applied successfully' });
      setFixResults([...results]);

      // Show success message
      setTimeout(() => {
        alert('✅ NetworkError fixes applied successfully!\n\nThe application should now work properly. If you still experience issues, try refreshing the page.');
      }, 500);

    } catch (error) {
      results.push({
        step: 'Fix Process',
        status: 'error',
        message: `Fix failed: ${error.message}`
      });
    } finally {
      setIsFixing(false);
      setFixResults([...results]);
    }
  };

  const forceReload = () => {
    if (confirm('This will reload the page to clear all network errors. Continue?')) {
      window.location.reload();
    }
  };

  const clearAllCache = () => {
    if ('caches' in window) {
      caches.keys().then(names => {
        names.forEach(name => caches.delete(name));
      });
    }
    
    // Clear localStorage (except user data)
    const preserveKeys = ['userData', 'userToken', 'adminData', 'adminToken'];
    const allKeys = Object.keys(localStorage);
    allKeys.forEach(key => {
      if (!preserveKeys.includes(key)) {
        localStorage.removeItem(key);
      }
    });

    alert('🧹 Cache cleared! Please reload the page.');
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success': return <Icon name="CheckCircle" className="text-success" size={16} />;
      case 'warning': return <Icon name="AlertTriangle" className="text-warning" size={16} />;
      case 'error': return <Icon name="XCircle" className="text-destructive" size={16} />;
      case 'running': return <Icon name="Loader2" className="animate-spin text-primary" size={16} />;
      default: return <Icon name="Circle" className="text-muted-foreground" size={16} />;
    }
  };

  return (
    <div className="bg-card border rounded-lg p-6 max-w-4xl mx-auto">
      <div className="flex items-center space-x-2 mb-6">
        <Icon name="Shield" className="text-primary" />
        <h2 className="text-xl font-semibold">NetworkError Fix Manager</h2>
        <div className={`px-2 py-1 rounded text-xs ${networkStatus ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'}`}>
          {networkStatus ? 'Online' : 'Offline'}
        </div>
      </div>

      {errorReport && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-muted/30 p-4 rounded">
            <h3 className="font-medium mb-2">Total Errors</h3>
            <div className="text-2xl font-bold text-destructive">{errorReport.totalErrors}</div>
          </div>
          <div className="bg-muted/30 p-4 rounded">
            <h3 className="font-medium mb-2">Error Types</h3>
            <div className="text-2xl font-bold text-warning">{Object.keys(errorReport.summary).length}</div>
          </div>
          <div className="bg-muted/30 p-4 rounded">
            <h3 className="font-medium mb-2">Network Status</h3>
            <div className={`text-2xl font-bold ${errorReport.networkStatus === 'online' ? 'text-success' : 'text-destructive'}`}>
              {errorReport.networkStatus}
            </div>
          </div>
        </div>
      )}

      {errorReport && Object.keys(errorReport.summary).length > 0 && (
        <div className="bg-muted/30 p-4 rounded mb-6">
          <h3 className="font-medium mb-3">Detected Error Types</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {Object.entries(errorReport.summary).map(([type, count]) => (
              <div key={type} className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">{type.replace(/_/g, ' ')}</span>
                <span className="font-medium text-destructive">{count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-4 mb-6">
        <Button 
          onClick={runComprehensiveFix} 
          disabled={isFixing}
          className="w-full"
        >
          {isFixing ? (
            <>
              <Icon name="Loader2" size={16} className="mr-2 animate-spin" />
              Fixing NetworkErrors...
            </>
          ) : (
            <>
              <Icon name="Wrench" size={16} className="mr-2" />
              Fix All NetworkErrors
            </>
          )}
        </Button>

        <div className="flex space-x-2">
          <Button variant="outline" onClick={forceReload} className="flex-1">
            <Icon name="RefreshCw" size={16} className="mr-2" />
            Force Reload
          </Button>
          <Button variant="outline" onClick={clearAllCache} className="flex-1">
            <Icon name="Trash2" size={16} className="mr-2" />
            Clear Cache
          </Button>
        </div>
      </div>

      {fixResults.length > 0 && (
        <div className="bg-muted/30 p-4 rounded">
          <h3 className="font-medium mb-3">Fix Progress</h3>
          <div className="space-y-2">
            {fixResults.map((result, index) => (
              <div key={index} className="flex items-center space-x-3 text-sm">
                {getStatusIcon(result.status)}
                <span className="font-medium">{result.step}:</span>
                <span className="text-muted-foreground">{result.message}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {errorReport && errorReport.recentErrors.length > 0 && (
        <div className="mt-6 bg-muted/30 p-4 rounded">
          <h3 className="font-medium mb-3">Recent Errors</h3>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {errorReport.recentErrors.map((error, index) => (
              <div key={index} className="text-xs p-2 bg-background rounded">
                <div className="font-medium text-destructive">{error.type}</div>
                <div className="text-muted-foreground truncate">{error.message}</div>
                <div className="text-xs text-muted-foreground">
                  {new Date(error.timestamp).toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default NetworkErrorFixManager;
