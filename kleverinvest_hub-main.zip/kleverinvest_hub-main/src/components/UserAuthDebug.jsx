import React, { useState, useEffect } from 'react';
import { useUserAuth } from '../contexts/UserAuthContext';
import Button from './ui/Button';
import Icon from './AppIcon';

const UserAuthDebug = () => {
  const { user, loading, isUserAuthenticated, userLogin, userLogout } = useUserAuth();
  const [authState, setAuthState] = useState(null);
  const [testCredentials, setTestCredentials] = useState({
    email: 'user@kleverinvest.com',
    password: 'password123'
  });

  useEffect(() => {
    // Check localStorage for auth data
    const userToken = localStorage.getItem('userToken');
    const userData = localStorage.getItem('userData');
    const adminToken = localStorage.getItem('adminToken');
    
    setAuthState({
      userToken: !!userToken,
      userData: !!userData,
      adminToken: !!adminToken,
      userTokenValue: userToken,
      userDataValue: userData ? JSON.parse(userData) : null,
      currentUrl: window.location.href,
      userFromContext: user,
      isAuthenticated: isUserAuthenticated,
      loading
    });
  }, [user, isUserAuthenticated, loading]);

  const handleTestLogin = async () => {
    try {
      await userLogin(testCredentials);
      alert('Login successful!');
    } catch (error) {
      alert(`Login failed: ${error.message}`);
    }
  };

  const handleClearAuth = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userData');
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminData');
    userLogout();
    window.location.reload();
  };

  const navigateToDashboard = () => {
    window.location.href = '/user-dashboard';
  };

  if (!authState) {
    return <div>Loading debug info...</div>;
  }

  return (
    <div className="bg-card border rounded-lg p-6 max-w-2xl mx-auto my-8">
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="Bug" className="text-warning" />
        <h2 className="text-lg font-semibold">User Authentication Debug</h2>
      </div>

      <div className="space-y-4">
        <div className="bg-muted/30 p-4 rounded">
          <h3 className="font-medium mb-2">Current State</h3>
          <div className="space-y-1 text-sm">
            <div>Loading: <span className={loading ? 'text-warning' : 'text-success'}>{loading.toString()}</span></div>
            <div>Is Authenticated: <span className={isUserAuthenticated ? 'text-success' : 'text-destructive'}>{isUserAuthenticated.toString()}</span></div>
            <div>User Token in Storage: <span className={authState.userToken ? 'text-success' : 'text-destructive'}>{authState.userToken.toString()}</span></div>
            <div>User Data in Storage: <span className={authState.userData ? 'text-success' : 'text-destructive'}>{authState.userData.toString()}</span></div>
            <div>Admin Token in Storage: <span className={authState.adminToken ? 'text-warning' : 'text-muted-foreground'}>{authState.adminToken.toString()}</span></div>
            <div>Current URL: <span className="text-muted-foreground">{authState.currentUrl}</span></div>
          </div>
        </div>

        {authState.userDataValue && (
          <div className="bg-muted/30 p-4 rounded">
            <h3 className="font-medium mb-2">User Data</h3>
            <pre className="text-xs overflow-auto">{JSON.stringify(authState.userDataValue, null, 2)}</pre>
          </div>
        )}

        {user && (
          <div className="bg-muted/30 p-4 rounded">
            <h3 className="font-medium mb-2">User from Context</h3>
            <div className="space-y-1 text-sm">
              <div>Name: {user.name}</div>
              <div>Email: {user.email}</div>
              <div>Role: {user.role}</div>
              <div>KYC Status: {user.kycStatus}</div>
              <div>Verified: {user.verified?.toString()}</div>
            </div>
          </div>
        )}

        <div className="bg-muted/30 p-4 rounded">
          <h3 className="font-medium mb-2">Test Login</h3>
          <div className="space-y-2">
            <input
              type="email"
              value={testCredentials.email}
              onChange={(e) => setTestCredentials({...testCredentials, email: e.target.value})}
              className="w-full p-2 border rounded"
              placeholder="Email"
            />
            <input
              type="password"
              value={testCredentials.password}
              onChange={(e) => setTestCredentials({...testCredentials, password: e.target.value})}
              className="w-full p-2 border rounded"
              placeholder="Password"
            />
            <Button onClick={handleTestLogin} className="w-full">
              Test Login
            </Button>
          </div>
        </div>

        <div className="flex space-x-2">
          <Button variant="outline" onClick={handleClearAuth}>
            Clear All Auth Data
          </Button>
          <Button onClick={navigateToDashboard}>
            Try Access Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
};

export default UserAuthDebug;
