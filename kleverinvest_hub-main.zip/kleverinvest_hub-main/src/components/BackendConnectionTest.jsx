import React, { useState, useEffect } from 'react';
import Icon from './AppIcon';
import Button from './ui/Button';
import { testBackendConnection, apiConfig, adminAPI, authAPI } from '../utils/api';

const BackendConnectionTest = ({ onClose }) => {
  const [testResults, setTestResults] = useState([]);
  const [testing, setTesting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('unknown');

  useEffect(() => {
    try {
      runInitialTest();
    } catch (error) {
      console.error('Failed to run initial test:', error);
      setConnectionStatus('disconnected');
      setTestResults([{
        name: 'Backend Health Check',
        result: {
          success: false,
          message: 'Failed to initialize test',
          error: error.message,
          type: 'error'
        },
        timestamp: new Date().toISOString()
      }]);
      setTesting(false);
    }
  }, []);

  const runInitialTest = async () => {
    setTesting(true);
    try {
      const result = await testBackendConnection();
      setConnectionStatus(result.success ? 'connected' : 'disconnected');
      setTestResults([{
        name: 'Backend Health Check',
        result,
        timestamp: new Date().toISOString()
      }]);
    } catch (error) {
      console.warn('Initial test failed:', error);
      setConnectionStatus('disconnected');
      setTestResults([{
        name: 'Backend Health Check',
        result: {
          success: false,
          message: 'Test failed to execute',
          error: error.message,
          type: 'error'
        },
        timestamp: new Date().toISOString()
      }]);
    } finally {
      setTesting(false);
    }
  };

  const runFullTest = async () => {
    setTesting(true);
    setTestResults([]);
    
    const tests = [
      {
        name: 'Backend Health Check',
        test: async () => {
          try {
            return await testBackendConnection();
          } catch (error) {
            return {
              success: false,
              message: 'Health check failed to execute',
              error: error.message,
              type: 'error'
            };
          }
        }
      },
      {
        name: 'Authentication API',
        test: async () => {
          try {
            const result = await authAPI.verifyToken();
            return {
              success: result.success,
              message: result.message || 'Authentication API test complete',
              type: result.type || (result.success ? 'success' : 'warning')
            };
          } catch (error) {
            return {
              success: false,
              message: 'Authentication API failed',
              error: error.message,
              type: 'error'
            };
          }
        }
      },
      {
        name: 'Admin API - System Stats',
        test: async () => {
          try {
            const result = await adminAPI.getSystemStats();
            return {
              success: result.success,
              message: result.message || 'System stats retrieved',
              data: result.data,
              type: result.type || (result.success ? 'success' : 'warning')
            };
          } catch (error) {
            return {
              success: false,
              message: 'System stats API failed',
              error: error.message,
              type: 'error'
            };
          }
        }
      },
      {
        name: 'Admin API - Users',
        test: async () => {
          try {
            const result = await adminAPI.getUsers({ page: 1, limit: 1 });
            return {
              success: result.success,
              message: result.message || 'User data retrieved',
              data: result.data,
              type: result.type || (result.success ? 'success' : 'warning')
            };
          } catch (error) {
            return {
              success: false,
              message: 'User API failed',
              error: error.message,
              type: 'error'
            };
          }
        }
      },
      {
        name: 'Admin API - Transactions',
        test: async () => {
          try {
            const result = await adminAPI.getTransactions({ page: 1, limit: 1 });
            return {
              success: result.success,
              message: result.message || 'Transaction data retrieved',
              data: result.data,
              type: result.type || (result.success ? 'success' : 'warning')
            };
          } catch (error) {
            return {
              success: false,
              message: 'Transaction API failed',
              error: error.message,
              type: 'error'
            };
          }
        }
      }
    ];

    const results = [];
    for (const test of tests) {
      try {
        const result = await test.test();
        results.push({
          name: test.name,
          result,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        results.push({
          name: test.name,
          result: {
            success: false,
            message: 'Test failed with exception',
            error: error.message,
            type: 'error'
          },
          timestamp: new Date().toISOString()
        });
      }
      
      // Add a small delay between tests
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    setTestResults(results);
    
    // Update overall connection status
    const hasSuccessfulConnection = results.some(r => r.result.success);
    setConnectionStatus(hasSuccessfulConnection ? 'connected' : 'disconnected');
    setTesting(false);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'connected': return 'CheckCircle';
      case 'disconnected': return 'XCircle';
      case 'unknown': return 'HelpCircle';
      default: return 'HelpCircle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected': return 'text-success';
      case 'disconnected': return 'text-destructive';
      case 'unknown': return 'text-warning';
      default: return 'text-muted-foreground';
    }
  };

  const getResultIcon = (result) => {
    switch (result.type) {
      case 'success': return 'CheckCircle';
      case 'error': return 'XCircle';
      case 'warning': return 'AlertTriangle';
      default: return 'Info';
    }
  };

  const getResultColor = (result) => {
    switch (result.type) {
      case 'success': return 'text-success bg-success/10 border-success/20';
      case 'error': return 'text-destructive bg-destructive/10 border-destructive/20';
      case 'warning': return 'text-warning bg-warning/10 border-warning/20';
      default: return 'text-primary bg-primary/10 border-primary/20';
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-lg shadow-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <Icon name="Server" size={24} className="text-primary" />
            <div>
              <h2 className="text-xl font-semibold text-foreground">Backend Connection Test</h2>
              <p className="text-sm text-muted-foreground">Test connectivity to backend services</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={onClose}>
            <Icon name="X" size={16} />
          </Button>
        </div>

        {/* Configuration Info */}
        <div className="p-6 border-b border-border bg-muted/20">
          <h3 className="text-lg font-medium text-foreground mb-4">Current Configuration</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-muted-foreground">API Base URL</label>
              <div className="text-sm font-mono text-foreground bg-background border rounded px-2 py-1">
                {apiConfig?.baseURL || 'Not configured'}
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Backend Enabled</label>
              <div className={`text-sm font-medium ${apiConfig?.backendEnabled ? 'text-success' : 'text-warning'}`}>
                {apiConfig?.backendEnabled ? 'Yes' : 'No (Mock Mode)'}
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Connection Status</label>
              <div className={`flex items-center space-x-2 ${getStatusColor(connectionStatus)}`}>
                <Icon name={getStatusIcon(connectionStatus)} size={16} />
                <span className="text-sm font-medium capitalize">{connectionStatus}</span>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Timeout</label>
              <div className="text-sm text-foreground">
                {apiConfig?.timeout ? (apiConfig.timeout / 1000) + 's' : 'Default'}
              </div>
            </div>
          </div>
        </div>

        {/* Test Controls */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-foreground mb-1">Connection Tests</h3>
              <p className="text-sm text-muted-foreground">
                Run comprehensive tests to verify backend connectivity
              </p>
            </div>
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                onClick={runInitialTest}
                disabled={testing}
              >
                <Icon name="RefreshCw" size={16} className={testing ? "animate-spin" : ""} />
                Quick Test
              </Button>
              <Button 
                onClick={runFullTest}
                disabled={testing}
              >
                <Icon name="Play" size={16} />
                Full Test Suite
              </Button>
            </div>
          </div>
        </div>

        {/* Test Results */}
        <div className="p-6 max-h-96 overflow-y-auto">
          <h3 className="text-lg font-medium text-foreground mb-4">Test Results</h3>
          
          {testing && (
            <div className="flex items-center justify-center py-8">
              <div className="text-center">
                <Icon name="Loader2" size={32} className="text-primary animate-spin mx-auto mb-2" />
                <p className="text-muted-foreground">Running tests...</p>
              </div>
            </div>
          )}

          {testResults.length > 0 && (
            <div className="space-y-4">
              {testResults.map((test, index) => (
                <div key={index} className="border border-border rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${getResultColor(test.result)}`}>
                      <Icon name={getResultIcon(test.result)} size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-foreground">{test.name}</h4>
                        <span className="text-xs text-muted-foreground">
                          {new Date(test.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{test.result.message}</p>
                      
                      {test.result.error && (
                        <div className="text-xs font-mono text-destructive bg-destructive/10 border border-destructive/20 rounded p-2 mb-2">
                          {test.result.error}
                        </div>
                      )}
                      
                      {test.result.data && (
                        <details className="text-xs">
                          <summary className="cursor-pointer text-muted-foreground hover:text-foreground">
                            View Response Data
                          </summary>
                          <pre className="mt-2 bg-background border rounded p-2 overflow-x-auto">
                            {JSON.stringify(test.result.data, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {!testing && testResults.length === 0 && (
            <div className="text-center py-8">
              <Icon name="Server" size={48} className="text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground">No tests run yet. Click "Quick Test" or "Full Test Suite" to begin.</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border bg-muted/20">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              To enable backend connectivity, set <code className="bg-background px-1 rounded">REACT_APP_ENABLE_BACKEND=true</code> in your environment
            </div>
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BackendConnectionTest;
