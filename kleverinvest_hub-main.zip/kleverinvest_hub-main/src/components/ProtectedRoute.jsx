import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Icon from './AppIcon';

// Loading component for auth checks
const AuthLoader = () => (
  <div className="min-h-screen bg-background flex items-center justify-center">
    <div className="text-center">
      <div className="w-16 h-16 bg-primary/10 rounded-full mx-auto mb-4 flex items-center justify-center">
        <Icon name="Loader" size={32} className="text-primary animate-spin" />
      </div>
      <p className="text-muted-foreground">Checking authentication...</p>
    </div>
  </div>
);

// Unauthorized access component
const UnauthorizedAccess = ({ requiredRole }) => (
  <div className="min-h-screen bg-background flex items-center justify-center p-6">
    <div className="max-w-md w-full text-center">
      <div className="w-16 h-16 bg-destructive/10 rounded-full mx-auto mb-6 flex items-center justify-center">
        <Icon name="ShieldX" size={32} className="text-destructive" />
      </div>
      <h1 className="text-2xl font-bold text-foreground mb-4">Access Denied</h1>
      <p className="text-muted-foreground mb-6">
        You don't have permission to access this {requiredRole} area. 
        Please use the appropriate login portal.
      </p>
      <div className="space-y-3">
        {requiredRole === 'admin' ? (
          <a 
            href="/admin-secure-login" 
            className="inline-flex items-center justify-center w-full px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition-colors"
          >
            <Icon name="Shield" size={20} className="mr-2" />
            Admin Login
          </a>
        ) : (
          <a 
            href="/login" 
            className="inline-flex items-center justify-center w-full px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition-colors"
          >
            <Icon name="User" size={20} className="mr-2" />
            User Login
          </a>
        )}
        <a 
          href="/" 
          className="inline-flex items-center justify-center w-full px-4 py-2 border border-border text-foreground rounded-md hover:bg-muted/50 transition-colors"
        >
          <Icon name="Home" size={20} className="mr-2" />
          Go Home
        </a>
      </div>
    </div>
  </div>
);

// Admin-only protected route
export const AdminRoute = ({ children }) => {
  const { user, loading, hasRole } = useAuth();
  const location = useLocation();

  if (loading) {
    return <AuthLoader />;
  }

  if (!user) {
    return <Navigate to="/admin-secure-login" state={{ from: location }} replace />;
  }

  if (!hasRole('admin')) {
    return <UnauthorizedAccess requiredRole="admin" />;
  }

  return children;
};

// User-only protected route
export const UserRoute = ({ children }) => {
  const { user, loading, hasRole } = useAuth();
  const location = useLocation();

  if (loading) {
    return <AuthLoader />;
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (!hasRole('user')) {
    return <UnauthorizedAccess requiredRole="user" />;
  }

  return children;
};

// Any authenticated user (user or admin)
export const ProtectedRoute = ({ children }) => {
  const { user, loading, isAuthenticated } = useAuth();
  const location = useLocation();

  if (loading) {
    return <AuthLoader />;
  }

  if (!isAuthenticated()) {
    return <Navigate to="/login-selection" state={{ from: location }} replace />;
  }

  return children;
};

// Public route (redirect if already authenticated)
export const PublicRoute = ({ children }) => {
  const { user, loading, hasRole } = useAuth();

  if (loading) {
    return <AuthLoader />;
  }

  if (user) {
    if (hasRole('admin')) {
      return <Navigate to="/admin-dashboard" replace />;
    } else if (hasRole('user')) {
      return <Navigate to="/user-dashboard" replace />;
    }
  }

  return children;
};

export default ProtectedRoute;
