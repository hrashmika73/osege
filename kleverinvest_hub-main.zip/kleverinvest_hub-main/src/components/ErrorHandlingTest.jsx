import React, { useState } from 'react';
import Button from './ui/Button';
import Icon from './AppIcon';

const ErrorHandlingTest = () => {
  const [testResults, setTestResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const runErrorTests = async () => {
    setIsLoading(true);
    setTestResults([]);

    const tests = [
      {
        name: 'Test Dynamic Import Error Handling',
        test: async () => {
          try {
            // Try to import a non-existent module
            await import('../utils/nonExistentModule');
            return {
              success: false,
              message: 'Import should have failed',
              type: 'error'
            };
          } catch (error) {
            return {
              success: true,
              message: 'Dynamic import error handled gracefully',
              error: error.message,
              type: 'success'
            };
          }
        }
      },
      {
        name: 'Test Fetch Error Handling',
        test: async () => {
          try {
            await fetch('http://localhost:9999/nonexistent-endpoint');
            return {
              success: false,
              message: 'Fetch should have failed',
              type: 'error'
            };
          } catch (error) {
            return {
              success: true,
              message: 'Fetch error handled gracefully',
              error: error.message,
              type: 'success'
            };
          }
        }
      },
      {
        name: 'Test UserDataManager Import',
        test: async () => {
          try {
            const userDataManager = await import('../utils/userDataManager');
            const { getAllUsers } = userDataManager;
            const users = getAllUsers();
            return {
              success: true,
              message: 'UserDataManager import successful',
              data: { userCount: users.length },
              type: 'success'
            };
          } catch (error) {
            return {
              success: false,
              message: 'UserDataManager import failed',
              error: error.message,
              type: 'warning'
            };
          }
        }
      },
      {
        name: 'Test Promise Rejection Handling',
        test: async () => {
          try {
            // Create an unhandled promise rejection
            Promise.reject(new Error('Test NetworkError rejection'));
            
            // Wait a bit to see if it's caught
            await new Promise(resolve => setTimeout(resolve, 100));
            
            return {
              success: true,
              message: 'Promise rejection test completed (check console)',
              type: 'success'
            };
          } catch (error) {
            return {
              success: true,
              message: 'Promise rejection handled',
              error: error.message,
              type: 'success'
            };
          }
        }
      },
      {
        name: 'Test Image Loading Error',
        test: async () => {
          return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
              resolve({
                success: false,
                message: 'Image should have failed to load',
                type: 'error'
              });
            };
            img.onerror = () => {
              resolve({
                success: true,
                message: 'Image loading error handled gracefully',
                type: 'success'
              });
            };
            img.src = 'http://localhost:9999/nonexistent-image.jpg';
            
            // Timeout after 2 seconds
            setTimeout(() => {
              resolve({
                success: true,
                message: 'Image error test timed out (handled gracefully)',
                type: 'success'
              });
            }, 2000);
          });
        }
      },
      {
        name: 'Test API Configuration',
        test: async () => {
          try {
            const { apiConfig } = await import('../utils/api');
            return {
              success: true,
              message: 'API configuration loaded successfully',
              data: {
                backendEnabled: apiConfig.backendEnabled,
                baseURL: apiConfig.baseURL
              },
              type: 'success'
            };
          } catch (error) {
            return {
              success: false,
              message: 'API configuration load failed',
              error: error.message,
              type: 'error'
            };
          }
        }
      }
    ];

    const results = [];
    for (const test of tests) {
      try {
        console.log(`🧪 Running test: ${test.name}`);
        const result = await test.test();
        results.push({
          name: test.name,
          result,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        console.warn(`❌ Test failed: ${test.name}`, error);
        results.push({
          name: test.name,
          result: {
            success: false,
            message: 'Test threw an unexpected error',
            error: error.message,
            type: 'error'
          },
          timestamp: new Date().toISOString()
        });
      }
      
      // Small delay between tests
      await new Promise(resolve => setTimeout(resolve, 300));
    }

    setTestResults(results);
    setIsLoading(false);
  };

  const getResultIcon = (result) => {
    switch (result.type) {
      case 'success': return 'CheckCircle';
      case 'warning': return 'AlertTriangle';
      case 'error': return 'XCircle';
      default: return 'Info';
    }
  };

  const getResultColor = (result) => {
    switch (result.type) {
      case 'success': return 'text-green-600 bg-green-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'error': return 'text-red-600 bg-red-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  const checkConsoleStatus = () => {
    console.log('🛡️ Error Handling System Status Check');
    console.log('Global error handlers:', {
      unhandledrejection: !!window.onunhandledrejection,
      error: !!window.onerror
    });
    
    // Test the handlers are working
    console.warn('Testing error handler with a mock NetworkError...');
    setTimeout(() => {
      Promise.reject(new Error('Mock NetworkError test - should be caught by handler'));
    }, 100);
  };

  return (
    <div className="bg-card border rounded-lg p-6 max-w-4xl mx-auto">
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold text-foreground mb-2">
          Error Handling System Test
        </h2>
        <p className="text-muted-foreground">
          Comprehensive test of NetworkError and exception handling
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Button
          onClick={runErrorTests}
          disabled={isLoading}
          className="flex-1"
        >
          {isLoading ? (
            <>
              <Icon name="Loader2" size={16} className="animate-spin mr-2" />
              Running Tests...
            </>
          ) : (
            <>
              <Icon name="Play" size={16} className="mr-2" />
              Run Error Handling Tests
            </>
          )}
        </Button>
        
        <Button
          variant="outline"
          onClick={checkConsoleStatus}
          disabled={isLoading}
        >
          <Icon name="Terminal" size={16} className="mr-2" />
          Check Console Status
        </Button>
      </div>

      {testResults.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-medium text-foreground">Test Results:</h3>
          {testResults.map((test, index) => (
            <div key={index} className="border border-border rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${getResultColor(test.result)}`}>
                  <Icon name={getResultIcon(test.result)} size={16} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-foreground">{test.name}</h4>
                    <span className="text-xs text-muted-foreground">
                      {new Date(test.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{test.result.message}</p>
                  
                  {test.result.error && (
                    <div className="text-xs font-mono text-red-600 bg-red-50 border border-red-200 rounded p-2 mb-2">
                      Error: {test.result.error}
                    </div>
                  )}
                  
                  {test.result.data && (
                    <details className="text-xs">
                      <summary className="cursor-pointer text-muted-foreground hover:text-foreground">
                        View Data
                      </summary>
                      <pre className="mt-2 bg-muted/50 border rounded p-2 overflow-x-auto">
                        {JSON.stringify(test.result.data, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-6 text-xs text-muted-foreground">
        <p className="mb-2">🛡️ What this test does:</p>
        <ul className="list-disc list-inside space-y-1">
          <li>Tests dynamic import error handling</li>
          <li>Tests fetch/network error handling</li>
          <li>Tests unhandled promise rejection catching</li>
          <li>Tests resource loading error handling</li>
          <li>Verifies error handlers are installed</li>
          <li>Checks API configuration is working</li>
        </ul>
      </div>
    </div>
  );
};

export default ErrorHandlingTest;
