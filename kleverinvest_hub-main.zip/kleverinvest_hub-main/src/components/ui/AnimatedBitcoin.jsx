import React from 'react';

const AnimatedBitcoin = ({ 
  size = 'md', 
  animation = 'float', 
  className = '',
  showGlow = false,
  speed = 'normal'
}) => {
  const sizeClasses = {
    xs: 'w-4 h-4',
    sm: 'w-6 h-6', 
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
    '2xl': 'w-24 h-24'
  };

  const animationClasses = {
    float: speed === 'slow' ? 'animate-float-slow' : speed === 'fast' ? 'animate-float-fast' : 'animate-float',
    bounce: speed === 'slow' ? 'animate-bounce-slow' : speed === 'fast' ? 'animate-bounce-fast' : 'animate-bounce',
    pulse: speed === 'slow' ? 'animate-pulse-slow' : speed === 'fast' ? 'animate-pulse-fast' : 'animate-pulse',
    spin: speed === 'slow' ? 'animate-spin-slow' : speed === 'fast' ? 'animate-spin-fast' : 'animate-spin',
    none: ''
  };

  const glowClass = showGlow ? 'drop-shadow-[0_0_8px_rgba(255,165,0,0.6)]' : '';

  return (
    <div className={`inline-flex items-center justify-center ${className}`}>
      <div 
        className={`
          ${sizeClasses[size]} 
          ${animationClasses[animation]} 
          ${glowClass}
          transition-all duration-300 ease-in-out
        `}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
        >
          <defs>
            <linearGradient id="bitcoinGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f7931a" />
              <stop offset="50%" stopColor="#ffb84d" />
              <stop offset="100%" stopColor="#f7931a" />
            </linearGradient>
          </defs>
          
          {/* Bitcoin Circle */}
          <circle
            cx="12"
            cy="12"
            r="11"
            fill="url(#bitcoinGradient)"
            stroke="#e67e22"
            strokeWidth="1"
          />
          
          {/* Bitcoin B Symbol */}
          <path
            d="M10.5 7h1.5v1.5h1c.8 0 1.5.7 1.5 1.5s-.7 1.5-1.5 1.5c.8 0 1.5.7 1.5 1.5s-.7 1.5-1.5 1.5h-1v1.5h-1.5v-1.5h-1v-1.5h1v-3h-1v-1.5h1v-1.5zm1.5 3h1c.3 0 .5-.2.5-.5s-.2-.5-.5-.5h-1v1zm0 3h1c.3 0 .5-.2.5-.5s-.2-.5-.5-.5h-1v1z"
            fill="white"
            strokeWidth="0.5"
            stroke="#e67e22"
          />
          
          {/* Top vertical line */}
          <rect x="11.25" y="5.5" width="1.5" height="2" fill="white" />
          
          {/* Bottom vertical line */}
          <rect x="11.25" y="16.5" width="1.5" height="2" fill="white" />
        </svg>
      </div>
    </div>
  );
};

export default AnimatedBitcoin;
