import React from 'react';
import { cn } from '../../utils/cn';

const Checkbox = React.forwardRef(({
  className,
  id,
  label,
  description,
  error,
  required = false,
  disabled = false,
  ...props
}, ref) => {
  // Generate unique ID if not provided
  const checkboxId = id || `checkbox-${Math.random().toString(36).substr(2, 9)}`;

  return (
    <div className="flex items-start space-x-3">
      <div className="flex items-center">
        <input
          type="checkbox"
          id={checkboxId}
          className={cn(
            "h-4 w-4 rounded border border-input bg-background text-primary focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
            error && "border-destructive focus:ring-destructive",
            className
          )}
          ref={ref}
          disabled={disabled}
          aria-describedby={
            [
              description && `${checkboxId}-description`,
              error && `${checkboxId}-error`
            ].filter(Boolean).join(' ') || undefined
          }
          {...props}
        />
      </div>

      {(label || description || error) && (
        <div className="grid gap-1.5 leading-none">
          {label && (
            <label
              htmlFor={checkboxId}
              className={cn(
                "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer",
                error ? "text-destructive" : "text-foreground",
                disabled && "opacity-50 cursor-not-allowed"
              )}
            >
              {label}
              {required && <span className="text-destructive ml-1" aria-label="required">*</span>}
            </label>
          )}

          {description && !error && (
            <p id={`${checkboxId}-description`} className="text-xs text-muted-foreground">
              {description}
            </p>
          )}

          {error && (
            <p id={`${checkboxId}-error`} className="text-xs text-destructive" role="alert">
              {error}
            </p>
          )}
        </div>
      )}
    </div>
  );
});

Checkbox.displayName = "Checkbox";

export { Checkbox };
export default Checkbox;
