import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import Icon from '../AppIcon';
import Button from './Button';

const Sidebar = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const location = useLocation();

  // Try to get user from either context
  const { user: userContext, isUserAuthenticated } = useUserAuth();
  const { admin: adminContext, isAdminAuthenticated } = useAdminAuth();

  // Determine which user is active and their role
  const user = isAdminAuthenticated ? adminContext : (isUserAuthenticated ? userContext : null);
  const hasRole = (role) => {
    if (role === 'admin') return isAdminAuthenticated;
    if (role === 'user') return isUserAuthenticated;
    return false;
  };

  // Admin navigation items
  const adminNavItems = [
    {
      label: 'Dashboard',
      path: '/admin-dashboard',
      icon: 'LayoutDashboard',
      description: 'Overview & Analytics'
    },
    {
      label: 'Enhanced User Management',
      path: '/admin-user-management-enhanced',
      icon: 'Users',
      description: 'Advanced User Controls'
    },
    {
      label: 'Payment Gateway',
      path: '/admin-payment-gateway',
      icon: 'CreditCard',
      description: 'Payment Management'
    },
    {
      label: 'System Analytics',
      path: '/admin-system-analytics',
      icon: 'BarChart3',
      description: 'Performance Monitoring'
    },
    {
      label: 'System Logs',
      path: '/admin-system-logs',
      icon: 'FileText',
      description: 'System Monitoring'
    },
    {
      label: 'Site Settings',
      path: '/admin-site-settings',
      icon: 'Settings',
      description: 'Platform Configuration'
    },
  ];

  // User navigation items
  const userNavItems = [
    {
      label: 'Dashboard',
      path: '/user-dashboard',
      icon: 'LayoutDashboard',
      description: 'Your Overview'
    },
    {
      label: 'Portfolio',
      path: '/investment-portfolio-dashboard',
      icon: 'PieChart',
      description: 'Investment Portfolio'
    },
    {
      label: 'Trading',
      path: '/trading-dashboard',
      icon: 'BarChart3',
      description: 'Trading Interface'
    },
    {
      label: 'Referral Program',
      path: '/referral-program',
      icon: 'UserPlus',
      description: 'Earn Commissions'
    },
    {
      label: 'Profile Settings',
      path: '/user-profile-settings',
      icon: 'Settings',
      description: 'Account Settings'
    },
    {
      label: 'Support Chat',
      path: '/support-chat-system',
      icon: 'MessageCircle',
      description: 'Get Help'
    },
  ];

  // Show appropriate navigation based on user role
  const navigationItems = user && hasRole('admin') ? adminNavItems : userNavItems;
  const sectionTitle = user && hasRole('admin') ? 'Administration' : 'User Dashboard';

  const isActivePath = (path) => location.pathname === path;

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className={`hidden lg:fixed lg:inset-y-0 lg:left-0 lg:z-40 lg:flex lg:flex-col transition-all duration-300 ${
        isCollapsed ? 'lg:w-16' : 'lg:w-64'
      }`}>
        <div className="flex flex-col flex-1 min-h-0 bg-card border-r">
          {/* Sidebar Header */}
          <div className="flex items-center justify-between p-4 border-b">
            {!isCollapsed && (
              <div className="flex items-center space-x-2">
                <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
                  <Icon name="TrendingUp" size={20} color="white" />
                </div>
                <span className="font-bold text-lg text-foreground">KleverInvest</span>
              </div>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleCollapse}
              className={`${isCollapsed ? 'mx-auto' : ''}`}
            >
              <Icon name={isCollapsed ? "ChevronRight" : "ChevronLeft"} size={16} />
            </Button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-3 py-4 space-y-6">
            {/* Main Navigation Section */}
            <div>
              {!isCollapsed && (
                <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                  {sectionTitle}
                </h3>
              )}
              <div className="space-y-1">
                {navigationItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors duration-150 ${
                      isActivePath(item.path)
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                    }`}
                    title={isCollapsed ? item.label : ''}
                  >
                    <Icon name={item.icon} size={18} className="flex-shrink-0" />
                    {!isCollapsed && (
                      <div className="ml-3 flex-1 min-w-0">
                        <div className="truncate">{item.label}</div>
                        <div className="text-xs opacity-75 truncate">{item.description}</div>
                      </div>
                    )}
                  </Link>
                ))}
              </div>
            </div>
          </nav>

          {/* Sidebar Footer */}
          <div className="p-3 border-t">
            <div className={`flex items-center ${isCollapsed ? 'justify-center' : 'space-x-3'}`}>
              <div className="flex items-center justify-center w-8 h-8 bg-muted rounded-full">
                <Icon name="User" size={16} />
              </div>
              {!isCollapsed && (
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-foreground truncate">
                    {user?.name || (hasRole('admin') ? 'Admin User' : 'User')}
                  </div>
                  <div className="text-xs text-muted-foreground truncate">
                    {user?.email || (hasRole('admin') ? 'admin@kleverinvest.com' : 'user@kleverinvest.com')}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Sidebar Overlay - Hidden by default, shown when needed */}
      <div className="lg:hidden">
        {/* This would be controlled by a mobile menu state in the parent component */}
      </div>
    </>
  );
};

export default Sidebar;
