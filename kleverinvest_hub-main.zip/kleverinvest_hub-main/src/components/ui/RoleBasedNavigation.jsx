import React, { createContext, useContext, useState, useEffect } from 'react';

const NavigationContext = createContext();

export const useNavigation = () => {
  const context = useContext(NavigationContext);
  if (!context) {
    throw new Error('useNavigation must be used within a NavigationProvider');
  }
  return context;
};

const RoleBasedNavigation = ({ children }) => {
  const [userRole, setUserRole] = useState('admin'); // Default to admin for demo
  const [isAuthenticated, setIsAuthenticated] = useState(true); // Default to authenticated for demo
  const [navigationState, setNavigationState] = useState({
    isMobileMenuOpen: false,
    isSidebarCollapsed: false,
    activeRoute: '/',
  });

  // Simulate authentication check
  useEffect(() => {
    // In a real app, this would check localStorage, cookies, or make an API call
    const checkAuth = () => {
      const storedRole = localStorage.getItem('userRole') || 'admin';
      const authStatus = localStorage.getItem('isAuthenticated') === 'true';
      
      setUserRole(storedRole);
      setIsAuthenticated(authStatus);
    };

    checkAuth();
  }, []);

  // Update active route based on current location
  useEffect(() => {
    setNavigationState(prev => ({
      ...prev,
      activeRoute: window.location.pathname,
    }));
  }, []);

  const updateNavigationState = (updates) => {
    setNavigationState(prev => ({ ...prev, ...updates }));
  };

  const toggleMobileMenu = () => {
    setNavigationState(prev => ({
      ...prev,
      isMobileMenuOpen: !prev.isMobileMenuOpen,
    }));
  };

  const toggleSidebar = () => {
    setNavigationState(prev => ({
      ...prev,
      isSidebarCollapsed: !prev.isSidebarCollapsed,
    }));
  };

  const closeMobileMenu = () => {
    setNavigationState(prev => ({
      ...prev,
      isMobileMenuOpen: false,
    }));
  };

  // Define navigation items based on role
  const getNavigationItems = () => {
    const baseItems = {
      admin: [
        { label: 'Dashboard', path: '/admin-dashboard', icon: 'LayoutDashboard', section: 'admin' },
        { label: 'User Management', path: '/admin-user-management', icon: 'Users', section: 'admin' },
        { label: 'Transaction Management', path: '/admin-transaction-management', icon: 'CreditCard', section: 'admin' },
        { label: 'Referral Program', path: '/referral-program', icon: 'UserPlus', section: 'user' },
        { label: 'Profile Settings', path: '/user-profile-settings', icon: 'Settings', section: 'user' },
        { label: 'Support Chat', path: '/support-chat-system', icon: 'MessageCircle', section: 'user' },
      ],
      user: [
        { label: 'Referral Program', path: '/referral-program', icon: 'UserPlus', section: 'user' },
        { label: 'Profile Settings', path: '/user-profile-settings', icon: 'Settings', section: 'user' },
        { label: 'Support Chat', path: '/support-chat-system', icon: 'MessageCircle', section: 'user' },
      ],
    };

    return baseItems[userRole] || baseItems.user;
  };

  const contextValue = {
    userRole,
    isAuthenticated,
    navigationState,
    navigationItems: getNavigationItems(),
    updateNavigationState,
    toggleMobileMenu,
    toggleSidebar,
    closeMobileMenu,
    setUserRole,
    setIsAuthenticated,
  };

  return (
    <NavigationContext.Provider value={contextValue}>
      {children}
    </NavigationContext.Provider>
  );
};

export default RoleBasedNavigation;