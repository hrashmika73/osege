import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useUserAuth } from '../../contexts/UserAuthContext';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const location = useLocation();

  // Try to get user from either context - but ensure only ONE can be active
  const { user: userContext, isUserAuthenticated } = useUserAuth();
  const { admin: adminContext, isAdminAuthenticated } = useAdminAuth();

  // DEBUG: Log authentication states
  console.log('Header Auth Debug:', {
    isUserAuthenticated,
    isAdminAuthenticated,
    userContext: userContext ? userContext.role : null,
    adminContext: adminContext ? adminContext.role : null
  });

  // CRITICAL: Ensure complete separation - only one type of auth can be active
  // If admin is authenticated, ignore user auth completely
  // If user is authenticated, ensure no admin access
  const user = isAdminAuthenticated ? adminContext : (isUserAuthenticated ? userContext : null);
  const hasRole = (role) => {
    // STRICT separation: admin context can ONLY access admin, user context can ONLY access user
    if (role === 'admin') return isAdminAuthenticated && !isUserAuthenticated;
    if (role === 'user') return isUserAuthenticated && !isAdminAuthenticated;
    return false;
  };

  // User navigation items
  const userPrimaryNavItems = [
    { label: 'Dashboard', path: '/user-dashboard', icon: 'LayoutDashboard' },
    { label: 'Portfolio', path: '/investment-portfolio-dashboard', icon: 'PieChart' },
    { label: 'Trading', path: '/trading-dashboard', icon: 'BarChart3' },
    { label: 'BTC Trade', path: '/btc-live-trading-interface', icon: 'TrendingUp' },
    { label: 'Opportunities', path: '/investment-opportunities', icon: 'Target' },
    { label: 'Transactions', path: '/transaction-history', icon: 'CreditCard' },
  ];

  // Admin navigation items
  const adminPrimaryNavItems = [
    { label: 'Dashboard', path: '/admin-dashboard', icon: 'LayoutDashboard' },
    { label: 'Users', path: '/admin-user-management-enhanced', icon: 'Users' },
    { label: 'Payments', path: '/admin-payment-gateway', icon: 'CreditCard' },
    { label: 'Analytics', path: '/admin-system-analytics', icon: 'BarChart3' },
    { label: 'Logs', path: '/admin-system-logs', icon: 'FileText' },
    { label: 'Settings', path: '/admin-site-settings', icon: 'Settings' },
  ];

  const userSecondaryNavItems = [
    { label: 'Withdrawals', path: '/withdrawal-requests', icon: 'Send' },
    { label: 'Referrals', path: '/referral-program', icon: 'UserPlus' },
    { label: 'Profile Settings', path: '/user-profile-settings', icon: 'Settings' },
    { label: 'Support', path: '/support-chat-system', icon: 'MessageCircle' },
  ];

  const adminSecondaryNavItems = [
    { label: 'Transactions', path: '/admin-transaction-management', icon: 'Send' },
    { label: 'User Management', path: '/admin-user-management', icon: 'Users' },
    { label: 'Support', path: '/support-chat-system', icon: 'MessageCircle' },
  ];

  // Get navigation items based on user role
  const primaryNavItems = user && hasRole('admin') ? adminPrimaryNavItems : userPrimaryNavItems;
  const secondaryNavItems = user && hasRole('admin') ? adminSecondaryNavItems : userSecondaryNavItems;

  const isActivePath = (path) => location.pathname === path;

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const toggleMoreMenu = () => {
    setIsMoreMenuOpen(!isMoreMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border glass-effect">
      <div className="container flex h-16 items-center">
        {/* Logo */}
        <Link to="/" className="flex items-center space-x-2 mr-8">
          <div className="flex items-center justify-center w-8 h-8 gradient-gold rounded-lg">
            <Icon name="TrendingUp" size={20} color="black" />
          </div>
          <span className="font-bold text-xl text-foreground">KleverInvest Hub</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1 flex-1">
          {primaryNavItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-150 ${
                isActivePath(item.path)
                  ? 'gradient-gold text-black' :'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              <Icon name={item.icon} size={16} />
              <span>{item.label}</span>
            </Link>
          ))}

          {/* More Menu */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleMoreMenu}
              className="flex items-center space-x-2"
            >
              <Icon name="MoreHorizontal" size={16} />
              <span>More</span>
            </Button>

            {isMoreMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setIsMoreMenuOpen(false)}
                />
                <div className="absolute right-0 top-full mt-2 w-48 glass-effect border border-border rounded-md shadow-elevation-2 z-20">
                  {secondaryNavItems.map((item) => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setIsMoreMenuOpen(false)}
                      className={`flex items-center space-x-2 px-3 py-2 text-sm transition-colors duration-150 first:rounded-t-md last:rounded-b-md ${
                        isActivePath(item.path)
                          ? 'gradient-gold text-black' :'text-popover-foreground hover:bg-muted'
                      }`}
                    >
                      <Icon name={item.icon} size={16} />
                      <span>{item.label}</span>
                    </Link>
                  ))}
                </div>
              </>
            )}
          </div>
        </nav>

        {/* User Actions */}
        <div className="hidden md:flex items-center space-x-2 ml-auto">
          <Link to="/notifications-center">
            <Button variant="ghost" size="sm">
              <Icon name="Bell" size={16} />
            </Button>
          </Link>
          <Button variant="ghost" size="sm">
            <Icon name="User" size={16} />
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="sm"
          className="md:hidden ml-auto"
          onClick={toggleMobileMenu}
        >
          <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={20} />
        </Button>
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <>
          <div
            className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden"
            onClick={closeMobileMenu}
          />
          <div className="fixed top-16 left-0 right-0 z-50 glass-effect border-b shadow-elevation-2 md:hidden animate-slide-in-from-top">
            <nav className="container py-4 space-y-2">
              {[...primaryNavItems, ...secondaryNavItems].map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={closeMobileMenu}
                  className={`flex items-center space-x-3 px-3 py-3 rounded-md text-sm font-medium transition-colors duration-150 ${
                    isActivePath(item.path)
                      ? 'gradient-gold text-black' :'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}
                >
                  <Icon name={item.icon} size={18} />
                  <span>{item.label}</span>
                </Link>
              ))}
              
              <div className="border-t border-border pt-4 mt-4">
                <div className="flex items-center space-x-2">
                  <Link to="/notifications-center" className="flex-1">
                    <Button variant="ghost" size="sm" className="w-full justify-start">
                      <Icon name="Bell" size={16} />
                      <span className="ml-2">Notifications</span>
                    </Button>
                  </Link>
                  <Button variant="ghost" size="sm" className="flex-1 justify-start">
                    <Icon name="User" size={16} />
                    <span className="ml-2">Profile</span>
                  </Button>
                </div>
              </div>
            </nav>
          </div>
        </>
      )}
    </header>
  );
};

export default Header;
