import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAdminAuth } from '../../contexts/AdminAuthContext';
import Icon from '../AppIcon';
import Button from './Button';
import AdminNotifications from './AdminNotifications';

const AdminNavigation = ({
  title,
  breadcrumb = [],
  showBackButton = true,
  actions = []
}) => {
  const navigate = useNavigate();

  // Use admin auth context
  const { admin, adminLogout } = useAdminAuth();

  const handleLogout = () => {
    adminLogout();
    navigate('/admin-login');
  };

  return (
    <div className="bg-card border-b px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          {/* Back to Dashboard Button */}
          {showBackButton && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate('/admin-dashboard')}
              className="flex items-center space-x-2"
            >
              <Icon name="ArrowLeft" size={16} />
              <span>Dashboard</span>
            </Button>
          )}
          
          <div>
            <div className="flex items-center space-x-2">
              {/* Breadcrumb */}
              {breadcrumb.length > 0 && (
                <nav className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Link to="/admin-dashboard" className="hover:text-foreground transition-colors">
                    Dashboard
                  </Link>
                  {breadcrumb.map((item, index) => (
                    <React.Fragment key={index}>
                      <Icon name="ChevronRight" size={16} />
                      {item.link ? (
                        <Link to={item.link} className="hover:text-foreground transition-colors">
                          {item.label}
                        </Link>
                      ) : (
                        <span className="text-foreground">{item.label}</span>
                      )}
                    </React.Fragment>
                  ))}
                </nav>
              )}
            </div>
            
            {title && (
              <h1 className="text-2xl font-bold text-foreground mt-2">{title}</h1>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {/* Custom Actions */}
          {actions.map((action, index) => (
            <Button
              key={index}
              variant={action.variant || "outline"}
              size={action.size || "sm"}
              onClick={action.onClick}
              className={action.className}
            >
              {action.icon && <Icon name={action.icon} size={16} />}
              {action.label}
            </Button>
          ))}
          
          {/* Notifications */}
          <AdminNotifications />

          {/* Admin Info & Logout */}
          <div className="flex items-center space-x-3 border-l border-border pl-3">
            <div className="text-right">
              <div className="text-sm font-medium text-foreground">{admin?.name || admin?.username || 'Administrator'}</div>
              <div className="text-xs text-muted-foreground">Investment Management</div>
            </div>

            <Button variant="outline" size="sm" onClick={handleLogout}>
              <Icon name="LogOut" size={16} />
              Logout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminNavigation;
