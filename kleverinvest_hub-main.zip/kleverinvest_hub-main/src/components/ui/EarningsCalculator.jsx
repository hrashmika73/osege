import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';
import Button from './Button';
import Input from './Input';

const EarningsCalculator = () => {
  const [investment, setInvestment] = useState(1000);
  const [selectedPlan, setSelectedPlan] = useState('daily');
  const [duration, setDuration] = useState(30);
  const [results, setResults] = useState(null);

  const plans = {
    daily: { roi: 3, name: 'Daily 3%', min: 100, max: 10000, duration: 30 },
    weekly: { roi: 15, name: 'Weekly 15%', min: 1000, max: 50000, duration: 60 },
    monthly: { roi: 50, name: 'Monthly 50%', min: 5000, max: 100000, duration: 90 }
  };

  const calculateEarnings = () => {
    const plan = plans[selectedPlan];
    if (!plan || investment < plan.min || investment > plan.max) return;

    let totalEarnings = 0;
    let currentAmount = investment;
    const periods = selectedPlan === 'daily' ? duration : 
                   selectedPlan === 'weekly' ? Math.floor(duration / 7) :
                   Math.floor(duration / 30);

    const earnings = [];
    
    for (let i = 0; i < periods; i++) {
      const periodEarnings = (investment * plan.roi) / 100;
      totalEarnings += periodEarnings;
      currentAmount += periodEarnings;
      
      earnings.push({
        period: i + 1,
        earnings: periodEarnings,
        total: totalEarnings,
        balance: currentAmount
      });
    }

    setResults({
      totalInvestment: investment,
      totalEarnings,
      finalAmount: investment + totalEarnings,
      roiPercentage: (totalEarnings / investment) * 100,
      dailyEarnings: totalEarnings / duration,
      monthlyEarnings: (totalEarnings / duration) * 30,
      breakdown: earnings.slice(-10) // Show last 10 periods
    });
  };

  useEffect(() => {
    if (investment >= plans[selectedPlan].min && investment <= plans[selectedPlan].max) {
      calculateEarnings();
    }
  }, [investment, selectedPlan, duration]);

  const plan = plans[selectedPlan];
  const isValidAmount = investment >= plan.min && investment <= plan.max;

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Icon name="Calculator" size={24} className="text-primary" />
        <h3 className="text-lg font-semibold text-foreground">Earnings Calculator</h3>
      </div>

      <div className="space-y-6">
        {/* Investment Amount */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Investment Amount (USD)
          </label>
          <Input
            type="number"
            value={investment}
            onChange={(e) => setInvestment(parseFloat(e.target.value) || 0)}
            min={plan.min}
            max={plan.max}
            step="100"
          />
          <div className="text-xs text-muted-foreground mt-1">
            Range: ${plan.min.toLocaleString()} - ${plan.max.toLocaleString()}
          </div>
          {!isValidAmount && investment > 0 && (
            <div className="text-xs text-destructive mt-1">
              Amount must be between ${plan.min.toLocaleString()} and ${plan.max.toLocaleString()}
            </div>
          )}
        </div>

        {/* Plan Selection */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Investment Plan
          </label>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {Object.entries(plans).map(([key, planData]) => (
              <button
                key={key}
                onClick={() => setSelectedPlan(key)}
                className={`p-4 rounded-lg border transition-colors text-left ${
                  selectedPlan === key
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border hover:border-primary/50'
                }`}
              >
                <div className="font-medium">{planData.name}</div>
                <div className="text-sm opacity-75">
                  {planData.roi}% per {key}
                </div>
                <div className="text-xs opacity-60">
                  Min: ${planData.min.toLocaleString()}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Duration */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Duration (Days)
          </label>
          <div className="flex items-center space-x-4">
            <Input
              type="range"
              value={duration}
              onChange={(e) => setDuration(parseInt(e.target.value))}
              min="7"
              max="365"
              className="flex-1"
            />
            <div className="text-sm font-medium text-foreground w-16">
              {duration} days
            </div>
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Recommended: {plan.duration} days
          </div>
        </div>

        {/* Results */}
        {results && isValidAmount && (
          <div className="space-y-4 pt-4 border-t border-border">
            <h4 className="font-medium text-foreground">Projected Earnings</h4>
            
            {/* Summary Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-muted/30 p-3 rounded-lg text-center">
                <div className="text-xs text-muted-foreground">Total Investment</div>
                <div className="font-bold text-foreground">
                  ${results.totalInvestment.toLocaleString()}
                </div>
              </div>
              <div className="bg-success/10 p-3 rounded-lg text-center">
                <div className="text-xs text-muted-foreground">Total Earnings</div>
                <div className="font-bold text-success">
                  ${results.totalEarnings.toLocaleString()}
                </div>
              </div>
              <div className="bg-primary/10 p-3 rounded-lg text-center">
                <div className="text-xs text-muted-foreground">Final Amount</div>
                <div className="font-bold text-primary">
                  ${results.finalAmount.toLocaleString()}
                </div>
              </div>
              <div className="bg-accent/10 p-3 rounded-lg text-center">
                <div className="text-xs text-muted-foreground">ROI</div>
                <div className="font-bold text-accent">
                  {results.roiPercentage.toFixed(1)}%
                </div>
              </div>
            </div>

            {/* Breakdown */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="text-sm font-medium text-foreground mb-2">Daily Breakdown</div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Daily Earnings:</span>
                    <span className="font-medium text-success">
                      ${results.dailyEarnings.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Monthly Earnings:</span>
                    <span className="font-medium text-success">
                      ${results.monthlyEarnings.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <div className="text-sm font-medium text-foreground mb-2">
                  {selectedPlan === 'daily' ? 'Daily' : selectedPlan === 'weekly' ? 'Weekly' : 'Monthly'} Progress
                </div>
                <div className="space-y-1 max-h-32 overflow-y-auto">
                  {results.breakdown.slice(-5).map((period, index) => (
                    <div key={index} className="flex justify-between text-xs">
                      <span className="text-muted-foreground">
                        Period {period.period}:
                      </span>
                      <span className="font-medium text-success">
                        +${period.earnings.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Button */}
            <div className="pt-2">
              <Button 
                className="w-full"
                onClick={() => {
                  // Navigate to investment plans or registration
                  alert(`Ready to invest $${investment.toLocaleString()} in the ${plan.name}?\n\nProjected earnings: $${results.totalEarnings.toLocaleString()}\nFinal amount: $${results.finalAmount.toLocaleString()}\n\nClick OK to proceed to investment plans.`);
                }}
              >
                <Icon name="TrendingUp" size={16} className="mr-2" />
                Start Investing
              </Button>
            </div>
          </div>
        )}

        {/* Disclaimer */}
        <div className="bg-warning/10 p-3 rounded-lg">
          <div className="flex items-start space-x-2">
            <Icon name="AlertTriangle" size={16} className="text-warning mt-0.5" />
            <div className="text-xs text-muted-foreground">
              <strong>Disclaimer:</strong> These calculations are estimates based on the selected plan. 
              Actual returns may vary. Past performance does not guarantee future results. 
              Please invest responsibly.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EarningsCalculator;
