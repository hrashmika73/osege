import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';

const LiveBTCBar = () => {
  const [btcData, setBtcData] = useState({
    price: 43250.50,
    change24h: 2.45,
    changePercent: 5.67,
    volume24h: 28500000000,
    marketCap: 850000000000,
    lastUpdate: new Date()
  });

  const [isConnected, setIsConnected] = useState(true);

  // Simulate live price updates
  useEffect(() => {
    const interval = setInterval(() => {
      setBtcData(prev => {
        const randomChange = (Math.random() - 0.5) * 100; // Random change between -50 and +50
        const newPrice = Math.max(prev.price + randomChange, 35000); // Minimum price floor
        const change24h = newPrice - prev.price + prev.change24h;
        const changePercent = (change24h / prev.price) * 100;
        
        return {
          ...prev,
          price: newPrice,
          change24h: change24h,
          changePercent: changePercent,
          lastUpdate: new Date()
        };
      });
    }, 3000); // Update every 3 seconds

    return () => clearInterval(interval);
  }, []);

  // Simulate connection status
  useEffect(() => {
    const connectionCheck = setInterval(() => {
      setIsConnected(Math.random() > 0.1); // 90% chance of being connected
    }, 10000);

    return () => clearInterval(connectionCheck);
  }, []);

  const formatNumber = (num) => {
    if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
    if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
    return num.toFixed(2);
  };

  const isPositive = btcData.changePercent >= 0;

  return (
    <div className="bg-gradient-to-r from-primary to-primary/80 text-white px-6 py-3 shadow-lg">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        {/* BTC Price Section */}
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center font-bold text-sm">
              ₿
            </div>
            <span className="font-bold text-lg">BTC/USD</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-2xl font-bold">
              ${btcData.price.toLocaleString(undefined, { 
                minimumFractionDigits: 2, 
                maximumFractionDigits: 2 
              })}
            </div>
            
            <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-sm font-medium ${
              isPositive 
                ? 'bg-green-500/20 text-green-100' 
                : 'bg-red-500/20 text-red-100'
            }`}>
              <Icon 
                name={isPositive ? 'TrendingUp' : 'TrendingDown'} 
                size={14} 
              />
              <span>
                {isPositive ? '+' : ''}${btcData.change24h.toFixed(2)} 
                ({isPositive ? '+' : ''}{btcData.changePercent.toFixed(2)}%)
              </span>
            </div>
          </div>
        </div>

        {/* Market Data Section */}
        <div className="hidden lg:flex items-center space-x-8 text-sm">
          <div className="text-center">
            <div className="text-white/70">24h Volume</div>
            <div className="font-semibold">${formatNumber(btcData.volume24h)}</div>
          </div>
          
          <div className="text-center">
            <div className="text-white/70">Market Cap</div>
            <div className="font-semibold">${formatNumber(btcData.marketCap)}</div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${
              isConnected ? 'bg-green-400' : 'bg-red-400'
            }`}></div>
            <span className="text-white/70 text-xs">
              {isConnected ? 'Live' : 'Disconnected'}
            </span>
          </div>
          
          <div className="text-xs text-white/60">
            Last update: {btcData.lastUpdate.toLocaleTimeString()}
          </div>
        </div>

        {/* Mobile Menu */}
        <div className="lg:hidden">
          <button className="text-white hover:text-white/80">
            <Icon name="Menu" size={24} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default LiveBTCBar;
