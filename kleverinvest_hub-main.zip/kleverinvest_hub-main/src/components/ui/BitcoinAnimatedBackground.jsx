import React, { useEffect, useRef } from 'react';

const BitcoinAnimatedBackground = () => {
  const canvasRef = useRef(null);
  const animationRef = useRef(null);
  const particlesRef = useRef([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    
    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Particle class
    class Particle {
      constructor() {
        this.reset();
        this.y = Math.random() * canvas.height;
        this.vx = Math.random() * 0.5 - 0.25;
      }

      reset() {
        this.x = Math.random() * canvas.width;
        this.y = -10;
        this.size = Math.random() * 3 + 1;
        this.vy = Math.random() * 2 + 0.5;
        this.opacity = Math.random() * 0.8 + 0.2;
        this.color = this.getRandomColor();
        this.type = Math.random() > 0.7 ? 'bitcoin' : 'particle';
        this.rotation = 0;
        this.rotationSpeed = (Math.random() - 0.5) * 0.02;
      }

      getRandomColor() {
        const colors = [
          'rgba(255, 193, 7, ', // Bitcoin gold
          'rgba(255, 165, 0, ', // Orange
          'rgba(255, 215, 0, ', // Gold
          'rgba(255, 255, 255, ', // White
          'rgba(59, 130, 246, ', // Blue
          'rgba(16, 185, 129, ' // Emerald
        ];
        return colors[Math.floor(Math.random() * colors.length)];
      }

      update() {
        this.x += this.vx;
        this.y += this.vy;
        this.rotation += this.rotationSpeed;

        // Add floating effect
        this.x += Math.sin(this.y * 0.01) * 0.2;

        // Reset particle when it goes off screen
        if (this.y > canvas.height + 10 || this.x < -10 || this.x > canvas.width + 10) {
          this.reset();
        }

        // Fade effect based on position
        const fadeZone = canvas.height * 0.8;
        if (this.y > fadeZone) {
          this.opacity = Math.max(0, 1 - (this.y - fadeZone) / (canvas.height * 0.2));
        }
      }

      draw(ctx) {
        ctx.save();
        ctx.globalAlpha = this.opacity;
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);

        if (this.type === 'bitcoin') {
          this.drawBitcoin(ctx);
        } else {
          this.drawParticle(ctx);
        }

        ctx.restore();
      }

      drawBitcoin(ctx) {
        const size = this.size * 3;
        
        // Bitcoin symbol
        ctx.fillStyle = this.color + this.opacity + ')';
        ctx.strokeStyle = this.color + this.opacity + ')';
        ctx.lineWidth = 1;

        // Draw Bitcoin B
        ctx.beginPath();
        ctx.arc(0, 0, size, 0, Math.PI * 2);
        ctx.fillStyle = this.color + (this.opacity * 0.3) + ')';
        ctx.fill();

        // Draw Bitcoin symbol
        ctx.fillStyle = this.color + this.opacity + ')';
        ctx.font = `${size * 1.2}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('₿', 0, 0);
      }

      drawParticle(ctx) {
        ctx.fillStyle = this.color + this.opacity + ')';
        
        // Create different particle shapes
        const shapes = ['circle', 'square', 'diamond'];
        const shape = shapes[Math.floor(this.rotation * 100) % shapes.length];

        switch (shape) {
          case 'circle':
            ctx.beginPath();
            ctx.arc(0, 0, this.size, 0, Math.PI * 2);
            ctx.fill();
            break;
          
          case 'square':
            ctx.fillRect(-this.size/2, -this.size/2, this.size, this.size);
            break;
          
          case 'diamond':
            ctx.beginPath();
            ctx.moveTo(0, -this.size);
            ctx.lineTo(this.size, 0);
            ctx.lineTo(0, this.size);
            ctx.lineTo(-this.size, 0);
            ctx.closePath();
            ctx.fill();
            break;
        }

        // Add glow effect
        ctx.shadowColor = this.color + '0.5)';
        ctx.shadowBlur = this.size * 2;
      }
    }

    // Initialize particles
    const particleCount = Math.floor((canvas.width * canvas.height) / 15000);
    particlesRef.current = [];
    
    for (let i = 0; i < particleCount; i++) {
      particlesRef.current.push(new Particle());
    }

    // Animation loop
    const animate = () => {
      // Clear canvas with gradient background
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      gradient.addColorStop(0, 'rgba(15, 23, 42, 0.95)'); // Dark blue top
      gradient.addColorStop(0.5, 'rgba(30, 41, 59, 0.90)'); // Medium blue middle
      gradient.addColorStop(1, 'rgba(51, 65, 85, 0.85)'); // Lighter blue bottom
      
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Add subtle grid pattern
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.1)';
      ctx.lineWidth = 1;
      const gridSize = 50;
      
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // Update and draw particles
      particlesRef.current.forEach(particle => {
        particle.update();
        particle.draw(ctx);
      });

      // Add connection lines between nearby particles
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.2)';
      ctx.lineWidth = 1;
      
      for (let i = 0; i < particlesRef.current.length; i++) {
        for (let j = i + 1; j < particlesRef.current.length; j++) {
          const dx = particlesRef.current[i].x - particlesRef.current[j].x;
          const dy = particlesRef.current[i].y - particlesRef.current[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < 150) {
            const opacity = (150 - distance) / 150 * 0.5;
            ctx.globalAlpha = opacity;
            ctx.beginPath();
            ctx.moveTo(particlesRef.current[i].x, particlesRef.current[i].y);
            ctx.lineTo(particlesRef.current[j].x, particlesRef.current[j].y);
            ctx.stroke();
            ctx.globalAlpha = 1;
          }
        }
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    // Cleanup
    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 -z-10 w-full h-full"
      style={{
        background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)',
        pointerEvents: 'none'
      }}
    />
  );
};

export default BitcoinAnimatedBackground;
