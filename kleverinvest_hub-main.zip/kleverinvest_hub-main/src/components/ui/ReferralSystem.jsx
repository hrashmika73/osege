import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import Icon from '../AppIcon';
import Button from './Button';
import Input from './Input';

const ReferralSystem = () => {
  const { user } = useAuth();
  const [referralStats, setReferralStats] = useState({
    totalReferrals: 12,
    activeReferrals: 8,
    totalEarnings: 247.50,
    monthlyEarnings: 52.30,
    pendingCommission: 15.75,
    conversionRate: 66.7
  });

  const [referralHistory, setReferralHistory] = useState([
    { id: 1, name: 'John D.', email: 'john.d***@gmail.com', joinDate: '2024-01-15', status: 'active', invested: 5000, commission: 25.50 },
    { id: 2, name: 'Sarah M.', email: 'sarah.m***@outlook.com', joinDate: '2024-01-12', status: 'active', invested: 2500, commission: 12.75 },
    { id: 3, name: 'Mike R.', email: 'mike.r***@yahoo.com', joinDate: '2024-01-10', status: 'pending', invested: 0, commission: 0 },
    { id: 4, name: 'Emma L.', email: 'emma.l***@gmail.com', joinDate: '2024-01-08', status: 'active', invested: 8000, commission: 40.25 }
  ]);

  const [commissionTiers, setCommissionTiers] = useState([
    { level: 1, referrals: '1-10', commission: '10%', bonus: '0%' },
    { level: 2, referrals: '11-25', commission: '12%', bonus: '2%' },
    { level: 3, referrals: '26-50', commission: '15%', bonus: '5%' },
    { level: 4, referrals: '51+', commission: '20%', bonus: '10%' }
  ]);

  const referralCode = user?.referralCode || 'REF' + (user?.id?.toString().padStart(6, '0') || '000001');
  const referralLink = `https://kleverinvest.com/register?ref=${referralCode}`;

  const [activeTab, setActiveTab] = useState('overview');

  // Copy referral link
  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink);
    alert('Referral link copied to clipboard!');
  };

  // Share referral link
  const shareReferralLink = (platform) => {
    const text = "Join KleverInvest and start earning with cryptocurrency investments!";
    const urls = {
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`,
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(referralLink)}`,
      telegram: `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(text)}`,
      whatsapp: `https://wa.me/?text=${encodeURIComponent(text + ' ' + referralLink)}`,
      email: `mailto:?subject=${encodeURIComponent('Join KleverInvest')}&body=${encodeURIComponent(text + '\\n\\n' + referralLink)}`
    };

    if (urls[platform]) {
      window.open(urls[platform], '_blank');
    }
  };

  // Request payout
  const requestPayout = () => {
    if (referralStats.pendingCommission < 10) {
      alert('Minimum payout amount is $10. You need $' + (10 - referralStats.pendingCommission).toFixed(2) + ' more.');
      return;
    }
    
    const proceed = confirm(`Request payout of $${referralStats.pendingCommission.toFixed(2)}?\\n\\nFunds will be sent to your registered wallet within 24-48 hours.`);
    if (proceed) {
      alert('Payout request submitted successfully!\\n\\nYou will receive confirmation via email.');
      setReferralStats(prev => ({ ...prev, pendingCommission: 0 }));
    }
  };

  const getCurrentTier = () => {
    const total = referralStats.totalReferrals;
    if (total >= 51) return commissionTiers[3];
    if (total >= 26) return commissionTiers[2];
    if (total >= 11) return commissionTiers[1];
    return commissionTiers[0];
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-primary to-accent rounded-lg p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <Icon name="Users" size={24} />
            <span className="text-xs opacity-75">Total Referrals</span>
          </div>
          <div className="text-2xl font-bold">{referralStats.totalReferrals}</div>
          <div className="text-xs opacity-75">{referralStats.activeReferrals} active</div>
        </div>

        <div className="bg-card border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <Icon name="DollarSign" size={24} className="text-success" />
            <span className="text-xs text-muted-foreground">Total Earnings</span>
          </div>
          <div className="text-2xl font-bold text-foreground">${referralStats.totalEarnings}</div>
          <div className="text-xs text-success">+${referralStats.monthlyEarnings} this month</div>
        </div>

        <div className="bg-card border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <Icon name="Clock" size={24} className="text-warning" />
            <span className="text-xs text-muted-foreground">Pending</span>
          </div>
          <div className="text-2xl font-bold text-foreground">${referralStats.pendingCommission}</div>
          <div className="text-xs text-muted-foreground">Available for payout</div>
        </div>
      </div>

      {/* Referral Link */}
      <div className="bg-card border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Your Referral Link</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Referral Code</label>
            <div className="flex space-x-2">
              <Input value={referralCode} readOnly className="flex-1" />
              <Button variant="outline" onClick={copyReferralLink}>
                <Icon name="Copy" size={16} />
              </Button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Referral Link</label>
            <div className="flex space-x-2">
              <Input value={referralLink} readOnly className="flex-1 text-xs" />
              <Button variant="outline" onClick={copyReferralLink}>
                <Icon name="Share" size={16} />
              </Button>
            </div>
          </div>

          {/* Share Buttons */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Share on Social Media</label>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" onClick={() => shareReferralLink('facebook')}>
                <Icon name="Facebook" size={16} className="mr-2" />
                Facebook
              </Button>
              <Button variant="outline" size="sm" onClick={() => shareReferralLink('twitter')}>
                <Icon name="Twitter" size={16} className="mr-2" />
                Twitter
              </Button>
              <Button variant="outline" size="sm" onClick={() => shareReferralLink('telegram')}>
                <Icon name="Send" size={16} className="mr-2" />
                Telegram
              </Button>
              <Button variant="outline" size="sm" onClick={() => shareReferralLink('whatsapp')}>
                <Icon name="MessageCircle" size={16} className="mr-2" />
                WhatsApp
              </Button>
              <Button variant="outline" size="sm" onClick={() => shareReferralLink('email')}>
                <Icon name="Mail" size={16} className="mr-2" />
                Email
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Commission Tier */}
      <div className="bg-card border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Commission Tier</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Current Tier: Level {getCurrentTier().level}</span>
                <span className="text-lg font-bold text-primary">{getCurrentTier().commission}</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min((referralStats.totalReferrals / 10) * 100, 100)}%` }}
                ></div>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {referralStats.totalReferrals}/10 referrals to next tier
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Commission Rate:</span>
                <span className="font-medium text-success">{getCurrentTier().commission}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Bonus Rate:</span>
                <span className="font-medium text-accent">{getCurrentTier().bonus}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Conversion Rate:</span>
                <span className="font-medium text-foreground">{referralStats.conversionRate}%</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-medium text-foreground mb-3">All Tiers</h4>
            <div className="space-y-2">
              {commissionTiers.map(tier => (
                <div 
                  key={tier.level}
                  className={`p-2 rounded border text-xs ${
                    tier.level === getCurrentTier().level 
                      ? 'border-primary bg-primary/10' 
                      : 'border-border'
                  }`}
                >
                  <div className="flex justify-between">
                    <span>Level {tier.level} ({tier.referrals})</span>
                    <span className="font-medium">{tier.commission}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderHistory = () => (
    <div className="bg-card border rounded-lg overflow-hidden">
      <div className="p-6 border-b border-border">
        <h3 className="text-lg font-semibold text-foreground">Referral History</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted border-b border-border">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase">User</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Join Date</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Invested</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Commission</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {referralHistory.map(ref => (
              <tr key={ref.id} className="hover:bg-muted/50">
                <td className="px-6 py-4">
                  <div>
                    <div className="font-medium text-foreground">{ref.name}</div>
                    <div className="text-sm text-muted-foreground">{ref.email}</div>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-muted-foreground">
                  {new Date(ref.joinDate).toLocaleDateString()}
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    ref.status === 'active' 
                      ? 'bg-success/10 text-success' 
                      : 'bg-warning/10 text-warning'
                  }`}>
                    {ref.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-foreground">
                  ${ref.invested.toLocaleString()}
                </td>
                <td className="px-6 py-4 text-sm font-medium text-success">
                  ${ref.commission.toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'BarChart3' },
    { id: 'history', label: 'History', icon: 'Clock' },
    { id: 'earnings', label: 'Earnings', icon: 'DollarSign' }
  ];

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Icon name="Users" size={24} className="text-primary" />
          <h2 className="text-xl font-semibold text-foreground">Referral Program</h2>
        </div>
        <Button 
          onClick={requestPayout}
          disabled={referralStats.pendingCommission < 10}
          className="bg-success hover:bg-success/90"
        >
          <Icon name="Download" size={16} className="mr-2" />
          Request Payout
        </Button>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="border-b border-border">
          <nav className="-mb-px flex space-x-8">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                  activeTab === tab.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                }`}
              >
                <Icon name={tab.icon} size={16} />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && renderOverview()}
      {activeTab === 'history' && renderHistory()}
      {activeTab === 'earnings' && (
        <div className="text-center py-12">
          <Icon name="DollarSign" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">Earnings Analytics</h3>
          <p className="text-muted-foreground">Detailed earnings breakdown coming soon</p>
        </div>
      )}

      {/* How it Works */}
      <div className="mt-8 bg-muted/30 p-6 rounded-lg">
        <h4 className="font-medium text-foreground mb-3">How the Referral Program Works</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div className="text-center">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-white font-bold text-xs">1</span>
            </div>
            <div className="font-medium text-foreground">Share Your Link</div>
            <div className="text-muted-foreground">Share your unique referral link with friends</div>
          </div>
          <div className="text-center">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-white font-bold text-xs">2</span>
            </div>
            <div className="font-medium text-foreground">They Sign Up</div>
            <div className="text-muted-foreground">Your referrals create an account and invest</div>
          </div>
          <div className="text-center">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-white font-bold text-xs">3</span>
            </div>
            <div className="font-medium text-foreground">Earn Commission</div>
            <div className="text-muted-foreground">Get 10-20% of their profits for life</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReferralSystem;
