import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';

const BTCPriceChart = ({ height = 300, showControls = true }) => {
  const [currentPrice, setCurrentPrice] = useState(45000);
  const [priceHistory, setPriceHistory] = useState([]);
  const [timeframe, setTimeframe] = useState('24h');
  const [isLive, setIsLive] = useState(true);

  // Generate initial price history
  useEffect(() => {
    const generateHistory = () => {
      const points = timeframe === '1h' ? 60 : timeframe === '24h' ? 24 : 30;
      const interval = timeframe === '1h' ? 1 : timeframe === '24h' ? 60 : 1440; // minutes
      
      const history = [];
      let price = 45000;
      
      for (let i = 0; i < points; i++) {
        const change = (Math.random() - 0.5) * 2000;
        price = Math.max(40000, Math.min(50000, price + change));
        
        const time = new Date();
        time.setMinutes(time.getMinutes() - (points - i) * interval);
        
        history.push({
          time: time.toISOString(),
          price: price,
          volume: Math.random() * 1000000000
        });
      }
      
      return history;
    };

    setPriceHistory(generateHistory());
  }, [timeframe]);

  // Real-time price updates
  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(() => {
      const change = (Math.random() - 0.5) * 500;
      const newPrice = Math.max(40000, Math.min(50000, currentPrice + change));
      
      setCurrentPrice(newPrice);
      
      setPriceHistory(prev => {
        const newHistory = [...prev];
        newHistory.push({
          time: new Date().toISOString(),
          price: newPrice,
          volume: Math.random() * 1000000000
        });
        
        // Keep only recent data
        const maxPoints = timeframe === '1h' ? 60 : timeframe === '24h' ? 24 : 30;
        if (newHistory.length > maxPoints) {
          newHistory.shift();
        }
        
        return newHistory;
      });
    }, timeframe === '1h' ? 60000 : 300000); // 1min for 1h, 5min for others

    return () => clearInterval(interval);
  }, [currentPrice, isLive, timeframe]);

  // Calculate price change
  const priceChange = priceHistory.length > 1 
    ? currentPrice - priceHistory[0].price 
    : 0;
  const percentChange = priceHistory.length > 1 
    ? (priceChange / priceHistory[0].price) * 100 
    : 0;

  // SVG Chart rendering
  const renderChart = () => {
    if (priceHistory.length < 2) return null;

    const padding = 20;
    const chartWidth = 800 - padding * 2;
    const chartHeight = height - padding * 2;
    
    const minPrice = Math.min(...priceHistory.map(p => p.price));
    const maxPrice = Math.max(...priceHistory.map(p => p.price));
    const priceRange = maxPrice - minPrice;
    
    // Create path for price line
    const pathData = priceHistory.map((point, index) => {
      const x = padding + (index / (priceHistory.length - 1)) * chartWidth;
      const y = padding + chartHeight - ((point.price - minPrice) / priceRange) * chartHeight;
      return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
    }).join(' ');

    // Create gradient area
    const areaData = `${pathData} L ${padding + chartWidth} ${padding + chartHeight} L ${padding} ${padding + chartHeight} Z`;

    return (
      <svg width="100%" height={height} viewBox="0 0 800 300" className="overflow-visible">
        <defs>
          <linearGradient id="priceGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={percentChange >= 0 ? "#10b981" : "#ef4444"} stopOpacity="0.3"/>
            <stop offset="100%" stopColor={percentChange >= 0 ? "#10b981" : "#ef4444"} stopOpacity="0.1"/>
          </linearGradient>
        </defs>
        
        {/* Grid lines */}
        {[...Array(5)].map((_, i) => (
          <line
            key={i}
            x1={padding}
            y1={padding + (i * chartHeight / 4)}
            x2={padding + chartWidth}
            y2={padding + (i * chartHeight / 4)}
            stroke="currentColor"
            strokeOpacity="0.1"
            strokeDasharray="2,2"
          />
        ))}
        
        {/* Price area */}
        <path
          d={areaData}
          fill="url(#priceGradient)"
        />
        
        {/* Price line */}
        <path
          d={pathData}
          fill="none"
          stroke={percentChange >= 0 ? "#10b981" : "#ef4444"}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        
        {/* Price points */}
        {priceHistory.map((point, index) => {
          if (index % Math.ceil(priceHistory.length / 10) !== 0 && index !== priceHistory.length - 1) return null;
          
          const x = padding + (index / (priceHistory.length - 1)) * chartWidth;
          const y = padding + chartHeight - ((point.price - minPrice) / priceRange) * chartHeight;
          
          return (
            <circle
              key={index}
              cx={x}
              cy={y}
              r="3"
              fill={percentChange >= 0 ? "#10b981" : "#ef4444"}
              stroke="white"
              strokeWidth="1"
            />
          );
        })}
      </svg>
    );
  };

  return (
    <div className="bg-card border rounded-lg p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Icon name="Bitcoin" size={24} className="text-orange-500" />
            <div>
              <h3 className="text-lg font-semibold text-foreground">Bitcoin Price</h3>
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-bold text-foreground">
                  ${currentPrice.toLocaleString()}
                </span>
                <span className={`text-sm font-medium ${
                  percentChange >= 0 ? 'text-success' : 'text-destructive'
                }`}>
                  {percentChange >= 0 ? '+' : ''}{percentChange.toFixed(2)}%
                </span>
              </div>
            </div>
          </div>
          {isLive && (
            <div className="flex items-center space-x-1 text-xs text-success">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
              <span>Live</span>
            </div>
          )}
        </div>

        {showControls && (
          <div className="flex items-center space-x-2">
            {/* Timeframe selector */}
            <div className="flex bg-muted rounded-lg p-1">
              {['1h', '24h', '30d'].map(tf => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-3 py-1 text-xs font-medium rounded ${
                    timeframe === tf 
                      ? 'bg-background text-foreground shadow-sm' 
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>

            {/* Live toggle */}
            <button
              onClick={() => setIsLive(!isLive)}
              className={`p-2 rounded-lg transition-colors ${
                isLive 
                  ? 'bg-success/10 text-success hover:bg-success/20' 
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              <Icon name={isLive ? "Pause" : "Play"} size={16} />
            </button>
          </div>
        )}
      </div>

      {/* Chart */}
      <div className="relative">
        {renderChart()}
        
        {/* Loading state */}
        {priceHistory.length < 2 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <Icon name="Loader2" size={32} className="text-muted-foreground animate-spin mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">Loading price data...</p>
            </div>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-border">
        <div className="text-center">
          <div className="text-xs text-muted-foreground">24h High</div>
          <div className="font-medium text-foreground">
            ${Math.max(...priceHistory.map(p => p.price)).toLocaleString()}
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs text-muted-foreground">24h Low</div>
          <div className="font-medium text-foreground">
            ${Math.min(...priceHistory.map(p => p.price)).toLocaleString()}
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs text-muted-foreground">24h Volume</div>
          <div className="font-medium text-foreground">
            ${(Math.random() * 50000000000).toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs text-muted-foreground">Market Cap</div>
          <div className="font-medium text-foreground">
            ${(currentPrice * 19700000).toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BTCPriceChart;
