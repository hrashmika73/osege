import React, { useState, useEffect } from 'react';
import { useAdminAuth } from '../contexts/AdminAuthContext';
import Icon from './AppIcon';

const AdminSecurityMonitor = () => {
  const { admin, sessionInfo, securityLevel, isHighSecurity } = useAdminAuth();
  const [securityAlerts, setSecurityAlerts] = useState([]);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    if (!admin || !sessionInfo) return;

    const checkSecurityStatus = () => {
      const alerts = [];
      const now = new Date();
      const loginTime = new Date(sessionInfo.loginTime);
      const sessionDuration = now - loginTime;

      // Session duration warning
      if (sessionDuration > 6 * 60 * 60 * 1000) { // 6 hours
        alerts.push({
          id: 'session_duration',
          type: 'warning',
          message: 'Long session detected. Consider refreshing your session.',
          icon: 'Clock'
        });
      }

      // Security level check
      if (securityLevel === 'low') {
        alerts.push({
          id: 'low_security',
          type: 'error',
          message: 'Low security device detected. Enable additional security measures.',
          icon: 'AlertTriangle'
        });
      }

      // Biometric check
      if (!sessionInfo.loginMethod?.includes('biometric') && securityLevel === 'high') {
        alerts.push({
          id: 'biometric_available',
          type: 'info',
          message: 'Biometric authentication is available for enhanced security.',
          icon: 'Fingerprint'
        });
      }

      // Session expiry warning
      if (sessionInfo.expiresAt) {
        const expiryTime = new Date(sessionInfo.expiresAt);
        const timeToExpiry = expiryTime - now;
        
        if (timeToExpiry < 30 * 60 * 1000 && timeToExpiry > 0) { // 30 minutes
          alerts.push({
            id: 'session_expiry',
            type: 'warning',
            message: `Session expires in ${Math.ceil(timeToExpiry / 1000 / 60)} minutes.`,
            icon: 'AlertCircle'
          });
        }
      }

      setSecurityAlerts(alerts);
    };

    // Check immediately and then every minute
    checkSecurityStatus();
    const interval = setInterval(checkSecurityStatus, 60000);

    return () => clearInterval(interval);
  }, [admin, sessionInfo, securityLevel]);

  if (!admin || !sessionInfo) return null;

  const getSecurityLevelColor = (level) => {
    switch (level) {
      case 'high': return 'text-green-500';
      case 'medium': return 'text-yellow-500';
      case 'low': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const getAlertColor = (type) => {
    switch (type) {
      case 'error': return 'bg-red-500/10 border-red-500/30 text-red-300';
      case 'warning': return 'bg-yellow-500/10 border-yellow-500/30 text-yellow-300';
      case 'info': return 'bg-blue-500/10 border-blue-500/30 text-blue-300';
      default: return 'bg-gray-500/10 border-gray-500/30 text-gray-300';
    }
  };

  return (
    <div className="fixed top-4 right-4 z-50">
      {/* Security Status Indicator */}
      <div 
        className={`
          bg-black/80 backdrop-blur-sm rounded-lg border p-3 cursor-pointer transition-all duration-300
          ${isHighSecurity ? 'border-green-500/30' : 'border-yellow-500/30'}
          ${isExpanded ? 'w-80' : 'w-auto'}
        `}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${isHighSecurity ? 'bg-green-500' : 'bg-yellow-500'} animate-pulse`} />
          <Icon 
            name="Shield" 
            size={16} 
            className={getSecurityLevelColor(securityLevel)} 
          />
          <span className="text-white text-sm font-medium">
            {isExpanded ? 'Security Monitor' : securityLevel?.toUpperCase()}
          </span>
          {securityAlerts.length > 0 && (
            <div className="w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xs">{securityAlerts.length}</span>
            </div>
          )}
          <Icon 
            name={isExpanded ? "ChevronUp" : "ChevronDown"} 
            size={14} 
            className="text-gray-400" 
          />
        </div>

        {isExpanded && (
          <div className="mt-4 space-y-3">
            {/* Session Info */}
            <div className="space-y-2">
              <div className="text-xs text-gray-400 font-semibold">SESSION INFO</div>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-300">Device ID:</span>
                  <span className="text-white font-mono">
                    {sessionInfo.deviceId?.substring(0, 8)}...
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Security Level:</span>
                  <span className={getSecurityLevelColor(securityLevel)}>
                    {securityLevel?.toUpperCase()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Login Method:</span>
                  <span className="text-white">
                    {sessionInfo.loginMethod === 'biometric' ? '🔐 Biometric' : '🔑 Password'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Session Duration:</span>
                  <span className="text-white">
                    {Math.ceil((new Date() - new Date(sessionInfo.loginTime)) / 1000 / 60)}m
                  </span>
                </div>
              </div>
            </div>

            {/* Security Alerts */}
            {securityAlerts.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs text-gray-400 font-semibold">SECURITY ALERTS</div>
                <div className="space-y-2">
                  {securityAlerts.map((alert) => (
                    <div 
                      key={alert.id}
                      className={`p-2 rounded border text-xs ${getAlertColor(alert.type)}`}
                    >
                      <div className="flex items-start space-x-2">
                        <Icon name={alert.icon} size={12} className="mt-0.5 flex-shrink-0" />
                        <span>{alert.message}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Security Features */}
            <div className="space-y-2">
              <div className="text-xs text-gray-400 font-semibold">ACTIVE SECURITY</div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex items-center space-x-1">
                  <Icon name="Lock" size={10} className="text-green-400" />
                  <span className="text-gray-300">JWT Token</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Eye" size={10} className="text-green-400" />
                  <span className="text-gray-300">Monitoring</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Fingerprint" size={10} className="text-green-400" />
                  <span className="text-gray-300">Device ID</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Activity" size={10} className="text-green-400" />
                  <span className="text-gray-300">Rate Limit</span>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="pt-2 border-t border-gray-600">
              <div className="flex space-x-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    // Trigger session refresh
                    window.location.reload();
                  }}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-xs py-1 px-2 rounded transition-colors"
                >
                  Refresh Session
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    // Clear alerts
                    setSecurityAlerts([]);
                  }}
                  className="flex-1 bg-gray-600 hover:bg-gray-700 text-white text-xs py-1 px-2 rounded transition-colors"
                >
                  Clear Alerts
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminSecurityMonitor;
