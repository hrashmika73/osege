import React, { useState } from 'react';
import Icon from './AppIcon';
import Button from './ui/Button';
import AdminRouteProtectionTest from './AdminRouteProtectionTest';

const AdminLoginInfo = () => {
  const [showCredentials, setShowCredentials] = useState(false);

  const adminCredentials = [
    {
      name: "System Administrator",
      email: "admin@kleverinvest.com",
      username: "admin",
      password: "Admin@123!",
      role: "Administrator",
      permissions: "Full Access",
      description: "Primary admin account with complete system access"
    },
    {
      name: "Super Administrator", 
      email: "superadmin@kleverinvest.com",
      username: "superadmin",
      password: "SuperAdmin@456!",
      role: "Super Administrator",
      permissions: "Full Access + System Control",
      description: "Enhanced admin account with system control privileges"
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-red-600 to-red-800 rounded-lg p-6 text-white">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
            <Icon name="Shield" size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Admin Login Information</h1>
            <p className="text-red-200">Secure administrative access credentials</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div className="bg-white/10 rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Icon name="Key" size={14} />
              <span className="font-semibold">Authentication</span>
            </div>
            <p className="text-red-200">Multi-factor with biometric support</p>
          </div>
          <div className="bg-white/10 rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Icon name="Clock" size={14} />
              <span className="font-semibold">Session</span>
            </div>
            <p className="text-red-200">8-hour secure JWT tokens</p>
          </div>
          <div className="bg-white/10 rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Icon name="Activity" size={14} />
              <span className="font-semibold">Monitoring</span>
            </div>
            <p className="text-red-200">Real-time security tracking</p>
          </div>
        </div>
      </div>

      {/* Login Access */}
      <div className="bg-card border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Admin Access Portal</h2>
            <p className="text-muted-foreground">Click below to access the secure admin login page</p>
          </div>
          <Button
            onClick={() => window.location.href = '/admin-secure-login'}
            className="bg-red-600 hover:bg-red-700 text-white"
            size="lg"
          >
            <Icon name="ArrowRight" size={16} className="mr-2" />
            Go to Admin Login
          </Button>
        </div>
        
        <div className="bg-muted/50 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Info" size={16} className="text-blue-500" />
            <span className="font-medium text-foreground">Security Features</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm text-muted-foreground">
            <div>✓ Device fingerprinting</div>
            <div>✓ Rate limiting protection</div>
            <div>✓ Biometric authentication</div>
            <div>✓ Progressive lockout</div>
            <div>✓ IP monitoring</div>
            <div>✓ Session security</div>
            <div>✓ Security headers</div>
            <div>✓ Real-time alerts</div>
          </div>
        </div>
      </div>

      {/* Admin Credentials */}
      <div className="bg-card border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Admin Credentials</h2>
            <p className="text-muted-foreground">Available administrator accounts for system access</p>
          </div>
          <Button
            onClick={() => setShowCredentials(!showCredentials)}
            variant="outline"
            size="sm"
          >
            <Icon name={showCredentials ? "EyeOff" : "Eye"} size={16} className="mr-2" />
            {showCredentials ? "Hide" : "Show"} Credentials
          </Button>
        </div>

        {showCredentials && (
          <div className="space-y-4">
            {adminCredentials.map((admin, index) => (
              <div key={index} className="bg-background border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-foreground">{admin.name}</h3>
                    <p className="text-sm text-muted-foreground">{admin.description}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">
                      {admin.role}
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div>
                      <label className="text-xs font-medium text-muted-foreground">Email</label>
                      <div className="bg-muted/30 rounded p-2 font-mono text-sm text-foreground">
                        {admin.email}
                      </div>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-muted-foreground">Username</label>
                      <div className="bg-muted/30 rounded p-2 font-mono text-sm text-foreground">
                        {admin.username}
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <label className="text-xs font-medium text-muted-foreground">Password</label>
                      <div className="bg-red-50 border border-red-200 rounded p-2 font-mono text-sm text-red-700">
                        {admin.password}
                      </div>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-muted-foreground">Permissions</label>
                      <div className="bg-green-50 border border-green-200 rounded p-2 text-sm text-green-700">
                        {admin.permissions}
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-3 pt-3 border-t">
                  <Button
                    onClick={() => window.location.href = '/admin-secure-login'}
                    variant="outline"
                    size="sm"
                    className="w-full"
                  >
                    <Icon name="Lock" size={14} className="mr-2" />
                    Go to Secure Login
                  </Button>
                  <p className="text-xs text-muted-foreground mt-2 text-center">
                    ⚠ Manual credential entry required
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {!showCredentials && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="AlertTriangle" size={16} className="text-yellow-600" />
              <span className="font-medium text-yellow-800">Security Notice</span>
            </div>
            <p className="text-sm text-yellow-700">
              Admin credentials are hidden for security. Click "Show Credentials" to view login information.
              These credentials provide full administrative access to the KleverInvest Hub platform.
            </p>
          </div>
        )}
      </div>

      {/* Route Protection Status */}
      <div className="bg-card border rounded-lg p-6">
        <div className="mb-4">
          <h2 className="text-xl font-semibold text-foreground">Route Protection Status</h2>
          <p className="text-muted-foreground">Current admin route accessibility and security status</p>
        </div>
        <AdminRouteProtectionTest />
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Fingerprint" size={16} className="text-purple-500" />
            <h3 className="font-semibold text-foreground">Biometric Test</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-3">
            Test biometric authentication on your device
          </p>
          <Button
            onClick={() => window.location.href = '/biometric-demo'}
            variant="outline"
            size="sm"
            className="w-full"
          >
            Biometric Demo
          </Button>
        </div>

        <div className="bg-card border rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="TestTube" size={16} className="text-blue-500" />
            <h3 className="font-semibold text-foreground">Security Test</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-3">
            Run comprehensive security validation tests
          </p>
          <Button
            onClick={() => window.location.href = '/admin-security-test'}
            variant="outline"
            size="sm"
            className="w-full"
          >
            Security Test Suite
          </Button>
        </div>

        <div className="bg-card border rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="BarChart" size={16} className="text-green-500" />
            <h3 className="font-semibold text-foreground">Dashboard</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-3">
            Access main administrative dashboard
          </p>
          <Button
            onClick={() => window.location.href = '/admin-dashboard'}
            variant="outline"
            size="sm"
            className="w-full"
            disabled
          >
            Login Required
          </Button>
        </div>

        <div className="bg-card border rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Users" size={16} className="text-purple-500" />
            <h3 className="font-semibold text-foreground">User Management</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-3">
            Manage platform users and permissions
          </p>
          <Button
            onClick={() => window.location.href = '/admin-user-management'}
            variant="outline"
            size="sm"
            className="w-full"
            disabled
          >
            Login Required
          </Button>
        </div>
      </div>

      {/* Important Notes */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-2">
          <Icon name="AlertCircle" size={16} className="text-red-600" />
          <span className="font-semibold text-red-800">Important Security Information</span>
        </div>
        <ul className="text-sm text-red-700 space-y-1">
          <li>• Admin credentials provide full system access - use responsibly</li>
          <li>• Sessions expire after 8 hours for security</li>
          <li>• Failed login attempts trigger progressive lockouts</li>
          <li>• All admin activities are monitored and logged</li>
          <li>• Biometric authentication is recommended when available</li>
        </ul>
      </div>
    </div>
  );
};

export default AdminLoginInfo;
