import React, { useState, useEffect } from 'react';
import Icon from './AppIcon';
import Button from './ui/Button';
import { 
  adminUserAPI, 
  adminSystemAPI, 
  adminTransactionAPI,
  testBackendConnection 
} from '../services/adminApiService';

const BackendIntegrationDemo = () => {
  const [activeTab, setActiveTab] = useState('users');
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const tabs = [
    { id: 'users', label: 'Users', icon: 'Users' },
    { id: 'transactions', label: 'Transactions', icon: 'CreditCard' },
    { id: 'system', label: 'System', icon: 'Monitor' },
    { id: 'connection', label: 'Connection', icon: 'Wifi' }
  ];

  const fetchData = async (endpoint) => {
    setLoading(true);
    setError(null);
    
    try {
      let response;
      
      switch (endpoint) {
        case 'users':
          response = await adminUserAPI.getUsers(1, 10);
          break;
        case 'transactions':
          response = await adminTransactionAPI.getTransactions(1, 10);
          break;
        case 'system':
          const [healthResponse, metricsResponse] = await Promise.all([
            adminSystemAPI.getSystemHealth(),
            adminSystemAPI.getMetrics()
          ]);
          response = {
            success: true,
            data: {
              health: healthResponse.data,
              metrics: metricsResponse.data
            },
            mockMode: healthResponse.mockMode
          };
          break;
        case 'connection':
          response = await testBackendConnection();
          break;
        default:
          throw new Error('Unknown endpoint');
      }
      
      setData(prev => ({
        ...prev,
        [endpoint]: response
      }));
      
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData(activeTab);
  }, [activeTab]);

  const renderContent = () => {
    const currentData = data[activeTab];
    
    if (loading) {
      return (
        <div className="flex items-center justify-center py-8">
          <Icon name="Loader2" size={24} className="animate-spin text-muted-foreground" />
          <span className="ml-2 text-muted-foreground">Loading...</span>
        </div>
      );
    }

    if (error) {
      return (
        <div className="py-8 text-center">
          <Icon name="AlertCircle" size={24} className="text-red-500 mx-auto mb-2" />
          <p className="text-red-600 mb-2">Error: {error}</p>
          <Button onClick={() => fetchData(activeTab)} size="sm" variant="outline">
            Retry
          </Button>
        </div>
      );
    }

    if (!currentData) {
      return (
        <div className="py-8 text-center">
          <p className="text-muted-foreground">No data available</p>
        </div>
      );
    }

    switch (activeTab) {
      case 'users':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">User Data</h3>
              <span className={`text-xs px-2 py-1 rounded ${
                currentData.mockMode ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
              }`}>
                {currentData.mockMode ? 'Mock Data' : 'Live Data'}
              </span>
            </div>
            
            {currentData.data?.users?.map((user, index) => (
              <div key={index} className="bg-muted/50 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">{user.fullName}</span>
                  <span className={`text-xs px-2 py-1 rounded ${
                    user.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                  }`}>
                    {user.status}
                  </span>
                </div>
                <div className="text-sm text-muted-foreground space-y-1">
                  <div>Email: {user.email}</div>
                  <div>Balance: ${user.balance?.toLocaleString()}</div>
                  <div>KYC: {user.kycStatus}</div>
                </div>
              </div>
            ))}
          </div>
        );

      case 'transactions':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Transaction Data</h3>
              <span className={`text-xs px-2 py-1 rounded ${
                currentData.mockMode ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
              }`}>
                {currentData.mockMode ? 'Mock Data' : 'Live Data'}
              </span>
            </div>
            
            {currentData.data?.transactions?.map((tx, index) => (
              <div key={index} className="bg-muted/50 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">{tx.id}</span>
                  <span className={`text-xs px-2 py-1 rounded ${
                    tx.status === 'completed' ? 'bg-green-100 text-green-800' : 
                    tx.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {tx.status}
                  </span>
                </div>
                <div className="text-sm text-muted-foreground space-y-1">
                  <div>Type: {tx.type}</div>
                  <div>Amount: ${tx.amount?.toLocaleString()}</div>
                  <div>User ID: {tx.userId}</div>
                </div>
              </div>
            ))}
          </div>
        );

      case 'system':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">System Data</h3>
              <span className={`text-xs px-2 py-1 rounded ${
                currentData.mockMode ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
              }`}>
                {currentData.mockMode ? 'Mock Data' : 'Live Data'}
              </span>
            </div>
            
            {/* System Health */}
            <div className="bg-muted/50 rounded-lg p-3">
              <h4 className="font-medium mb-2">System Health</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>Status: <span className="text-green-600">{currentData.data?.health?.status}</span></div>
                <div>Uptime: {currentData.data?.health?.uptime}</div>
                <div>Version: {currentData.data?.health?.version}</div>
                <div>Database: <span className="text-green-600">{currentData.data?.health?.database?.status}</span></div>
              </div>
            </div>

            {/* System Metrics */}
            <div className="bg-muted/50 rounded-lg p-3">
              <h4 className="font-medium mb-2">System Metrics</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>CPU: {currentData.data?.metrics?.cpu?.toFixed(1)}%</div>
                <div>Memory: {currentData.data?.metrics?.memory?.toFixed(1)}%</div>
                <div>Connections: {currentData.data?.metrics?.activeConnections}</div>
                <div>Requests/min: {currentData.data?.metrics?.requestsPerMinute}</div>
              </div>
            </div>
          </div>
        );

      case 'connection':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Connection Status</h3>
              <Button onClick={() => fetchData('connection')} size="sm" variant="outline">
                Test Again
              </Button>
            </div>
            
            <div className="bg-muted/50 rounded-lg p-4">
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Icon 
                    name={currentData.connected ? 'CheckCircle' : 'XCircle'} 
                    size={16} 
                    className={currentData.connected ? 'text-green-500' : 'text-red-500'} 
                  />
                  <span className="font-medium">{currentData.message}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Connected: {currentData.connected ? 'Yes' : 'No'}</div>
                  <div>Mode: {currentData.mockMode ? 'Mock' : 'Live'}</div>
                  <div>Status: {currentData.status}</div>
                  <div>Backend Enabled: {import.meta.env.VITE_ENABLE_BACKEND === 'true' ? 'Yes' : 'No'}</div>
                </div>

                <div className="text-xs text-muted-foreground">
                  <div>API URL: {import.meta.env.VITE_API_URL || 'http://localhost:3001/api'}</div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="bg-card border rounded-lg p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-foreground mb-2">Backend Integration Demo</h2>
        <p className="text-sm text-muted-foreground">
          Test the connection between admin frontend and backend API
        </p>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 mb-6 bg-muted p-1 rounded-lg">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`
              flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors
              ${activeTab === tab.id 
                ? 'bg-background text-foreground shadow-sm' 
                : 'text-muted-foreground hover:text-foreground'
              }
            `}
          >
            <Icon name={tab.icon} size={16} />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="min-h-[200px]">
        {renderContent()}
      </div>
    </div>
  );
};

export default BackendIntegrationDemo;
