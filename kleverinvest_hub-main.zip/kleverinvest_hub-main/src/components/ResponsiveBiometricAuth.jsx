import React, { useState, useEffect } from 'react';
import Icon from './AppIcon';
import Button from './ui/Button';
import { enhancedBiometricAuth, deviceDetection } from '../utils/crossPlatformBiometric';

const ResponsiveBiometricAuth = ({ 
  userId, 
  userName, 
  onSuccess, 
  onError, 
  onFallback,
  className = '' 
}) => {
  const [deviceInfo, setDeviceInfo] = useState(null);
  const [isAvailable, setIsAvailable] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [step, setStep] = useState('check'); // check, register, authenticate, success, error

  useEffect(() => {
    checkBiometricAvailability();
  }, [userId]);

  const checkBiometricAvailability = async () => {
    try {
      const availability = await enhancedBiometricAuth.isAvailable();
      const deviceType = deviceDetection.getDeviceType();
      const isMobile = deviceDetection.isMobile();
      const hasTouch = deviceDetection.hasTouch();

      setDeviceInfo({
        type: deviceType,
        isMobile,
        hasTouch,
        capabilities: availability.capabilities || {}
      });

      if (availability && availability.available) {
        setIsAvailable(true);
        setIsRegistered(enhancedBiometricAuth.isRegistered(userId));
        setStep(enhancedBiometricAuth.isRegistered(userId) ? 'authenticate' : 'register');
      } else {
        setIsAvailable(false);
        setStep('unavailable');
      }
    } catch (error) {
      console.error('Biometric check failed:', error);
      setError(error.message);
      setStep('error');
    }
  };

  const handleRegister = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const result = await enhancedBiometricAuth.register(userId, userName);
      
      if (result.success) {
        setIsRegistered(true);
        setStep('success');
        setTimeout(() => setStep('authenticate'), 2000);
      } else {
        setError(result.error);
        setStep('error');
      }
    } catch (error) {
      setError(error.message);
      setStep('error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAuthenticate = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const result = await enhancedBiometricAuth.authenticate(userId);
      
      if (result.success && onSuccess) {
        setStep('success');
        onSuccess(result);
      } else {
        setError(result.error);
        if (onError) onError(result);
        setStep('error');
      }
    } catch (error) {
      setError(error.message);
      if (onError) onError({ error: error.message });
      setStep('error');
    } finally {
      setIsLoading(false);
    }
  };

  const getBiometricIcon = () => {
    if (!deviceInfo) return 'Fingerprint';
    
    const { type, isMobile } = deviceInfo;
    
    if (type === 'iOS') return 'Scan';
    if (type === 'Android') return 'Fingerprint';
    if (type === 'Windows') return 'User';
    if (type === 'macOS') return 'Scan';
    if (isMobile) return 'Smartphone';
    return 'Fingerprint';
  };

  const getBiometricDescription = () => {
    if (!deviceInfo) return 'Biometric Authentication';
    return enhancedBiometricAuth.getCapabilitiesDescription();
  };

  const getInstructions = () => {
    if (!deviceInfo) return '';
    
    const { type, isMobile } = deviceInfo;
    
    const instructions = {
      'iOS': 'Touch the fingerprint sensor or look at the camera for Face ID',
      'Android': 'Place your finger on the sensor or look at the camera',
      'Windows': 'Use Windows Hello, fingerprint sensor, or camera',
      'macOS': 'Touch the Touch ID sensor or look at the camera',
      'Mobile': 'Use your device\'s biometric authentication',
      'Desktop': 'Use your system\'s biometric authentication'
    };

    return instructions[type] || instructions[isMobile ? 'Mobile' : 'Desktop'];
  };

  if (!deviceInfo) {
    return (
      <div className={`flex items-center justify-center p-4 ${className}`}>
        <Icon name="Loader2" size={24} className="animate-spin text-muted-foreground" />
      </div>
    );
  }

  const containerClass = `
    ${className}
    ${deviceInfo.isMobile ? 'p-4 text-center' : 'p-6'}
    bg-gradient-to-br from-blue-500/10 to-purple-500/10 
    border border-blue-500/20 rounded-lg
  `;

  return (
    <div className={containerClass}>
      {/* Device-responsive header */}
      <div className="text-center mb-6">
        <div className={`
          ${deviceInfo.isMobile ? 'w-16 h-16' : 'w-20 h-20'} 
          bg-gradient-to-br from-blue-500 to-purple-600 
          rounded-full mx-auto mb-4 flex items-center justify-center
          shadow-lg
        `}>
          <Icon 
            name={getBiometricIcon()} 
            size={deviceInfo.isMobile ? 32 : 40} 
            className="text-white" 
          />
        </div>
        
        <h3 className={`
          ${deviceInfo.isMobile ? 'text-lg' : 'text-xl'} 
          font-semibold text-foreground mb-2
        `}>
          {getBiometricDescription()}
        </h3>
        
        <p className={`
          ${deviceInfo.isMobile ? 'text-sm' : 'text-base'} 
          text-muted-foreground
        `}>
          {getInstructions()}
        </p>
      </div>

      {/* Step-based content */}
      {step === 'unavailable' && (
        <div className="text-center">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
            <Icon name="AlertTriangle" size={20} className="text-yellow-600 mx-auto mb-2" />
            <p className="text-sm text-yellow-800">
              Biometric authentication is not available on this {deviceInfo.type} device
            </p>
          </div>
          <Button
            onClick={onFallback}
            variant="outline"
            size={deviceInfo.isMobile ? "sm" : "default"}
            className="w-full"
          >
            Use Password Instead
          </Button>
        </div>
      )}

      {step === 'register' && (
        <div className="text-center space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <Icon name="Info" size={20} className="text-blue-600 mx-auto mb-2" />
            <p className="text-sm text-blue-800">
              Register your biometric for faster future logins
            </p>
          </div>
          
          <div className="space-y-3">
            <Button
              onClick={handleRegister}
              disabled={isLoading}
              loading={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              size={deviceInfo.isMobile ? "default" : "lg"}
            >
              <Icon name="Plus" size={16} className="mr-2" />
              Register {getBiometricDescription()}
            </Button>
            
            <Button
              onClick={onFallback}
              variant="ghost"
              size={deviceInfo.isMobile ? "sm" : "default"}
              className="w-full"
            >
              Skip for Now
            </Button>
          </div>
        </div>
      )}

      {step === 'authenticate' && (
        <div className="text-center space-y-4">
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <Icon name="CheckCircle" size={20} className="text-green-600 mx-auto mb-2" />
            <p className="text-sm text-green-800">
              {getBiometricDescription()} is ready
            </p>
          </div>
          
          <div className="space-y-3">
            <Button
              onClick={handleAuthenticate}
              disabled={isLoading}
              loading={isLoading}
              className="w-full bg-green-600 hover:bg-green-700 text-white"
              size={deviceInfo.isMobile ? "default" : "lg"}
            >
              <Icon name={getBiometricIcon()} size={16} className="mr-2" />
              Authenticate with {getBiometricDescription()}
            </Button>
            
            <Button
              onClick={onFallback}
              variant="outline"
              size={deviceInfo.isMobile ? "sm" : "default"}
              className="w-full"
            >
              Use Password Instead
            </Button>
          </div>
        </div>
      )}

      {step === 'success' && (
        <div className="text-center">
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <Icon name="CheckCircle" size={24} className="text-green-600 mx-auto mb-2" />
            <p className="text-sm text-green-800 font-medium">
              Authentication Successful!
            </p>
          </div>
        </div>
      )}

      {step === 'error' && error && (
        <div className="text-center space-y-4">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <Icon name="XCircle" size={20} className="text-red-600 mx-auto mb-2" />
            <p className="text-sm text-red-800 mb-2">{error}</p>
            <p className="text-xs text-red-600">
              {enhancedBiometricAuth.getErrorSuggestion({ message: error })}
            </p>
          </div>
          
          <div className="space-y-2">
            <Button
              onClick={isRegistered ? handleAuthenticate : handleRegister}
              variant="outline"
              size={deviceInfo.isMobile ? "sm" : "default"}
              className="w-full"
            >
              Try Again
            </Button>
            
            <Button
              onClick={onFallback}
              variant="ghost"
              size={deviceInfo.isMobile ? "sm" : "default"}
              className="w-full"
            >
              Use Password Instead
            </Button>
          </div>
        </div>
      )}

      {/* Device info display (optional) */}
      {deviceInfo && (
        <div className="mt-4 pt-4 border-t border-muted text-center">
          <div className="flex items-center justify-center space-x-4 text-xs text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Icon name={deviceInfo.isMobile ? "Smartphone" : "Monitor"} size={12} />
              <span>{deviceInfo.type}</span>
            </div>
            {deviceInfo.hasTouch && (
              <div className="flex items-center space-x-1">
                <Icon name="Hand" size={12} />
                <span>Touch</span>
              </div>
            )}
            <div className="flex items-center space-x-1">
              <Icon name="Shield" size={12} />
              <span>Secure</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResponsiveBiometricAuth;
