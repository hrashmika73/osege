import React from 'react';
import useBuilderContent from '../hooks/useBuilderContent';
import LoadingSpinner from './ui/LoadingSpinner';

/**
 * Component that renders Builder.io content with real-time updates
 * Equivalent to PHP's always-fresh content rendering
 */
const BuilderContentRenderer = ({ 
  modelName, 
  fallbackContent = null,
  className = '',
  enableRealTime = true,
  cacheBust = true 
}) => {
  const { 
    content, 
    loading, 
    error, 
    forceRefresh, 
    isStale,
    lastUpdated 
  } = useBuilderContent(modelName, {
    cacheBust,
    realTimeUpdates: enableRealTime,
    autoRefresh: true,
    refreshInterval: 30000 // 30 seconds
  });

  // Show loading state
  if (loading && !content) {
    return (
      <div className={`builder-content-loading ${className}`}>
        <LoadingSpinner />
        <p className="text-sm text-gray-500 mt-2">Loading content...</p>
      </div>
    );
  }

  // Show error state with fallback
  if (error && !content) {
    return (
      <div className={`builder-content-error ${className}`}>
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <h3 className="text-red-800 font-medium">Content Loading Error</h3>
          <p className="text-red-600 text-sm mt-1">{error}</p>
          <button 
            onClick={forceRefresh}
            className="mt-2 px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700"
          >
            Retry
          </button>
        </div>
        {fallbackContent && (
          <div className="mt-4">
            {fallbackContent}
          </div>
        )}
      </div>
    );
  }

  // No content available
  if (!content || !content.results || content.results.length === 0) {
    return fallbackContent || (
      <div className={`builder-content-empty ${className}`}>
        <p className="text-gray-500">No content available</p>
      </div>
    );
  }

  const pageData = content.results[0];

  return (
    <div className={`builder-content ${className}`}>
      {/* Development info (remove in production) */}
      {import.meta.env.VITE_DEBUG_MODE === 'true' && (
        <div className="bg-blue-50 border border-blue-200 rounded p-2 mb-4 text-xs">
          <div className="flex justify-between items-center">
            <span>
              Model: {modelName} | 
              Last Updated: {lastUpdated?.toLocaleTimeString()} |
              {isStale && <span className="text-orange-600"> (Stale)</span>}
            </span>
            <button 
              onClick={forceRefresh}
              className="px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              Force Refresh
            </button>
          </div>
        </div>
      )}

      {/* Render Builder.io content */}
      <BuilderContentBlocks data={pageData.data} />
    </div>
  );
};

/**
 * Renders Builder.io content blocks
 */
const BuilderContentBlocks = ({ data }) => {
  if (!data || !data.blocks) return null;

  return (
    <div className="builder-blocks">
      {data.blocks.map((block, index) => (
        <BuilderBlock key={block.id || index} block={block} />
      ))}
    </div>
  );
};

/**
 * Renders individual Builder.io blocks
 */
const BuilderBlock = ({ block }) => {
  const { component, properties = {}, children = [] } = block;

  // Handle different component types
  switch (component?.name) {
    case 'Text':
      return (
        <div 
          className={properties.className || ''}
          style={properties.style}
          dangerouslySetInnerHTML={{ __html: properties.text || '' }}
        />
      );

    case 'Image':
      return (
        <img
          src={properties.image}
          alt={properties.altText || ''}
          className={properties.className || ''}
          style={properties.style}
        />
      );

    case 'Button':
      return (
        <button
          className={properties.className || 'btn btn-primary'}
          style={properties.style}
          onClick={() => properties.link && (window.location.href = properties.link)}
        >
          {properties.text || 'Button'}
        </button>
      );

    case 'Columns':
      return (
        <div className={`flex ${properties.className || ''}`} style={properties.style}>
          {children.map((child, index) => (
            <div key={index} className="flex-1">
              <BuilderBlock block={child} />
            </div>
          ))}
        </div>
      );

    default:
      // Generic container for unknown components
      return (
        <div className={properties.className || ''} style={properties.style}>
          {children.map((child, index) => (
            <BuilderBlock key={index} block={child} />
          ))}
          {properties.text && (
            <div dangerouslySetInnerHTML={{ __html: properties.text }} />
          )}
        </div>
      );
  }
};

/**
 * HOC for pages that need Builder.io content
 */
export const withBuilderContent = (WrappedComponent, modelName, options = {}) => {
  return function BuilderWrappedComponent(props) {
    const builderData = useBuilderContent(modelName, options);
    
    return (
      <WrappedComponent 
        {...props} 
        builderContent={builderData} 
      />
    );
  };
};

export default BuilderContentRenderer;
