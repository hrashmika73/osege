import React, { useState, useEffect } from 'react';
import Icon from './AppIcon';
import Button from './ui/Button';

const GlobalNotificationSystem = () => {
  const [notifications, setNotifications] = useState([]);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Load existing global notifications
    const loadNotifications = () => {
      const saved = localStorage.getItem('global_notifications');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Only show persistent notifications from last 24 hours
        const recent = parsed.filter(notif => {
          const age = Date.now() - new Date(notif.timestamp).getTime();
          return age < 24 * 60 * 60 * 1000 && notif.persistent;
        });
        setNotifications(recent);
        if (recent.length > 0) setIsVisible(true);
      }
    };

    loadNotifications();

    // Listen for new global notifications
    const handleGlobalNotification = (event) => {
      const notification = event.detail;
      setNotifications(prev => [notification, ...prev]);
      setIsVisible(true);

      // Auto-hide non-persistent notifications after 10 seconds
      if (!notification.persistent) {
        setTimeout(() => {
          setNotifications(prev => prev.filter(n => n.id !== notification.id));
        }, 10000);
      }
    };

    // Listen for storage changes from other tabs
    const handleStorageChange = () => {
      loadNotifications();
    };

    window.addEventListener('globalNotification', handleGlobalNotification);
    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('globalNotification', handleGlobalNotification);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'success': return 'CheckCircle';
      case 'warning': return 'AlertTriangle';
      case 'error': return 'XCircle';
      case 'info': 
      default: return 'Info';
    }
  };

  const getNotificationColor = (type) => {
    switch (type) {
      case 'success': return 'border-success bg-success/10 text-success';
      case 'warning': return 'border-warning bg-warning/10 text-warning';
      case 'error': return 'border-destructive bg-destructive/10 text-destructive';
      case 'info':
      default: return 'border-primary bg-primary/10 text-primary';
    }
  };

  const dismissNotification = (id) => {
    setNotifications(prev => {
      const updated = prev.filter(n => n.id !== id);
      
      // Update localStorage
      const saved = JSON.parse(localStorage.getItem('global_notifications') || '[]');
      const filteredSaved = saved.filter(n => n.id !== id);
      localStorage.setItem('global_notifications', JSON.stringify(filteredSaved));
      
      return updated;
    });

    if (notifications.length <= 1) {
      setIsVisible(false);
    }
  };

  const dismissAll = () => {
    setNotifications([]);
    setIsVisible(false);
    
    // Remove all notifications from localStorage
    localStorage.removeItem('global_notifications');
  };

  if (!isVisible || notifications.length === 0) {
    return null;
  }

  return (
    <div className="fixed top-4 right-4 z-50 max-w-md space-y-2">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`border-l-4 rounded-lg p-4 shadow-lg backdrop-blur-sm bg-background/95 ${getNotificationColor(notification.type)}`}
        >
          <div className="flex items-start space-x-3">
            <Icon name={getNotificationIcon(notification.type)} size={20} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <p className="text-sm font-medium text-foreground">
                  {notification.from || 'System'}
                </p>
                <button
                  onClick={() => dismissNotification(notification.id)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <Icon name="X" size={16} />
                </button>
              </div>
              <p className="text-sm text-foreground">{notification.message}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {new Date(notification.timestamp).toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      ))}
      
      {notifications.length > 1 && (
        <div className="text-center">
          <Button
            variant="outline"
            size="sm"
            onClick={dismissAll}
            className="bg-background/95 backdrop-blur-sm"
          >
            <Icon name="X" size={14} className="mr-1" />
            Dismiss All ({notifications.length})
          </Button>
        </div>
      )}
    </div>
  );
};

export default GlobalNotificationSystem;
