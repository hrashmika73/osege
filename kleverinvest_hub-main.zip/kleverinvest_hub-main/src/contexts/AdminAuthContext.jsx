import React, { createContext, useContext, useState, useEffect } from 'react';
import { sessionManager, generateJWT, verifyJWT } from '../utils/auth';
import { securityHeaders, generateDeviceFingerprint } from '../utils/adminSecurity';
import { clearAllAdminAuth, isAdminLoggedIn } from '../utils/adminAuthReset';
import { adminAuthAPI, testBackendConnection } from '../services/adminApiService';
// import { pageStatePreservation } from '../utils/pageStatePreservation'; // Temporarily disabled

const AdminAuthContext = createContext();

export const useAdminAuth = () => {
  const context = useContext(AdminAuthContext);
  if (!context) {
    throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  }
  return context;
};

export const AdminAuthProvider = ({ children }) => {
  const [admin, setAdmin] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState(null);
  const [sessionInfo, setSessionInfo] = useState(null);
  const [securityLevel, setSecurityLevel] = useState('unknown');

  // Rate limiting for brute force protection
  const MAX_LOGIN_ATTEMPTS = 3; // Stricter for admin
  const LOCKOUT_DURATION = 30 * 60 * 1000; // 30 minutes for admin

  useEffect(() => {
    const checkAdminAuth = async () => {
      try {
        // Setup security headers
        securityHeaders.setupHeaders();

        // Check if admin authentication exists and validate it
        const adminToken = localStorage.getItem('adminToken');
        const adminData = localStorage.getItem('adminData');

        if (!adminToken || !adminData) {
          console.log('No admin authentication data found - login required');
          setAdmin(null);
          setSessionInfo(null);
          setSecurityLevel('unknown');
          setLoading(false);
          return;
        }

        // We already have adminToken and adminData from above
        const attempts = localStorage.getItem('adminLoginAttempts');
        const lockout = localStorage.getItem('adminLockoutUntil');
        const sessionData = localStorage.getItem('adminSession');

        if (lockout) {
          const lockoutTime = parseInt(lockout);
          if (Date.now() < lockoutTime) {
            setLockoutUntil(lockoutTime);
          } else {
            localStorage.removeItem('adminLockoutUntil');
            localStorage.removeItem('adminLoginAttempts');
          }
        }

        if (attempts) {
          setLoginAttempts(parseInt(attempts));
        }

        // Enhanced token verification
        if (adminToken && adminData) {
          const parsedAdminData = JSON.parse(adminData);

          // Verify JWT token if it's a JWT
          if (adminToken.includes('.')) {
            const tokenPayload = verifyJWT(adminToken);
            if (!tokenPayload) {
              console.warn('Invalid or expired admin JWT token');
              clearAdminAuth();
              return;
            }
          }

          // Verify admin role and session
          if (parsedAdminData.role === 'admin') {
            const adminWithToken = {
              ...parsedAdminData,
              token: adminToken
            };

            setAdmin(adminWithToken);

            // Load session info if available
            if (sessionData) {
              try {
                const session = JSON.parse(sessionData);
                setSessionInfo(session);
                setSecurityLevel(session.securityLevel || 'medium');
              } catch (sessionError) {
                console.warn('Invalid session data:', sessionError);
              }
            }

            // Update activity timestamp
            updateAdminActivity(adminWithToken);
          } else {
            clearAdminAuth();
          }
        }
      } catch (error) {
        console.error('Admin auth check error:', error);
        clearAdminAuth();
      } finally {
        setLoading(false);
      }
    };

    checkAdminAuth();
  }, []);

  const adminLogin = async (credentials) => {
    // Check if account is locked
    if (lockoutUntil && Date.now() < lockoutUntil) {
      const remainingTime = Math.ceil((lockoutUntil - Date.now()) / 1000 / 60);
      throw new Error(`Admin account locked. Try again in ${remainingTime} minutes.`);
    }

    try {
      // Generate device fingerprint if not provided
      let deviceFingerprint = credentials.deviceFingerprint;
      if (!deviceFingerprint) {
        deviceFingerprint = await generateDeviceFingerprint();
      }

      // Use backend admin login with automatic fallback to mock
      const response = await adminAuthAPI.login(credentials);

      if (response.success) {
        const admin = response.data.admin;
        const adminData = {
          id: admin.id,
          name: admin.name,
          email: admin.email,
          role: 'admin',
          username: admin.username,
          permissions: admin.permissions || ['full_access'],
          lastLogin: new Date().toISOString(),
          securityLevel: credentials.securityLevel || deviceFingerprint?.securityLevel || 'medium',
          mockMode: response.mockMode || false,
          biometricEnabled: credentials.biometricAuth || false
        };

        // Create enhanced JWT token with security info
        const tokenPayload = {
          ...adminData,
          deviceId: deviceFingerprint?.id,
          securityLevel: adminData.securityLevel,
          loginMethod: credentials.biometricAuth ? 'biometric' : 'password',
          sessionId: generateSessionId()
        };

        // Use backend token if available, otherwise generate JWT
        const jwtToken = response.data.token || generateJWT(tokenPayload, '8h');

        // Create session info
        const sessionInfo = {
          sessionId: tokenPayload.sessionId,
          deviceId: deviceFingerprint?.id,
          deviceDetails: deviceFingerprint?.details,
          securityLevel: adminData.securityLevel,
          loginTime: new Date().toISOString(),
          lastActivity: new Date().toISOString(),
          loginMethod: tokenPayload.loginMethod,
          ipAddress: '127.0.0.1', // In production, get from server
          userAgent: navigator.userAgent,
          expiresAt: new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString() // 8 hours
        };

        // Store admin auth data separately with enhanced security
        localStorage.setItem('adminToken', jwtToken);
        localStorage.setItem('adminData', JSON.stringify(adminData));
        localStorage.setItem('adminSession', JSON.stringify(sessionInfo));

        // CRITICAL: Clear any user session to ensure complete separation
        localStorage.removeItem('userToken');
        localStorage.removeItem('userData');
        localStorage.removeItem('userLoginAttempts');
        localStorage.removeItem('userLockoutUntil');
        localStorage.removeItem('userSession');

        // Clear failed attempts
        localStorage.removeItem('adminLoginAttempts');
        localStorage.removeItem('adminLockoutUntil');
        setLoginAttempts(0);
        setLockoutUntil(null);

        setAdmin({ ...adminData, token: jwtToken });
        setSessionInfo(sessionInfo);
        setSecurityLevel(adminData.securityLevel);

        // Store current page state for preservation on reload
        // pageStatePreservation.autoStorePage(); // Temporarily disabled

        // Clear any existing demo data for clean start
        try {
          const { clearAllDemoData } = await import('../utils/clearDemoData');
          clearAllDemoData();
          console.log('Demo data cleared for clean admin session');
        } catch (error) {
          console.warn('Could not clear demo data:', error);
        }

        // Log success message with security info
        console.log('Admin login successful:', {
          mockMode: response.mockMode,
          securityLevel: adminData.securityLevel,
          deviceId: deviceFingerprint?.id?.substring(0, 8),
          biometric: credentials.biometricAuth || false
        });

        return { success: true, sessionInfo };
      } else {
        throw new Error(response.message || 'Admin login failed');
      }
    } catch (error) {
      // Increment failed attempts only for actual auth failures, not network errors
      if (!error.message.includes('Network') && !error.message.includes('ECONNREFUSED')) {
        const newAttempts = loginAttempts + 1;
        setLoginAttempts(newAttempts);
        localStorage.setItem('adminLoginAttempts', newAttempts.toString());

        // Check if should lockout
        if (newAttempts >= MAX_LOGIN_ATTEMPTS) {
          const lockoutTime = Date.now() + LOCKOUT_DURATION;
          setLockoutUntil(lockoutTime);
          localStorage.setItem('adminLockoutUntil', lockoutTime.toString());
        }
      }

      throw error;
    }
  };

  // Update admin activity
  const updateAdminActivity = (adminData) => {
    try {
      const sessionData = localStorage.getItem('adminSession');
      if (sessionData) {
        const session = JSON.parse(sessionData);
        session.lastActivity = new Date().toISOString();
        localStorage.setItem('adminSession', JSON.stringify(session));
        setSessionInfo(session);
      }
    } catch (error) {
      console.warn('Failed to update admin activity:', error);
    }
  };

  // Generate session ID
  const generateSessionId = () => {
    return `admin_session_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
  };

  const adminLogout = () => {
    // Log session end
    if (sessionInfo) {
      console.log('Admin session ended:', {
        sessionId: sessionInfo.sessionId,
        duration: new Date() - new Date(sessionInfo.loginTime)
      });
    }

    clearAdminAuth();
    setAdmin(null);
    setSessionInfo(null);
    setSecurityLevel('unknown');
  };

  const clearAdminAuth = () => {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminData');
    localStorage.removeItem('adminSession');
  };

  const hasAdminRole = () => {
    return admin && admin.role === 'admin';
  };

  const hasPermission = (permission) => {
    if (!admin) return false;
    return admin.permissions?.includes(permission) || admin.permissions?.includes('full_access');
  };

  const value = {
    admin,
    loading,
    adminLogin,
    adminLogout,
    hasAdminRole,
    hasPermission,
    loginAttempts,
    lockoutUntil,
    sessionInfo,
    securityLevel,
    updateAdminActivity,
    isAdminAuthenticated: !!admin,
    isHighSecurity: securityLevel === 'high'
  };

  return (
    <AdminAuthContext.Provider value={value}>
      {children}
    </AdminAuthContext.Provider>
  );
};

// Mock admin login with better error handling
const simulateAdminLogin = async (credentials) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Admin credentials - more restrictive
      const adminUsers = [
        {
          id: 'admin_001',
          email: 'admin@kleverinvest.com',
          username: 'admin',
          password: 'Admin@123!',
          name: 'System Administrator',
          role: 'admin',
          permissions: ['full_access']
        },
        {
          id: 'admin_002',
          email: 'superadmin@kleverinvest.com',
          username: 'superadmin',
          password: 'SuperAdmin@456!',
          name: 'Super Administrator',
          role: 'admin',
          permissions: ['full_access', 'system_control']
        }
      ];

      // Strict credential validation - must match exactly
      let admin = null;

      // Check for exact matches only - no empty or undefined values allowed
      const credEmail = credentials.email && credentials.email.trim();
      const credUsername = credentials.username && credentials.username.trim();
      const credPassword = credentials.password && credentials.password.trim();

      if (!credPassword) {
        console.warn('Admin login attempt with empty password');
        admin = null;
      } else if (credEmail || credUsername) {
        admin = adminUsers.find(u => {
          const emailMatch = credEmail && u.email === credEmail;
          const usernameMatch = credUsername && u.username === credUsername;
          const passwordMatch = u.password === credPassword;

          return (emailMatch || usernameMatch) && passwordMatch;
        });
      }

      if (admin) {
        console.log('Admin login successful for:', admin.email);
        resolve({
          success: true,
          token: `admin_token_${admin.id}_${Date.now()}`,
          admin: { ...admin, password: undefined },
          mockMode: true
        });
      } else {
        console.warn('Admin login failed - invalid credentials provided:', {
          email: credEmail ? '***' : 'empty',
          username: credUsername ? '***' : 'empty',
          password: credPassword ? '***' : 'empty'
        });
        resolve({
          success: false,
          message: 'Invalid admin credentials. Please check your username/email and password.'
        });
      }
    }, 1000); // Reduced delay for better UX
  });
};
