import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState(null);

  // Rate limiting for brute force protection
  const MAX_LOGIN_ATTEMPTS = 5;
  const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes

  useEffect(() => {
    const checkAuth = () => {
      try {
        const token = localStorage.getItem('userToken');
        const userData = localStorage.getItem('userData');
        const userRole = localStorage.getItem('userRole');
        const attempts = localStorage.getItem('loginAttempts');
        const lockout = localStorage.getItem('lockoutUntil');

        if (lockout) {
          const lockoutTime = parseInt(lockout);
          if (Date.now() < lockoutTime) {
            setLockoutUntil(lockoutTime);
          } else {
            localStorage.removeItem('lockoutUntil');
            localStorage.removeItem('loginAttempts');
          }
        }

        if (attempts) {
          setLoginAttempts(parseInt(attempts));
        }

        if (token && userData && userRole) {
          setUser({
            ...JSON.parse(userData),
            role: userRole,
            token: token
          });
        }
      } catch (error) {
        console.error('Auth check error:', error);
        clearAuth();
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (credentials) => {
    // Check if account is locked
    if (lockoutUntil && Date.now() < lockoutUntil) {
      const remainingTime = Math.ceil((lockoutUntil - Date.now()) / 1000 / 60);
      throw new Error(`Account locked. Try again in ${remainingTime} minutes.`);
    }

    try {
      // Simulate API call - replace with actual authentication
      const response = await simulateLogin(credentials);
      
      if (response.success) {
        const userData = {
          id: response.user.id,
          name: response.user.name,
          email: response.user.email,
          role: response.user.role,
          verified: response.user.verified,
          memberSince: response.user.memberSince,
          balance: response.user.balance || 0,
          wallet: response.user.wallet || null
        };

        // Store auth data
        localStorage.setItem('userToken', response.token);
        localStorage.setItem('userData', JSON.stringify(userData));
        localStorage.setItem('userRole', response.user.role);
        
        // Clear failed attempts
        localStorage.removeItem('loginAttempts');
        localStorage.removeItem('lockoutUntil');
        setLoginAttempts(0);
        setLockoutUntil(null);

        setUser({ ...userData, token: response.token });
        return { success: true };
      } else {
        throw new Error(response.message || 'Login failed');
      }
    } catch (error) {
      // Increment failed attempts
      const newAttempts = loginAttempts + 1;
      setLoginAttempts(newAttempts);
      localStorage.setItem('loginAttempts', newAttempts.toString());

      // Check if should lockout
      if (newAttempts >= MAX_LOGIN_ATTEMPTS) {
        const lockoutTime = Date.now() + LOCKOUT_DURATION;
        setLockoutUntil(lockoutTime);
        localStorage.setItem('lockoutUntil', lockoutTime.toString());
      }

      throw error;
    }
  };

  const logout = () => {
    clearAuth();
    setUser(null);
  };

  const clearAuth = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userData');
    localStorage.removeItem('userRole');
  };

  const hasRole = (requiredRole) => {
    if (!user) return false;
    if (requiredRole === 'admin') return user.role === 'admin';
    if (requiredRole === 'user') return user.role === 'user' || user.role === 'admin';
    return true;
  };

  const loginAdmin = async (credentials) => {
    try {
      // Admin login logic (same as regular login but can add admin-specific validation)
      const result = await login(credentials);
      return result;
    } catch (error) {
      return {
        success: false,
        error: error.message || 'Login failed. Please try again.'
      };
    }
  };

  const updateUser = (updatedData) => {
    const newUserData = { ...user, ...updatedData };
    setUser(newUserData);
    localStorage.setItem('userData', JSON.stringify(newUserData));
  };

  const value = {
    user,
    loading,
    login,
    loginAdmin,
    logout,
    hasRole,
    updateUser,
    loginAttempts,
    lockoutUntil,
    isAuthenticated: !!user
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// Simulate login API call - replace with actual backend integration
const simulateLogin = async (credentials) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Default users
      const users = [
        {
          id: 1,
          email: 'user@kleverinvest.com',
          password: 'password123',
          name: 'Test User',
          role: 'user',
          verified: true,
          memberSince: new Date().toISOString().split('T')[0],
          balance: 0,
          wallet: null
        },
        {
          id: 2,
          email: 'admin@kleverinvest.com',
          password: 'admin123',
          name: 'Admin User',
          role: 'admin',
          verified: true,
          memberSince: new Date().toISOString().split('T')[0],
          balance: 0,
          wallet: null
        }
      ];

      const user = users.find(u => 
        u.email === credentials.email && u.password === credentials.password
      );

      if (user) {
        resolve({
          success: true,
          token: `token_${user.id}_${Date.now()}`,
          user: { ...user, password: undefined }
        });
      } else {
        resolve({
          success: false,
          message: 'Invalid email or password'
        });
      }
    }, 1000);
  });
};
