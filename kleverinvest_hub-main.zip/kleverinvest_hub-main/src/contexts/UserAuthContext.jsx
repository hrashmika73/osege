import React, { createContext, useContext, useState, useEffect } from 'react';

const UserAuthContext = createContext();

export const useUserAuth = () => {
  const context = useContext(UserAuthContext);
  if (!context) {
    throw new Error('useUserAuth must be used within a UserAuthProvider');
  }
  return context;
};

export const UserAuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState(null);

  // Rate limiting for brute force protection
  const MAX_LOGIN_ATTEMPTS = 5;
  const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes

  useEffect(() => {
    const checkUserAuth = async () => {
      try {
        // Clean up any old auth data from legacy AuthContext that might interfere
        localStorage.removeItem('userRole'); // This was from the old AuthContext
        localStorage.removeItem('token');    // This was from the old AuthContext

        // Initialize test users if they don't exist to prevent 403 errors
        try {
          const { initializeTestUsers } = await import('../utils/initTestUser');
          initializeTestUsers();
        } catch (error) {
          console.warn('Could not initialize test users:', error);
        }

        const userToken = localStorage.getItem('userToken');
        const userData = localStorage.getItem('userData');
        const attempts = localStorage.getItem('userLoginAttempts');
        const lockout = localStorage.getItem('userLockoutUntil');

        if (lockout) {
          const lockoutTime = parseInt(lockout);
          if (Date.now() < lockoutTime) {
            setLockoutUntil(lockoutTime);
          } else {
            localStorage.removeItem('userLockoutUntil');
            localStorage.removeItem('userLoginAttempts');
          }
        }

        if (attempts) {
          setLoginAttempts(parseInt(attempts));
        }

        if (userToken && userData) {
          const parsedUserData = JSON.parse(userData);
          // Verify user role (not admin)
          if (parsedUserData.role === 'user') {
            setUser({
              ...parsedUserData,
              token: userToken
            });
          } else {
            clearUserAuth();
          }
        }
      } catch (error) {
        console.error('User auth check error:', error);
        clearUserAuth();
      } finally {
        setLoading(false);
      }
    };

    checkUserAuth();
  }, []);

  const userLogin = async (credentials) => {
    // Check if account is locked
    if (lockoutUntil && Date.now() < lockoutUntil) {
      const remainingTime = Math.ceil((lockoutUntil - Date.now()) / 1000 / 60);
      throw new Error(`Account locked. Try again in ${remainingTime} minutes.`);
    }

    try {
      // Simulate user login
      const response = await simulateUserLogin(credentials);
      
      if (response.success) {
        const userData = {
          id: response.user.id,
          name: response.user.name,
          email: response.user.email,
          role: 'user',
          verified: response.user.verified,
          memberSince: response.user.memberSince,
          balance: response.user.balance || 0,
          wallet: response.user.wallet || null,
          referralCode: response.user.referralCode,
          lastLogin: new Date().toISOString()
        };

        // Store user auth data separately
        localStorage.setItem('userToken', response.token);
        localStorage.setItem('userData', JSON.stringify(userData));

        // CRITICAL: Clear any admin session to ensure complete separation
        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminData');
        localStorage.removeItem('adminLoginAttempts');
        localStorage.removeItem('adminLockoutUntil');

        // Clear failed attempts
        localStorage.removeItem('userLoginAttempts');
        localStorage.removeItem('userLockoutUntil');
        setLoginAttempts(0);
        setLockoutUntil(null);

        setUser({ ...userData, token: response.token });
        return { success: true };
      } else {
        throw new Error(response.message || 'Login failed');
      }
    } catch (error) {
      // Increment failed attempts
      const newAttempts = loginAttempts + 1;
      setLoginAttempts(newAttempts);
      localStorage.setItem('userLoginAttempts', newAttempts.toString());

      // Check if should lockout
      if (newAttempts >= MAX_LOGIN_ATTEMPTS) {
        const lockoutTime = Date.now() + LOCKOUT_DURATION;
        setLockoutUntil(lockoutTime);
        localStorage.setItem('userLockoutUntil', lockoutTime.toString());
      }

      throw error;
    }
  };

  const userLogout = () => {
    clearUserAuth();
    setUser(null);
  };

  const clearUserAuth = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userData');
  };

  const hasUserRole = () => {
    return user && user.role === 'user';
  };

  const updateUser = (updatedData) => {
    const newUserData = { ...user, ...updatedData };
    setUser(newUserData);
    localStorage.setItem('userData', JSON.stringify(newUserData));
  };

  const userRegister = async (userData) => {
    try {
      // Create new user
      const newUser = {
        id: 'user_' + Date.now(),
        email: userData.email,
        name: userData.name,
        role: 'user',
        verified: false,
        memberSince: new Date().toISOString().split('T')[0],
        balance: 0,
        wallet: null,
        referralCode: 'REF' + Date.now().toString().slice(-6),
        kycStatus: 'pending_documents'
      };

      // Store user session
      localStorage.setItem('userToken', 'temp_token_' + Date.now());
      localStorage.setItem('userData', JSON.stringify(newUser));

      // Sync with admin user management system
      const adminUsers = JSON.parse(localStorage.getItem('admin_users_data') || '[]');
      const adminUserData = {
        id: parseInt(newUser.id.replace('user_', '')),
        userId: newUser.id,
        username: newUser.email.split('@')[0],
        email: newUser.email,
        fullName: newUser.name,
        status: 'active',
        lastActive: new Date().toISOString(),
        registrationDate: new Date().toISOString(),
        totalInvestments: 0,
        balance: 0,
        kycStatus: 'pending_documents',
        location: 'Unknown',
        riskLevel: 'low'
      };
      adminUsers.push(adminUserData);
      localStorage.setItem('admin_users_data', JSON.stringify(adminUsers));

      // Create KYC request for admin
      const kycRequests = JSON.parse(localStorage.getItem('admin_pending_kyc') || '[]');
      const kycRequest = {
        id: Date.now(),
        userId: newUser.id,
        username: newUser.email.split('@')[0],
        email: newUser.email,
        fullName: newUser.name,
        submissionDate: new Date().toISOString(),
        documentType: 'pending',
        documentNumber: 'PENDING',
        country: 'Unknown',
        phoneNumber: 'Not provided',
        address: 'Not provided',
        priority: 'medium',
        investmentAmount: 0,
        riskLevel: 'low',
        documentsSubmitted: [],
        verificationStatus: 'pending',
        notes: 'New user registration - awaiting document submission'
      };
      kycRequests.push(kycRequest);
      localStorage.setItem('admin_pending_kyc', JSON.stringify(kycRequests));

      setUser(newUser);
      return { success: true, user: newUser };
    } catch (error) {
      throw error;
    }
  };

  const value = {
    user,
    loading,
    userLogin,
    userLogout,
    userRegister,
    hasUserRole,
    updateUser,
    loginAttempts,
    lockoutUntil,
    isUserAuthenticated: !!user
  };

  return (
    <UserAuthContext.Provider value={value}>
      {children}
    </UserAuthContext.Provider>
  );
};

// Simulate user login API call - replace with actual backend integration
const simulateUserLogin = async (credentials) => {
  return new Promise(async (resolve) => {
    setTimeout(async () => {
      try {
        // Load registered users from centralized user system
        const userDataManager = await import('../utils/userDataManager');
        const { getAllUsers } = userDataManager;
        const allUsers = getAllUsers();

        // Default test users for backward compatibility
        const defaultUsers = [
          {
            id: 'user_001',
            email: 'user@kleverinvest.com',
            password: 'password123',
            name: 'Test User',
            fullName: 'Test User',
            role: 'user',
            verified: true,
            memberSince: new Date().toISOString().split('T')[0],
            balance: 5000,
            wallet: null,
            referralCode: 'REF000001',
            kycStatus: 'verified'
          }
        ];

        // Convert admin users to login format
        const registeredUsers = allUsers.map(adminUser => ({
          id: adminUser.userId || adminUser.id,
          email: adminUser.email,
          password: adminUser.password || 'password123', // Use stored password or default
          name: adminUser.fullName,
          fullName: adminUser.fullName,
          firstName: adminUser.firstName,
          lastName: adminUser.lastName,
          phone: adminUser.phone,
          address: adminUser.address,
          dateOfBirth: adminUser.dateOfBirth,
          role: 'user',
          verified: adminUser.kycStatus === 'verified',
          kycStatus: adminUser.kycStatus || 'pending',
          memberSince: adminUser.registrationDate?.split('T')[0] || new Date().toISOString().split('T')[0],
          balance: adminUser.balance || 0,
          wallet: null,
          referralCode: adminUser.referralCode || ('REF' + Date.now().toString().slice(-6))
        }));

        // Combine default and registered users
        const combinedUsers = [...defaultUsers, ...registeredUsers];

        const user = combinedUsers.find(u =>
          u.email === credentials.email && u.password === credentials.password
        );

        if (user) {
          resolve({
            success: true,
            token: `user_token_${user.id}_${Date.now()}`,
            user: { ...user, password: undefined } // Remove password from response
          });
        } else {
          resolve({
            success: false,
            message: 'Invalid email or password'
          });
        }
      } catch (error) {
        console.error('Login error:', error);

        // Fallback to basic login without userDataManager
        const defaultUsers = [
          {
            id: 'user_001',
            email: 'user@kleverinvest.com',
            password: 'password123',
            name: 'Test User',
            fullName: 'Test User',
            role: 'user',
            verified: true,
            memberSince: new Date().toISOString().split('T')[0],
            balance: 5000,
            wallet: null,
            referralCode: 'REF000001',
            kycStatus: 'verified'
          }
        ];

        const user = defaultUsers.find(u =>
          u.email === credentials.email && u.password === credentials.password
        );

        if (user) {
          resolve({
            success: true,
            token: `user_token_${user.id}_${Date.now()}`,
            user: { ...user, password: undefined }
          });
        } else {
          resolve({
            success: false,
            message: 'Login system error. Please try again.'
          });
        }
      }
    }, 1000);
  });
};
